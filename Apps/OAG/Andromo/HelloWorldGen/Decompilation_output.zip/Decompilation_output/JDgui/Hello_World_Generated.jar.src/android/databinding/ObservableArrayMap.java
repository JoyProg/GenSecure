package android.databinding;

import android.support.v4.util.ArrayMap;
import java.util.Collection;
import java.util.Iterator;

public class ObservableArrayMap<K, V> extends ArrayMap<K, V> implements ObservableMap<K, V> {
  private transient MapChangeRegistry mListeners;
  
  private void notifyChange(Object paramObject) {
    if (this.mListeners != null)
      this.mListeners.notifyCallbacks(this, 0, paramObject); 
  }
  
  public void addOnMapChangedCallback(ObservableMap.OnMapChangedCallback<? extends ObservableMap<K, V>, K, V> paramOnMapChangedCallback) {
    if (this.mListeners == null)
      this.mListeners = new MapChangeRegistry(); 
    this.mListeners.add(paramOnMapChangedCallback);
  }
  
  public void clear() {
    if (!isEmpty()) {
      super.clear();
      notifyChange((Object)null);
    } 
  }
  
  public V put(K paramK, V paramV) {
    super.put(paramK, paramV);
    notifyChange(paramK);
    return paramV;
  }
  
  public boolean removeAll(Collection<?> paramCollection) {
    Iterator<?> iterator = paramCollection.iterator();
    boolean bool = false;
    while (iterator.hasNext()) {
      int i = indexOfKey(iterator.next());
      if (i >= 0) {
        bool = true;
        removeAt(i);
      } 
    } 
    return bool;
  }
  
  public V removeAt(int paramInt) {
    Object object1 = keyAt(paramInt);
    Object object2 = super.removeAt(paramInt);
    if (object2 != null)
      notifyChange(object1); 
    return (V)object2;
  }
  
  public void removeOnMapChangedCallback(ObservableMap.OnMapChangedCallback<? extends ObservableMap<K, V>, K, V> paramOnMapChangedCallback) {
    if (this.mListeners != null)
      this.mListeners.remove(paramOnMapChangedCallback); 
  }
  
  public boolean retainAll(Collection<?> paramCollection) {
    int i = size() - 1;
    boolean bool = false;
    while (i >= 0) {
      if (!paramCollection.contains(keyAt(i))) {
        removeAt(i);
        bool = true;
      } 
      i--;
    } 
    return bool;
  }
  
  public V setValueAt(int paramInt, V paramV) {
    Object object = keyAt(paramInt);
    paramV = (V)super.setValueAt(paramInt, paramV);
    notifyChange(object);
    return paramV;
  }
}


/* Location:              /Users/amirrshams/UW/Courses/CS858/Project/Apps/App_generator/Hello_World_Generated.jar!/android/databinding/ObservableArrayMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */