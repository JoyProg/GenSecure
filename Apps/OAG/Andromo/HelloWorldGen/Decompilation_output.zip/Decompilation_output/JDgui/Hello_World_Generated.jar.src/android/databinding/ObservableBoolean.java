package android.databinding;

import android.os.Parcel;
import android.os.Parcelable;
import java.io.Serializable;

public class ObservableBoolean extends BaseObservableField implements Parcelable, Serializable {
  public static final Parcelable.Creator<ObservableBoolean> CREATOR = new Parcelable.Creator<ObservableBoolean>() {
      public ObservableBoolean createFromParcel(Parcel param1Parcel) {
        int i = param1Parcel.readInt();
        boolean bool = true;
        if (i != 1)
          bool = false; 
        return new ObservableBoolean(bool);
      }
      
      public ObservableBoolean[] newArray(int param1Int) {
        return new ObservableBoolean[param1Int];
      }
    };
  
  static final long serialVersionUID = 1L;
  
  private boolean mValue;
  
  public ObservableBoolean() {}
  
  public ObservableBoolean(boolean paramBoolean) {
    this.mValue = paramBoolean;
  }
  
  public ObservableBoolean(Observable... paramVarArgs) {
    super(paramVarArgs);
  }
  
  public int describeContents() {
    return 0;
  }
  
  public boolean get() {
    return this.mValue;
  }
  
  public void set(boolean paramBoolean) {
    if (paramBoolean != this.mValue) {
      this.mValue = paramBoolean;
      notifyChange();
    } 
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeInt(this.mValue);
  }
}


/* Location:              /Users/amirrshams/UW/Courses/CS858/Project/Apps/App_generator/Hello_World_Generated.jar!/android/databinding/ObservableBoolean.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */