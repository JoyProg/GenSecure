package android.databinding;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

@Target({ElementType.METHOD})
public @interface BindingConversion {}


/* Location:              /Users/amirrshams/UW/Courses/CS858/Project/Apps/App_generator/Hello_World_Generated.jar!/android/databinding/BindingConversion.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */