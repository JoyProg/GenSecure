package android.databinding;

import android.support.annotation.NonNull;

public class PropertyChangeRegistry extends CallbackRegistry<Observable.OnPropertyChangedCallback, Observable, Void> {
  private static final CallbackRegistry.NotifierCallback<Observable.OnPropertyChangedCallback, Observable, Void> NOTIFIER_CALLBACK = new CallbackRegistry.NotifierCallback<Observable.OnPropertyChangedCallback, Observable, Void>() {
      public void onNotifyCallback(Observable.OnPropertyChangedCallback param1OnPropertyChangedCallback, Observable param1Observable, int param1Int, Void param1Void) {
        param1OnPropertyChangedCallback.onPropertyChanged(param1Observable, param1Int);
      }
    };
  
  public PropertyChangeRegistry() {
    super(NOTIFIER_CALLBACK);
  }
  
  public void notifyChange(@NonNull Observable paramObservable, int paramInt) {
    notifyCallbacks(paramObservable, paramInt, null);
  }
}


/* Location:              /Users/amirrshams/UW/Courses/CS858/Project/Apps/App_generator/Hello_World_Generated.jar!/android/databinding/PropertyChangeRegistry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */