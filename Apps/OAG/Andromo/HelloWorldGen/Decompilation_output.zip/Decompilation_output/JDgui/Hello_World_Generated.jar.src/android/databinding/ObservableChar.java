package android.databinding;

import android.os.Parcel;
import android.os.Parcelable;
import java.io.Serializable;

public class ObservableChar extends BaseObservableField implements Parcelable, Serializable {
  public static final Parcelable.Creator<ObservableChar> CREATOR = new Parcelable.Creator<ObservableChar>() {
      public ObservableChar createFromParcel(Parcel param1Parcel) {
        return new ObservableChar((char)param1Parcel.readInt());
      }
      
      public ObservableChar[] newArray(int param1Int) {
        return new ObservableChar[param1Int];
      }
    };
  
  static final long serialVersionUID = 1L;
  
  private char mValue;
  
  public ObservableChar() {}
  
  public ObservableChar(char paramChar) {
    this.mValue = (char)paramChar;
  }
  
  public ObservableChar(Observable... paramVarArgs) {
    super(paramVarArgs);
  }
  
  public int describeContents() {
    return 0;
  }
  
  public char get() {
    return this.mValue;
  }
  
  public void set(char paramChar) {
    if (paramChar != this.mValue) {
      this.mValue = (char)paramChar;
      notifyChange();
    } 
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeInt(this.mValue);
  }
}


/* Location:              /Users/amirrshams/UW/Courses/CS858/Project/Apps/App_generator/Hello_World_Generated.jar!/android/databinding/ObservableChar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */