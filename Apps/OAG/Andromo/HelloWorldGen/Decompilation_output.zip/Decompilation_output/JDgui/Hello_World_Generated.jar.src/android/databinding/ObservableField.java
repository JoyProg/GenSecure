package android.databinding;

import android.support.annotation.Nullable;
import java.io.Serializable;

public class ObservableField<T> extends BaseObservableField implements Serializable {
  static final long serialVersionUID = 1L;
  
  private T mValue;
  
  public ObservableField() {}
  
  public ObservableField(T paramT) {
    this.mValue = paramT;
  }
  
  public ObservableField(Observable... paramVarArgs) {
    super(paramVarArgs);
  }
  
  @Nullable
  public T get() {
    return this.mValue;
  }
  
  public void set(T paramT) {
    if (paramT != this.mValue) {
      this.mValue = paramT;
      notifyChange();
    } 
  }
}


/* Location:              /Users/amirrshams/UW/Courses/CS858/Project/Apps/App_generator/Hello_World_Generated.jar!/android/databinding/ObservableField.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */