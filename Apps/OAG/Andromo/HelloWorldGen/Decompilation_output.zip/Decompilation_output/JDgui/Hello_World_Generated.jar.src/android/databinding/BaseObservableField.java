package android.databinding;

abstract class BaseObservableField extends BaseObservable {
  public BaseObservableField() {}
  
  public BaseObservableField(Observable... paramVarArgs) {
    if (paramVarArgs != null && paramVarArgs.length != 0) {
      DependencyCallback dependencyCallback = new DependencyCallback();
      for (byte b = 0; b < paramVarArgs.length; b++)
        paramVarArgs[b].addOnPropertyChangedCallback(dependencyCallback); 
    } 
  }
  
  class DependencyCallback extends Observable.OnPropertyChangedCallback {
    public void onPropertyChanged(Observable param1Observable, int param1Int) {
      BaseObservableField.this.notifyChange();
    }
  }
}


/* Location:              /Users/amirrshams/UW/Courses/CS858/Project/Apps/App_generator/Hello_World_Generated.jar!/android/databinding/BaseObservableField.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */