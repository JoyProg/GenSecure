package android.databinding;

import android.support.annotation.NonNull;

public class BaseObservable implements Observable {
  private transient PropertyChangeRegistry mCallbacks;
  
  public void addOnPropertyChangedCallback(@NonNull Observable.OnPropertyChangedCallback paramOnPropertyChangedCallback) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mCallbacks : Landroid/databinding/PropertyChangeRegistry;
    //   6: ifnonnull -> 22
    //   9: new android/databinding/PropertyChangeRegistry
    //   12: astore_2
    //   13: aload_2
    //   14: invokespecial <init> : ()V
    //   17: aload_0
    //   18: aload_2
    //   19: putfield mCallbacks : Landroid/databinding/PropertyChangeRegistry;
    //   22: aload_0
    //   23: monitorexit
    //   24: aload_0
    //   25: getfield mCallbacks : Landroid/databinding/PropertyChangeRegistry;
    //   28: aload_1
    //   29: invokevirtual add : (Ljava/lang/Object;)V
    //   32: return
    //   33: astore_1
    //   34: aload_0
    //   35: monitorexit
    //   36: aload_1
    //   37: athrow
    // Exception table:
    //   from	to	target	type
    //   2	22	33	finally
    //   22	24	33	finally
    //   34	36	33	finally
  }
  
  public void notifyChange() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mCallbacks : Landroid/databinding/PropertyChangeRegistry;
    //   6: ifnonnull -> 12
    //   9: aload_0
    //   10: monitorexit
    //   11: return
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_0
    //   15: getfield mCallbacks : Landroid/databinding/PropertyChangeRegistry;
    //   18: aload_0
    //   19: iconst_0
    //   20: aconst_null
    //   21: invokevirtual notifyCallbacks : (Ljava/lang/Object;ILjava/lang/Object;)V
    //   24: return
    //   25: astore_1
    //   26: aload_0
    //   27: monitorexit
    //   28: aload_1
    //   29: athrow
    // Exception table:
    //   from	to	target	type
    //   2	11	25	finally
    //   12	14	25	finally
    //   26	28	25	finally
  }
  
  public void notifyPropertyChanged(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mCallbacks : Landroid/databinding/PropertyChangeRegistry;
    //   6: ifnonnull -> 12
    //   9: aload_0
    //   10: monitorexit
    //   11: return
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_0
    //   15: getfield mCallbacks : Landroid/databinding/PropertyChangeRegistry;
    //   18: aload_0
    //   19: iload_1
    //   20: aconst_null
    //   21: invokevirtual notifyCallbacks : (Ljava/lang/Object;ILjava/lang/Object;)V
    //   24: return
    //   25: astore_2
    //   26: aload_0
    //   27: monitorexit
    //   28: aload_2
    //   29: athrow
    // Exception table:
    //   from	to	target	type
    //   2	11	25	finally
    //   12	14	25	finally
    //   26	28	25	finally
  }
  
  public void removeOnPropertyChangedCallback(@NonNull Observable.OnPropertyChangedCallback paramOnPropertyChangedCallback) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mCallbacks : Landroid/databinding/PropertyChangeRegistry;
    //   6: ifnonnull -> 12
    //   9: aload_0
    //   10: monitorexit
    //   11: return
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_0
    //   15: getfield mCallbacks : Landroid/databinding/PropertyChangeRegistry;
    //   18: aload_1
    //   19: invokevirtual remove : (Ljava/lang/Object;)V
    //   22: return
    //   23: astore_1
    //   24: aload_0
    //   25: monitorexit
    //   26: aload_1
    //   27: athrow
    // Exception table:
    //   from	to	target	type
    //   2	11	23	finally
    //   12	14	23	finally
    //   24	26	23	finally
  }
}


/* Location:              /Users/amirrshams/UW/Courses/CS858/Project/Apps/App_generator/Hello_World_Generated.jar!/android/databinding/BaseObservable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */