package android.databinding;

import android.support.annotation.NonNull;
import android.support.v4.util.Pools;

public class ListChangeRegistry extends CallbackRegistry<ObservableList.OnListChangedCallback, ObservableList, ListChangeRegistry.ListChanges> {
  private static final int ALL = 0;
  
  private static final int CHANGED = 1;
  
  private static final int INSERTED = 2;
  
  private static final int MOVED = 3;
  
  private static final CallbackRegistry.NotifierCallback<ObservableList.OnListChangedCallback, ObservableList, ListChanges> NOTIFIER_CALLBACK;
  
  private static final int REMOVED = 4;
  
  private static final Pools.SynchronizedPool<ListChanges> sListChanges = new Pools.SynchronizedPool(10);
  
  static {
    NOTIFIER_CALLBACK = new CallbackRegistry.NotifierCallback<ObservableList.OnListChangedCallback, ObservableList, ListChanges>() {
        public void onNotifyCallback(ObservableList.OnListChangedCallback<ObservableList> param1OnListChangedCallback, ObservableList param1ObservableList, int param1Int, ListChangeRegistry.ListChanges param1ListChanges) {
          switch (param1Int) {
            default:
              param1OnListChangedCallback.onChanged(param1ObservableList);
              return;
            case 4:
              param1OnListChangedCallback.onItemRangeRemoved(param1ObservableList, param1ListChanges.start, param1ListChanges.count);
              return;
            case 3:
              param1OnListChangedCallback.onItemRangeMoved(param1ObservableList, param1ListChanges.start, param1ListChanges.to, param1ListChanges.count);
              return;
            case 2:
              param1OnListChangedCallback.onItemRangeInserted(param1ObservableList, param1ListChanges.start, param1ListChanges.count);
              return;
            case 1:
              break;
          } 
          param1OnListChangedCallback.onItemRangeChanged(param1ObservableList, param1ListChanges.start, param1ListChanges.count);
        }
      };
  }
  
  public ListChangeRegistry() {
    super(NOTIFIER_CALLBACK);
  }
  
  private static ListChanges acquire(int paramInt1, int paramInt2, int paramInt3) {
    ListChanges listChanges1 = (ListChanges)sListChanges.acquire();
    ListChanges listChanges2 = listChanges1;
    if (listChanges1 == null)
      listChanges2 = new ListChanges(); 
    listChanges2.start = paramInt1;
    listChanges2.to = paramInt2;
    listChanges2.count = paramInt3;
    return listChanges2;
  }
  
  public void notifyCallbacks(@NonNull ObservableList paramObservableList, int paramInt, ListChanges paramListChanges) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: iload_2
    //   5: aload_3
    //   6: invokespecial notifyCallbacks : (Ljava/lang/Object;ILjava/lang/Object;)V
    //   9: aload_3
    //   10: ifnull -> 21
    //   13: getstatic android/databinding/ListChangeRegistry.sListChanges : Landroid/support/v4/util/Pools$SynchronizedPool;
    //   16: aload_3
    //   17: invokevirtual release : (Ljava/lang/Object;)Z
    //   20: pop
    //   21: aload_0
    //   22: monitorexit
    //   23: return
    //   24: astore_1
    //   25: aload_0
    //   26: monitorexit
    //   27: aload_1
    //   28: athrow
    // Exception table:
    //   from	to	target	type
    //   2	9	24	finally
    //   13	21	24	finally
  }
  
  public void notifyChanged(@NonNull ObservableList paramObservableList) {
    notifyCallbacks(paramObservableList, 0, (ListChanges)null);
  }
  
  public void notifyChanged(@NonNull ObservableList paramObservableList, int paramInt1, int paramInt2) {
    notifyCallbacks(paramObservableList, 1, acquire(paramInt1, 0, paramInt2));
  }
  
  public void notifyInserted(@NonNull ObservableList paramObservableList, int paramInt1, int paramInt2) {
    notifyCallbacks(paramObservableList, 2, acquire(paramInt1, 0, paramInt2));
  }
  
  public void notifyMoved(@NonNull ObservableList paramObservableList, int paramInt1, int paramInt2, int paramInt3) {
    notifyCallbacks(paramObservableList, 3, acquire(paramInt1, paramInt2, paramInt3));
  }
  
  public void notifyRemoved(@NonNull ObservableList paramObservableList, int paramInt1, int paramInt2) {
    notifyCallbacks(paramObservableList, 4, acquire(paramInt1, 0, paramInt2));
  }
  
  static class ListChanges {
    public int count;
    
    public int start;
    
    public int to;
  }
}


/* Location:              /Users/amirrshams/UW/Courses/CS858/Project/Apps/App_generator/Hello_World_Generated.jar!/android/databinding/ListChangeRegistry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */