package android.databinding;

import android.os.Parcel;
import android.os.Parcelable;
import java.io.Serializable;

public class ObservableParcelable<T extends Parcelable> extends ObservableField<T> implements Parcelable, Serializable {
  public static final Parcelable.Creator<ObservableParcelable> CREATOR = new Parcelable.Creator<ObservableParcelable>() {
      public ObservableParcelable createFromParcel(Parcel param1Parcel) {
        return new ObservableParcelable<Parcelable>(param1Parcel.readParcelable(getClass().getClassLoader()));
      }
      
      public ObservableParcelable[] newArray(int param1Int) {
        return new ObservableParcelable[param1Int];
      }
    };
  
  static final long serialVersionUID = 1L;
  
  public ObservableParcelable() {}
  
  public ObservableParcelable(T paramT) {
    super(paramT);
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeParcelable((Parcelable)get(), 0);
  }
}


/* Location:              /Users/amirrshams/UW/Courses/CS858/Project/Apps/App_generator/Hello_World_Generated.jar!/android/databinding/ObservableParcelable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */