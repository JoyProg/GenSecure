package android.databinding;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

@Target({ElementType.TYPE})
public @interface BindingMethods {
  BindingMethod[] value();
}


/* Location:              /Users/amirrshams/UW/Courses/CS858/Project/Apps/App_generator/Hello_World_Generated.jar!/android/databinding/BindingMethods.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */