package android.databinding;

public abstract class OnRebindCallback<T extends ViewDataBinding> {
  public void onBound(T paramT) {}
  
  public void onCanceled(T paramT) {}
  
  public boolean onPreBind(T paramT) {
    return true;
  }
}


/* Location:              /Users/amirrshams/UW/Courses/CS858/Project/Apps/App_generator/Hello_World_Generated.jar!/android/databinding/OnRebindCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */