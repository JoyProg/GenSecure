package android.databinding;

import android.os.Parcel;
import android.os.Parcelable;
import java.io.Serializable;

public class ObservableDouble extends BaseObservableField implements Parcelable, Serializable {
  public static final Parcelable.Creator<ObservableDouble> CREATOR = new Parcelable.Creator<ObservableDouble>() {
      public ObservableDouble createFromParcel(Parcel param1Parcel) {
        return new ObservableDouble(param1Parcel.readDouble());
      }
      
      public ObservableDouble[] newArray(int param1Int) {
        return new ObservableDouble[param1Int];
      }
    };
  
  static final long serialVersionUID = 1L;
  
  private double mValue;
  
  public ObservableDouble() {}
  
  public ObservableDouble(double paramDouble) {
    this.mValue = paramDouble;
  }
  
  public ObservableDouble(Observable... paramVarArgs) {
    super(paramVarArgs);
  }
  
  public int describeContents() {
    return 0;
  }
  
  public double get() {
    return this.mValue;
  }
  
  public void set(double paramDouble) {
    if (paramDouble != this.mValue) {
      this.mValue = paramDouble;
      notifyChange();
    } 
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeDouble(this.mValue);
  }
}


/* Location:              /Users/amirrshams/UW/Courses/CS858/Project/Apps/App_generator/Hello_World_Generated.jar!/android/databinding/ObservableDouble.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */