package android.databinding;

import android.util.SparseArray;
import android.view.View;
import com.newandromo.dev1856558.app2514732.databinding.CardWideScrimTitleSubtitleDesc01Binding;
import com.newandromo.dev1856558.app2514732.databinding.DataDummyBinding;
import com.newandromo.dev1856558.app2514732.databinding.MaterialDashboardVerticalMainBinding;
import com.newandromo.dev1856558.app2514732.databinding.WebviewMainBinding;

class DataBinderMapperImpl extends DataBinderMapper {
  public String convertBrIdToString(int paramInt) {
    return (String)InnerBrLookup.sKeys.get(paramInt);
  }
  
  public ViewDataBinding getDataBinder(DataBindingComponent paramDataBindingComponent, View paramView, int paramInt) {
    StringBuilder stringBuilder;
    if (paramInt != 2131427358) {
      if (paramInt != 2131427361) {
        if (paramInt != 2131427380) {
          if (paramInt != 2131427430)
            return null; 
          Object object3 = paramView.getTag();
          if (object3 != null) {
            if ("layout/webview_main_0".equals(object3))
              return (ViewDataBinding)new WebviewMainBinding(paramDataBindingComponent, paramView); 
            stringBuilder = new StringBuilder();
            stringBuilder.append("The tag for webview_main is invalid. Received: ");
            stringBuilder.append(object3);
            throw new IllegalArgumentException(stringBuilder.toString());
          } 
          throw new RuntimeException("view must have a tag");
        } 
        Object object2 = paramView.getTag();
        if (object2 != null) {
          if ("layout/material_dashboard_vertical_main_0".equals(object2))
            return (ViewDataBinding)new MaterialDashboardVerticalMainBinding((DataBindingComponent)stringBuilder, paramView); 
          stringBuilder = new StringBuilder();
          stringBuilder.append("The tag for material_dashboard_vertical_main is invalid. Received: ");
          stringBuilder.append(object2);
          throw new IllegalArgumentException(stringBuilder.toString());
        } 
        throw new RuntimeException("view must have a tag");
      } 
      Object object1 = paramView.getTag();
      if (object1 != null) {
        if ("layout/data_dummy_0".equals(object1))
          return (ViewDataBinding)new DataDummyBinding((DataBindingComponent)stringBuilder, paramView); 
        stringBuilder = new StringBuilder();
        stringBuilder.append("The tag for data_dummy is invalid. Received: ");
        stringBuilder.append(object1);
        throw new IllegalArgumentException(stringBuilder.toString());
      } 
      throw new RuntimeException("view must have a tag");
    } 
    Object object = paramView.getTag();
    if (object != null) {
      if ("layout/card_wide_scrim_title_subtitle_desc_01_0".equals(object))
        return (ViewDataBinding)new CardWideScrimTitleSubtitleDesc01Binding((DataBindingComponent)stringBuilder, paramView); 
      stringBuilder = new StringBuilder();
      stringBuilder.append("The tag for card_wide_scrim_title_subtitle_desc_01 is invalid. Received: ");
      stringBuilder.append(object);
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    throw new RuntimeException("view must have a tag");
  }
  
  public ViewDataBinding getDataBinder(DataBindingComponent paramDataBindingComponent, View[] paramArrayOfView, int paramInt) {
    return null;
  }
  
  public int getLayoutId(String paramString) {
    if (paramString == null)
      return 0; 
    int i = paramString.hashCode();
    if (i != -1323238007) {
      if (i != 530586549) {
        if (i != 1264953429) {
          if (i == 1386912795 && paramString.equals("layout/card_wide_scrim_title_subtitle_desc_01_0"))
            return 2131427358; 
        } else if (paramString.equals("layout/material_dashboard_vertical_main_0")) {
          return 2131427380;
        } 
      } else if (paramString.equals("layout/webview_main_0")) {
        return 2131427430;
      } 
    } else if (paramString.equals("layout/data_dummy_0")) {
      return 2131427361;
    } 
    return 0;
  }
  
  private static class InnerBrLookup {
    static final SparseArray<String> sKeys = new SparseArray();
    
    static {
      sKeys.put(0, "_all");
      sKeys.put(0, "_all");
      sKeys.put(1, "auto");
      sKeys.put(2, "primaryColor");
      sKeys.put(3, "prettyPubDate");
      sKeys.put(4, "toolbarColor");
      sKeys.put(5, "palette");
      sKeys.put(6, "autoBackgroundColor");
      sKeys.put(7, "backgroundType");
      sKeys.put(8, "item");
      sKeys.put(9, "thumbnail");
      sKeys.put(10, "hasDescription");
      sKeys.put(11, "wideImageRatio");
      sKeys.put(12, "pubDate");
      sKeys.put(13, "subtitle");
      sKeys.put(14, "position");
      sKeys.put(15, "autoSecondaryTextColor");
      sKeys.put(16, "autoBodyTextColor");
      sKeys.put(17, "palette0");
      sKeys.put(18, "palette2");
      sKeys.put(19, "palette1");
      sKeys.put(20, "icon");
      sKeys.put(21, "palette4");
      sKeys.put(22, "description");
      sKeys.put(23, "palette3");
      sKeys.put(24, "palette6");
      sKeys.put(25, "autoPrimaryTextColor");
      sKeys.put(26, "palette5");
      sKeys.put(27, "title");
      sKeys.put(28, "palette8");
      sKeys.put(29, "palette7");
      sKeys.put(30, "backgroundIndex");
      sKeys.put(31, "palette9");
      sKeys.put(32, "isDarkTheme");
      sKeys.put(33, "timeAgo");
      sKeys.put(34, "hasSubtitle");
      sKeys.put(35, "defaultLayoutBinding");
      sKeys.put(36, "compactTimeAgo");
      sKeys.put(37, "hasPubDate");
      sKeys.put(38, "imageFallbackColor");
      sKeys.put(39, "backgroundColor");
      sKeys.put(40, "wideImage");
      sKeys.put(41, "auto8");
      sKeys.put(42, "autoTitleTextColor");
      sKeys.put(43, "auto7");
      sKeys.put(44, "auto9");
      sKeys.put(45, "auto4");
      sKeys.put(46, "squareImage");
      sKeys.put(47, "auto3");
      sKeys.put(48, "holder");
      sKeys.put(49, "auto6");
      sKeys.put(50, "auto5");
      sKeys.put(51, "auto0");
      sKeys.put(52, "titleGravity");
      sKeys.put(53, "auto2");
      sKeys.put(54, "auto1");
    }
  }
}


/* Location:              /Users/amirrshams/UW/Courses/CS858/Project/Apps/App_generator/Hello_World_Generated.jar!/android/databinding/DataBinderMapperImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */