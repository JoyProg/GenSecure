package android.databinding;

public interface Observable {
  void addOnPropertyChangedCallback(OnPropertyChangedCallback paramOnPropertyChangedCallback);
  
  void removeOnPropertyChangedCallback(OnPropertyChangedCallback paramOnPropertyChangedCallback);
  
  public static abstract class OnPropertyChangedCallback {
    public abstract void onPropertyChanged(Observable param1Observable, int param1Int);
  }
}


/* Location:              /Users/amirrshams/UW/Courses/CS858/Project/Apps/App_generator/Hello_World_Generated.jar!/android/databinding/Observable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */