package android.databinding;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class DataBindingUtil {
  private static DataBindingComponent sDefaultComponent;
  
  private static DataBinderMapper sMapper = new DataBinderMapperImpl();
  
  static {
    sDefaultComponent = null;
  }
  
  static <T extends ViewDataBinding> T bind(DataBindingComponent paramDataBindingComponent, View paramView, int paramInt) {
    return (T)sMapper.getDataBinder(paramDataBindingComponent, paramView, paramInt);
  }
  
  static <T extends ViewDataBinding> T bind(DataBindingComponent paramDataBindingComponent, View[] paramArrayOfView, int paramInt) {
    return (T)sMapper.getDataBinder(paramDataBindingComponent, paramArrayOfView, paramInt);
  }
  
  @Nullable
  public static <T extends ViewDataBinding> T bind(@NonNull View paramView) {
    return bind(paramView, sDefaultComponent);
  }
  
  @Nullable
  public static <T extends ViewDataBinding> T bind(@NonNull View paramView, DataBindingComponent paramDataBindingComponent) {
    T t = (T)getBinding(paramView);
    if (t != null)
      return t; 
    t = (T)paramView.getTag();
    if (t instanceof String) {
      String str = (String)t;
      int i = sMapper.getLayoutId(str);
      if (i != 0)
        return (T)sMapper.getDataBinder(paramDataBindingComponent, paramView, i); 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("View is not a binding layout. Tag: ");
      stringBuilder.append(t);
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    throw new IllegalArgumentException("View is not a binding layout");
  }
  
  private static <T extends ViewDataBinding> T bindToAddedViews(DataBindingComponent paramDataBindingComponent, ViewGroup paramViewGroup, int paramInt1, int paramInt2) {
    int i = paramViewGroup.getChildCount();
    int j = i - paramInt1;
    if (j == 1)
      return bind(paramDataBindingComponent, paramViewGroup.getChildAt(i - 1), paramInt2); 
    View[] arrayOfView = new View[j];
    for (i = 0; i < j; i++)
      arrayOfView[i] = paramViewGroup.getChildAt(i + paramInt1); 
    return bind(paramDataBindingComponent, arrayOfView, paramInt2);
  }
  
  @Nullable
  public static String convertBrIdToString(int paramInt) {
    return sMapper.convertBrIdToString(paramInt);
  }
  
  @Nullable
  public static <T extends ViewDataBinding> T findBinding(@NonNull View paramView) {
    // Byte code:
    //   0: aload_0
    //   1: ifnull -> 161
    //   4: aload_0
    //   5: invokestatic getBinding : (Landroid/view/View;)Landroid/databinding/ViewDataBinding;
    //   8: astore_1
    //   9: aload_1
    //   10: ifnull -> 15
    //   13: aload_1
    //   14: areturn
    //   15: aload_0
    //   16: invokevirtual getTag : ()Ljava/lang/Object;
    //   19: astore_1
    //   20: aload_1
    //   21: instanceof java/lang/String
    //   24: ifeq -> 136
    //   27: aload_1
    //   28: checkcast java/lang/String
    //   31: astore_1
    //   32: aload_1
    //   33: ldc 'layout'
    //   35: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   38: ifeq -> 136
    //   41: aload_1
    //   42: ldc '_0'
    //   44: invokevirtual endsWith : (Ljava/lang/String;)Z
    //   47: ifeq -> 136
    //   50: aload_1
    //   51: bipush #6
    //   53: invokevirtual charAt : (I)C
    //   56: istore_2
    //   57: aload_1
    //   58: bipush #47
    //   60: bipush #7
    //   62: invokevirtual indexOf : (II)I
    //   65: istore_3
    //   66: iconst_0
    //   67: istore #4
    //   69: iload_2
    //   70: bipush #47
    //   72: if_icmpne -> 90
    //   75: iload #4
    //   77: istore #5
    //   79: iload_3
    //   80: iconst_m1
    //   81: if_icmpne -> 129
    //   84: iconst_1
    //   85: istore #5
    //   87: goto -> 129
    //   90: iload #4
    //   92: istore #5
    //   94: iload_2
    //   95: bipush #45
    //   97: if_icmpne -> 129
    //   100: iload #4
    //   102: istore #5
    //   104: iload_3
    //   105: iconst_m1
    //   106: if_icmpeq -> 129
    //   109: iload #4
    //   111: istore #5
    //   113: aload_1
    //   114: bipush #47
    //   116: iload_3
    //   117: iconst_1
    //   118: iadd
    //   119: invokevirtual indexOf : (II)I
    //   122: iconst_m1
    //   123: if_icmpne -> 129
    //   126: goto -> 84
    //   129: iload #5
    //   131: ifeq -> 136
    //   134: aconst_null
    //   135: areturn
    //   136: aload_0
    //   137: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   140: astore_0
    //   141: aload_0
    //   142: instanceof android/view/View
    //   145: ifeq -> 156
    //   148: aload_0
    //   149: checkcast android/view/View
    //   152: astore_0
    //   153: goto -> 0
    //   156: aconst_null
    //   157: astore_0
    //   158: goto -> 0
    //   161: aconst_null
    //   162: areturn
  }
  
  @Nullable
  public static <T extends ViewDataBinding> T getBinding(@NonNull View paramView) {
    return (T)ViewDataBinding.getBinding(paramView);
  }
  
  @Nullable
  public static DataBindingComponent getDefaultComponent() {
    return sDefaultComponent;
  }
  
  public static <T extends ViewDataBinding> T inflate(@NonNull LayoutInflater paramLayoutInflater, int paramInt, @Nullable ViewGroup paramViewGroup, boolean paramBoolean) {
    return inflate(paramLayoutInflater, paramInt, paramViewGroup, paramBoolean, sDefaultComponent);
  }
  
  public static <T extends ViewDataBinding> T inflate(@NonNull LayoutInflater paramLayoutInflater, int paramInt, @Nullable ViewGroup paramViewGroup, boolean paramBoolean, @Nullable DataBindingComponent paramDataBindingComponent) {
    boolean bool;
    int i = 0;
    if (paramViewGroup != null && paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool)
      i = paramViewGroup.getChildCount(); 
    View view = paramLayoutInflater.inflate(paramInt, paramViewGroup, paramBoolean);
    return bool ? bindToAddedViews(paramDataBindingComponent, paramViewGroup, i, paramInt) : bind(paramDataBindingComponent, view, paramInt);
  }
  
  public static <T extends ViewDataBinding> T setContentView(@NonNull Activity paramActivity, int paramInt) {
    return setContentView(paramActivity, paramInt, sDefaultComponent);
  }
  
  public static <T extends ViewDataBinding> T setContentView(@NonNull Activity paramActivity, int paramInt, @Nullable DataBindingComponent paramDataBindingComponent) {
    paramActivity.setContentView(paramInt);
    return bindToAddedViews(paramDataBindingComponent, (ViewGroup)paramActivity.getWindow().getDecorView().findViewById(16908290), 0, paramInt);
  }
  
  public static void setDefaultComponent(@Nullable DataBindingComponent paramDataBindingComponent) {
    sDefaultComponent = paramDataBindingComponent;
  }
}


/* Location:              /Users/amirrshams/UW/Courses/CS858/Project/Apps/App_generator/Hello_World_Generated.jar!/android/databinding/DataBindingUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */