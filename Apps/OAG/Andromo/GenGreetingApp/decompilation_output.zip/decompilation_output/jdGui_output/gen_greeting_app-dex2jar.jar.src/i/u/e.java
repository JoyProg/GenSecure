package i.u;

import java.io.File;
import java.io.IOException;

public class e
  extends IOException
{
  public final File g;
  public final File h;
  public final String i;
  
  public e(File paramFile1, File paramFile2, String paramString)
  {
    super(c.a(paramFile1, paramFile2, paramString));
    this.g = paramFile1;
    this.h = paramFile2;
    this.i = paramString;
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/i/u/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */