package i.s;

import i.v.c.l;
import i.v.d.i;

public abstract class b<B extends g.b, E extends B>
  implements g.c<E>
{
  public final l<g.b, E> g;
  public final g.c<?> h;
  
  public b(g.c<B> paramc, l<? super g.b, ? extends E> paraml)
  {
    this.g = paraml;
    paraml = paramc;
    if ((paramc instanceof b)) {
      paraml = ((b)paramc).h;
    }
    this.h = paraml;
  }
  
  public final boolean a(g.c<?> paramc)
  {
    i.e(paramc, "key");
    boolean bool;
    if ((paramc != this) && (this.h != paramc)) {
      bool = false;
    } else {
      bool = true;
    }
    return bool;
  }
  
  public final E b(g.b paramb)
  {
    i.e(paramb, "element");
    return (g.b)this.g.invoke(paramb);
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/i/s/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */