package l;

import java.io.EOFException;
import java.nio.ByteBuffer;
import java.util.Objects;

public final class o
  implements e
{
  public final c g = new c();
  public final t h;
  public boolean i;
  
  public o(t paramt)
  {
    Objects.requireNonNull(paramt, "source == null");
    this.h = paramt;
  }
  
  public byte A0()
  {
    p0(1L);
    return this.g.A0();
  }
  
  public int E()
  {
    p0(4L);
    return this.g.E();
  }
  
  public String J()
  {
    return h0(Long.MAX_VALUE);
  }
  
  public byte[] L()
  {
    this.g.r0(this.h);
    return this.g.L();
  }
  
  public int N()
  {
    p0(4L);
    return this.g.N();
  }
  
  public c O()
  {
    return this.g;
  }
  
  public boolean Q()
  {
    if (!this.i)
    {
      boolean bool;
      if ((this.g.Q()) && (this.h.e0(this.g, 8192L) == -1L)) {
        bool = true;
      } else {
        bool = false;
      }
      return bool;
    }
    throw new IllegalStateException("closed");
  }
  
  public byte[] T(long paramLong)
  {
    p0(paramLong);
    return this.g.T(paramLong);
  }
  
  public long a(byte paramByte, long paramLong1, long paramLong2)
  {
    if (!this.i)
    {
      if ((paramLong1 >= 0L) && (paramLong2 >= paramLong1))
      {
        while (paramLong1 < paramLong2)
        {
          long l = this.g.q(paramByte, paramLong1, paramLong2);
          if (l != -1L) {
            return l;
          }
          localObject = this.g;
          l = ((c)localObject).i;
          if ((l >= paramLong2) || (this.h.e0((c)localObject, 8192L) == -1L)) {
            break;
          }
          paramLong1 = Math.max(paramLong1, l);
        }
        return -1L;
      }
      throw new IllegalArgumentException(String.format("fromIndex=%s toIndex=%s", new Object[] { Long.valueOf(paramLong1), Long.valueOf(paramLong2) }));
    }
    Object localObject = new IllegalStateException("closed");
    for (;;)
    {
      throw ((Throwable)localObject);
    }
  }
  
  public boolean b(long paramLong)
  {
    if (paramLong >= 0L)
    {
      if (!this.i)
      {
        do
        {
          localObject = this.g;
          if (((c)localObject).i >= paramLong) {
            break;
          }
        } while (this.h.e0((c)localObject, 8192L) != -1L);
        return false;
        return true;
      }
      throw new IllegalStateException("closed");
    }
    Object localObject = new StringBuilder();
    ((StringBuilder)localObject).append("byteCount < 0: ");
    ((StringBuilder)localObject).append(paramLong);
    localObject = new IllegalArgumentException(((StringBuilder)localObject).toString());
    for (;;)
    {
      throw ((Throwable)localObject);
    }
  }
  
  public short b0()
  {
    p0(2L);
    return this.g.b0();
  }
  
  public c c()
  {
    return this.g;
  }
  
  public void close()
  {
    if (this.i) {
      return;
    }
    this.i = true;
    this.h.close();
    this.g.a();
  }
  
  public long e0(c paramc, long paramLong)
  {
    if (paramc != null)
    {
      if (paramLong >= 0L)
      {
        if (!this.i)
        {
          c localc = this.g;
          if ((localc.i == 0L) && (this.h.e0(localc, 8192L) == -1L)) {
            return -1L;
          }
          paramLong = Math.min(paramLong, this.g.i);
          return this.g.e0(paramc, paramLong);
        }
        throw new IllegalStateException("closed");
      }
      paramc = new StringBuilder();
      paramc.append("byteCount < 0: ");
      paramc.append(paramLong);
      throw new IllegalArgumentException(paramc.toString());
    }
    throw new IllegalArgumentException("sink == null");
  }
  
  public u f()
  {
    return this.h.f();
  }
  
  public String h0(long paramLong)
  {
    if (paramLong >= 0L)
    {
      long l1;
      if (paramLong == Long.MAX_VALUE) {
        l1 = Long.MAX_VALUE;
      } else {
        l1 = paramLong + 1L;
      }
      long l2 = a((byte)10, 0L, l1);
      if (l2 != -1L) {
        return this.g.W(l2);
      }
      if ((l1 < Long.MAX_VALUE) && (b(l1)) && (this.g.o(l1 - 1L) == 13) && (b(1L + l1)) && (this.g.o(l1) == 10)) {
        return this.g.W(l1);
      }
      localObject1 = new c();
      Object localObject2 = this.g;
      ((c)localObject2).h((c)localObject1, 0L, Math.min(32L, ((c)localObject2).a0()));
      localObject2 = new StringBuilder();
      ((StringBuilder)localObject2).append("\\n not found: limit=");
      ((StringBuilder)localObject2).append(Math.min(this.g.a0(), paramLong));
      ((StringBuilder)localObject2).append(" content=");
      ((StringBuilder)localObject2).append(((c)localObject1).u().r());
      ((StringBuilder)localObject2).append('…');
      throw new EOFException(((StringBuilder)localObject2).toString());
    }
    Object localObject1 = new StringBuilder();
    ((StringBuilder)localObject1).append("limit < 0: ");
    ((StringBuilder)localObject1).append(paramLong);
    throw new IllegalArgumentException(((StringBuilder)localObject1).toString());
  }
  
  public boolean isOpen()
  {
    return this.i ^ true;
  }
  
  public short j0()
  {
    p0(2L);
    return this.g.j0();
  }
  
  public void p(byte[] paramArrayOfByte)
  {
    label73:
    try
    {
      p0(paramArrayOfByte.length);
      this.g.p(paramArrayOfByte);
      return;
    }
    catch (EOFException localEOFException)
    {
      int j = 0;
      for (;;)
      {
        c localc = this.g;
        long l = localc.i;
        if (l <= 0L) {
          break label73;
        }
        int k = localc.s(paramArrayOfByte, j, (int)l);
        if (k == -1) {
          break;
        }
        j += k;
      }
      throw new AssertionError();
    }
    for (;;)
    {
      throw localEOFException;
    }
  }
  
  public void p0(long paramLong)
  {
    if (b(paramLong)) {
      return;
    }
    throw new EOFException();
  }
  
  public int read(ByteBuffer paramByteBuffer)
  {
    c localc = this.g;
    if ((localc.i == 0L) && (this.h.e0(localc, 8192L) == -1L)) {
      return -1;
    }
    return this.g.read(paramByteBuffer);
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("buffer(");
    localStringBuilder.append(this.h);
    localStringBuilder.append(")");
    return localStringBuilder.toString();
  }
  
  public f w(long paramLong)
  {
    p0(paramLong);
    return this.g.w(paramLong);
  }
  
  public long w0(byte paramByte)
  {
    return a(paramByte, 0L, Long.MAX_VALUE);
  }
  
  public long y0()
  {
    p0(1L);
    int k;
    byte b;
    for (int j = 0;; j = k)
    {
      k = j + 1;
      if (!b(k)) {
        break label105;
      }
      b = this.g.o(j);
      if (((b < 48) || (b > 57)) && ((b < 97) || (b > 102)) && ((b < 65) || (b > 70))) {
        break;
      }
    }
    if (j == 0) {
      throw new NumberFormatException(String.format("Expected leading [0-9a-fA-F] character but was %#x", new Object[] { Byte.valueOf(b) }));
    }
    label105:
    return this.g.y0();
  }
  
  public void z(long paramLong)
  {
    if (!this.i)
    {
      while (paramLong > 0L)
      {
        localObject = this.g;
        if ((((c)localObject).i == 0L) && (this.h.e0((c)localObject, 8192L) == -1L)) {
          throw new EOFException();
        }
        long l = Math.min(paramLong, this.g.a0());
        this.g.z(l);
        paramLong -= l;
      }
      return;
    }
    Object localObject = new IllegalStateException("closed");
    for (;;)
    {
      throw ((Throwable)localObject);
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/l/o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */