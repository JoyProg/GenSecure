package k;

import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.Proxy.Type;
import java.util.Objects;

public final class i0
{
  public final e a;
  public final Proxy b;
  public final InetSocketAddress c;
  
  public i0(e parame, Proxy paramProxy, InetSocketAddress paramInetSocketAddress)
  {
    Objects.requireNonNull(parame, "address == null");
    Objects.requireNonNull(paramProxy, "proxy == null");
    Objects.requireNonNull(paramInetSocketAddress, "inetSocketAddress == null");
    this.a = parame;
    this.b = paramProxy;
    this.c = paramInetSocketAddress;
  }
  
  public e a()
  {
    return this.a;
  }
  
  public Proxy b()
  {
    return this.b;
  }
  
  public boolean c()
  {
    boolean bool;
    if ((this.a.i != null) && (this.b.type() == Proxy.Type.HTTP)) {
      bool = true;
    } else {
      bool = false;
    }
    return bool;
  }
  
  public InetSocketAddress d()
  {
    return this.c;
  }
  
  public boolean equals(Object paramObject)
  {
    if ((paramObject instanceof i0))
    {
      paramObject = (i0)paramObject;
      if ((((i0)paramObject).a.equals(this.a)) && (((i0)paramObject).b.equals(this.b)) && (((i0)paramObject).c.equals(this.c))) {
        return true;
      }
    }
    boolean bool = false;
    return bool;
  }
  
  public int hashCode()
  {
    return ((527 + this.a.hashCode()) * 31 + this.b.hashCode()) * 31 + this.c.hashCode();
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("Route{");
    localStringBuilder.append(this.c);
    localStringBuilder.append("}");
    return localStringBuilder.toString();
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/k/i0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */