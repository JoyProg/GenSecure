package k;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public final class m
{
  public static final m A;
  public static final m A0 = c("TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA", 49162);
  public static final m B;
  public static final m B0 = c("TLS_ECDH_RSA_WITH_NULL_SHA", 49163);
  public static final m C;
  public static final m C0 = c("TLS_ECDH_RSA_WITH_RC4_128_SHA", 49164);
  public static final m D;
  public static final m D0 = c("TLS_ECDH_RSA_WITH_3DES_EDE_CBC_SHA", 49165);
  public static final m E;
  public static final m E0 = c("TLS_ECDH_RSA_WITH_AES_128_CBC_SHA", 49166);
  public static final m F;
  public static final m F0 = c("TLS_ECDH_RSA_WITH_AES_256_CBC_SHA", 49167);
  public static final m G;
  public static final m G0 = c("TLS_ECDHE_RSA_WITH_NULL_SHA", 49168);
  public static final m H;
  public static final m H0 = c("TLS_ECDHE_RSA_WITH_RC4_128_SHA", 49169);
  public static final m I;
  public static final m I0 = c("TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA", 49170);
  public static final m J;
  public static final m J0 = c("TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA", 49171);
  public static final m K;
  public static final m K0 = c("TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA", 49172);
  public static final m L;
  public static final m L0 = c("TLS_ECDH_anon_WITH_NULL_SHA", 49173);
  public static final m M;
  public static final m M0 = c("TLS_ECDH_anon_WITH_RC4_128_SHA", 49174);
  public static final m N;
  public static final m N0 = c("TLS_ECDH_anon_WITH_3DES_EDE_CBC_SHA", 49175);
  public static final m O;
  public static final m O0 = c("TLS_ECDH_anon_WITH_AES_128_CBC_SHA", 49176);
  public static final m P;
  public static final m P0 = c("TLS_ECDH_anon_WITH_AES_256_CBC_SHA", 49177);
  public static final m Q;
  public static final m Q0 = c("TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256", 49187);
  public static final m R;
  public static final m R0 = c("TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384", 49188);
  public static final m S;
  public static final m S0 = c("TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256", 49189);
  public static final m T;
  public static final m T0 = c("TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384", 49190);
  public static final m U;
  public static final m U0 = c("TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256", 49191);
  public static final m V;
  public static final m V0 = c("TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384", 49192);
  public static final m W;
  public static final m W0 = c("TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256", 49193);
  public static final m X;
  public static final m X0 = c("TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384", 49194);
  public static final m Y;
  public static final m Y0 = c("TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256", 49195);
  public static final m Z;
  public static final m Z0 = c("TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384", 49196);
  public static final Comparator<String> a = b.g;
  public static final m a0;
  public static final m a1 = c("TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256", 49197);
  public static final Map<String, m> b = new LinkedHashMap();
  public static final m b0;
  public static final m b1 = c("TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384", 49198);
  public static final m c = c("SSL_RSA_WITH_NULL_MD5", 1);
  public static final m c0;
  public static final m c1 = c("TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256", 49199);
  public static final m d = c("SSL_RSA_WITH_NULL_SHA", 2);
  public static final m d0;
  public static final m d1 = c("TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384", 49200);
  public static final m e = c("SSL_RSA_EXPORT_WITH_RC4_40_MD5", 3);
  public static final m e0;
  public static final m e1 = c("TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256", 49201);
  public static final m f = c("SSL_RSA_WITH_RC4_128_MD5", 4);
  public static final m f0;
  public static final m f1 = c("TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384", 49202);
  public static final m g = c("SSL_RSA_WITH_RC4_128_SHA", 5);
  public static final m g0;
  public static final m g1 = c("TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA", 49205);
  public static final m h = c("SSL_RSA_EXPORT_WITH_DES40_CBC_SHA", 8);
  public static final m h0;
  public static final m h1 = c("TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA", 49206);
  public static final m i = c("SSL_RSA_WITH_DES_CBC_SHA", 9);
  public static final m i0;
  public static final m i1 = c("TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256", 52392);
  public static final m j = c("SSL_RSA_WITH_3DES_EDE_CBC_SHA", 10);
  public static final m j0;
  public static final m j1 = c("TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256", 52393);
  public static final m k = c("SSL_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA", 17);
  public static final m k0;
  public static final m k1 = c("TLS_DHE_RSA_WITH_CHACHA20_POLY1305_SHA256", 52394);
  public static final m l = c("SSL_DHE_DSS_WITH_DES_CBC_SHA", 18);
  public static final m l0;
  public static final m l1 = c("TLS_ECDHE_PSK_WITH_CHACHA20_POLY1305_SHA256", 52396);
  public static final m m = c("SSL_DHE_DSS_WITH_3DES_EDE_CBC_SHA", 19);
  public static final m m0;
  public static final m m1 = c("TLS_AES_128_GCM_SHA256", 4865);
  public static final m n = c("SSL_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA", 20);
  public static final m n0;
  public static final m n1 = c("TLS_AES_256_GCM_SHA384", 4866);
  public static final m o = c("SSL_DHE_RSA_WITH_DES_CBC_SHA", 21);
  public static final m o0;
  public static final m o1 = c("TLS_CHACHA20_POLY1305_SHA256", 4867);
  public static final m p = c("SSL_DHE_RSA_WITH_3DES_EDE_CBC_SHA", 22);
  public static final m p0;
  public static final m p1 = c("TLS_AES_128_CCM_SHA256", 4868);
  public static final m q = c("SSL_DH_anon_EXPORT_WITH_RC4_40_MD5", 23);
  public static final m q0;
  public static final m q1 = c("TLS_AES_128_CCM_8_SHA256", 4869);
  public static final m r = c("SSL_DH_anon_WITH_RC4_128_MD5", 24);
  public static final m r0;
  public static final m s = c("SSL_DH_anon_EXPORT_WITH_DES40_CBC_SHA", 25);
  public static final m s0;
  public static final m t = c("SSL_DH_anon_WITH_DES_CBC_SHA", 26);
  public static final m t0;
  public static final m u = c("SSL_DH_anon_WITH_3DES_EDE_CBC_SHA", 27);
  public static final m u0;
  public static final m v = c("TLS_KRB5_WITH_DES_CBC_SHA", 30);
  public static final m v0;
  public static final m w = c("TLS_KRB5_WITH_3DES_EDE_CBC_SHA", 31);
  public static final m w0;
  public static final m x = c("TLS_KRB5_WITH_RC4_128_SHA", 32);
  public static final m x0;
  public static final m y = c("TLS_KRB5_WITH_DES_CBC_MD5", 34);
  public static final m y0;
  public static final m z = c("TLS_KRB5_WITH_3DES_EDE_CBC_MD5", 35);
  public static final m z0;
  public final String r1;
  
  static
  {
    A = c("TLS_KRB5_WITH_RC4_128_MD5", 36);
    B = c("TLS_KRB5_EXPORT_WITH_DES_CBC_40_SHA", 38);
    C = c("TLS_KRB5_EXPORT_WITH_RC4_40_SHA", 40);
    D = c("TLS_KRB5_EXPORT_WITH_DES_CBC_40_MD5", 41);
    E = c("TLS_KRB5_EXPORT_WITH_RC4_40_MD5", 43);
    F = c("TLS_RSA_WITH_AES_128_CBC_SHA", 47);
    G = c("TLS_DHE_DSS_WITH_AES_128_CBC_SHA", 50);
    H = c("TLS_DHE_RSA_WITH_AES_128_CBC_SHA", 51);
    I = c("TLS_DH_anon_WITH_AES_128_CBC_SHA", 52);
    J = c("TLS_RSA_WITH_AES_256_CBC_SHA", 53);
    K = c("TLS_DHE_DSS_WITH_AES_256_CBC_SHA", 56);
    L = c("TLS_DHE_RSA_WITH_AES_256_CBC_SHA", 57);
    M = c("TLS_DH_anon_WITH_AES_256_CBC_SHA", 58);
    N = c("TLS_RSA_WITH_NULL_SHA256", 59);
    O = c("TLS_RSA_WITH_AES_128_CBC_SHA256", 60);
    P = c("TLS_RSA_WITH_AES_256_CBC_SHA256", 61);
    Q = c("TLS_DHE_DSS_WITH_AES_128_CBC_SHA256", 64);
    R = c("TLS_RSA_WITH_CAMELLIA_128_CBC_SHA", 65);
    S = c("TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA", 68);
    T = c("TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA", 69);
    U = c("TLS_DHE_RSA_WITH_AES_128_CBC_SHA256", 103);
    V = c("TLS_DHE_DSS_WITH_AES_256_CBC_SHA256", 106);
    W = c("TLS_DHE_RSA_WITH_AES_256_CBC_SHA256", 107);
    X = c("TLS_DH_anon_WITH_AES_128_CBC_SHA256", 108);
    Y = c("TLS_DH_anon_WITH_AES_256_CBC_SHA256", 109);
    Z = c("TLS_RSA_WITH_CAMELLIA_256_CBC_SHA", 132);
    a0 = c("TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA", 135);
    b0 = c("TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA", 136);
    c0 = c("TLS_PSK_WITH_RC4_128_SHA", 138);
    d0 = c("TLS_PSK_WITH_3DES_EDE_CBC_SHA", 139);
    e0 = c("TLS_PSK_WITH_AES_128_CBC_SHA", 140);
    f0 = c("TLS_PSK_WITH_AES_256_CBC_SHA", 141);
    g0 = c("TLS_RSA_WITH_SEED_CBC_SHA", 150);
    h0 = c("TLS_RSA_WITH_AES_128_GCM_SHA256", 156);
    i0 = c("TLS_RSA_WITH_AES_256_GCM_SHA384", 157);
    j0 = c("TLS_DHE_RSA_WITH_AES_128_GCM_SHA256", 158);
    k0 = c("TLS_DHE_RSA_WITH_AES_256_GCM_SHA384", 159);
    l0 = c("TLS_DHE_DSS_WITH_AES_128_GCM_SHA256", 162);
    m0 = c("TLS_DHE_DSS_WITH_AES_256_GCM_SHA384", 163);
    n0 = c("TLS_DH_anon_WITH_AES_128_GCM_SHA256", 166);
    o0 = c("TLS_DH_anon_WITH_AES_256_GCM_SHA384", 167);
    p0 = c("TLS_EMPTY_RENEGOTIATION_INFO_SCSV", 255);
    q0 = c("TLS_FALLBACK_SCSV", 22016);
    r0 = c("TLS_ECDH_ECDSA_WITH_NULL_SHA", 49153);
    s0 = c("TLS_ECDH_ECDSA_WITH_RC4_128_SHA", 49154);
    t0 = c("TLS_ECDH_ECDSA_WITH_3DES_EDE_CBC_SHA", 49155);
    u0 = c("TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA", 49156);
    v0 = c("TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA", 49157);
    w0 = c("TLS_ECDHE_ECDSA_WITH_NULL_SHA", 49158);
    x0 = c("TLS_ECDHE_ECDSA_WITH_RC4_128_SHA", 49159);
    y0 = c("TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA", 49160);
    z0 = c("TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA", 49161);
  }
  
  public m(String paramString)
  {
    Objects.requireNonNull(paramString);
    this.r1 = paramString;
  }
  
  public static m a(String paramString)
  {
    try
    {
      Map localMap = b;
      m localm1 = (m)localMap.get(paramString);
      m localm2 = localm1;
      if (localm1 == null)
      {
        localm1 = (m)localMap.get(e(paramString));
        localm2 = localm1;
        if (localm1 == null)
        {
          localm2 = new k/m;
          localm2.<init>(paramString);
        }
        localMap.put(paramString, localm2);
      }
      return localm2;
    }
    finally {}
  }
  
  public static List<m> b(String... paramVarArgs)
  {
    ArrayList localArrayList = new ArrayList(paramVarArgs.length);
    int i2 = paramVarArgs.length;
    for (int i3 = 0; i3 < i2; i3++) {
      localArrayList.add(a(paramVarArgs[i3]));
    }
    return Collections.unmodifiableList(localArrayList);
  }
  
  public static m c(String paramString, int paramInt)
  {
    m localm = new m(paramString);
    b.put(paramString, localm);
    return localm;
  }
  
  public static String e(String paramString)
  {
    if (paramString.startsWith("TLS_"))
    {
      localObject = new StringBuilder();
      ((StringBuilder)localObject).append("SSL_");
      ((StringBuilder)localObject).append(paramString.substring(4));
      return ((StringBuilder)localObject).toString();
    }
    Object localObject = paramString;
    if (paramString.startsWith("SSL_"))
    {
      localObject = new StringBuilder();
      ((StringBuilder)localObject).append("TLS_");
      ((StringBuilder)localObject).append(paramString.substring(4));
      localObject = ((StringBuilder)localObject).toString();
    }
    return (String)localObject;
  }
  
  public String toString()
  {
    return this.r1;
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/k/m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */