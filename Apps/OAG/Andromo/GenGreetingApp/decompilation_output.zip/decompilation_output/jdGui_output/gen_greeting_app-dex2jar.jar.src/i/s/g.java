package i.s;

import i.v.c.p;
import i.v.d.i;
import i.v.d.j;

public abstract interface g
{
  public abstract <R> R fold(R paramR, p<? super R, ? super b, ? extends R> paramp);
  
  public abstract <E extends b> E get(c<E> paramc);
  
  public abstract g minusKey(c<?> paramc);
  
  public abstract g plus(g paramg);
  
  public static final class a
  {
    public static g a(g paramg1, g paramg2)
    {
      i.e(paramg2, "context");
      if (paramg2 != h.g) {
        paramg1 = (g)paramg2.fold(paramg1, a.g);
      }
      return paramg1;
    }
    
    public static final class a
      extends j
      implements p<g, g.b, g>
    {
      public static final a g = new a();
      
      public a()
      {
        super();
      }
      
      public final g a(g paramg, g.b paramb)
      {
        i.e(paramg, "acc");
        i.e(paramb, "element");
        g localg = paramg.minusKey(paramb.getKey());
        h localh = h.g;
        if (localg != localh)
        {
          e.b localb = e.d;
          paramg = (e)localg.get(localb);
          if (paramg == null) {}
          for (paramg = new c(localg, paramb);; paramg = new c(new c(localg, paramb), paramg))
          {
            paramb = paramg;
            break;
            localg = localg.minusKey(localb);
            if (localg == localh)
            {
              paramb = new c(paramb, paramg);
              break;
            }
          }
        }
        return paramb;
      }
    }
  }
  
  public static abstract interface b
    extends g
  {
    public abstract <E extends b> E get(g.c<E> paramc);
    
    public abstract g.c<?> getKey();
    
    public static final class a
    {
      public static <R> R a(g.b paramb, R paramR, p<? super R, ? super g.b, ? extends R> paramp)
      {
        i.e(paramp, "operation");
        return (R)paramp.invoke(paramR, paramb);
      }
      
      public static <E extends g.b> E b(g.b paramb, g.c<E> paramc)
      {
        i.e(paramc, "key");
        if (i.a(paramb.getKey(), paramc)) {
          i.c(paramb, "null cannot be cast to non-null type E of kotlin.coroutines.CoroutineContext.Element.get");
        } else {
          paramb = null;
        }
        return paramb;
      }
      
      public static g c(g.b paramb, g.c<?> paramc)
      {
        i.e(paramc, "key");
        Object localObject = paramb;
        if (i.a(paramb.getKey(), paramc)) {
          localObject = h.g;
        }
        return (g)localObject;
      }
      
      public static g d(g.b paramb, g paramg)
      {
        i.e(paramg, "context");
        return g.a.a(paramb, paramg);
      }
    }
  }
  
  public static abstract interface c<E extends g.b> {}
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/i/s/g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */