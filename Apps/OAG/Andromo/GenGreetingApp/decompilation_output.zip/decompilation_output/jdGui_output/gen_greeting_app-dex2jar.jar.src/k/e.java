package k;

import java.net.Proxy;
import java.net.ProxySelector;
import java.util.List;
import java.util.Objects;
import javax.net.SocketFactory;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSocketFactory;

public final class e
{
  public final y a;
  public final u b;
  public final SocketFactory c;
  public final g d;
  public final List<c0> e;
  public final List<p> f;
  public final ProxySelector g;
  public final Proxy h;
  public final SSLSocketFactory i;
  public final HostnameVerifier j;
  public final l k;
  
  public e(String paramString, int paramInt, u paramu, SocketFactory paramSocketFactory, SSLSocketFactory paramSSLSocketFactory, HostnameVerifier paramHostnameVerifier, l paraml, g paramg, Proxy paramProxy, List<c0> paramList, List<p> paramList1, ProxySelector paramProxySelector)
  {
    y.a locala = new y.a();
    String str;
    if (paramSSLSocketFactory != null) {
      str = "https";
    } else {
      str = "http";
    }
    this.a = locala.q(str).e(paramString).l(paramInt).a();
    Objects.requireNonNull(paramu, "dns == null");
    this.b = paramu;
    Objects.requireNonNull(paramSocketFactory, "socketFactory == null");
    this.c = paramSocketFactory;
    Objects.requireNonNull(paramg, "proxyAuthenticator == null");
    this.d = paramg;
    Objects.requireNonNull(paramList, "protocols == null");
    this.e = k.k0.e.r(paramList);
    Objects.requireNonNull(paramList1, "connectionSpecs == null");
    this.f = k.k0.e.r(paramList1);
    Objects.requireNonNull(paramProxySelector, "proxySelector == null");
    this.g = paramProxySelector;
    this.h = paramProxy;
    this.i = paramSSLSocketFactory;
    this.j = paramHostnameVerifier;
    this.k = paraml;
  }
  
  public l a()
  {
    return this.k;
  }
  
  public List<p> b()
  {
    return this.f;
  }
  
  public u c()
  {
    return this.b;
  }
  
  public boolean d(e parame)
  {
    boolean bool;
    if ((this.b.equals(parame.b)) && (this.d.equals(parame.d)) && (this.e.equals(parame.e)) && (this.f.equals(parame.f)) && (this.g.equals(parame.g)) && (Objects.equals(this.h, parame.h)) && (Objects.equals(this.i, parame.i)) && (Objects.equals(this.j, parame.j)) && (Objects.equals(this.k, parame.k)) && (l().w() == parame.l().w())) {
      bool = true;
    } else {
      bool = false;
    }
    return bool;
  }
  
  public HostnameVerifier e()
  {
    return this.j;
  }
  
  public boolean equals(Object paramObject)
  {
    if ((paramObject instanceof e))
    {
      y localy = this.a;
      paramObject = (e)paramObject;
      if ((localy.equals(((e)paramObject).a)) && (d((e)paramObject))) {
        return true;
      }
    }
    boolean bool = false;
    return bool;
  }
  
  public List<c0> f()
  {
    return this.e;
  }
  
  public Proxy g()
  {
    return this.h;
  }
  
  public g h()
  {
    return this.d;
  }
  
  public int hashCode()
  {
    return (((((((((527 + this.a.hashCode()) * 31 + this.b.hashCode()) * 31 + this.d.hashCode()) * 31 + this.e.hashCode()) * 31 + this.f.hashCode()) * 31 + this.g.hashCode()) * 31 + Objects.hashCode(this.h)) * 31 + Objects.hashCode(this.i)) * 31 + Objects.hashCode(this.j)) * 31 + Objects.hashCode(this.k);
  }
  
  public ProxySelector i()
  {
    return this.g;
  }
  
  public SocketFactory j()
  {
    return this.c;
  }
  
  public SSLSocketFactory k()
  {
    return this.i;
  }
  
  public y l()
  {
    return this.a;
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("Address{");
    localStringBuilder.append(this.a.l());
    localStringBuilder.append(":");
    localStringBuilder.append(this.a.w());
    if (this.h != null)
    {
      localStringBuilder.append(", proxy=");
      localStringBuilder.append(this.h);
    }
    else
    {
      localStringBuilder.append(", proxySelector=");
      localStringBuilder.append(this.g);
    }
    localStringBuilder.append("}");
    return localStringBuilder.toString();
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/k/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */