package i.s;

import i.v.c.p;

public abstract class a
  implements g.b
{
  private final g.c<?> key;
  
  public a(g.c<?> paramc)
  {
    this.key = paramc;
  }
  
  public <R> R fold(R paramR, p<? super R, ? super g.b, ? extends R> paramp)
  {
    return (R)g.b.a.a(this, paramR, paramp);
  }
  
  public <E extends g.b> E get(g.c<E> paramc)
  {
    return g.b.a.b(this, paramc);
  }
  
  public g.c<?> getKey()
  {
    return this.key;
  }
  
  public g minusKey(g.c<?> paramc)
  {
    return g.b.a.c(this, paramc);
  }
  
  public g plus(g paramg)
  {
    return g.b.a.d(this, paramg);
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/i/s/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */