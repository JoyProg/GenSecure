package i.v;

import i.v.d.b;
import i.v.d.i;
import i.v.d.m;
import i.y.c;

public final class a
{
  public static final <T> Class<T> a(c<T> paramc)
  {
    i.e(paramc, "<this>");
    paramc = ((b)paramc).b();
    if (!paramc.isPrimitive())
    {
      i.c(paramc, "null cannot be cast to non-null type java.lang.Class<T of kotlin.jvm.JvmClassMappingKt.<get-javaObjectType>>");
      return paramc;
    }
    String str = paramc.getName();
    switch (str.hashCode())
    {
    default: 
      break;
    case 109413500: 
      if (str.equals("short")) {
        paramc = Short.class;
      }
      break;
    case 97526364: 
      if (str.equals("float")) {
        paramc = Float.class;
      }
      break;
    case 64711720: 
      if (str.equals("boolean")) {
        paramc = Boolean.class;
      }
      break;
    case 3625364: 
      if (str.equals("void")) {
        paramc = Void.class;
      }
      break;
    case 3327612: 
      if (str.equals("long")) {
        paramc = Long.class;
      }
      break;
    case 3052374: 
      if (str.equals("char")) {
        paramc = Character.class;
      }
      break;
    case 3039496: 
      if (str.equals("byte")) {
        paramc = Byte.class;
      }
      break;
    case 104431: 
      if (str.equals("int")) {
        paramc = Integer.class;
      }
      break;
    case -1325958191: 
      if (str.equals("double")) {
        paramc = Double.class;
      }
      break;
    }
    i.c(paramc, "null cannot be cast to non-null type java.lang.Class<T of kotlin.jvm.JvmClassMappingKt.<get-javaObjectType>>");
    return paramc;
  }
  
  public static final <T> c<T> b(Class<T> paramClass)
  {
    i.e(paramClass, "<this>");
    return m.b(paramClass);
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/i/v/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */