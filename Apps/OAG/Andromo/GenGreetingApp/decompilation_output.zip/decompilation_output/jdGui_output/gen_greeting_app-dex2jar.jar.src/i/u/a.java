package i.u;

import i.v.d.i;
import java.io.InputStream;
import java.io.OutputStream;

public final class a
{
  public static final long a(InputStream paramInputStream, OutputStream paramOutputStream, int paramInt)
  {
    i.e(paramInputStream, "<this>");
    i.e(paramOutputStream, "out");
    byte[] arrayOfByte = new byte[paramInt];
    paramInt = paramInputStream.read(arrayOfByte);
    long l = 0L;
    while (paramInt >= 0)
    {
      paramOutputStream.write(arrayOfByte, 0, paramInt);
      l += paramInt;
      paramInt = paramInputStream.read(arrayOfByte);
    }
    return l;
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/i/u/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */