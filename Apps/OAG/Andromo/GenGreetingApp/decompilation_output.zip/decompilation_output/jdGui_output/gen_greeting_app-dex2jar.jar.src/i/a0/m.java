package i.a0;

import i.q.d;
import i.q.o;
import i.q.t;
import i.v.c.p;
import i.v.d.j;
import i.x.e;
import i.z.g;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public class m
  extends l
{
  public static final int B(CharSequence paramCharSequence, char[] paramArrayOfChar, int paramInt, boolean paramBoolean)
  {
    i.v.d.i.e(paramCharSequence, "<this>");
    i.v.d.i.e(paramArrayOfChar, "chars");
    int i;
    if ((!paramBoolean) && (paramArrayOfChar.length == 1) && ((paramCharSequence instanceof String)))
    {
      i = d.h(paramArrayOfChar);
      return ((String)paramCharSequence).indexOf(i, paramInt);
    }
    t localt = new i.x.c(e.a(paramInt, 0), u(paramCharSequence)).u();
    while (localt.hasNext())
    {
      i = localt.b();
      char c = paramCharSequence.charAt(i);
      int j = paramArrayOfChar.length;
      for (paramInt = 0; paramInt < j; paramInt++) {
        if (b.d(paramArrayOfChar[paramInt], c, paramBoolean))
        {
          paramInt = 1;
          break label131;
        }
      }
      paramInt = 0;
      label131:
      if (paramInt != 0) {
        return i;
      }
    }
    return -1;
  }
  
  public static final int C(CharSequence paramCharSequence, char paramChar, int paramInt, boolean paramBoolean)
  {
    i.v.d.i.e(paramCharSequence, "<this>");
    if ((!paramBoolean) && ((paramCharSequence instanceof String))) {
      paramInt = ((String)paramCharSequence).lastIndexOf(paramChar, paramInt);
    } else {
      paramInt = G(paramCharSequence, new char[] { paramChar }, paramInt, paramBoolean);
    }
    return paramInt;
  }
  
  public static final int D(CharSequence paramCharSequence, String paramString, int paramInt, boolean paramBoolean)
  {
    i.v.d.i.e(paramCharSequence, "<this>");
    i.v.d.i.e(paramString, "string");
    if ((!paramBoolean) && ((paramCharSequence instanceof String))) {
      paramInt = ((String)paramCharSequence).lastIndexOf(paramString, paramInt);
    } else {
      paramInt = x(paramCharSequence, paramString, paramInt, 0, paramBoolean, true);
    }
    return paramInt;
  }
  
  public static final int G(CharSequence paramCharSequence, char[] paramArrayOfChar, int paramInt, boolean paramBoolean)
  {
    i.v.d.i.e(paramCharSequence, "<this>");
    i.v.d.i.e(paramArrayOfChar, "chars");
    int i;
    if ((!paramBoolean) && (paramArrayOfChar.length == 1) && ((paramCharSequence instanceof String)))
    {
      i = d.h(paramArrayOfChar);
      return ((String)paramCharSequence).lastIndexOf(i, paramInt);
    }
    for (paramInt = e.c(paramInt, u(paramCharSequence)); -1 < paramInt; paramInt--)
    {
      char c = paramCharSequence.charAt(paramInt);
      int j = paramArrayOfChar.length;
      int k = 0;
      for (int m = 0;; m++)
      {
        i = k;
        if (m >= j) {
          break;
        }
        if (b.d(paramArrayOfChar[m], c, paramBoolean))
        {
          i = 1;
          break;
        }
      }
      if (i != 0) {
        return paramInt;
      }
    }
    return -1;
  }
  
  public static final i.z.b<String> H(CharSequence paramCharSequence)
  {
    i.v.d.i.e(paramCharSequence, "<this>");
    return O(paramCharSequence, new String[] { "\r\n", "\n", "\r" }, false, 0, 6, null);
  }
  
  public static final List<String> I(CharSequence paramCharSequence)
  {
    i.v.d.i.e(paramCharSequence, "<this>");
    return g.e(H(paramCharSequence));
  }
  
  public static final i.z.b<i.x.c> J(CharSequence paramCharSequence, String[] paramArrayOfString, int paramInt1, final boolean paramBoolean, int paramInt2)
  {
    M(paramInt2);
    return new c(paramCharSequence, paramInt1, paramInt2, new a(i.q.c.a(paramArrayOfString), paramBoolean));
  }
  
  public static final boolean L(CharSequence paramCharSequence1, int paramInt1, CharSequence paramCharSequence2, int paramInt2, int paramInt3, boolean paramBoolean)
  {
    i.v.d.i.e(paramCharSequence1, "<this>");
    i.v.d.i.e(paramCharSequence2, "other");
    if ((paramInt2 >= 0) && (paramInt1 >= 0) && (paramInt1 <= paramCharSequence1.length() - paramInt3) && (paramInt2 <= paramCharSequence2.length() - paramInt3))
    {
      for (int i = 0; i < paramInt3; i++) {
        if (!b.d(paramCharSequence1.charAt(paramInt1 + i), paramCharSequence2.charAt(paramInt2 + i), paramBoolean)) {
          return false;
        }
      }
      return true;
    }
    return false;
  }
  
  public static final void M(int paramInt)
  {
    int i;
    if (paramInt >= 0) {
      i = 1;
    } else {
      i = 0;
    }
    if (i != 0) {
      return;
    }
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("Limit must be non-negative, but was ");
    localStringBuilder.append(paramInt);
    throw new IllegalArgumentException(localStringBuilder.toString().toString());
  }
  
  public static final i.z.b<String> N(CharSequence paramCharSequence, String[] paramArrayOfString, boolean paramBoolean, int paramInt)
  {
    i.v.d.i.e(paramCharSequence, "<this>");
    i.v.d.i.e(paramArrayOfString, "delimiters");
    return g.c(K(paramCharSequence, paramArrayOfString, 0, paramBoolean, paramInt, 2, null), new b(paramCharSequence));
  }
  
  public static final String P(CharSequence paramCharSequence, i.x.c paramc)
  {
    i.v.d.i.e(paramCharSequence, "<this>");
    i.v.d.i.e(paramc, "range");
    return paramCharSequence.subSequence(paramc.y().intValue(), paramc.x().intValue() + 1).toString();
  }
  
  public static final String Q(String paramString1, char paramChar, String paramString2)
  {
    i.v.d.i.e(paramString1, "<this>");
    i.v.d.i.e(paramString2, "missingDelimiterValue");
    int i = z(paramString1, paramChar, 0, false, 6, null);
    if (i != -1)
    {
      paramString2 = paramString1.substring(i + 1, paramString1.length());
      i.v.d.i.d(paramString2, "this as java.lang.String…ing(startIndex, endIndex)");
    }
    return paramString2;
  }
  
  public static final String R(String paramString1, String paramString2, String paramString3)
  {
    i.v.d.i.e(paramString1, "<this>");
    i.v.d.i.e(paramString2, "delimiter");
    i.v.d.i.e(paramString3, "missingDelimiterValue");
    int i = A(paramString1, paramString2, 0, false, 6, null);
    if (i != -1)
    {
      paramString3 = paramString1.substring(i + paramString2.length(), paramString1.length());
      i.v.d.i.d(paramString3, "this as java.lang.String…ing(startIndex, endIndex)");
    }
    return paramString3;
  }
  
  public static final String U(String paramString1, char paramChar, String paramString2)
  {
    i.v.d.i.e(paramString1, "<this>");
    i.v.d.i.e(paramString2, "missingDelimiterValue");
    int i = E(paramString1, paramChar, 0, false, 6, null);
    if (i != -1)
    {
      paramString2 = paramString1.substring(i + 1, paramString1.length());
      i.v.d.i.d(paramString2, "this as java.lang.String…ing(startIndex, endIndex)");
    }
    return paramString2;
  }
  
  public static final String W(String paramString1, char paramChar, String paramString2)
  {
    i.v.d.i.e(paramString1, "<this>");
    i.v.d.i.e(paramString2, "missingDelimiterValue");
    int i = z(paramString1, paramChar, 0, false, 6, null);
    if (i != -1)
    {
      paramString2 = paramString1.substring(0, i);
      i.v.d.i.d(paramString2, "this as java.lang.String…ing(startIndex, endIndex)");
    }
    return paramString2;
  }
  
  public static final String X(String paramString1, String paramString2, String paramString3)
  {
    i.v.d.i.e(paramString1, "<this>");
    i.v.d.i.e(paramString2, "delimiter");
    i.v.d.i.e(paramString3, "missingDelimiterValue");
    int i = A(paramString1, paramString2, 0, false, 6, null);
    if (i != -1)
    {
      paramString3 = paramString1.substring(0, i);
      i.v.d.i.d(paramString3, "this as java.lang.String…ing(startIndex, endIndex)");
    }
    return paramString3;
  }
  
  public static final CharSequence a0(CharSequence paramCharSequence)
  {
    i.v.d.i.e(paramCharSequence, "<this>");
    int i = paramCharSequence.length() - 1;
    int j = 0;
    int k = 0;
    while (j <= i)
    {
      int m;
      if (k == 0) {
        m = j;
      } else {
        m = i;
      }
      boolean bool = a.c(paramCharSequence.charAt(m));
      if (k == 0)
      {
        if (!bool) {
          k = 1;
        } else {
          j++;
        }
      }
      else
      {
        if (!bool) {
          break;
        }
        i--;
      }
    }
    return paramCharSequence.subSequence(j, i + 1);
  }
  
  public static final boolean q(CharSequence paramCharSequence1, CharSequence paramCharSequence2, boolean paramBoolean)
  {
    i.v.d.i.e(paramCharSequence1, "<this>");
    i.v.d.i.e(paramCharSequence2, "other");
    boolean bool1 = paramCharSequence2 instanceof String;
    boolean bool2 = true;
    if (bool1)
    {
      if (A(paramCharSequence1, (String)paramCharSequence2, 0, paramBoolean, 2, null) >= 0) {
        return bool2;
      }
    }
    else if (y(paramCharSequence1, paramCharSequence2, 0, paramCharSequence1.length(), paramBoolean, false, 16, null) >= 0) {
      return bool2;
    }
    paramBoolean = false;
    return paramBoolean;
  }
  
  public static final i.i<Integer, String> s(CharSequence paramCharSequence, Collection<String> paramCollection, int paramInt, boolean paramBoolean1, boolean paramBoolean2)
  {
    Object localObject = null;
    if ((!paramBoolean1) && (paramCollection.size() == 1))
    {
      paramCollection = (String)o.o(paramCollection);
      if (!paramBoolean2) {
        paramInt = A(paramCharSequence, paramCollection, paramInt, false, 4, null);
      } else {
        paramInt = F(paramCharSequence, paramCollection, paramInt, false, 4, null);
      }
      if (paramInt < 0) {
        paramCharSequence = (CharSequence)localObject;
      } else {
        paramCharSequence = i.m.a(Integer.valueOf(paramInt), paramCollection);
      }
      return paramCharSequence;
    }
    if (!paramBoolean2) {
      localObject = new i.x.c(e.a(paramInt, 0), paramCharSequence.length());
    } else {
      localObject = e.f(e.c(paramInt, u(paramCharSequence)), 0);
    }
    int i;
    int j;
    int k;
    Iterator localIterator;
    String str;
    if ((paramCharSequence instanceof String))
    {
      i = ((i.x.a)localObject).g();
      j = ((i.x.a)localObject).m();
      k = ((i.x.a)localObject).t();
      if (k > 0)
      {
        paramInt = i;
        if (i <= j) {}
      }
      else
      {
        if ((k >= 0) || (j > i)) {
          break label414;
        }
        paramInt = i;
      }
      for (;;)
      {
        localIterator = paramCollection.iterator();
        while (localIterator.hasNext())
        {
          localObject = localIterator.next();
          str = (String)localObject;
          if (l.m(str, 0, (String)paramCharSequence, paramInt, str.length(), paramBoolean1)) {
            break label234;
          }
        }
        localObject = null;
        label234:
        localObject = (String)localObject;
        if (localObject != null) {
          return i.m.a(Integer.valueOf(paramInt), localObject);
        }
        if (paramInt == j) {
          break;
        }
        paramInt += k;
      }
    }
    else
    {
      i = ((i.x.a)localObject).g();
      j = ((i.x.a)localObject).m();
      k = ((i.x.a)localObject).t();
      if (k > 0)
      {
        paramInt = i;
        if (i <= j) {}
      }
      else
      {
        if ((k >= 0) || (j > i)) {
          break label414;
        }
        paramInt = i;
      }
      for (;;)
      {
        localIterator = paramCollection.iterator();
        while (localIterator.hasNext())
        {
          localObject = localIterator.next();
          str = (String)localObject;
          if (L(str, 0, paramCharSequence, paramInt, str.length(), paramBoolean1)) {
            break label378;
          }
        }
        localObject = null;
        label378:
        localObject = (String)localObject;
        if (localObject != null) {
          return i.m.a(Integer.valueOf(paramInt), localObject);
        }
        if (paramInt == j) {
          break;
        }
        paramInt += k;
      }
    }
    label414:
    return null;
  }
  
  public static final i.x.c t(CharSequence paramCharSequence)
  {
    i.v.d.i.e(paramCharSequence, "<this>");
    return new i.x.c(0, paramCharSequence.length() - 1);
  }
  
  public static final int u(CharSequence paramCharSequence)
  {
    i.v.d.i.e(paramCharSequence, "<this>");
    return paramCharSequence.length() - 1;
  }
  
  public static final int v(CharSequence paramCharSequence, char paramChar, int paramInt, boolean paramBoolean)
  {
    i.v.d.i.e(paramCharSequence, "<this>");
    if ((!paramBoolean) && ((paramCharSequence instanceof String))) {
      paramInt = ((String)paramCharSequence).indexOf(paramChar, paramInt);
    } else {
      paramInt = B(paramCharSequence, new char[] { paramChar }, paramInt, paramBoolean);
    }
    return paramInt;
  }
  
  public static final int w(CharSequence paramCharSequence, String paramString, int paramInt, boolean paramBoolean)
  {
    i.v.d.i.e(paramCharSequence, "<this>");
    i.v.d.i.e(paramString, "string");
    if ((!paramBoolean) && ((paramCharSequence instanceof String))) {
      paramInt = ((String)paramCharSequence).indexOf(paramString, paramInt);
    } else {
      paramInt = y(paramCharSequence, paramString, paramInt, paramCharSequence.length(), paramBoolean, false, 16, null);
    }
    return paramInt;
  }
  
  public static final int x(CharSequence paramCharSequence1, CharSequence paramCharSequence2, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2)
  {
    Object localObject;
    if (!paramBoolean2) {
      localObject = new i.x.c(e.a(paramInt1, 0), e.c(paramInt2, paramCharSequence1.length()));
    } else {
      localObject = e.f(e.c(paramInt1, u(paramCharSequence1)), e.a(paramInt2, 0));
    }
    int i;
    int j;
    if (((paramCharSequence1 instanceof String)) && ((paramCharSequence2 instanceof String)))
    {
      paramInt2 = ((i.x.a)localObject).g();
      i = ((i.x.a)localObject).m();
      j = ((i.x.a)localObject).t();
      if (j > 0)
      {
        paramInt1 = paramInt2;
        if (paramInt2 <= i) {}
      }
      else
      {
        if ((j >= 0) || (i > paramInt2)) {
          break label230;
        }
        paramInt1 = paramInt2;
      }
      for (;;)
      {
        if (l.m((String)paramCharSequence2, 0, (String)paramCharSequence1, paramInt1, paramCharSequence2.length(), paramBoolean1)) {
          return paramInt1;
        }
        if (paramInt1 == i) {
          break;
        }
        paramInt1 += j;
      }
    }
    else
    {
      paramInt2 = ((i.x.a)localObject).g();
      i = ((i.x.a)localObject).m();
      j = ((i.x.a)localObject).t();
      if (j > 0)
      {
        paramInt1 = paramInt2;
        if (paramInt2 <= i) {}
      }
      else
      {
        if ((j >= 0) || (i > paramInt2)) {
          break label230;
        }
        paramInt1 = paramInt2;
      }
      for (;;)
      {
        if (L(paramCharSequence2, 0, paramCharSequence1, paramInt1, paramCharSequence2.length(), paramBoolean1)) {
          return paramInt1;
        }
        if (paramInt1 == i) {
          break;
        }
        paramInt1 += j;
      }
    }
    label230:
    return -1;
  }
  
  public static final class a
    extends j
    implements p<CharSequence, Integer, i.i<? extends Integer, ? extends Integer>>
  {
    public a(List<String> paramList, boolean paramBoolean)
    {
      super();
    }
    
    public final i.i<Integer, Integer> a(CharSequence paramCharSequence, int paramInt)
    {
      i.v.d.i.e(paramCharSequence, "$this$$receiver");
      paramCharSequence = m.p(paramCharSequence, this.g, paramInt, paramBoolean, false);
      if (paramCharSequence != null) {
        paramCharSequence = i.m.a(paramCharSequence.c(), Integer.valueOf(((String)paramCharSequence.d()).length()));
      } else {
        paramCharSequence = null;
      }
      return paramCharSequence;
    }
  }
  
  public static final class b
    extends j
    implements i.v.c.l<i.x.c, String>
  {
    public b(CharSequence paramCharSequence)
    {
      super();
    }
    
    public final String a(i.x.c paramc)
    {
      i.v.d.i.e(paramc, "it");
      return m.P(this.g, paramc);
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/i/a0/m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */