package l;

import java.io.EOFException;
import java.io.IOException;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;

public final class k
  implements t
{
  public final e g;
  public final Inflater h;
  public int i;
  public boolean j;
  
  public k(e parame, Inflater paramInflater)
  {
    if (parame != null)
    {
      if (paramInflater != null)
      {
        this.g = parame;
        this.h = paramInflater;
        return;
      }
      throw new IllegalArgumentException("inflater == null");
    }
    throw new IllegalArgumentException("source == null");
  }
  
  public final boolean a()
  {
    if (!this.h.needsInput()) {
      return false;
    }
    b();
    if (this.h.getRemaining() == 0)
    {
      if (this.g.Q()) {
        return true;
      }
      p localp = this.g.c().h;
      int k = localp.c;
      int m = localp.b;
      k -= m;
      this.i = k;
      this.h.setInput(localp.a, m, k);
      return false;
    }
    throw new IllegalStateException("?");
  }
  
  public final void b()
  {
    int k = this.i;
    if (k == 0) {
      return;
    }
    k -= this.h.getRemaining();
    this.i -= k;
    this.g.z(k);
  }
  
  public void close()
  {
    if (this.j) {
      return;
    }
    this.h.end();
    this.j = true;
    this.g.close();
  }
  
  public long e0(c paramc, long paramLong)
  {
    if (paramLong >= 0L)
    {
      if (!this.j)
      {
        if (paramLong == 0L) {
          return 0L;
        }
        for (;;)
        {
          boolean bool = a();
          try
          {
            p localp = paramc.g0(1);
            int k = (int)Math.min(paramLong, 8192 - localp.c);
            k = this.h.inflate(localp.a, localp.c, k);
            if (k > 0)
            {
              localp.c += k;
              paramLong = paramc.i;
              long l = k;
              paramc.i = (paramLong + l);
              return l;
            }
            if ((!this.h.finished()) && (!this.h.needsDictionary()))
            {
              if (bool)
              {
                paramc = new java/io/EOFException;
                paramc.<init>("source exhausted prematurely");
                throw paramc;
              }
            }
            else
            {
              b();
              if (localp.b == localp.c)
              {
                paramc.h = localp.b();
                q.a(localp);
              }
              return -1L;
            }
          }
          catch (DataFormatException paramc)
          {
            throw new IOException(paramc);
          }
        }
      }
      throw new IllegalStateException("closed");
    }
    paramc = new StringBuilder();
    paramc.append("byteCount < 0: ");
    paramc.append(paramLong);
    paramc = new IllegalArgumentException(paramc.toString());
    for (;;)
    {
      throw paramc;
    }
  }
  
  public u f()
  {
    return this.g.f();
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/l/k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */