package i.a0;

import i.v.d.i;
import i.x.e;

public class o
  extends n
{
  public static final String b0(String paramString, int paramInt)
  {
    i.e(paramString, "<this>");
    int i;
    if (paramInt >= 0) {
      i = 1;
    } else {
      i = 0;
    }
    if (i != 0)
    {
      paramString = paramString.substring(e.c(paramInt, paramString.length()));
      i.d(paramString, "this as java.lang.String).substring(startIndex)");
      return paramString;
    }
    paramString = new StringBuilder();
    paramString.append("Requested character count ");
    paramString.append(paramInt);
    paramString.append(" is less than zero.");
    throw new IllegalArgumentException(paramString.toString().toString());
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/i/a0/o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */