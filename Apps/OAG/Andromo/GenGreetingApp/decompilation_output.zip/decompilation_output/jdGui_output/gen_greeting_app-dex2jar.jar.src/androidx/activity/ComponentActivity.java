package androidx.activity;

import android.app.Activity;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import androidx.savedstate.SavedStateRegistry;
import c.a.c;
import c.f.d.e;
import c.k.f;
import c.k.f.a;
import c.k.f.b;
import c.k.h;
import c.k.j;
import c.k.k;
import c.k.s;
import c.k.w;
import c.k.x;
import c.o.a;
import c.o.b;

public class ComponentActivity
  extends e
  implements j, x, b, c
{
  private int mContentLayoutId;
  private final k mLifecycleRegistry = new k(this);
  private final OnBackPressedDispatcher mOnBackPressedDispatcher = new OnBackPressedDispatcher(new a());
  private final a mSavedStateRegistryController = a.a(this);
  private w mViewModelStore;
  
  public ComponentActivity()
  {
    if (getLifecycle() != null)
    {
      int i = Build.VERSION.SDK_INT;
      if (i >= 19) {
        getLifecycle().a(new h()
        {
          public void a(j paramAnonymousj, f.a paramAnonymousa)
          {
            if (paramAnonymousa == f.a.ON_STOP)
            {
              paramAnonymousj = ComponentActivity.this.getWindow();
              if (paramAnonymousj != null) {
                paramAnonymousj = paramAnonymousj.peekDecorView();
              } else {
                paramAnonymousj = null;
              }
              if (paramAnonymousj != null) {
                paramAnonymousj.cancelPendingInputEvents();
              }
            }
          }
        });
      }
      getLifecycle().a(new h()
      {
        public void a(j paramAnonymousj, f.a paramAnonymousa)
        {
          if ((paramAnonymousa == f.a.ON_DESTROY) && (!ComponentActivity.this.isChangingConfigurations())) {
            ComponentActivity.this.getViewModelStore().a();
          }
        }
      });
      if ((19 <= i) && (i <= 23)) {
        getLifecycle().a(new ImmLeaksCleaner(this));
      }
      return;
    }
    throw new IllegalStateException("getLifecycle() returned null in ComponentActivity's constructor. Please make sure you are lazily constructing your Lifecycle in the first call to getLifecycle() rather than relying on field initialization.");
  }
  
  public ComponentActivity(int paramInt)
  {
    this();
    this.mContentLayoutId = paramInt;
  }
  
  @Deprecated
  public Object getLastCustomNonConfigurationInstance()
  {
    Object localObject = (b)getLastNonConfigurationInstance();
    if (localObject != null) {
      localObject = ((b)localObject).a;
    } else {
      localObject = null;
    }
    return localObject;
  }
  
  public f getLifecycle()
  {
    return this.mLifecycleRegistry;
  }
  
  public final OnBackPressedDispatcher getOnBackPressedDispatcher()
  {
    return this.mOnBackPressedDispatcher;
  }
  
  public final SavedStateRegistry getSavedStateRegistry()
  {
    return this.mSavedStateRegistryController.b();
  }
  
  public w getViewModelStore()
  {
    if (getApplication() != null)
    {
      if (this.mViewModelStore == null)
      {
        b localb = (b)getLastNonConfigurationInstance();
        if (localb != null) {
          this.mViewModelStore = localb.b;
        }
        if (this.mViewModelStore == null) {
          this.mViewModelStore = new w();
        }
      }
      return this.mViewModelStore;
    }
    throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
  }
  
  public void onBackPressed()
  {
    this.mOnBackPressedDispatcher.c();
  }
  
  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    this.mSavedStateRegistryController.c(paramBundle);
    s.g(this);
    int i = this.mContentLayoutId;
    if (i != 0) {
      setContentView(i);
    }
  }
  
  @Deprecated
  public Object onRetainCustomNonConfigurationInstance()
  {
    return null;
  }
  
  public final Object onRetainNonConfigurationInstance()
  {
    Object localObject1 = onRetainCustomNonConfigurationInstance();
    Object localObject2 = this.mViewModelStore;
    Object localObject3 = localObject2;
    if (localObject2 == null)
    {
      b localb = (b)getLastNonConfigurationInstance();
      localObject3 = localObject2;
      if (localb != null) {
        localObject3 = localb.b;
      }
    }
    if ((localObject3 == null) && (localObject1 == null)) {
      return null;
    }
    localObject2 = new b();
    ((b)localObject2).a = localObject1;
    ((b)localObject2).b = ((w)localObject3);
    return localObject2;
  }
  
  public void onSaveInstanceState(Bundle paramBundle)
  {
    f localf = getLifecycle();
    if ((localf instanceof k)) {
      ((k)localf).p(f.b.i);
    }
    super.onSaveInstanceState(paramBundle);
    this.mSavedStateRegistryController.d(paramBundle);
  }
  
  public class a
    implements Runnable
  {
    public a() {}
    
    public void run()
    {
      ComponentActivity.access$001(ComponentActivity.this);
    }
  }
  
  public static final class b
  {
    public Object a;
    public w b;
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/androidx/activity/ComponentActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */