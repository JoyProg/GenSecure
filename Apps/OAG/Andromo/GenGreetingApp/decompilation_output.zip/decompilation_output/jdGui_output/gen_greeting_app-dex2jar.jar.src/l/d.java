package l;

import java.nio.channels.WritableByteChannel;

public abstract interface d
  extends s, WritableByteChannel
{
  public abstract d A(int paramInt);
  
  public abstract d F(int paramInt);
  
  public abstract d R(int paramInt);
  
  public abstract d Z(byte[] paramArrayOfByte);
  
  public abstract c c();
  
  public abstract d d0();
  
  public abstract void flush();
  
  public abstract d j(byte[] paramArrayOfByte, int paramInt1, int paramInt2);
  
  public abstract d r(long paramLong);
  
  public abstract d s0(String paramString);
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/l/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */