package l;

import java.io.EOFException;
import java.nio.ByteBuffer;
import java.nio.channels.ByteChannel;
import java.nio.charset.Charset;

public final class c
  implements e, d, Cloneable, ByteChannel
{
  public static final byte[] g = { 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 97, 98, 99, 100, 101, 102 };
  public p h;
  public long i;
  
  public byte A0()
  {
    long l = this.i;
    if (l != 0L)
    {
      p localp = this.h;
      int j = localp.b;
      int k = localp.c;
      byte[] arrayOfByte = localp.a;
      int m = j + 1;
      byte b = arrayOfByte[j];
      this.i = (l - 1L);
      if (m == k)
      {
        this.h = localp.b();
        q.a(localp);
      }
      else
      {
        localp.b = m;
      }
      return b;
    }
    throw new IllegalStateException("size == 0");
  }
  
  public String B(long paramLong, Charset paramCharset)
  {
    v.b(this.i, 0L, paramLong);
    if (paramCharset != null)
    {
      if (paramLong <= 2147483647L)
      {
        if (paramLong == 0L) {
          return "";
        }
        p localp = this.h;
        if (localp.b + paramLong > localp.c) {
          return new String(T(paramLong), paramCharset);
        }
        paramCharset = new String(localp.a, localp.b, (int)paramLong, paramCharset);
        int j = (int)(localp.b + paramLong);
        localp.b = j;
        this.i -= paramLong;
        if (j == localp.c)
        {
          this.h = localp.b();
          q.a(localp);
        }
        return paramCharset;
      }
      paramCharset = new StringBuilder();
      paramCharset.append("byteCount > Integer.MAX_VALUE: ");
      paramCharset.append(paramLong);
      throw new IllegalArgumentException(paramCharset.toString());
    }
    throw new IllegalArgumentException("charset == null");
  }
  
  public c B0(long paramLong)
  {
    if (paramLong == 0L) {
      return z0(48);
    }
    int j = Long.numberOfTrailingZeros(Long.highestOneBit(paramLong)) / 4 + 1;
    p localp = g0(j);
    byte[] arrayOfByte = localp.a;
    int k = localp.c;
    for (int m = k + j - 1; m >= k; m--)
    {
      arrayOfByte[m] = ((byte)g[((int)(0xF & paramLong))]);
      paramLong >>>= 4;
    }
    localp.c += j;
    this.i += j;
    return this;
  }
  
  public c C0(int paramInt)
  {
    p localp = g0(4);
    byte[] arrayOfByte = localp.a;
    int j = localp.c;
    int k = j + 1;
    arrayOfByte[j] = ((byte)(byte)(paramInt >>> 24 & 0xFF));
    j = k + 1;
    arrayOfByte[k] = ((byte)(byte)(paramInt >>> 16 & 0xFF));
    k = j + 1;
    arrayOfByte[j] = ((byte)(byte)(paramInt >>> 8 & 0xFF));
    arrayOfByte[k] = ((byte)(byte)(paramInt & 0xFF));
    localp.c = (k + 1);
    this.i += 4L;
    return this;
  }
  
  public c D0(int paramInt)
  {
    p localp = g0(2);
    byte[] arrayOfByte = localp.a;
    int j = localp.c;
    int k = j + 1;
    arrayOfByte[j] = ((byte)(byte)(paramInt >>> 8 & 0xFF));
    arrayOfByte[k] = ((byte)(byte)(paramInt & 0xFF));
    localp.c = (k + 1);
    this.i += 2L;
    return this;
  }
  
  public int E()
  {
    long l = this.i;
    if (l >= 4L)
    {
      p localp = this.h;
      int j = localp.b;
      int k = localp.c;
      if (k - j < 4) {
        return (A0() & 0xFF) << 24 | (A0() & 0xFF) << 16 | (A0() & 0xFF) << 8 | A0() & 0xFF;
      }
      localObject = localp.a;
      int m = j + 1;
      j = localObject[j];
      int n = m + 1;
      m = localObject[m];
      int i1 = n + 1;
      n = localObject[n];
      int i2 = i1 + 1;
      i1 = localObject[i1];
      this.i = (l - 4L);
      if (i2 == k)
      {
        this.h = localp.b();
        q.a(localp);
      }
      else
      {
        localp.b = i2;
      }
      return (j & 0xFF) << 24 | (m & 0xFF) << 16 | (n & 0xFF) << 8 | i1 & 0xFF;
    }
    Object localObject = new StringBuilder();
    ((StringBuilder)localObject).append("size < 4: ");
    ((StringBuilder)localObject).append(this.i);
    throw new IllegalStateException(((StringBuilder)localObject).toString());
  }
  
  public c E0(String paramString, int paramInt1, int paramInt2, Charset paramCharset)
  {
    if (paramString != null)
    {
      if (paramInt1 >= 0)
      {
        if (paramInt2 >= paramInt1)
        {
          if (paramInt2 <= paramString.length())
          {
            if (paramCharset != null)
            {
              if (paramCharset.equals(v.a)) {
                return G0(paramString, paramInt1, paramInt2);
              }
              paramString = paramString.substring(paramInt1, paramInt2).getBytes(paramCharset);
              return q0(paramString, 0, paramString.length);
            }
            throw new IllegalArgumentException("charset == null");
          }
          paramCharset = new StringBuilder();
          paramCharset.append("endIndex > string.length: ");
          paramCharset.append(paramInt2);
          paramCharset.append(" > ");
          paramCharset.append(paramString.length());
          throw new IllegalArgumentException(paramCharset.toString());
        }
        paramString = new StringBuilder();
        paramString.append("endIndex < beginIndex: ");
        paramString.append(paramInt2);
        paramString.append(" < ");
        paramString.append(paramInt1);
        throw new IllegalArgumentException(paramString.toString());
      }
      paramString = new StringBuilder();
      paramString.append("beginIndex < 0: ");
      paramString.append(paramInt1);
      throw new IllegalAccessError(paramString.toString());
    }
    throw new IllegalArgumentException("string == null");
  }
  
  public c F0(String paramString)
  {
    return G0(paramString, 0, paramString.length());
  }
  
  public c G0(String paramString, int paramInt1, int paramInt2)
  {
    if (paramString != null)
    {
      if (paramInt1 >= 0)
      {
        if (paramInt2 >= paramInt1)
        {
          if (paramInt2 <= paramString.length())
          {
            while (paramInt1 < paramInt2)
            {
              int j = paramString.charAt(paramInt1);
              int k;
              int n;
              if (j < 128)
              {
                localObject = g0(1);
                byte[] arrayOfByte = ((p)localObject).a;
                k = ((p)localObject).c - paramInt1;
                int m = Math.min(paramInt2, 8192 - k);
                n = paramInt1 + 1;
                arrayOfByte[(paramInt1 + k)] = ((byte)(byte)j);
                for (paramInt1 = n; paramInt1 < m; paramInt1++)
                {
                  n = paramString.charAt(paramInt1);
                  if (n >= 128) {
                    break;
                  }
                  arrayOfByte[(paramInt1 + k)] = ((byte)(byte)n);
                }
                n = ((p)localObject).c;
                k = k + paramInt1 - n;
                ((p)localObject).c = (n + k);
                this.i += k;
              }
              else
              {
                if (j < 2048)
                {
                  z0(j >> 6 | 0xC0);
                  z0(j & 0x3F | 0x80);
                }
                for (;;)
                {
                  paramInt1++;
                  break;
                  if ((j >= 55296) && (j <= 57343))
                  {
                    k = paramInt1 + 1;
                    if (k < paramInt2) {
                      n = paramString.charAt(k);
                    } else {
                      n = 0;
                    }
                    if ((j <= 56319) && (n >= 56320) && (n <= 57343))
                    {
                      n = ((j & 0xFFFF27FF) << 10 | 0xFFFF23FF & n) + 65536;
                      z0(n >> 18 | 0xF0);
                      z0(n >> 12 & 0x3F | 0x80);
                      z0(n >> 6 & 0x3F | 0x80);
                      z0(n & 0x3F | 0x80);
                      paramInt1 += 2;
                      break;
                    }
                    z0(63);
                    paramInt1 = k;
                    break;
                  }
                  z0(j >> 12 | 0xE0);
                  z0(j >> 6 & 0x3F | 0x80);
                  z0(j & 0x3F | 0x80);
                }
              }
            }
            return this;
          }
          Object localObject = new StringBuilder();
          ((StringBuilder)localObject).append("endIndex > string.length: ");
          ((StringBuilder)localObject).append(paramInt2);
          ((StringBuilder)localObject).append(" > ");
          ((StringBuilder)localObject).append(paramString.length());
          throw new IllegalArgumentException(((StringBuilder)localObject).toString());
        }
        paramString = new StringBuilder();
        paramString.append("endIndex < beginIndex: ");
        paramString.append(paramInt2);
        paramString.append(" < ");
        paramString.append(paramInt1);
        throw new IllegalArgumentException(paramString.toString());
      }
      paramString = new StringBuilder();
      paramString.append("beginIndex < 0: ");
      paramString.append(paramInt1);
      throw new IllegalArgumentException(paramString.toString());
    }
    paramString = new IllegalArgumentException("string == null");
    for (;;)
    {
      throw paramString;
    }
  }
  
  public c H0(int paramInt)
  {
    if (paramInt < 128)
    {
      z0(paramInt);
    }
    else if (paramInt < 2048)
    {
      z0(paramInt >> 6 | 0xC0);
      z0(paramInt & 0x3F | 0x80);
    }
    else if (paramInt < 65536)
    {
      if ((paramInt >= 55296) && (paramInt <= 57343))
      {
        z0(63);
      }
      else
      {
        z0(paramInt >> 12 | 0xE0);
        z0(paramInt >> 6 & 0x3F | 0x80);
        z0(paramInt & 0x3F | 0x80);
      }
    }
    else
    {
      if (paramInt > 1114111) {
        break label191;
      }
      z0(paramInt >> 18 | 0xF0);
      z0(paramInt >> 12 & 0x3F | 0x80);
      z0(paramInt >> 6 & 0x3F | 0x80);
      z0(paramInt & 0x3F | 0x80);
    }
    return this;
    label191:
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("Unexpected code point: ");
    localStringBuilder.append(Integer.toHexString(paramInt));
    throw new IllegalArgumentException(localStringBuilder.toString());
  }
  
  public String J()
  {
    return h0(Long.MAX_VALUE);
  }
  
  public byte[] L()
  {
    try
    {
      byte[] arrayOfByte = T(this.i);
      return arrayOfByte;
    }
    catch (EOFException localEOFException)
    {
      throw new AssertionError(localEOFException);
    }
  }
  
  public int N()
  {
    return v.c(E());
  }
  
  public c O()
  {
    return this;
  }
  
  public String P()
  {
    try
    {
      String str = B(this.i, v.a);
      return str;
    }
    catch (EOFException localEOFException)
    {
      throw new AssertionError(localEOFException);
    }
  }
  
  public boolean Q()
  {
    boolean bool;
    if (this.i == 0L) {
      bool = true;
    } else {
      bool = false;
    }
    return bool;
  }
  
  public byte[] T(long paramLong)
  {
    v.b(this.i, 0L, paramLong);
    if (paramLong <= 2147483647L)
    {
      localObject = new byte[(int)paramLong];
      p((byte[])localObject);
      return (byte[])localObject;
    }
    Object localObject = new StringBuilder();
    ((StringBuilder)localObject).append("byteCount > Integer.MAX_VALUE: ");
    ((StringBuilder)localObject).append(paramLong);
    throw new IllegalArgumentException(((StringBuilder)localObject).toString());
  }
  
  public String V(long paramLong)
  {
    return B(paramLong, v.a);
  }
  
  public String W(long paramLong)
  {
    if (paramLong > 0L)
    {
      long l = paramLong - 1L;
      if (o(l) == 13)
      {
        str = V(l);
        z(2L);
        return str;
      }
    }
    String str = V(paramLong);
    z(1L);
    return str;
  }
  
  public final void a()
  {
    try
    {
      z(this.i);
      return;
    }
    catch (EOFException localEOFException)
    {
      throw new AssertionError(localEOFException);
    }
  }
  
  public final long a0()
  {
    return this.i;
  }
  
  public c b()
  {
    c localc = new c();
    if (this.i == 0L) {
      return localc;
    }
    p localp = this.h.d();
    localc.h = localp;
    localp.g = localp;
    localp.f = localp;
    localp = this.h;
    for (;;)
    {
      localp = localp.f;
      if (localp == this.h) {
        break;
      }
      localc.h.g.c(localp.d());
    }
    localc.i = this.i;
    return localc;
  }
  
  public short b0()
  {
    return v.d(j0());
  }
  
  public c c()
  {
    return this;
  }
  
  public final f c0()
  {
    long l = this.i;
    if (l <= 2147483647L) {
      return f0((int)l);
    }
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("size > Integer.MAX_VALUE: ");
    localStringBuilder.append(this.i);
    throw new IllegalArgumentException(localStringBuilder.toString());
  }
  
  public void close() {}
  
  public final long d()
  {
    long l1 = this.i;
    if (l1 == 0L) {
      return 0L;
    }
    p localp = this.h.g;
    int j = localp.c;
    long l2 = l1;
    if (j < 8192)
    {
      l2 = l1;
      if (localp.e) {
        l2 = l1 - (j - localp.b);
      }
    }
    return l2;
  }
  
  public long e0(c paramc, long paramLong)
  {
    if (paramc != null)
    {
      if (paramLong >= 0L)
      {
        long l1 = this.i;
        if (l1 == 0L) {
          return -1L;
        }
        long l2 = paramLong;
        if (paramLong > l1) {
          l2 = l1;
        }
        paramc.n(this, l2);
        return l2;
      }
      paramc = new StringBuilder();
      paramc.append("byteCount < 0: ");
      paramc.append(paramLong);
      throw new IllegalArgumentException(paramc.toString());
    }
    throw new IllegalArgumentException("sink == null");
  }
  
  public boolean equals(Object paramObject)
  {
    if (this == paramObject) {
      return true;
    }
    if (!(paramObject instanceof c)) {
      return false;
    }
    paramObject = (c)paramObject;
    long l1 = this.i;
    if (l1 != ((c)paramObject).i) {
      return false;
    }
    long l2 = 0L;
    if (l1 == 0L) {
      return true;
    }
    Object localObject1 = this.h;
    paramObject = ((c)paramObject).h;
    int j = ((p)localObject1).b;
    int k = ((p)paramObject).b;
    while (l2 < this.i)
    {
      l1 = Math.min(((p)localObject1).c - j, ((p)paramObject).c - k);
      int m = 0;
      while (m < l1)
      {
        if (localObject1.a[j] != paramObject.a[k]) {
          return false;
        }
        m++;
        j++;
        k++;
      }
      Object localObject2 = localObject1;
      m = j;
      if (j == ((p)localObject1).c)
      {
        localObject2 = ((p)localObject1).f;
        m = ((p)localObject2).b;
      }
      int n = k;
      Object localObject3 = paramObject;
      if (k == ((p)paramObject).c)
      {
        localObject3 = ((p)paramObject).f;
        n = ((p)localObject3).b;
      }
      l2 += l1;
      localObject1 = localObject2;
      j = m;
      k = n;
      paramObject = localObject3;
    }
    return true;
  }
  
  public u f()
  {
    return u.a;
  }
  
  public final f f0(int paramInt)
  {
    if (paramInt == 0) {
      return f.h;
    }
    return new r(this, paramInt);
  }
  
  public void flush() {}
  
  public p g0(int paramInt)
  {
    if ((paramInt >= 1) && (paramInt <= 8192))
    {
      Object localObject = this.h;
      if (localObject == null)
      {
        localObject = q.b();
        this.h = ((p)localObject);
        ((p)localObject).g = ((p)localObject);
        ((p)localObject).f = ((p)localObject);
        return (p)localObject;
      }
      p localp = ((p)localObject).g;
      if (localp.c + paramInt <= 8192)
      {
        localObject = localp;
        if (localp.e) {}
      }
      else
      {
        localObject = localp.c(q.b());
      }
      return (p)localObject;
    }
    throw new IllegalArgumentException();
  }
  
  public final c h(c paramc, long paramLong1, long paramLong2)
  {
    if (paramc != null)
    {
      v.b(this.i, paramLong1, paramLong2);
      if (paramLong2 == 0L) {
        return this;
      }
      paramc.i += paramLong2;
      int k;
      p localp2;
      long l1;
      long l2;
      for (p localp1 = this.h;; localp1 = localp1.f)
      {
        int j = localp1.c;
        k = localp1.b;
        localp2 = localp1;
        l1 = paramLong1;
        l2 = paramLong2;
        if (paramLong1 < j - k) {
          break;
        }
        paramLong1 -= j - k;
      }
      while (l2 > 0L)
      {
        p localp3 = localp2.d();
        k = (int)(localp3.b + l1);
        localp3.b = k;
        localp3.c = Math.min(k + (int)l2, localp3.c);
        localp1 = paramc.h;
        if (localp1 == null)
        {
          localp3.g = localp3;
          localp3.f = localp3;
          paramc.h = localp3;
        }
        else
        {
          localp1.g.c(localp3);
        }
        l2 -= localp3.c - localp3.b;
        localp2 = localp2.f;
        l1 = 0L;
      }
      return this;
    }
    paramc = new IllegalArgumentException("out == null");
    for (;;)
    {
      throw paramc;
    }
  }
  
  public String h0(long paramLong)
  {
    if (paramLong >= 0L)
    {
      long l1 = Long.MAX_VALUE;
      if (paramLong != Long.MAX_VALUE) {
        l1 = paramLong + 1L;
      }
      long l2 = q((byte)10, 0L, l1);
      if (l2 != -1L) {
        return W(l2);
      }
      if ((l1 < a0()) && (o(l1 - 1L) == 13) && (o(l1) == 10)) {
        return W(l1);
      }
      c localc = new c();
      h(localc, 0L, Math.min(32L, a0()));
      localStringBuilder = new StringBuilder();
      localStringBuilder.append("\\n not found: limit=");
      localStringBuilder.append(Math.min(a0(), paramLong));
      localStringBuilder.append(" content=");
      localStringBuilder.append(localc.u().r());
      localStringBuilder.append('…');
      throw new EOFException(localStringBuilder.toString());
    }
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("limit < 0: ");
    localStringBuilder.append(paramLong);
    throw new IllegalArgumentException(localStringBuilder.toString());
  }
  
  public int hashCode()
  {
    Object localObject = this.h;
    if (localObject == null) {
      return 0;
    }
    int j = 1;
    int n;
    p localp;
    do
    {
      int k = ((p)localObject).b;
      int m = ((p)localObject).c;
      n = j;
      while (k < m)
      {
        n = n * 31 + localObject.a[k];
        k++;
      }
      localp = ((p)localObject).f;
      localObject = localp;
      j = n;
    } while (localp != this.h);
    return n;
  }
  
  public c i()
  {
    return this;
  }
  
  public boolean isOpen()
  {
    return true;
  }
  
  public short j0()
  {
    long l = this.i;
    if (l >= 2L)
    {
      p localp = this.h;
      int j = localp.b;
      int k = localp.c;
      if (k - j < 2) {
        return (short)((A0() & 0xFF) << 8 | A0() & 0xFF);
      }
      localObject = localp.a;
      int m = j + 1;
      j = localObject[j];
      int n = m + 1;
      m = localObject[m];
      this.i = (l - 2L);
      if (n == k)
      {
        this.h = localp.b();
        q.a(localp);
      }
      else
      {
        localp.b = n;
      }
      return (short)((j & 0xFF) << 8 | m & 0xFF);
    }
    Object localObject = new StringBuilder();
    ((StringBuilder)localObject).append("size < 2: ");
    ((StringBuilder)localObject).append(this.i);
    throw new IllegalStateException(((StringBuilder)localObject).toString());
  }
  
  public c m0(f paramf)
  {
    if (paramf != null)
    {
      paramf.D(this);
      return this;
    }
    throw new IllegalArgumentException("byteString == null");
  }
  
  public void n(c paramc, long paramLong)
  {
    if (paramc != null)
    {
      if (paramc != this)
      {
        v.b(paramc.i, 0L, paramLong);
        while (paramLong > 0L)
        {
          p localp1 = paramc.h;
          if (paramLong < localp1.c - localp1.b)
          {
            localp2 = this.h;
            if (localp2 != null) {
              localp2 = localp2.g;
            } else {
              localp2 = null;
            }
            if ((localp2 != null) && (localp2.e))
            {
              l = localp2.c;
              int j;
              if (localp2.d) {
                j = 0;
              } else {
                j = localp2.b;
              }
              if (l + paramLong - j <= 8192L)
              {
                localp1.f(localp2, (int)paramLong);
                paramc.i -= paramLong;
                this.i += paramLong;
                return;
              }
            }
            paramc.h = localp1.e((int)paramLong);
          }
          localp1 = paramc.h;
          long l = localp1.c - localp1.b;
          paramc.h = localp1.b();
          p localp2 = this.h;
          if (localp2 == null)
          {
            this.h = localp1;
            localp1.g = localp1;
            localp1.f = localp1;
          }
          else
          {
            localp2.g.c(localp1).a();
          }
          paramc.i -= l;
          this.i += l;
          paramLong -= l;
        }
        return;
      }
      throw new IllegalArgumentException("source == this");
    }
    paramc = new IllegalArgumentException("source == null");
    for (;;)
    {
      throw paramc;
    }
  }
  
  public final byte o(long paramLong)
  {
    v.b(this.i, paramLong, 1L);
    long l = this.i;
    int j;
    int k;
    if (l - paramLong > paramLong) {
      for (localObject = this.h;; localObject = ((p)localObject).f)
      {
        j = ((p)localObject).c;
        k = ((p)localObject).b;
        l = j - k;
        if (paramLong < l) {
          return localObject.a[(k + (int)paramLong)];
        }
        paramLong -= l;
      }
    }
    paramLong -= l;
    Object localObject = this.h;
    p localp;
    do
    {
      localp = ((p)localObject).g;
      k = localp.c;
      j = localp.b;
      l = paramLong + (k - j);
      localObject = localp;
      paramLong = l;
    } while (l < 0L);
    return localp.a[(j + (int)l)];
  }
  
  public c o0(byte[] paramArrayOfByte)
  {
    if (paramArrayOfByte != null) {
      return q0(paramArrayOfByte, 0, paramArrayOfByte.length);
    }
    throw new IllegalArgumentException("source == null");
  }
  
  public void p(byte[] paramArrayOfByte)
  {
    int j = 0;
    while (j < paramArrayOfByte.length)
    {
      int k = s(paramArrayOfByte, j, paramArrayOfByte.length - j);
      if (k != -1) {
        j += k;
      } else {
        throw new EOFException();
      }
    }
  }
  
  public void p0(long paramLong)
  {
    if (this.i >= paramLong) {
      return;
    }
    throw new EOFException();
  }
  
  public long q(byte paramByte, long paramLong1, long paramLong2)
  {
    long l1 = 0L;
    if ((paramLong1 >= 0L) && (paramLong2 >= paramLong1))
    {
      long l2 = this.i;
      long l3;
      if (paramLong2 > l2) {
        l3 = l2;
      } else {
        l3 = paramLong2;
      }
      if (paramLong1 == l3) {
        return -1L;
      }
      localObject1 = this.h;
      if (localObject1 == null) {
        return -1L;
      }
      paramLong2 = l1;
      Object localObject2 = localObject1;
      if (l2 - paramLong1 < paramLong1) {
        for (;;)
        {
          paramLong2 = l2;
          localObject2 = localObject1;
          if (l2 <= paramLong1) {
            break;
          }
          localObject1 = ((p)localObject1).g;
          l2 -= ((p)localObject1).c - ((p)localObject1).b;
        }
      }
      for (;;)
      {
        l2 = ((p)localObject2).c - ((p)localObject2).b + paramLong2;
        if (l2 >= paramLong1) {
          break;
        }
        localObject2 = ((p)localObject2).f;
        paramLong2 = l2;
      }
      while (paramLong2 < l3)
      {
        localObject1 = ((p)localObject2).a;
        int j = (int)Math.min(((p)localObject2).c, ((p)localObject2).b + l3 - paramLong2);
        for (int k = (int)(((p)localObject2).b + paramLong1 - paramLong2); k < j; k++) {
          if (localObject1[k] == paramByte) {
            return k - ((p)localObject2).b + paramLong2;
          }
        }
        paramLong2 += ((p)localObject2).c - ((p)localObject2).b;
        localObject2 = ((p)localObject2).f;
        paramLong1 = paramLong2;
      }
      return -1L;
    }
    Object localObject1 = new IllegalArgumentException(String.format("size=%s fromIndex=%s toIndex=%s", new Object[] { Long.valueOf(this.i), Long.valueOf(paramLong1), Long.valueOf(paramLong2) }));
    for (;;)
    {
      throw ((Throwable)localObject1);
    }
  }
  
  public c q0(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    if (paramArrayOfByte != null)
    {
      long l1 = paramArrayOfByte.length;
      long l2 = paramInt1;
      long l3 = paramInt2;
      v.b(l1, l2, l3);
      paramInt2 += paramInt1;
      while (paramInt1 < paramInt2)
      {
        p localp = g0(1);
        int j = Math.min(paramInt2 - paramInt1, 8192 - localp.c);
        System.arraycopy(paramArrayOfByte, paramInt1, localp.a, localp.c, j);
        paramInt1 += j;
        localp.c += j;
      }
      this.i += l3;
      return this;
    }
    paramArrayOfByte = new IllegalArgumentException("source == null");
    for (;;)
    {
      throw paramArrayOfByte;
    }
  }
  
  public long r0(t paramt)
  {
    if (paramt != null)
    {
      long l2;
      for (long l1 = 0L;; l1 += l2)
      {
        l2 = paramt.e0(this, 8192L);
        if (l2 == -1L) {
          break;
        }
      }
      return l1;
    }
    paramt = new IllegalArgumentException("source == null");
    for (;;)
    {
      throw paramt;
    }
  }
  
  public int read(ByteBuffer paramByteBuffer)
  {
    p localp = this.h;
    if (localp == null) {
      return -1;
    }
    int j = Math.min(paramByteBuffer.remaining(), localp.c - localp.b);
    paramByteBuffer.put(localp.a, localp.b, j);
    int k = localp.b + j;
    localp.b = k;
    this.i -= j;
    if (k == localp.c)
    {
      this.h = localp.b();
      q.a(localp);
    }
    return j;
  }
  
  public int s(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    v.b(paramArrayOfByte.length, paramInt1, paramInt2);
    p localp = this.h;
    if (localp == null) {
      return -1;
    }
    paramInt2 = Math.min(paramInt2, localp.c - localp.b);
    System.arraycopy(localp.a, localp.b, paramArrayOfByte, paramInt1, paramInt2);
    paramInt1 = localp.b + paramInt2;
    localp.b = paramInt1;
    this.i -= paramInt2;
    if (paramInt1 == localp.c)
    {
      this.h = localp.b();
      q.a(localp);
    }
    return paramInt2;
  }
  
  public String toString()
  {
    return c0().toString();
  }
  
  public f u()
  {
    return new f(L());
  }
  
  public f w(long paramLong)
  {
    return new f(T(paramLong));
  }
  
  public long w0(byte paramByte)
  {
    return q(paramByte, 0L, Long.MAX_VALUE);
  }
  
  public int write(ByteBuffer paramByteBuffer)
  {
    if (paramByteBuffer != null)
    {
      int j = paramByteBuffer.remaining();
      int k = j;
      while (k > 0)
      {
        p localp = g0(1);
        int m = Math.min(k, 8192 - localp.c);
        paramByteBuffer.get(localp.a, localp.c, m);
        k -= m;
        localp.c += m;
      }
      this.i += j;
      return j;
    }
    paramByteBuffer = new IllegalArgumentException("source == null");
    for (;;)
    {
      throw paramByteBuffer;
    }
  }
  
  public long y0()
  {
    if (this.i != 0L)
    {
      int j = 0;
      long l1 = 0L;
      int k = 0;
      long l2;
      int i1;
      label229:
      label282:
      do
      {
        Object localObject1 = this.h;
        localObject2 = ((p)localObject1).a;
        int m = ((p)localObject1).b;
        int n = ((p)localObject1).c;
        l2 = l1;
        int i2;
        for (i1 = j;; i1++)
        {
          i2 = k;
          if (m >= n) {
            break label282;
          }
          i2 = localObject2[m];
          if ((i2 >= 48) && (i2 <= 57))
          {
            j = i2 - 48;
          }
          else
          {
            if ((i2 >= 97) && (i2 <= 102)) {}
            for (j = i2 - 97;; j = i2 - 65)
            {
              j += 10;
              break;
              if ((i2 < 65) || (i2 > 70)) {
                break label229;
              }
            }
          }
          if ((0xF000000000000000 & l2) != 0L) {
            break;
          }
          l2 = l2 << 4 | j;
          m++;
        }
        localObject1 = new c().B0(l2).z0(i2);
        localObject2 = new StringBuilder();
        ((StringBuilder)localObject2).append("Number too large: ");
        ((StringBuilder)localObject2).append(((c)localObject1).P());
        throw new NumberFormatException(((StringBuilder)localObject2).toString());
        if (i1 != 0)
        {
          i2 = 1;
        }
        else
        {
          localObject2 = new StringBuilder();
          ((StringBuilder)localObject2).append("Expected leading [0-9a-fA-F] character but was 0x");
          ((StringBuilder)localObject2).append(Integer.toHexString(i2));
          throw new NumberFormatException(((StringBuilder)localObject2).toString());
        }
        if (m == n)
        {
          this.h = ((p)localObject1).b();
          q.a((p)localObject1);
        }
        else
        {
          ((p)localObject1).b = m;
        }
        if (i2 != 0) {
          break;
        }
        j = i1;
        k = i2;
        l1 = l2;
      } while (this.h != null);
      this.i -= i1;
      return l2;
    }
    Object localObject2 = new IllegalStateException("size == 0");
    for (;;)
    {
      throw ((Throwable)localObject2);
    }
  }
  
  public void z(long paramLong)
  {
    while (paramLong > 0L)
    {
      p localp = this.h;
      if (localp != null)
      {
        int j = (int)Math.min(paramLong, localp.c - localp.b);
        long l1 = this.i;
        long l2 = j;
        this.i = (l1 - l2);
        l1 = paramLong - l2;
        localp = this.h;
        j = localp.b + j;
        localp.b = j;
        paramLong = l1;
        if (j == localp.c)
        {
          this.h = localp.b();
          q.a(localp);
          paramLong = l1;
        }
      }
      else
      {
        throw new EOFException();
      }
    }
  }
  
  public c z0(int paramInt)
  {
    p localp = g0(1);
    byte[] arrayOfByte = localp.a;
    int j = localp.c;
    localp.c = (j + 1);
    arrayOfByte[j] = ((byte)(byte)paramInt);
    this.i += 1L;
    return this;
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/l/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */