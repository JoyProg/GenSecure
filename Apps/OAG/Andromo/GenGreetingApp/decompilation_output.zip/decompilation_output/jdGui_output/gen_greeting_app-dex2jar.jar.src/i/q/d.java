package i.q;

import i.v.d.i;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.NoSuchElementException;

public class d
  extends c
{
  public static final <T> T g(T[] paramArrayOfT)
  {
    i.e(paramArrayOfT, "<this>");
    int i;
    if (paramArrayOfT.length == 0) {
      i = 1;
    } else {
      i = 0;
    }
    if (i == 0) {
      return paramArrayOfT[0];
    }
    throw new NoSuchElementException("Array is empty.");
  }
  
  public static final char h(char[] paramArrayOfChar)
  {
    i.e(paramArrayOfChar, "<this>");
    int i = paramArrayOfChar.length;
    if (i != 0)
    {
      if (i == 1) {
        return paramArrayOfChar[0];
      }
      throw new IllegalArgumentException("Array has more than one element.");
    }
    throw new NoSuchElementException("Array is empty.");
  }
  
  public static final <T> T i(T[] paramArrayOfT)
  {
    i.e(paramArrayOfT, "<this>");
    if (paramArrayOfT.length == 1) {
      paramArrayOfT = paramArrayOfT[0];
    } else {
      paramArrayOfT = null;
    }
    return paramArrayOfT;
  }
  
  public static final <T> T[] j(T[] paramArrayOfT, Comparator<? super T> paramComparator)
  {
    i.e(paramArrayOfT, "<this>");
    i.e(paramComparator, "comparator");
    int i;
    if (paramArrayOfT.length == 0) {
      i = 1;
    } else {
      i = 0;
    }
    if (i != 0) {
      return paramArrayOfT;
    }
    paramArrayOfT = Arrays.copyOf(paramArrayOfT, paramArrayOfT.length);
    i.d(paramArrayOfT, "copyOf(this, size)");
    c.f(paramArrayOfT, paramComparator);
    return paramArrayOfT;
  }
  
  public static final <T> List<T> k(T[] paramArrayOfT, Comparator<? super T> paramComparator)
  {
    i.e(paramArrayOfT, "<this>");
    i.e(paramComparator, "comparator");
    return c.a(j(paramArrayOfT, paramComparator));
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/i/q/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */