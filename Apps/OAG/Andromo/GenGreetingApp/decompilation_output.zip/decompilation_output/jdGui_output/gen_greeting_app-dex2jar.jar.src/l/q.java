package l;

public final class q
{
  public static p a;
  public static long b;
  
  public static void a(p paramp)
  {
    if ((paramp.f == null) && (paramp.g == null))
    {
      if (paramp.d) {
        return;
      }
      try
      {
        long l = b;
        if (l + 8192L > 65536L) {
          return;
        }
        b = l + 8192L;
        paramp.f = a;
        paramp.c = 0;
        paramp.b = 0;
        a = paramp;
        return;
      }
      finally {}
    }
    throw new IllegalArgumentException();
  }
  
  public static p b()
  {
    try
    {
      p localp = a;
      if (localp != null)
      {
        a = localp.f;
        localp.f = null;
        b -= 8192L;
        return localp;
      }
      return new p();
    }
    finally {}
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/l/q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */