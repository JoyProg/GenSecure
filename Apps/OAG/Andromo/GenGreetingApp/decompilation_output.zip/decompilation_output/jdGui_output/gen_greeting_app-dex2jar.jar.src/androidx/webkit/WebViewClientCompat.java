package androidx.webkit;

import android.app.PendingIntent;
import android.os.Build.VERSION;
import android.webkit.SafeBrowsingResponse;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import c.w.b;
import c.w.i;
import c.w.k;
import c.w.n.l;
import c.w.n.t;
import c.w.n.u;
import java.lang.reflect.InvocationHandler;
import org.chromium.support_lib_boundary.WebViewClientBoundaryInterface;

public class WebViewClientCompat
  extends WebViewClient
  implements WebViewClientBoundaryInterface
{
  public static final String[] g = { "VISUAL_STATE_CALLBACK", "RECEIVE_WEB_RESOURCE_ERROR", "RECEIVE_HTTP_ERROR", "SHOULD_OVERRIDE_WITH_REDIRECTS", "SAFE_BROWSING_HIT" };
  
  public void b(WebView paramWebView, WebResourceRequest paramWebResourceRequest, i parami)
  {
    throw null;
  }
  
  public void c(WebView paramWebView, WebResourceRequest paramWebResourceRequest, int paramInt, b paramb)
  {
    if (k.a("SAFE_BROWSING_RESPONSE_SHOW_INTERSTITIAL"))
    {
      paramb.a(true);
      return;
    }
    throw u.a();
  }
  
  public final String[] getSupportedFeatures()
  {
    return g;
  }
  
  public void onPageCommitVisible(WebView paramWebView, String paramString) {}
  
  public final void onReceivedError(WebView paramWebView, WebResourceRequest paramWebResourceRequest, WebResourceError paramWebResourceError)
  {
    if (Build.VERSION.SDK_INT < 23) {
      return;
    }
    b(paramWebView, paramWebResourceRequest, new t(paramWebResourceError));
  }
  
  public final void onReceivedError(WebView paramWebView, WebResourceRequest paramWebResourceRequest, InvocationHandler paramInvocationHandler)
  {
    b(paramWebView, paramWebResourceRequest, new t(paramInvocationHandler));
  }
  
  public void onReceivedHttpError(WebView paramWebView, WebResourceRequest paramWebResourceRequest, WebResourceResponse paramWebResourceResponse) {}
  
  public final void onSafeBrowsingHit(WebView paramWebView, WebResourceRequest paramWebResourceRequest, int paramInt, SafeBrowsingResponse paramSafeBrowsingResponse)
  {
    c(paramWebView, paramWebResourceRequest, paramInt, new l(paramSafeBrowsingResponse));
  }
  
  public final void onSafeBrowsingHit(WebView paramWebView, WebResourceRequest paramWebResourceRequest, int paramInt, InvocationHandler paramInvocationHandler)
  {
    c(paramWebView, paramWebResourceRequest, paramInt, new l(paramInvocationHandler));
  }
  
  public boolean onWebAuthnIntent(WebView paramWebView, PendingIntent paramPendingIntent, InvocationHandler paramInvocationHandler)
  {
    return false;
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/androidx/webkit/WebViewClientCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */