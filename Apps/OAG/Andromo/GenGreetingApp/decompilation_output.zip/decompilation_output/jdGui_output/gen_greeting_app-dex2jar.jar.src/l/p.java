package l;

public final class p
{
  public final byte[] a;
  public int b;
  public int c;
  public boolean d;
  public boolean e;
  public p f;
  public p g;
  
  public p()
  {
    this.a = new byte[' '];
    this.e = true;
    this.d = false;
  }
  
  public p(byte[] paramArrayOfByte, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2)
  {
    this.a = paramArrayOfByte;
    this.b = paramInt1;
    this.c = paramInt2;
    this.d = paramBoolean1;
    this.e = paramBoolean2;
  }
  
  public final void a()
  {
    p localp = this.g;
    if (localp != this)
    {
      if (!localp.e) {
        return;
      }
      int i = this.c - this.b;
      int j = localp.c;
      int k;
      if (localp.d) {
        k = 0;
      } else {
        k = localp.b;
      }
      if (i > 8192 - j + k) {
        return;
      }
      f(localp, i);
      b();
      q.a(this);
      return;
    }
    throw new IllegalStateException();
  }
  
  public final p b()
  {
    p localp1 = this.f;
    p localp2;
    if (localp1 != this) {
      localp2 = localp1;
    } else {
      localp2 = null;
    }
    p localp3 = this.g;
    localp3.f = localp1;
    this.f.g = localp3;
    this.f = null;
    this.g = null;
    return localp2;
  }
  
  public final p c(p paramp)
  {
    paramp.g = this;
    paramp.f = this.f;
    this.f.g = paramp;
    this.f = paramp;
    return paramp;
  }
  
  public final p d()
  {
    this.d = true;
    return new p(this.a, this.b, this.c, true, false);
  }
  
  public final p e(int paramInt)
  {
    if ((paramInt > 0) && (paramInt <= this.c - this.b))
    {
      p localp;
      if (paramInt >= 1024)
      {
        localp = d();
      }
      else
      {
        localp = q.b();
        System.arraycopy(this.a, this.b, localp.a, 0, paramInt);
      }
      localp.c = (localp.b + paramInt);
      this.b += paramInt;
      this.g.c(localp);
      return localp;
    }
    throw new IllegalArgumentException();
  }
  
  public final void f(p paramp, int paramInt)
  {
    if (paramp.e)
    {
      int i = paramp.c;
      if (i + paramInt > 8192) {
        if (!paramp.d)
        {
          int j = paramp.b;
          if (i + paramInt - j <= 8192)
          {
            byte[] arrayOfByte = paramp.a;
            System.arraycopy(arrayOfByte, j, arrayOfByte, 0, i - j);
            paramp.c -= paramp.b;
            paramp.b = 0;
          }
          else
          {
            throw new IllegalArgumentException();
          }
        }
        else
        {
          throw new IllegalArgumentException();
        }
      }
      System.arraycopy(this.a, this.b, paramp.a, paramp.c, paramInt);
      paramp.c += paramInt;
      this.b += paramInt;
      return;
    }
    throw new IllegalArgumentException();
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/l/p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */