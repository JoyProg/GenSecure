package i;

import i.v.c.a;
import i.v.d.i;

public class g
{
  public static final <T> f<T> a(a<? extends T> parama)
  {
    i.e(parama, "initializer");
    return new l(parama, null, 2, null);
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/i/g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */