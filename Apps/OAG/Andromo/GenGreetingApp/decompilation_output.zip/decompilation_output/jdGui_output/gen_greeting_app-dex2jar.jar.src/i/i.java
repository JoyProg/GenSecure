package i;

import java.io.Serializable;

public final class i<A, B>
  implements Serializable
{
  public final A g;
  public final B h;
  
  public i(A paramA, B paramB)
  {
    this.g = paramA;
    this.h = paramB;
  }
  
  public final A a()
  {
    return (A)this.g;
  }
  
  public final B b()
  {
    return (B)this.h;
  }
  
  public final A c()
  {
    return (A)this.g;
  }
  
  public final B d()
  {
    return (B)this.h;
  }
  
  public boolean equals(Object paramObject)
  {
    if (this == paramObject) {
      return true;
    }
    if (!(paramObject instanceof i)) {
      return false;
    }
    paramObject = (i)paramObject;
    if (!i.v.d.i.a(this.g, ((i)paramObject).g)) {
      return false;
    }
    return i.v.d.i.a(this.h, ((i)paramObject).h);
  }
  
  public int hashCode()
  {
    Object localObject = this.g;
    int i = 0;
    int j;
    if (localObject == null) {
      j = 0;
    } else {
      j = localObject.hashCode();
    }
    localObject = this.h;
    if (localObject != null) {
      i = localObject.hashCode();
    }
    return j * 31 + i;
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append('(');
    localStringBuilder.append(this.g);
    localStringBuilder.append(", ");
    localStringBuilder.append(this.h);
    localStringBuilder.append(')');
    return localStringBuilder.toString();
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/i/i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */