package i;

import i.v.d.i;
import java.io.Serializable;

public final class j<T>
  implements Serializable
{
  public static final a g = new a(null);
  
  public static <T> Object a(Object paramObject)
  {
    return paramObject;
  }
  
  public static final Throwable b(Object paramObject)
  {
    if ((paramObject instanceof b)) {
      paramObject = ((b)paramObject).g;
    } else {
      paramObject = null;
    }
    return (Throwable)paramObject;
  }
  
  public static final boolean c(Object paramObject)
  {
    return paramObject instanceof b;
  }
  
  public static final boolean d(Object paramObject)
  {
    return paramObject instanceof b ^ true;
  }
  
  public static final class a {}
  
  public static final class b
    implements Serializable
  {
    public final Throwable g;
    
    public b(Throwable paramThrowable)
    {
      this.g = paramThrowable;
    }
    
    public boolean equals(Object paramObject)
    {
      boolean bool;
      if (((paramObject instanceof b)) && (i.a(this.g, ((b)paramObject).g))) {
        bool = true;
      } else {
        bool = false;
      }
      return bool;
    }
    
    public int hashCode()
    {
      return this.g.hashCode();
    }
    
    public String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append("Failure(");
      localStringBuilder.append(this.g);
      localStringBuilder.append(')');
      return localStringBuilder.toString();
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/i/j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */