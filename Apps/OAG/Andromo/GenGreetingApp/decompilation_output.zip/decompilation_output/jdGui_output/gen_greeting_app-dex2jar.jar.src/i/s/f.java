package i.s;

import i.j;
import i.s.i.b;
import i.v.d.i;

public final class f
{
  public static final <R, T> void a(i.v.c.p<? super R, ? super d<? super T>, ? extends Object> paramp, R paramR, d<? super T> paramd)
  {
    i.e(paramp, "<this>");
    i.e(paramd, "completion");
    paramp = b.b(b.a(paramp, paramR, paramd));
    paramR = j.g;
    paramp.resumeWith(j.a(i.p.a));
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/i/s/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */