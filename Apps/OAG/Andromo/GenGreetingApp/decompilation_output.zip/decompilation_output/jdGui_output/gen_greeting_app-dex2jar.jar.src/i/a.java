package i;

import i.t.b;
import i.v.d.i;

public class a
{
  public static final void a(Throwable paramThrowable1, Throwable paramThrowable2)
  {
    i.e(paramThrowable1, "<this>");
    i.e(paramThrowable2, "exception");
    if (paramThrowable1 != paramThrowable2) {
      b.a.a(paramThrowable1, paramThrowable2);
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/i/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */