package i.z;

import i.v.d.i;
import java.util.Iterator;

public class e
  extends d
{
  public static final <T> b<T> a(Iterator<? extends T> paramIterator)
  {
    i.e(paramIterator, "<this>");
    return b(new a(paramIterator));
  }
  
  public static final <T> b<T> b(b<? extends T> paramb)
  {
    i.e(paramb, "<this>");
    if (!(paramb instanceof a)) {
      paramb = new a(paramb);
    }
    return paramb;
  }
  
  public static final class a
    implements b<T>
  {
    public a(Iterator paramIterator) {}
    
    public Iterator<T> iterator()
    {
      return this.a;
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/i/z/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */