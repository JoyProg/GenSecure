package l;

import java.io.EOFException;
import java.io.IOException;
import java.util.zip.CRC32;
import java.util.zip.Inflater;

public final class j
  implements t
{
  public int g = 0;
  public final e h;
  public final Inflater i;
  public final k j;
  public final CRC32 k = new CRC32();
  
  public j(t paramt)
  {
    if (paramt != null)
    {
      Inflater localInflater = new Inflater(true);
      this.i = localInflater;
      paramt = l.b(paramt);
      this.h = paramt;
      this.j = new k(paramt, localInflater);
      return;
    }
    throw new IllegalArgumentException("source == null");
  }
  
  public final void a(String paramString, int paramInt1, int paramInt2)
  {
    if (paramInt2 == paramInt1) {
      return;
    }
    throw new IOException(String.format("%s: actual 0x%08x != expected 0x%08x", new Object[] { paramString, Integer.valueOf(paramInt2), Integer.valueOf(paramInt1) }));
  }
  
  public final void b()
  {
    this.h.p0(10L);
    int m = this.h.c().o(3L);
    int n;
    if ((m >> 1 & 0x1) == 1) {
      n = 1;
    } else {
      n = 0;
    }
    if (n != 0) {
      g(this.h.c(), 0L, 10L);
    }
    a("ID1ID2", 8075, this.h.j0());
    this.h.z(8L);
    long l;
    if ((m >> 2 & 0x1) == 1)
    {
      this.h.p0(2L);
      if (n != 0) {
        g(this.h.c(), 0L, 2L);
      }
      int i1 = this.h.c().b0();
      e locale = this.h;
      l = i1;
      locale.p0(l);
      if (n != 0) {
        g(this.h.c(), 0L, l);
      }
      this.h.z(l);
    }
    if ((m >> 3 & 0x1) == 1)
    {
      l = this.h.w0((byte)0);
      if (l != -1L)
      {
        if (n != 0) {
          g(this.h.c(), 0L, l + 1L);
        }
        this.h.z(l + 1L);
      }
      else
      {
        throw new EOFException();
      }
    }
    if ((m >> 4 & 0x1) == 1)
    {
      l = this.h.w0((byte)0);
      if (l != -1L)
      {
        if (n != 0) {
          g(this.h.c(), 0L, l + 1L);
        }
        this.h.z(l + 1L);
      }
      else
      {
        throw new EOFException();
      }
    }
    if (n != 0)
    {
      a("FHCRC", this.h.b0(), (short)(int)this.k.getValue());
      this.k.reset();
    }
  }
  
  public void close()
  {
    this.j.close();
  }
  
  public final void d()
  {
    a("CRC", this.h.N(), (int)this.k.getValue());
    a("ISIZE", this.h.N(), (int)this.i.getBytesWritten());
  }
  
  public long e0(c paramc, long paramLong)
  {
    if (paramLong >= 0L)
    {
      if (paramLong == 0L) {
        return 0L;
      }
      if (this.g == 0)
      {
        b();
        this.g = 1;
      }
      if (this.g == 1)
      {
        long l = paramc.i;
        paramLong = this.j.e0(paramc, paramLong);
        if (paramLong != -1L)
        {
          g(paramc, l, paramLong);
          return paramLong;
        }
        this.g = 2;
      }
      if (this.g == 2)
      {
        d();
        this.g = 3;
        if (!this.h.Q()) {
          throw new IOException("gzip finished without exhausting source");
        }
      }
      return -1L;
    }
    paramc = new StringBuilder();
    paramc.append("byteCount < 0: ");
    paramc.append(paramLong);
    throw new IllegalArgumentException(paramc.toString());
  }
  
  public u f()
  {
    return this.h.f();
  }
  
  public final void g(c paramc, long paramLong1, long paramLong2)
  {
    int m;
    int n;
    for (paramc = paramc.h;; paramc = paramc.f)
    {
      m = paramc.c;
      n = paramc.b;
      if (paramLong1 < m - n) {
        break;
      }
      paramLong1 -= m - n;
    }
    while (paramLong2 > 0L)
    {
      m = (int)(paramc.b + paramLong1);
      n = (int)Math.min(paramc.c - m, paramLong2);
      this.k.update(paramc.a, m, n);
      paramLong2 -= n;
      paramc = paramc.f;
      paramLong1 = 0L;
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/l/j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */