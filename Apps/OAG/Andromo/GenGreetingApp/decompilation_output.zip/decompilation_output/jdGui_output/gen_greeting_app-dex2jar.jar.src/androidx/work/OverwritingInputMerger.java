package androidx.work;

import c.y.e;
import c.y.e.a;
import c.y.j;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public final class OverwritingInputMerger
  extends j
{
  public e b(List<e> paramList)
  {
    e.a locala = new e.a();
    HashMap localHashMap = new HashMap();
    paramList = paramList.iterator();
    while (paramList.hasNext()) {
      localHashMap.putAll(((e)paramList.next()).h());
    }
    locala.d(localHashMap);
    return locala.a();
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/androidx/work/OverwritingInputMerger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */