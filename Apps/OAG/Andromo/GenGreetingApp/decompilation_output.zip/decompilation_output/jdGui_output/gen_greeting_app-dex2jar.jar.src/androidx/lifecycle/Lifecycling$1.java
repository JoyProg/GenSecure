package androidx.lifecycle;

import c.k.f.a;
import c.k.h;
import c.k.j;

public final class Lifecycling$1
  implements h
{
  public void a(j paramj, f.a parama)
  {
    this.a.a(paramj, parama);
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/androidx/lifecycle/Lifecycling$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */