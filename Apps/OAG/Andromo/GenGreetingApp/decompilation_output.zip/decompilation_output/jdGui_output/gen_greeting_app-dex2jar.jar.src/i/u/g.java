package i.u;

import i.p;
import i.v.d.i;
import java.io.File;
import java.io.FileOutputStream;

public class g
  extends f
{
  public static final void a(File paramFile, byte[] paramArrayOfByte)
  {
    i.e(paramFile, "<this>");
    i.e(paramArrayOfByte, "array");
    paramFile = new FileOutputStream(paramFile);
    try
    {
      paramFile.write(paramArrayOfByte);
      paramArrayOfByte = p.a;
      b.a(paramFile, null);
      return;
    }
    finally
    {
      try
      {
        throw localThrowable;
      }
      finally
      {
        b.a(paramFile, localThrowable);
      }
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/i/u/g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */