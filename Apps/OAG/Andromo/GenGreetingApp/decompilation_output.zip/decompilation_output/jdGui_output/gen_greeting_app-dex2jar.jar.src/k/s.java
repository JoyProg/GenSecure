package k;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import k.k0.e;

public final class s
{
  public int a = 64;
  public int b = 5;
  public Runnable c;
  public ExecutorService d;
  public final Deque<d0.a> e = new ArrayDeque();
  public final Deque<d0.a> f = new ArrayDeque();
  public final Deque<d0> g = new ArrayDeque();
  
  public void a(d0 paramd0)
  {
    try
    {
      this.g.add(paramd0);
      return;
    }
    finally
    {
      paramd0 = finally;
      throw paramd0;
    }
  }
  
  public ExecutorService b()
  {
    try
    {
      if (this.d == null)
      {
        localObject1 = new java/util/concurrent/ThreadPoolExecutor;
        TimeUnit localTimeUnit = TimeUnit.SECONDS;
        SynchronousQueue localSynchronousQueue = new java/util/concurrent/SynchronousQueue;
        localSynchronousQueue.<init>();
        ((ThreadPoolExecutor)localObject1).<init>(0, Integer.MAX_VALUE, 60L, localTimeUnit, localSynchronousQueue, e.G("OkHttp Dispatcher", false));
        this.d = ((ExecutorService)localObject1);
      }
      Object localObject1 = this.d;
      return (ExecutorService)localObject1;
    }
    finally {}
  }
  
  public final <T> void c(Deque<T> paramDeque, T paramT)
  {
    try
    {
      if (paramDeque.remove(paramT))
      {
        paramDeque = this.c;
        if ((!f()) && (paramDeque != null)) {
          paramDeque.run();
        }
        return;
      }
      paramDeque = new java/lang/AssertionError;
      paramDeque.<init>("Call wasn't in-flight!");
      throw paramDeque;
    }
    finally {}
  }
  
  public void d(d0.a parama)
  {
    parama.l().decrementAndGet();
    c(this.f, parama);
  }
  
  public void e(d0 paramd0)
  {
    c(this.g, paramd0);
  }
  
  public final boolean f()
  {
    ArrayList localArrayList = new ArrayList();
    try
    {
      Iterator localIterator = this.e.iterator();
      while (localIterator.hasNext())
      {
        d0.a locala = (d0.a)localIterator.next();
        if (this.f.size() >= this.a) {
          break;
        }
        if (locala.l().get() < this.b)
        {
          localIterator.remove();
          locala.l().incrementAndGet();
          localArrayList.add(locala);
          this.f.add(locala);
        }
      }
      int i = g();
      int j = 0;
      boolean bool;
      if (i > 0) {
        bool = true;
      } else {
        bool = false;
      }
      i = localArrayList.size();
      while (j < i)
      {
        ((d0.a)localArrayList.get(j)).m(b());
        j++;
      }
      return bool;
    }
    finally {}
    for (;;)
    {
      throw ((Throwable)localObject);
    }
  }
  
  public int g()
  {
    try
    {
      int i = this.f.size();
      int j = this.g.size();
      return i + j;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/k/s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */