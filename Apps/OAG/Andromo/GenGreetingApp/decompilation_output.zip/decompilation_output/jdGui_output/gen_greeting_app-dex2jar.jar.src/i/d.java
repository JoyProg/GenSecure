package i;

import i.v.d.i;
import i.x.c;

public final class d
  implements Comparable<d>
{
  public static final a g = new a(null);
  public static final d h = e.a();
  public final int i;
  public final int j;
  public final int k;
  public final int l;
  
  public d(int paramInt1, int paramInt2, int paramInt3)
  {
    this.i = paramInt1;
    this.j = paramInt2;
    this.k = paramInt3;
    this.l = g(paramInt1, paramInt2, paramInt3);
  }
  
  public int e(d paramd)
  {
    i.e(paramd, "other");
    return this.l - paramd.l;
  }
  
  public boolean equals(Object paramObject)
  {
    boolean bool = true;
    if (this == paramObject) {
      return true;
    }
    if ((paramObject instanceof d)) {
      paramObject = (d)paramObject;
    } else {
      paramObject = null;
    }
    if (paramObject == null) {
      return false;
    }
    if (this.l != ((d)paramObject).l) {
      bool = false;
    }
    return bool;
  }
  
  public final int g(int paramInt1, int paramInt2, int paramInt3)
  {
    int m = 0;
    int n = m;
    if (new c(0, 255).w(paramInt1))
    {
      n = m;
      if (new c(0, 255).w(paramInt2))
      {
        n = m;
        if (new c(0, 255).w(paramInt3)) {
          n = 1;
        }
      }
    }
    if (n != 0) {
      return (paramInt1 << 16) + (paramInt2 << 8) + paramInt3;
    }
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("Version components are out of range: ");
    localStringBuilder.append(paramInt1);
    localStringBuilder.append('.');
    localStringBuilder.append(paramInt2);
    localStringBuilder.append('.');
    localStringBuilder.append(paramInt3);
    throw new IllegalArgumentException(localStringBuilder.toString().toString());
  }
  
  public int hashCode()
  {
    return this.l;
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(this.i);
    localStringBuilder.append('.');
    localStringBuilder.append(this.j);
    localStringBuilder.append('.');
    localStringBuilder.append(this.k);
    return localStringBuilder.toString();
  }
  
  public static final class a {}
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/i/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */