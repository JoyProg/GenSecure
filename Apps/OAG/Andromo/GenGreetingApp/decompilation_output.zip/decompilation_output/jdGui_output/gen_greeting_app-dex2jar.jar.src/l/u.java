package l;

import java.io.InterruptedIOException;
import java.util.concurrent.TimeUnit;

public class u
{
  public static final u a = new a();
  public boolean b;
  public long c;
  public long d;
  
  public u a()
  {
    this.b = false;
    return this;
  }
  
  public u b()
  {
    this.d = 0L;
    return this;
  }
  
  public long c()
  {
    if (this.b) {
      return this.c;
    }
    throw new IllegalStateException("No deadline");
  }
  
  public u d(long paramLong)
  {
    this.b = true;
    this.c = paramLong;
    return this;
  }
  
  public boolean e()
  {
    return this.b;
  }
  
  public void f()
  {
    if (!Thread.interrupted())
    {
      if ((this.b) && (this.c - System.nanoTime() <= 0L)) {
        throw new InterruptedIOException("deadline reached");
      }
      return;
    }
    Thread.currentThread().interrupt();
    throw new InterruptedIOException("interrupted");
  }
  
  public u g(long paramLong, TimeUnit paramTimeUnit)
  {
    if (paramLong >= 0L)
    {
      if (paramTimeUnit != null)
      {
        this.d = paramTimeUnit.toNanos(paramLong);
        return this;
      }
      throw new IllegalArgumentException("unit == null");
    }
    paramTimeUnit = new StringBuilder();
    paramTimeUnit.append("timeout < 0: ");
    paramTimeUnit.append(paramLong);
    throw new IllegalArgumentException(paramTimeUnit.toString());
  }
  
  public long h()
  {
    return this.d;
  }
  
  public final class a
    extends u
  {
    public u d(long paramLong)
    {
      return this;
    }
    
    public void f() {}
    
    public u g(long paramLong, TimeUnit paramTimeUnit)
    {
      return this;
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/l/u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */