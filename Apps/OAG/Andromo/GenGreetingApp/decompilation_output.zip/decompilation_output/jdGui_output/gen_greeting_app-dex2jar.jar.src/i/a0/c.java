package i.a0;

import i.v.c.p;
import i.x.e;
import i.z.b;
import java.util.Iterator;
import java.util.NoSuchElementException;

public final class c
  implements b<i.x.c>
{
  public final CharSequence a;
  public final int b;
  public final int c;
  public final p<CharSequence, Integer, i.i<Integer, Integer>> d;
  
  public c(CharSequence paramCharSequence, int paramInt1, int paramInt2, p<? super CharSequence, ? super Integer, i.i<Integer, Integer>> paramp)
  {
    this.a = paramCharSequence;
    this.b = paramInt1;
    this.c = paramInt2;
    this.d = paramp;
  }
  
  public Iterator<i.x.c> iterator()
  {
    return new a(this);
  }
  
  public static final class a
    implements Iterator<i.x.c>
  {
    public int g = -1;
    public int h;
    public int i;
    public i.x.c j;
    public int k;
    
    public a(c paramc)
    {
      int m = e.e(c.d(paramc), 0, c.b(paramc).length());
      this.h = m;
      this.i = m;
    }
    
    public final void b()
    {
      int m = this.i;
      int n = 0;
      if (m < 0)
      {
        this.g = 0;
        this.j = null;
      }
      else
      {
        if (c.c(this.l) > 0)
        {
          m = this.k + 1;
          this.k = m;
          if (m >= c.c(this.l)) {}
        }
        else
        {
          if (this.i <= c.b(this.l).length()) {
            break label109;
          }
        }
        this.j = new i.x.c(this.h, m.u(c.b(this.l)));
        this.i = -1;
        break label235;
        label109:
        i.i locali = (i.i)c.a(this.l).invoke(c.b(this.l), Integer.valueOf(this.i));
        if (locali == null)
        {
          this.j = new i.x.c(this.h, m.u(c.b(this.l)));
          this.i = -1;
        }
        else
        {
          m = ((Number)locali.a()).intValue();
          int i1 = ((Number)locali.b()).intValue();
          this.j = e.g(this.h, m);
          m += i1;
          this.h = m;
          if (i1 == 0) {
            n = 1;
          }
          this.i = (m + n);
        }
        label235:
        this.g = 1;
      }
    }
    
    public i.x.c c()
    {
      if (this.g == -1) {
        b();
      }
      if (this.g != 0)
      {
        i.x.c localc = this.j;
        i.v.d.i.c(localc, "null cannot be cast to non-null type kotlin.ranges.IntRange");
        this.j = null;
        this.g = -1;
        return localc;
      }
      throw new NoSuchElementException();
    }
    
    public boolean hasNext()
    {
      if (this.g == -1) {
        b();
      }
      int m = this.g;
      boolean bool = true;
      if (m != 1) {
        bool = false;
      }
      return bool;
    }
    
    public void remove()
    {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/i/a0/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */