package k;

import java.util.concurrent.TimeUnit;
import k.k0.h.g;

public final class o
{
  public final g a;
  
  public o()
  {
    this(5, 5L, TimeUnit.MINUTES);
  }
  
  public o(int paramInt, long paramLong, TimeUnit paramTimeUnit)
  {
    this.a = new g(paramInt, paramLong, paramTimeUnit);
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/k/o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */