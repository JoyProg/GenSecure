package androidx.work;

import android.content.Context;
import c.r.b;
import c.y.b.b;
import c.y.l;
import c.y.v;
import java.util.Collections;
import java.util.List;

public final class WorkManagerInitializer
  implements b<v>
{
  public static final String a = l.f("WrkMgrInitializer");
  
  public List<Class<? extends b<?>>> a()
  {
    return Collections.emptyList();
  }
  
  public v c(Context paramContext)
  {
    l.c().a(a, "Initializing WorkManager with default configuration.", new Throwable[0]);
    v.d(paramContext, new b.b().a());
    return v.c(paramContext);
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/androidx/work/WorkManagerInitializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */