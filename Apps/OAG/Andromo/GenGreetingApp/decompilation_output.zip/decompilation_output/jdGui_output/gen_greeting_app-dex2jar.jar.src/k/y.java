package k;

import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import k.k0.e;
import l.c;

public final class y
{
  public static final char[] a = { 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 65, 66, 67, 68, 69, 70 };
  public final String b;
  public final String c;
  public final String d;
  public final String e;
  public final int f;
  public final List<String> g;
  public final List<String> h;
  public final String i;
  public final String j;
  
  public y(a parama)
  {
    this.b = parama.a;
    this.c = s(parama.b, false);
    this.d = s(parama.c, false);
    this.e = parama.d;
    this.f = parama.c();
    this.g = t(parama.f, false);
    Object localObject1 = parama.g;
    Object localObject2 = null;
    if (localObject1 != null) {
      localObject1 = t((List)localObject1, true);
    } else {
      localObject1 = null;
    }
    this.h = ((List)localObject1);
    String str = parama.h;
    localObject1 = localObject2;
    if (str != null) {
      localObject1 = s(str, false);
    }
    this.i = ((String)localObject1);
    this.j = parama.toString();
  }
  
  public static String a(String paramString1, int paramInt1, int paramInt2, String paramString2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, Charset paramCharset)
  {
    int k = paramInt1;
    while (k < paramInt2)
    {
      int m = paramString1.codePointAt(k);
      if ((m >= 32) && (m != 127) && ((m < 128) || (!paramBoolean4)) && (paramString2.indexOf(m) == -1) && ((m != 37) || ((paramBoolean1) && ((!paramBoolean2) || (v(paramString1, k, paramInt2))))) && ((m != 43) || (!paramBoolean3)))
      {
        k += Character.charCount(m);
      }
      else
      {
        c localc = new c();
        localc.G0(paramString1, paramInt1, k);
        c(localc, paramString1, k, paramInt2, paramString2, paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4, paramCharset);
        return localc.P();
      }
    }
    return paramString1.substring(paramInt1, paramInt2);
  }
  
  public static String b(String paramString1, String paramString2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4)
  {
    return a(paramString1, 0, paramString1.length(), paramString2, paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4, null);
  }
  
  public static void c(c paramc, String paramString1, int paramInt1, int paramInt2, String paramString2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, Charset paramCharset)
  {
    Object localObject2;
    for (Object localObject1 = null; paramInt1 < paramInt2; localObject1 = localObject2)
    {
      int k = paramString1.codePointAt(paramInt1);
      if (paramBoolean1)
      {
        localObject2 = localObject1;
        if (k == 9) {
          break label321;
        }
        localObject2 = localObject1;
        if (k == 10) {
          break label321;
        }
        localObject2 = localObject1;
        if (k == 12) {
          break label321;
        }
        if (k == 13)
        {
          localObject2 = localObject1;
          break label321;
        }
      }
      Object localObject3;
      if ((k == 43) && (paramBoolean3))
      {
        if (paramBoolean1) {
          localObject3 = "+";
        } else {
          localObject3 = "%2B";
        }
        paramc.F0((String)localObject3);
        localObject2 = localObject1;
      }
      else if ((k >= 32) && (k != 127) && ((k < 128) || (!paramBoolean4)) && (paramString2.indexOf(k) == -1) && ((k != 37) || ((paramBoolean1) && ((!paramBoolean2) || (v(paramString1, paramInt1, paramInt2))))))
      {
        paramc.H0(k);
        localObject2 = localObject1;
      }
      else
      {
        localObject3 = localObject1;
        if (localObject1 == null) {
          localObject3 = new c();
        }
        if ((paramCharset != null) && (!paramCharset.equals(StandardCharsets.UTF_8))) {
          ((c)localObject3).E0(paramString1, paramInt1, Character.charCount(k) + paramInt1, paramCharset);
        } else {
          ((c)localObject3).H0(k);
        }
        for (;;)
        {
          localObject2 = localObject3;
          if (((c)localObject3).Q()) {
            break;
          }
          int m = ((c)localObject3).A0() & 0xFF;
          paramc.z0(37);
          localObject1 = a;
          paramc.z0(localObject1[(m >> 4 & 0xF)]);
          paramc.z0(localObject1[(m & 0xF)]);
        }
      }
      label321:
      paramInt1 += Character.charCount(k);
    }
  }
  
  public static int d(String paramString)
  {
    if (paramString.equals("http")) {
      return 80;
    }
    if (paramString.equals("https")) {
      return 443;
    }
    return -1;
  }
  
  public static y k(String paramString)
  {
    return new a().h(null, paramString).a();
  }
  
  public static void n(StringBuilder paramStringBuilder, List<String> paramList)
  {
    int k = paramList.size();
    for (int m = 0; m < k; m += 2)
    {
      String str1 = (String)paramList.get(m);
      String str2 = (String)paramList.get(m + 1);
      if (m > 0) {
        paramStringBuilder.append('&');
      }
      paramStringBuilder.append(str1);
      if (str2 != null)
      {
        paramStringBuilder.append('=');
        paramStringBuilder.append(str2);
      }
    }
  }
  
  public static void q(StringBuilder paramStringBuilder, List<String> paramList)
  {
    int k = paramList.size();
    for (int m = 0; m < k; m++)
    {
      paramStringBuilder.append('/');
      paramStringBuilder.append((String)paramList.get(m));
    }
  }
  
  public static String r(String paramString, int paramInt1, int paramInt2, boolean paramBoolean)
  {
    int k = paramInt1;
    while (k < paramInt2)
    {
      int m = paramString.charAt(k);
      if ((m != 37) && ((m != 43) || (!paramBoolean)))
      {
        k++;
      }
      else
      {
        c localc = new c();
        localc.G0(paramString, paramInt1, k);
        u(localc, paramString, k, paramInt2, paramBoolean);
        return localc.P();
      }
    }
    return paramString.substring(paramInt1, paramInt2);
  }
  
  public static String s(String paramString, boolean paramBoolean)
  {
    return r(paramString, 0, paramString.length(), paramBoolean);
  }
  
  public static void u(c paramc, String paramString, int paramInt1, int paramInt2, boolean paramBoolean)
  {
    while (paramInt1 < paramInt2)
    {
      int k = paramString.codePointAt(paramInt1);
      if (k == 37)
      {
        int m = paramInt1 + 2;
        if (m < paramInt2)
        {
          int n = e.i(paramString.charAt(paramInt1 + 1));
          int i1 = e.i(paramString.charAt(m));
          if ((n == -1) || (i1 == -1)) {
            break label105;
          }
          paramc.z0((n << 4) + i1);
          paramInt1 = m;
          break label112;
        }
      }
      if ((k == 43) && (paramBoolean)) {
        paramc.z0(32);
      } else {
        label105:
        paramc.H0(k);
      }
      label112:
      paramInt1 += Character.charCount(k);
    }
  }
  
  public static boolean v(String paramString, int paramInt1, int paramInt2)
  {
    int k = paramInt1 + 2;
    boolean bool = true;
    if ((k >= paramInt2) || (paramString.charAt(paramInt1) != '%') || (e.i(paramString.charAt(paramInt1 + 1)) == -1) || (e.i(paramString.charAt(k)) == -1)) {
      bool = false;
    }
    return bool;
  }
  
  public static List<String> y(String paramString)
  {
    ArrayList localArrayList = new ArrayList();
    int n;
    for (int k = 0; k <= paramString.length(); k = n + 1)
    {
      int m = paramString.indexOf('&', k);
      n = m;
      if (m == -1) {
        n = paramString.length();
      }
      m = paramString.indexOf('=', k);
      if ((m != -1) && (m <= n))
      {
        localArrayList.add(paramString.substring(k, m));
        localArrayList.add(paramString.substring(m + 1, n));
      }
      else
      {
        localArrayList.add(paramString.substring(k, n));
        localArrayList.add(null);
      }
    }
    return localArrayList;
  }
  
  public y A(String paramString)
  {
    paramString = p(paramString);
    if (paramString != null) {
      paramString = paramString.a();
    } else {
      paramString = null;
    }
    return paramString;
  }
  
  public String B()
  {
    return this.b;
  }
  
  public URI C()
  {
    Object localObject = o().o().toString();
    try
    {
      URI localURI = new URI((String)localObject);
      return localURI;
    }
    catch (URISyntaxException localURISyntaxException)
    {
      try
      {
        localObject = URI.create(((String)localObject).replaceAll("[\\u0000-\\u001F\\u007F-\\u009F\\p{javaWhitespace}]", ""));
        return (URI)localObject;
      }
      catch (Exception localException)
      {
        throw new RuntimeException(localURISyntaxException);
      }
    }
  }
  
  public String e()
  {
    if (this.i == null) {
      return null;
    }
    int k = this.j.indexOf('#');
    return this.j.substring(k + 1);
  }
  
  public boolean equals(Object paramObject)
  {
    boolean bool;
    if (((paramObject instanceof y)) && (((y)paramObject).j.equals(this.j))) {
      bool = true;
    } else {
      bool = false;
    }
    return bool;
  }
  
  public String f()
  {
    if (this.d.isEmpty()) {
      return "";
    }
    int k = this.j.indexOf(':', this.b.length() + 3);
    int m = this.j.indexOf('@');
    return this.j.substring(k + 1, m);
  }
  
  public String g()
  {
    int k = this.j.indexOf('/', this.b.length() + 3);
    String str = this.j;
    int m = e.m(str, k, str.length(), "?#");
    return this.j.substring(k, m);
  }
  
  public List<String> h()
  {
    int k = this.j.indexOf('/', this.b.length() + 3);
    Object localObject = this.j;
    int m = e.m((String)localObject, k, ((String)localObject).length(), "?#");
    localObject = new ArrayList();
    while (k < m)
    {
      int n = k + 1;
      k = e.l(this.j, n, m, '/');
      ((List)localObject).add(this.j.substring(n, k));
    }
    return (List<String>)localObject;
  }
  
  public int hashCode()
  {
    return this.j.hashCode();
  }
  
  public String i()
  {
    if (this.h == null) {
      return null;
    }
    int k = this.j.indexOf('?') + 1;
    String str = this.j;
    int m = e.l(str, k, str.length(), '#');
    return this.j.substring(k, m);
  }
  
  public String j()
  {
    if (this.c.isEmpty()) {
      return "";
    }
    int k = this.b.length() + 3;
    String str = this.j;
    int m = e.m(str, k, str.length(), ":@");
    return this.j.substring(k, m);
  }
  
  public String l()
  {
    return this.e;
  }
  
  public boolean m()
  {
    return this.b.equals("https");
  }
  
  public a o()
  {
    a locala = new a();
    locala.a = this.b;
    locala.b = j();
    locala.c = f();
    locala.d = this.e;
    int k;
    if (this.f != d(this.b)) {
      k = this.f;
    } else {
      k = -1;
    }
    locala.e = k;
    locala.f.clear();
    locala.f.addAll(h());
    locala.d(i());
    locala.h = e();
    return locala;
  }
  
  public a p(String paramString)
  {
    try
    {
      a locala = new k/y$a;
      locala.<init>();
      paramString = locala.h(this, paramString);
      return paramString;
    }
    catch (IllegalArgumentException paramString) {}
    return null;
  }
  
  public final List<String> t(List<String> paramList, boolean paramBoolean)
  {
    int k = paramList.size();
    ArrayList localArrayList = new ArrayList(k);
    for (int m = 0; m < k; m++)
    {
      String str = (String)paramList.get(m);
      if (str != null) {
        str = s(str, paramBoolean);
      } else {
        str = null;
      }
      localArrayList.add(str);
    }
    return Collections.unmodifiableList(localArrayList);
  }
  
  public String toString()
  {
    return this.j;
  }
  
  public int w()
  {
    return this.f;
  }
  
  public String x()
  {
    if (this.h == null) {
      return null;
    }
    StringBuilder localStringBuilder = new StringBuilder();
    n(localStringBuilder, this.h);
    return localStringBuilder.toString();
  }
  
  public String z()
  {
    return p("/...").t("").j("").a().toString();
  }
  
  public static final class a
  {
    public String a;
    public String b = "";
    public String c = "";
    public String d;
    public int e = -1;
    public final List<String> f;
    public List<String> g;
    public String h;
    
    public a()
    {
      ArrayList localArrayList = new ArrayList();
      this.f = localArrayList;
      localArrayList.add("");
    }
    
    public static String b(String paramString, int paramInt1, int paramInt2)
    {
      return e.b(y.r(paramString, paramInt1, paramInt2, false));
    }
    
    public static int i(String paramString, int paramInt1, int paramInt2)
    {
      try
      {
        paramInt1 = Integer.parseInt(y.a(paramString, paramInt1, paramInt2, "", false, false, false, true, null));
        if ((paramInt1 > 0) && (paramInt1 <= 65535)) {
          return paramInt1;
        }
      }
      catch (NumberFormatException paramString)
      {
        for (;;) {}
      }
      return -1;
    }
    
    public static int m(String paramString, int paramInt1, int paramInt2)
    {
      while (paramInt1 < paramInt2)
      {
        int i = paramString.charAt(paramInt1);
        if (i != 58)
        {
          int j = paramInt1;
          if (i != 91)
          {
            j = paramInt1;
          }
          else
          {
            do
            {
              paramInt1 = j + 1;
              j = paramInt1;
              if (paramInt1 >= paramInt2) {
                break;
              }
              j = paramInt1;
            } while (paramString.charAt(paramInt1) != ']');
            j = paramInt1;
          }
          paramInt1 = j + 1;
        }
        else
        {
          return paramInt1;
        }
      }
      return paramInt2;
    }
    
    public static int r(String paramString, int paramInt1, int paramInt2)
    {
      if (paramInt2 - paramInt1 < 2) {
        return -1;
      }
      int i = paramString.charAt(paramInt1);
      int j;
      if (i >= 97)
      {
        j = paramInt1;
        if (i <= 122) {}
      }
      else
      {
        if (i < 65) {
          break label147;
        }
        j = paramInt1;
        if (i > 90) {
          break label147;
        }
      }
      for (;;)
      {
        paramInt1 = j + 1;
        if (paramInt1 >= paramInt2) {
          break label147;
        }
        i = paramString.charAt(paramInt1);
        if (i >= 97)
        {
          j = paramInt1;
          if (i <= 122) {}
        }
        else if (i >= 65)
        {
          j = paramInt1;
          if (i <= 90) {}
        }
        else if (i >= 48)
        {
          j = paramInt1;
          if (i <= 57) {}
        }
        else
        {
          j = paramInt1;
          if (i != 43)
          {
            j = paramInt1;
            if (i != 45)
            {
              if (i != 46) {
                break;
              }
              j = paramInt1;
            }
          }
        }
      }
      if (i == 58) {
        return paramInt1;
      }
      label147:
      return -1;
    }
    
    public static int s(String paramString, int paramInt1, int paramInt2)
    {
      int i = 0;
      while (paramInt1 < paramInt2)
      {
        int j = paramString.charAt(paramInt1);
        if ((j != 92) && (j != 47)) {
          break;
        }
        i++;
        paramInt1++;
      }
      return i;
    }
    
    public y a()
    {
      if (this.a != null)
      {
        if (this.d != null) {
          return new y(this);
        }
        throw new IllegalStateException("host == null");
      }
      throw new IllegalStateException("scheme == null");
    }
    
    public int c()
    {
      int i = this.e;
      if (i == -1) {
        i = y.d(this.a);
      }
      return i;
    }
    
    public a d(String paramString)
    {
      if (paramString != null) {
        paramString = y.y(y.b(paramString, " \"'<>#", true, false, true, true));
      } else {
        paramString = null;
      }
      this.g = paramString;
      return this;
    }
    
    public a e(String paramString)
    {
      Objects.requireNonNull(paramString, "host == null");
      Object localObject = b(paramString, 0, paramString.length());
      if (localObject != null)
      {
        this.d = ((String)localObject);
        return this;
      }
      localObject = new StringBuilder();
      ((StringBuilder)localObject).append("unexpected host: ");
      ((StringBuilder)localObject).append(paramString);
      throw new IllegalArgumentException(((StringBuilder)localObject).toString());
    }
    
    public final boolean f(String paramString)
    {
      boolean bool;
      if ((!paramString.equals(".")) && (!paramString.equalsIgnoreCase("%2e"))) {
        bool = false;
      } else {
        bool = true;
      }
      return bool;
    }
    
    public final boolean g(String paramString)
    {
      boolean bool;
      if ((!paramString.equals("..")) && (!paramString.equalsIgnoreCase("%2e.")) && (!paramString.equalsIgnoreCase(".%2e")) && (!paramString.equalsIgnoreCase("%2e%2e"))) {
        bool = false;
      } else {
        bool = true;
      }
      return bool;
    }
    
    public a h(y paramy, String paramString)
    {
      int i = e.E(paramString, 0, paramString.length());
      int j = e.F(paramString, i, paramString.length());
      int k = r(paramString, i, j);
      if (k != -1)
      {
        if (paramString.regionMatches(true, i, "https:", 0, 6))
        {
          this.a = "https";
          i += 6;
        }
        else if (paramString.regionMatches(true, i, "http:", 0, 5))
        {
          this.a = "http";
          i += 5;
        }
        else
        {
          paramy = new StringBuilder();
          paramy.append("Expected URL scheme 'http' or 'https' but was '");
          paramy.append(paramString.substring(0, k));
          paramy.append("'");
          throw new IllegalArgumentException(paramy.toString());
        }
      }
      else
      {
        if (paramy == null) {
          break label841;
        }
        this.a = paramy.b;
      }
      k = s(paramString, i, j);
      int m;
      if ((k < 2) && (paramy != null) && (paramy.b.equals(this.a)))
      {
        this.b = paramy.j();
        this.c = paramy.f();
        this.d = paramy.e;
        this.e = paramy.f;
        this.f.clear();
        this.f.addAll(paramy.h());
        if (i != j)
        {
          k = i;
          if (paramString.charAt(i) != '#') {}
        }
        else
        {
          d(paramy.i());
          k = i;
        }
      }
      else
      {
        m = i + k;
        i = 0;
        k = 0;
        for (;;)
        {
          n = e.m(paramString, m, j, "@/\\?#");
          if (n != j) {
            i1 = paramString.charAt(n);
          } else {
            i1 = -1;
          }
          if ((i1 == -1) || (i1 == 35) || (i1 == 47) || (i1 == 92) || (i1 == 63)) {
            break;
          }
          if (i1 == 64)
          {
            if (i == 0)
            {
              int i2 = e.l(paramString, m, n, ':');
              i1 = n;
              String str = y.a(paramString, m, i2, " \"':;<=>@[]^`{}|/\\?#", true, false, false, true, null);
              paramy = str;
              if (k != 0)
              {
                paramy = new StringBuilder();
                paramy.append(this.b);
                paramy.append("%40");
                paramy.append(str);
                paramy = paramy.toString();
              }
              this.b = paramy;
              if (i2 != i1)
              {
                this.c = y.a(paramString, i2 + 1, i1, " \"':;<=>@[]^`{}|/\\?#", true, false, false, true, null);
                i = 1;
              }
              k = 1;
            }
            else
            {
              paramy = new StringBuilder();
              paramy.append(this.c);
              paramy.append("%40");
              paramy.append(y.a(paramString, m, n, " \"':;<=>@[]^`{}|/\\?#", true, false, false, true, null));
              this.c = paramy.toString();
            }
            m = n + 1;
          }
        }
        i = m(paramString, m, n);
        int i1 = i + 1;
        if (i1 < n)
        {
          this.d = b(paramString, m, i);
          k = i(paramString, i1, n);
          this.e = k;
          if (k == -1)
          {
            paramy = new StringBuilder();
            paramy.append("Invalid URL port: \"");
            paramy.append(paramString.substring(i1, n));
            paramy.append('"');
            throw new IllegalArgumentException(paramy.toString());
          }
        }
        else
        {
          this.d = b(paramString, m, i);
          this.e = y.d(this.a);
        }
        if (this.d == null) {
          break label795;
        }
        k = n;
      }
      int n = e.m(paramString, k, j, "?#");
      p(paramString, k, n);
      i = n;
      if (n < j)
      {
        i = n;
        if (paramString.charAt(n) == '?')
        {
          i = e.l(paramString, n, j, '#');
          this.g = y.y(y.a(paramString, n + 1, i, " \"'<>#", true, false, true, true, null));
        }
      }
      if ((i < j) && (paramString.charAt(i) == '#')) {
        this.h = y.a(paramString, 1 + i, j, "", true, false, false, false, null);
      }
      return this;
      label795:
      paramy = new StringBuilder();
      paramy.append("Invalid URL host: \"");
      paramy.append(paramString.substring(m, i));
      paramy.append('"');
      throw new IllegalArgumentException(paramy.toString());
      label841:
      paramy = new IllegalArgumentException("Expected URL scheme 'http' or 'https' but no colon was found");
      for (;;)
      {
        throw paramy;
      }
    }
    
    public a j(String paramString)
    {
      Objects.requireNonNull(paramString, "password == null");
      this.c = y.b(paramString, " \"':;<=>@[]^`{}|/\\?#", false, false, false, true);
      return this;
    }
    
    public final void k()
    {
      List localList = this.f;
      if ((((String)localList.remove(localList.size() - 1)).isEmpty()) && (!this.f.isEmpty()))
      {
        localList = this.f;
        localList.set(localList.size() - 1, "");
      }
      else
      {
        this.f.add("");
      }
    }
    
    public a l(int paramInt)
    {
      if ((paramInt > 0) && (paramInt <= 65535))
      {
        this.e = paramInt;
        return this;
      }
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append("unexpected port: ");
      localStringBuilder.append(paramInt);
      throw new IllegalArgumentException(localStringBuilder.toString());
    }
    
    public final void n(String paramString, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2)
    {
      paramString = y.a(paramString, paramInt1, paramInt2, " \"<>^`{}|/\\?#", paramBoolean2, false, false, true, null);
      if (f(paramString)) {
        return;
      }
      if (g(paramString))
      {
        k();
        return;
      }
      List localList = this.f;
      if (((String)localList.get(localList.size() - 1)).isEmpty())
      {
        localList = this.f;
        localList.set(localList.size() - 1, paramString);
      }
      else
      {
        this.f.add(paramString);
      }
      if (paramBoolean1) {
        this.f.add("");
      }
    }
    
    public a o()
    {
      int i = this.f.size();
      int j = 0;
      for (int k = 0; k < i; k++)
      {
        localObject = (String)this.f.get(k);
        this.f.set(k, y.b((String)localObject, "[]", true, true, false, true));
      }
      Object localObject = this.g;
      if (localObject != null)
      {
        i = ((List)localObject).size();
        for (k = j; k < i; k++)
        {
          localObject = (String)this.g.get(k);
          if (localObject != null) {
            this.g.set(k, y.b((String)localObject, "\\^`{|}", true, true, true, true));
          }
        }
      }
      localObject = this.h;
      if (localObject != null) {
        this.h = y.b((String)localObject, " \"#<>\\^`{|}", true, true, false, false);
      }
      return this;
    }
    
    public final void p(String paramString, int paramInt1, int paramInt2)
    {
      if (paramInt1 == paramInt2) {
        return;
      }
      int i = paramString.charAt(paramInt1);
      if ((i != 47) && (i != 92))
      {
        List localList = this.f;
        localList.set(localList.size() - 1, "");
      }
      else
      {
        this.f.clear();
        this.f.add("");
        break label135;
      }
      while (paramInt1 < paramInt2)
      {
        i = e.m(paramString, paramInt1, paramInt2, "/\\");
        boolean bool;
        if (i < paramInt2) {
          bool = true;
        } else {
          bool = false;
        }
        n(paramString, paramInt1, i, bool, true);
        paramInt1 = i;
        if (bool)
        {
          paramInt1 = i;
          label135:
          paramInt1++;
        }
      }
    }
    
    public a q(String paramString)
    {
      Objects.requireNonNull(paramString, "scheme == null");
      if (paramString.equalsIgnoreCase("http"))
      {
        this.a = "http";
      }
      else
      {
        if (!paramString.equalsIgnoreCase("https")) {
          break label42;
        }
        this.a = "https";
      }
      return this;
      label42:
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append("unexpected scheme: ");
      localStringBuilder.append(paramString);
      throw new IllegalArgumentException(localStringBuilder.toString());
    }
    
    public a t(String paramString)
    {
      Objects.requireNonNull(paramString, "username == null");
      this.b = y.b(paramString, " \"':;<=>@[]^`{}|/\\?#", false, false, false, true);
      return this;
    }
    
    public String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder();
      String str = this.a;
      if (str != null)
      {
        localStringBuilder.append(str);
        localStringBuilder.append("://");
      }
      else
      {
        localStringBuilder.append("//");
      }
      if ((!this.b.isEmpty()) || (!this.c.isEmpty()))
      {
        localStringBuilder.append(this.b);
        if (!this.c.isEmpty())
        {
          localStringBuilder.append(':');
          localStringBuilder.append(this.c);
        }
        localStringBuilder.append('@');
      }
      str = this.d;
      if (str != null) {
        if (str.indexOf(':') != -1)
        {
          localStringBuilder.append('[');
          localStringBuilder.append(this.d);
          localStringBuilder.append(']');
        }
        else
        {
          localStringBuilder.append(this.d);
        }
      }
      if ((this.e != -1) || (this.a != null))
      {
        int i = c();
        str = this.a;
        if ((str == null) || (i != y.d(str)))
        {
          localStringBuilder.append(':');
          localStringBuilder.append(i);
        }
      }
      y.q(localStringBuilder, this.f);
      if (this.g != null)
      {
        localStringBuilder.append('?');
        y.n(localStringBuilder, this.g);
      }
      if (this.h != null)
      {
        localStringBuilder.append('#');
        localStringBuilder.append(this.h);
      }
      return localStringBuilder.toString();
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/k/y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */