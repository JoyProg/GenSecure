package l;

import java.io.Closeable;
import java.io.Flushable;

public abstract interface s
  extends Closeable, Flushable
{
  public abstract void close();
  
  public abstract u f();
  
  public abstract void flush();
  
  public abstract void n(c paramc, long paramLong);
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/l/s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */