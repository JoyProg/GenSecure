package androidx.versionedparcelable;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import c.v.a;
import c.v.b;
import c.v.c;

@SuppressLint({"BanParcelableUsage"})
public class ParcelImpl
  implements Parcelable
{
  public static final Parcelable.Creator<ParcelImpl> CREATOR = new a();
  public final c g;
  
  public ParcelImpl(Parcel paramParcel)
  {
    this.g = new b(paramParcel).u();
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    new b(paramParcel).L(this.g);
  }
  
  public static final class a
    implements Parcelable.Creator<ParcelImpl>
  {
    public ParcelImpl a(Parcel paramParcel)
    {
      return new ParcelImpl(paramParcel);
    }
    
    public ParcelImpl[] b(int paramInt)
    {
      return new ParcelImpl[paramInt];
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/androidx/versionedparcelable/ParcelImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */