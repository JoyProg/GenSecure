package l;

import java.io.IOException;
import java.io.InterruptedIOException;
import java.util.concurrent.TimeUnit;

public class a
  extends u
{
  public static final long e;
  public static final long f;
  public static a g;
  public boolean h;
  public a i;
  public long j;
  
  static
  {
    long l = TimeUnit.SECONDS.toMillis(60L);
    e = l;
    f = TimeUnit.MILLISECONDS.toNanos(l);
  }
  
  public static a i()
  {
    Object localObject1 = g.i;
    Object localObject2 = null;
    if (localObject1 == null)
    {
      l1 = System.nanoTime();
      a.class.wait(e);
      localObject1 = localObject2;
      if (g.i == null)
      {
        localObject1 = localObject2;
        if (System.nanoTime() - l1 >= f) {
          localObject1 = g;
        }
      }
      return (a)localObject1;
    }
    long l1 = ((a)localObject1).p(System.nanoTime());
    if (l1 > 0L)
    {
      long l2 = l1 / 1000000L;
      a.class.wait(l2, (int)(l1 - 1000000L * l2));
      return null;
    }
    g.i = ((a)localObject1).i;
    ((a)localObject1).i = null;
    return (a)localObject1;
  }
  
  public static boolean j(a parama)
  {
    try
    {
      a locala;
      for (Object localObject = g; localObject != null; localObject = locala)
      {
        locala = ((a)localObject).i;
        if (locala == parama)
        {
          ((a)localObject).i = parama.i;
          parama.i = null;
          return false;
        }
      }
      return true;
    }
    finally {}
    for (;;)
    {
      throw parama;
    }
  }
  
  public static void q(a parama, long paramLong, boolean paramBoolean)
  {
    try
    {
      if (g == null)
      {
        localObject = new l/a;
        ((a)localObject).<init>();
        g = (a)localObject;
        localObject = new l/a$c;
        ((c)localObject).<init>();
        ((Thread)localObject).start();
      }
      long l = System.nanoTime();
      if ((paramLong != 0L) && (paramBoolean))
      {
        parama.j = (Math.min(paramLong, parama.c() - l) + l);
      }
      else if (paramLong != 0L)
      {
        parama.j = (paramLong + l);
      }
      else
      {
        if (!paramBoolean) {
          break label185;
        }
        parama.j = parama.c();
      }
      paramLong = parama.p(l);
      for (Object localObject = g;; localObject = ((a)localObject).i)
      {
        a locala = ((a)localObject).i;
        if ((locala == null) || (paramLong < locala.p(l))) {
          break;
        }
      }
      parama.i = ((a)localObject).i;
      ((a)localObject).i = parama;
      if (localObject == g) {
        a.class.notify();
      }
      return;
      label185:
      parama = new java/lang/AssertionError;
      parama.<init>();
      throw parama;
    }
    finally {}
    for (;;)
    {
      throw parama;
    }
  }
  
  public final void k()
  {
    if (!this.h)
    {
      long l = h();
      boolean bool = e();
      if ((l == 0L) && (!bool)) {
        return;
      }
      this.h = true;
      q(this, l, bool);
      return;
    }
    throw new IllegalStateException("Unbalanced enter/exit");
  }
  
  public final IOException l(IOException paramIOException)
  {
    if (!n()) {
      return paramIOException;
    }
    return o(paramIOException);
  }
  
  public final void m(boolean paramBoolean)
  {
    if ((n()) && (paramBoolean)) {
      throw o(null);
    }
  }
  
  public final boolean n()
  {
    if (!this.h) {
      return false;
    }
    this.h = false;
    return j(this);
  }
  
  public IOException o(IOException paramIOException)
  {
    InterruptedIOException localInterruptedIOException = new InterruptedIOException("timeout");
    if (paramIOException != null) {
      localInterruptedIOException.initCause(paramIOException);
    }
    return localInterruptedIOException;
  }
  
  public final long p(long paramLong)
  {
    return this.j - paramLong;
  }
  
  public final s r(final s params)
  {
    return new a(params);
  }
  
  public final t s(final t paramt)
  {
    return new b(paramt);
  }
  
  public void t() {}
  
  public class a
    implements s
  {
    public a(s params) {}
    
    /* Error */
    public void close()
    {
      // Byte code:
      //   0: aload_0
      //   1: getfield 19	l/a$a:h	Ll/a;
      //   4: invokevirtual 31	l/a:k	()V
      //   7: aload_0
      //   8: getfield 21	l/a$a:g	Ll/s;
      //   11: invokeinterface 33 1 0
      //   16: aload_0
      //   17: getfield 19	l/a$a:h	Ll/a;
      //   20: iconst_1
      //   21: invokevirtual 37	l/a:m	(Z)V
      //   24: return
      //   25: astore_1
      //   26: goto +13 -> 39
      //   29: astore_1
      //   30: aload_0
      //   31: getfield 19	l/a$a:h	Ll/a;
      //   34: aload_1
      //   35: invokevirtual 41	l/a:l	(Ljava/io/IOException;)Ljava/io/IOException;
      //   38: athrow
      //   39: aload_0
      //   40: getfield 19	l/a$a:h	Ll/a;
      //   43: iconst_0
      //   44: invokevirtual 37	l/a:m	(Z)V
      //   47: aload_1
      //   48: athrow
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	49	0	this	a
      //   25	1	1	localObject	Object
      //   29	19	1	localIOException	IOException
      // Exception table:
      //   from	to	target	type
      //   7	16	25	finally
      //   30	39	25	finally
      //   7	16	29	java/io/IOException
    }
    
    public u f()
    {
      return a.this;
    }
    
    /* Error */
    public void flush()
    {
      // Byte code:
      //   0: aload_0
      //   1: getfield 19	l/a$a:h	Ll/a;
      //   4: invokevirtual 31	l/a:k	()V
      //   7: aload_0
      //   8: getfield 21	l/a$a:g	Ll/s;
      //   11: invokeinterface 46 1 0
      //   16: aload_0
      //   17: getfield 19	l/a$a:h	Ll/a;
      //   20: iconst_1
      //   21: invokevirtual 37	l/a:m	(Z)V
      //   24: return
      //   25: astore_1
      //   26: goto +13 -> 39
      //   29: astore_1
      //   30: aload_0
      //   31: getfield 19	l/a$a:h	Ll/a;
      //   34: aload_1
      //   35: invokevirtual 41	l/a:l	(Ljava/io/IOException;)Ljava/io/IOException;
      //   38: athrow
      //   39: aload_0
      //   40: getfield 19	l/a$a:h	Ll/a;
      //   43: iconst_0
      //   44: invokevirtual 37	l/a:m	(Z)V
      //   47: aload_1
      //   48: athrow
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	49	0	this	a
      //   25	1	1	localObject	Object
      //   29	19	1	localIOException	IOException
      // Exception table:
      //   from	to	target	type
      //   7	16	25	finally
      //   30	39	25	finally
      //   7	16	29	java/io/IOException
    }
    
    /* Error */
    public void n(c paramc, long paramLong)
    {
      // Byte code:
      //   0: aload_1
      //   1: getfield 54	l/c:i	J
      //   4: lconst_0
      //   5: lload_2
      //   6: invokestatic 60	l/v:b	(JJJ)V
      //   9: lconst_0
      //   10: lstore 4
      //   12: lload_2
      //   13: lconst_0
      //   14: lcmp
      //   15: ifle +121 -> 136
      //   18: aload_1
      //   19: getfield 63	l/c:h	Ll/p;
      //   22: astore 6
      //   24: lload 4
      //   26: lstore 7
      //   28: lload 4
      //   30: ldc2_w 64
      //   33: lcmp
      //   34: ifge +43 -> 77
      //   37: lload 4
      //   39: aload 6
      //   41: getfield 71	l/p:c	I
      //   44: aload 6
      //   46: getfield 73	l/p:b	I
      //   49: isub
      //   50: i2l
      //   51: ladd
      //   52: lstore 4
      //   54: lload 4
      //   56: lload_2
      //   57: lcmp
      //   58: iflt +9 -> 67
      //   61: lload_2
      //   62: lstore 7
      //   64: goto +13 -> 77
      //   67: aload 6
      //   69: getfield 75	l/p:f	Ll/p;
      //   72: astore 6
      //   74: goto -50 -> 24
      //   77: aload_0
      //   78: getfield 19	l/a$a:h	Ll/a;
      //   81: invokevirtual 31	l/a:k	()V
      //   84: aload_0
      //   85: getfield 21	l/a$a:g	Ll/s;
      //   88: aload_1
      //   89: lload 7
      //   91: invokeinterface 77 4 0
      //   96: lload_2
      //   97: lload 7
      //   99: lsub
      //   100: lstore_2
      //   101: aload_0
      //   102: getfield 19	l/a$a:h	Ll/a;
      //   105: iconst_1
      //   106: invokevirtual 37	l/a:m	(Z)V
      //   109: goto -100 -> 9
      //   112: astore_1
      //   113: goto +13 -> 126
      //   116: astore_1
      //   117: aload_0
      //   118: getfield 19	l/a$a:h	Ll/a;
      //   121: aload_1
      //   122: invokevirtual 41	l/a:l	(Ljava/io/IOException;)Ljava/io/IOException;
      //   125: athrow
      //   126: aload_0
      //   127: getfield 19	l/a$a:h	Ll/a;
      //   130: iconst_0
      //   131: invokevirtual 37	l/a:m	(Z)V
      //   134: aload_1
      //   135: athrow
      //   136: return
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	137	0	this	a
      //   0	137	1	paramc	c
      //   0	137	2	paramLong	long
      //   10	45	4	l1	long
      //   22	51	6	localp	p
      //   26	72	7	l2	long
      // Exception table:
      //   from	to	target	type
      //   84	96	112	finally
      //   117	126	112	finally
      //   84	96	116	java/io/IOException
    }
    
    public String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append("AsyncTimeout.sink(");
      localStringBuilder.append(params);
      localStringBuilder.append(")");
      return localStringBuilder.toString();
    }
  }
  
  public class b
    implements t
  {
    public b(t paramt) {}
    
    /* Error */
    public void close()
    {
      // Byte code:
      //   0: aload_0
      //   1: getfield 19	l/a$b:h	Ll/a;
      //   4: invokevirtual 31	l/a:k	()V
      //   7: aload_0
      //   8: getfield 21	l/a$b:g	Ll/t;
      //   11: invokeinterface 33 1 0
      //   16: aload_0
      //   17: getfield 19	l/a$b:h	Ll/a;
      //   20: iconst_1
      //   21: invokevirtual 37	l/a:m	(Z)V
      //   24: return
      //   25: astore_1
      //   26: goto +13 -> 39
      //   29: astore_1
      //   30: aload_0
      //   31: getfield 19	l/a$b:h	Ll/a;
      //   34: aload_1
      //   35: invokevirtual 41	l/a:l	(Ljava/io/IOException;)Ljava/io/IOException;
      //   38: athrow
      //   39: aload_0
      //   40: getfield 19	l/a$b:h	Ll/a;
      //   43: iconst_0
      //   44: invokevirtual 37	l/a:m	(Z)V
      //   47: aload_1
      //   48: athrow
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	49	0	this	b
      //   25	1	1	localObject	Object
      //   29	19	1	localIOException	IOException
      // Exception table:
      //   from	to	target	type
      //   7	16	25	finally
      //   30	39	25	finally
      //   7	16	29	java/io/IOException
    }
    
    /* Error */
    public long e0(c paramc, long paramLong)
    {
      // Byte code:
      //   0: aload_0
      //   1: getfield 19	l/a$b:h	Ll/a;
      //   4: invokevirtual 31	l/a:k	()V
      //   7: aload_0
      //   8: getfield 21	l/a$b:g	Ll/t;
      //   11: aload_1
      //   12: lload_2
      //   13: invokeinterface 45 4 0
      //   18: lstore_2
      //   19: aload_0
      //   20: getfield 19	l/a$b:h	Ll/a;
      //   23: iconst_1
      //   24: invokevirtual 37	l/a:m	(Z)V
      //   27: lload_2
      //   28: lreturn
      //   29: astore_1
      //   30: goto +13 -> 43
      //   33: astore_1
      //   34: aload_0
      //   35: getfield 19	l/a$b:h	Ll/a;
      //   38: aload_1
      //   39: invokevirtual 41	l/a:l	(Ljava/io/IOException;)Ljava/io/IOException;
      //   42: athrow
      //   43: aload_0
      //   44: getfield 19	l/a$b:h	Ll/a;
      //   47: iconst_0
      //   48: invokevirtual 37	l/a:m	(Z)V
      //   51: aload_1
      //   52: athrow
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	53	0	this	b
      //   0	53	1	paramc	c
      //   0	53	2	paramLong	long
      // Exception table:
      //   from	to	target	type
      //   7	19	29	finally
      //   34	43	29	finally
      //   7	19	33	java/io/IOException
    }
    
    public u f()
    {
      return a.this;
    }
    
    public String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append("AsyncTimeout.source(");
      localStringBuilder.append(paramt);
      localStringBuilder.append(")");
      return localStringBuilder.toString();
    }
  }
  
  public static final class c
    extends Thread
  {
    public c()
    {
      super();
      setDaemon(true);
    }
    
    public void run()
    {
      try
      {
        for (;;)
        {
          try
          {
            a locala = a.i();
            if (locala == null) {}
            if (locala == a.g)
            {
              a.g = null;
              return;
            }
            locala.t();
          }
          finally
          {
            for (;;)
            {
              throw ((Throwable)localObject);
            }
          }
        }
      }
      catch (InterruptedException localInterruptedException) {}
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/l/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */