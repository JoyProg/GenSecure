package k;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public enum j0
{
  public final String m;
  
  static
  {
    j0 localj01 = new j0("TLS_1_3", 0, "TLSv1.3");
    g = localj01;
    j0 localj02 = new j0("TLS_1_2", 1, "TLSv1.2");
    h = localj02;
    j0 localj03 = new j0("TLS_1_1", 2, "TLSv1.1");
    i = localj03;
    j0 localj04 = new j0("TLS_1_0", 3, "TLSv1");
    j = localj04;
    j0 localj05 = new j0("SSL_3_0", 4, "SSLv3");
    k = localj05;
    l = new j0[] { localj01, localj02, localj03, localj04, localj05 };
  }
  
  public j0(String paramString)
  {
    this.m = paramString;
  }
  
  public static j0 e(String paramString)
  {
    paramString.hashCode();
    int n = paramString.hashCode();
    int i1 = -1;
    switch (n)
    {
    default: 
      break;
    case 79923350: 
      if (paramString.equals("TLSv1")) {
        i1 = 4;
      }
      break;
    case 79201641: 
      if (paramString.equals("SSLv3")) {
        i1 = 3;
      }
      break;
    case -503070501: 
      if (paramString.equals("TLSv1.3")) {
        i1 = 2;
      }
      break;
    case -503070502: 
      if (paramString.equals("TLSv1.2")) {
        i1 = 1;
      }
      break;
    case -503070503: 
      if (paramString.equals("TLSv1.1")) {
        i1 = 0;
      }
      break;
    }
    switch (i1)
    {
    default: 
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append("Unexpected TLS version: ");
      localStringBuilder.append(paramString);
      throw new IllegalArgumentException(localStringBuilder.toString());
    case 4: 
      return j;
    case 3: 
      return k;
    case 2: 
      return g;
    case 1: 
      return h;
    }
    return i;
  }
  
  public static List<j0> g(String... paramVarArgs)
  {
    ArrayList localArrayList = new ArrayList(paramVarArgs.length);
    int n = paramVarArgs.length;
    for (int i1 = 0; i1 < n; i1++) {
      localArrayList.add(e(paramVarArgs[i1]));
    }
    return Collections.unmodifiableList(localArrayList);
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/k/j0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */