package kotlinx.coroutines;

import i.s.g;
import i.s.g.b;
import i.s.g.c;

public abstract interface CoroutineExceptionHandler
  extends g.b
{
  public static final a e = a.g;
  
  public abstract void handleException(g paramg, Throwable paramThrowable);
  
  public static final class a
    implements g.c<CoroutineExceptionHandler>
  {}
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/kotlinx/coroutines/CoroutineExceptionHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */