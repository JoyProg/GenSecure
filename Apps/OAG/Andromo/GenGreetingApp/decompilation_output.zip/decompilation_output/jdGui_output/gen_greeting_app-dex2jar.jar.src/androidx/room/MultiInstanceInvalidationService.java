package androidx.room;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteCallbackList;
import android.os.RemoteException;
import android.util.Log;
import c.n.c;
import c.n.d.a;
import java.util.HashMap;

public class MultiInstanceInvalidationService
  extends Service
{
  public int g = 0;
  public final HashMap<Integer, String> h = new HashMap();
  public final RemoteCallbackList<c> i = new a();
  public final d.a j = new b();
  
  public IBinder onBind(Intent paramIntent)
  {
    return this.j;
  }
  
  public class a
    extends RemoteCallbackList<c>
  {
    public a() {}
    
    public void a(c paramc, Object paramObject)
    {
      MultiInstanceInvalidationService.this.h.remove(Integer.valueOf(((Integer)paramObject).intValue()));
    }
  }
  
  public class b
    extends d.a
  {
    public b() {}
    
    public int N(c paramc, String paramString)
    {
      if (paramString == null) {
        return 0;
      }
      synchronized (MultiInstanceInvalidationService.this.i)
      {
        MultiInstanceInvalidationService localMultiInstanceInvalidationService = MultiInstanceInvalidationService.this;
        int i = localMultiInstanceInvalidationService.g + 1;
        localMultiInstanceInvalidationService.g = i;
        if (localMultiInstanceInvalidationService.i.register(paramc, Integer.valueOf(i)))
        {
          MultiInstanceInvalidationService.this.h.put(Integer.valueOf(i), paramString);
          return i;
        }
        paramc = MultiInstanceInvalidationService.this;
        paramc.g -= 1;
        return 0;
      }
    }
    
    public void a0(int paramInt, String[] paramArrayOfString)
    {
      synchronized (MultiInstanceInvalidationService.this.i)
      {
        String str1 = (String)MultiInstanceInvalidationService.this.h.get(Integer.valueOf(paramInt));
        if (str1 == null)
        {
          Log.w("ROOM", "Remote invalidation client ID not registered");
          return;
        }
        int i = MultiInstanceInvalidationService.this.i.beginBroadcast();
        int j = 0;
        while (j < i) {
          try
          {
            int k = ((Integer)MultiInstanceInvalidationService.this.i.getBroadcastCookie(j)).intValue();
            String str2 = (String)MultiInstanceInvalidationService.this.h.get(Integer.valueOf(k));
            if (paramInt != k)
            {
              boolean bool = str1.equals(str2);
              if (bool) {
                try
                {
                  ((c)MultiInstanceInvalidationService.this.i.getBroadcastItem(j)).D(paramArrayOfString);
                }
                catch (RemoteException localRemoteException)
                {
                  Log.w("ROOM", "Error invoking a remote callback", localRemoteException);
                }
              }
            }
            j++;
          }
          finally
          {
            MultiInstanceInvalidationService.this.i.finishBroadcast();
          }
        }
        MultiInstanceInvalidationService.this.i.finishBroadcast();
        return;
      }
      for (;;)
      {
        throw paramArrayOfString;
      }
    }
    
    public void j0(c paramc, int paramInt)
    {
      synchronized (MultiInstanceInvalidationService.this.i)
      {
        MultiInstanceInvalidationService.this.i.unregister(paramc);
        MultiInstanceInvalidationService.this.h.remove(Integer.valueOf(paramInt));
        return;
      }
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/androidx/room/MultiInstanceInvalidationService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */