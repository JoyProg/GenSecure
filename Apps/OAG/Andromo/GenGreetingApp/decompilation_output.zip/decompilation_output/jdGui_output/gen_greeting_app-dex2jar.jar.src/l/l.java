package l;

import java.io.IOException;
import java.io.InputStream;
import java.io.InterruptedIOException;
import java.io.OutputStream;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.logging.Level;
import java.util.logging.Logger;

public final class l
{
  public static final Logger a = Logger.getLogger(l.class.getName());
  
  public static d a(s params)
  {
    return new n(params);
  }
  
  public static e b(t paramt)
  {
    return new o(paramt);
  }
  
  public static boolean c(AssertionError paramAssertionError)
  {
    boolean bool;
    if ((paramAssertionError.getCause() != null) && (paramAssertionError.getMessage() != null) && (paramAssertionError.getMessage().contains("getsockname failed"))) {
      bool = true;
    } else {
      bool = false;
    }
    return bool;
  }
  
  public static s d(final OutputStream paramOutputStream, u paramu)
  {
    if (paramOutputStream != null)
    {
      if (paramu != null) {
        return new a(paramu, paramOutputStream);
      }
      throw new IllegalArgumentException("timeout == null");
    }
    throw new IllegalArgumentException("out == null");
  }
  
  public static s e(Socket paramSocket)
  {
    if (paramSocket != null)
    {
      if (paramSocket.getOutputStream() != null)
      {
        a locala = i(paramSocket);
        return locala.r(d(paramSocket.getOutputStream(), locala));
      }
      throw new IOException("socket's output stream == null");
    }
    throw new IllegalArgumentException("socket == null");
  }
  
  public static t f(InputStream paramInputStream)
  {
    return g(paramInputStream, new u());
  }
  
  public static t g(final InputStream paramInputStream, u paramu)
  {
    if (paramInputStream != null)
    {
      if (paramu != null) {
        return new b(paramu, paramInputStream);
      }
      throw new IllegalArgumentException("timeout == null");
    }
    throw new IllegalArgumentException("in == null");
  }
  
  public static t h(Socket paramSocket)
  {
    if (paramSocket != null)
    {
      if (paramSocket.getInputStream() != null)
      {
        a locala = i(paramSocket);
        return locala.s(g(paramSocket.getInputStream(), locala));
      }
      throw new IOException("socket's input stream == null");
    }
    throw new IllegalArgumentException("socket == null");
  }
  
  public static a i(Socket paramSocket)
  {
    return new c();
  }
  
  public final class a
    implements s
  {
    public a(OutputStream paramOutputStream) {}
    
    public void close()
    {
      paramOutputStream.close();
    }
    
    public u f()
    {
      return l.this;
    }
    
    public void flush()
    {
      paramOutputStream.flush();
    }
    
    public void n(c paramc, long paramLong)
    {
      v.b(paramc.i, 0L, paramLong);
      while (paramLong > 0L)
      {
        l.this.f();
        p localp = paramc.h;
        int i = (int)Math.min(paramLong, localp.c - localp.b);
        paramOutputStream.write(localp.a, localp.b, i);
        int j = localp.b + i;
        localp.b = j;
        long l1 = i;
        long l2 = paramLong - l1;
        paramc.i -= l1;
        paramLong = l2;
        if (j == localp.c)
        {
          paramc.h = localp.b();
          q.a(localp);
          paramLong = l2;
        }
      }
    }
    
    public String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append("sink(");
      localStringBuilder.append(paramOutputStream);
      localStringBuilder.append(")");
      return localStringBuilder.toString();
    }
  }
  
  public final class b
    implements t
  {
    public b(InputStream paramInputStream) {}
    
    public void close()
    {
      paramInputStream.close();
    }
    
    public long e0(c paramc, long paramLong)
    {
      if (paramLong >= 0L)
      {
        if (paramLong == 0L) {
          return 0L;
        }
        try
        {
          l.this.f();
          p localp = paramc.g0(1);
          int i = (int)Math.min(paramLong, 8192 - localp.c);
          i = paramInputStream.read(localp.a, localp.c, i);
          if (i == -1) {
            return -1L;
          }
          localp.c += i;
          long l = paramc.i;
          paramLong = i;
          paramc.i = (l + paramLong);
          return paramLong;
        }
        catch (AssertionError paramc)
        {
          if (l.c(paramc)) {
            throw new IOException(paramc);
          }
          throw paramc;
        }
      }
      paramc = new StringBuilder();
      paramc.append("byteCount < 0: ");
      paramc.append(paramLong);
      throw new IllegalArgumentException(paramc.toString());
    }
    
    public u f()
    {
      return l.this;
    }
    
    public String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append("source(");
      localStringBuilder.append(paramInputStream);
      localStringBuilder.append(")");
      return localStringBuilder.toString();
    }
  }
  
  public final class c
    extends a
  {
    public c() {}
    
    public IOException o(IOException paramIOException)
    {
      SocketTimeoutException localSocketTimeoutException = new SocketTimeoutException("timeout");
      if (paramIOException != null) {
        localSocketTimeoutException.initCause(paramIOException);
      }
      return localSocketTimeoutException;
    }
    
    public void t()
    {
      try
      {
        l.this.close();
      }
      catch (AssertionError localAssertionError)
      {
        if (l.c(localAssertionError))
        {
          localLogger = l.a;
          localObject = Level.WARNING;
          StringBuilder localStringBuilder = new StringBuilder();
          localStringBuilder.append("Failed to close timed out socket ");
          localStringBuilder.append(l.this);
          localLogger.log((Level)localObject, localStringBuilder.toString(), localAssertionError);
        }
        else
        {
          throw localAssertionError;
        }
      }
      catch (Exception localException)
      {
        Logger localLogger = l.a;
        Level localLevel = Level.WARNING;
        Object localObject = new StringBuilder();
        ((StringBuilder)localObject).append("Failed to close timed out socket ");
        ((StringBuilder)localObject).append(l.this);
        localLogger.log(localLevel, ((StringBuilder)localObject).toString(), localException);
      }
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/l/l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */