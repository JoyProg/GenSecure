package androidx.window;

public final class R
{
  public static final class attr
  {
    public static final int activityAction = 2130837537;
    public static final int activityName = 2130837539;
    public static final int alwaysExpand = 2130837547;
    public static final int clearTop = 2130837580;
    public static final int finishPrimaryWithSecondary = 2130837633;
    public static final int finishSecondaryWithPrimary = 2130837634;
    public static final int placeholderActivityName = 2130837702;
    public static final int primaryActivityName = 2130837707;
    public static final int secondaryActivityAction = 2130837721;
    public static final int secondaryActivityName = 2130837722;
    public static final int splitLayoutDirection = 2130837735;
    public static final int splitMinSmallestWidth = 2130837736;
    public static final int splitMinWidth = 2130837737;
    public static final int splitRatio = 2130837738;
  }
  
  public static final class id
  {
    public static final int androidx_window_activity_scope = 2131165252;
    public static final int locale = 2131165299;
    public static final int ltr = 2131165300;
    public static final int rtl = 2131165321;
  }
  
  public static final class styleable
  {
    public static final int[] ActivityFilter = { 2130837537, 2130837539 };
    public static final int ActivityFilter_activityAction = 0;
    public static final int ActivityFilter_activityName = 1;
    public static final int[] ActivityRule = { 2130837547 };
    public static final int ActivityRule_alwaysExpand = 0;
    public static final int[] SplitPairFilter = { 2130837707, 2130837721, 2130837722 };
    public static final int SplitPairFilter_primaryActivityName = 0;
    public static final int SplitPairFilter_secondaryActivityAction = 1;
    public static final int SplitPairFilter_secondaryActivityName = 2;
    public static final int[] SplitPairRule = { 2130837580, 2130837633, 2130837634, 2130837735, 2130837736, 2130837737, 2130837738 };
    public static final int SplitPairRule_clearTop = 0;
    public static final int SplitPairRule_finishPrimaryWithSecondary = 1;
    public static final int SplitPairRule_finishSecondaryWithPrimary = 2;
    public static final int SplitPairRule_splitLayoutDirection = 3;
    public static final int SplitPairRule_splitMinSmallestWidth = 4;
    public static final int SplitPairRule_splitMinWidth = 5;
    public static final int SplitPairRule_splitRatio = 6;
    public static final int[] SplitPlaceholderRule = { 2130837702, 2130837735, 2130837736, 2130837737, 2130837738 };
    public static final int SplitPlaceholderRule_placeholderActivityName = 0;
    public static final int SplitPlaceholderRule_splitLayoutDirection = 1;
    public static final int SplitPlaceholderRule_splitMinSmallestWidth = 2;
    public static final int SplitPlaceholderRule_splitMinWidth = 3;
    public static final int SplitPlaceholderRule_splitRatio = 4;
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/androidx/window/R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */