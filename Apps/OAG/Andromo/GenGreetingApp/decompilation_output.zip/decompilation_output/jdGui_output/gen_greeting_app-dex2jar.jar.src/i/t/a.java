package i.t;

import i.q.d;
import i.v.d.i;
import i.w.b;
import i.w.c;
import java.lang.reflect.Method;

public class a
{
  public void a(Throwable paramThrowable1, Throwable paramThrowable2)
  {
    i.e(paramThrowable1, "cause");
    i.e(paramThrowable2, "exception");
    Method localMethod = a.b;
    if (localMethod != null) {
      localMethod.invoke(paramThrowable1, new Object[] { paramThrowable2 });
    }
  }
  
  public c b()
  {
    return new b();
  }
  
  public static final class a
  {
    public static final a a = new a();
    public static final Method b;
    public static final Method c;
    
    static
    {
      Method[] arrayOfMethod = Throwable.class.getMethods();
      i.d(arrayOfMethod, "throwableMethods");
      int i = arrayOfMethod.length;
      int j = 0;
      Object localObject1;
      for (int k = 0;; k++)
      {
        localObject1 = null;
        if (k >= i) {
          break;
        }
        localObject2 = arrayOfMethod[k];
        if (i.a(((Method)localObject2).getName(), "addSuppressed"))
        {
          Class[] arrayOfClass = ((Method)localObject2).getParameterTypes();
          i.d(arrayOfClass, "it.parameterTypes");
          if (i.a(d.i(arrayOfClass), Throwable.class))
          {
            m = 1;
            break label91;
          }
        }
        m = 0;
        label91:
        if (m != 0) {
          break label108;
        }
      }
      Object localObject2 = null;
      label108:
      b = (Method)localObject2;
      int m = arrayOfMethod.length;
      for (k = j;; k++)
      {
        localObject2 = localObject1;
        if (k >= m) {
          break;
        }
        localObject2 = arrayOfMethod[k];
        if (i.a(((Method)localObject2).getName(), "getSuppressed")) {
          break;
        }
      }
      c = (Method)localObject2;
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/i/t/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */