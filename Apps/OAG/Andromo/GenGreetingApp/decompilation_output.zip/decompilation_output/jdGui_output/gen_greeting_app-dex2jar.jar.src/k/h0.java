package k;

import java.io.Closeable;
import java.io.IOException;
import java.util.Objects;
import l.c;

public abstract class h0
  implements Closeable
{
  public static h0 g(a0 parama0, final long paramLong, l.e parame)
  {
    Objects.requireNonNull(parame, "source == null");
    return new a(paramLong, parame);
  }
  
  public static h0 h(a0 parama0, byte[] paramArrayOfByte)
  {
    c localc = new c().o0(paramArrayOfByte);
    return g(parama0, paramArrayOfByte.length, localc);
  }
  
  public final byte[] b()
  {
    long l = d();
    if (l <= 2147483647L)
    {
      localObject1 = i();
      try
      {
        byte[] arrayOfByte = ((l.e)localObject1).L();
        a(null, (AutoCloseable)localObject1);
        if ((l != -1L) && (l != arrayOfByte.length))
        {
          localObject1 = new StringBuilder();
          ((StringBuilder)localObject1).append("Content-Length (");
          ((StringBuilder)localObject1).append(l);
          ((StringBuilder)localObject1).append(") and stream length (");
          ((StringBuilder)localObject1).append(arrayOfByte.length);
          ((StringBuilder)localObject1).append(") disagree");
          throw new IOException(((StringBuilder)localObject1).toString());
        }
        return arrayOfByte;
      }
      finally
      {
        try
        {
          throw localThrowable;
        }
        finally
        {
          if (localObject1 != null) {
            a(localThrowable, (AutoCloseable)localObject1);
          }
        }
      }
    }
    Object localObject1 = new StringBuilder();
    ((StringBuilder)localObject1).append("Cannot buffer entire body for content length: ");
    ((StringBuilder)localObject1).append(l);
    throw new IOException(((StringBuilder)localObject1).toString());
  }
  
  public void close()
  {
    k.k0.e.e(i());
  }
  
  public abstract long d();
  
  public abstract l.e i();
  
  public class a
    extends h0
  {
    public a(long paramLong, l.e parame) {}
    
    public long d()
    {
      return paramLong;
    }
    
    public l.e i()
    {
      return this.h;
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/k/h0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */