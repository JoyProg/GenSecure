package l;

import java.util.Arrays;

public final class r
  extends f
{
  public final transient byte[][] l;
  public final transient int[] m;
  
  public r(c paramc, int paramInt)
  {
    super(null);
    v.b(paramc.i, 0L, paramInt);
    Object localObject = paramc.h;
    int i = 0;
    int j = 0;
    int k = 0;
    int i1;
    while (j < paramInt)
    {
      int n = ((p)localObject).c;
      i1 = ((p)localObject).b;
      if (n != i1)
      {
        j += n - i1;
        k++;
        localObject = ((p)localObject).f;
      }
      else
      {
        throw new AssertionError("s.limit == s.pos");
      }
    }
    this.l = new byte[k][];
    this.m = new int[k * 2];
    paramc = paramc.h;
    j = 0;
    k = i;
    while (k < paramInt)
    {
      byte[][] arrayOfByte = this.l;
      arrayOfByte[j] = paramc.a;
      i = paramc.c;
      i1 = paramc.b;
      i = k + (i - i1);
      k = i;
      if (i > paramInt) {
        k = paramInt;
      }
      localObject = this.m;
      localObject[j] = k;
      localObject[(arrayOfByte.length + j)] = i1;
      paramc.d = true;
      j++;
      paramc = paramc.f;
    }
  }
  
  public f A()
  {
    return F().A();
  }
  
  public byte[] B()
  {
    Object localObject1 = this.m;
    Object localObject2 = this.l;
    localObject1 = new byte[localObject1[(localObject2.length - 1)]];
    int i = localObject2.length;
    int j = 0;
    int i1;
    for (int k = 0; j < i; k = i1)
    {
      localObject2 = this.m;
      int n = localObject2[(i + j)];
      i1 = localObject2[j];
      System.arraycopy(this.l[j], n, localObject1, k, i1 - k);
      j++;
    }
    return (byte[])localObject1;
  }
  
  public String C()
  {
    return F().C();
  }
  
  public void D(c paramc)
  {
    int i = this.l.length;
    int j = 0;
    int i1;
    for (int k = 0; j < i; k = i1)
    {
      Object localObject = this.m;
      int n = localObject[(i + j)];
      i1 = localObject[j];
      localObject = new p(this.l[j], n, n + i1 - k, true, false);
      p localp = paramc.h;
      if (localp == null)
      {
        ((p)localObject).g = ((p)localObject);
        ((p)localObject).f = ((p)localObject);
        paramc.h = ((p)localObject);
      }
      else
      {
        localp.g.c((p)localObject);
      }
      j++;
    }
    paramc.i += k;
  }
  
  public final int E(int paramInt)
  {
    paramInt = Arrays.binarySearch(this.m, 0, this.l.length, paramInt + 1);
    if (paramInt < 0) {
      paramInt ^= 0xFFFFFFFF;
    }
    return paramInt;
  }
  
  public final f F()
  {
    return new f(B());
  }
  
  public String e()
  {
    return F().e();
  }
  
  public boolean equals(Object paramObject)
  {
    boolean bool = true;
    if (paramObject == this) {
      return true;
    }
    if ((paramObject instanceof f))
    {
      paramObject = (f)paramObject;
      if ((((f)paramObject).x() == x()) && (t(0, (f)paramObject, 0, x()))) {}
    }
    else
    {
      bool = false;
    }
    return bool;
  }
  
  public int hashCode()
  {
    int i = this.j;
    if (i != 0) {
      return i;
    }
    int j = this.l.length;
    int k = 0;
    int n = 0;
    int i1 = 1;
    while (k < j)
    {
      byte[] arrayOfByte = this.l[k];
      int[] arrayOfInt = this.m;
      int i2 = arrayOfInt[(j + k)];
      int i3 = arrayOfInt[k];
      for (i = i2; i < i3 - n + i2; i++) {
        i1 = i1 * 31 + arrayOfByte[i];
      }
      k++;
      n = i3;
    }
    this.j = i1;
    return i1;
  }
  
  public byte q(int paramInt)
  {
    v.b(this.m[(this.l.length - 1)], paramInt, 1L);
    int i = E(paramInt);
    int j;
    if (i == 0) {
      j = 0;
    } else {
      j = this.m[(i - 1)];
    }
    int[] arrayOfInt = this.m;
    byte[][] arrayOfByte = this.l;
    int k = arrayOfInt[(arrayOfByte.length + i)];
    return arrayOfByte[i][(paramInt - j + k)];
  }
  
  public String r()
  {
    return F().r();
  }
  
  public boolean t(int paramInt1, f paramf, int paramInt2, int paramInt3)
  {
    if ((paramInt1 >= 0) && (paramInt1 <= x() - paramInt3))
    {
      for (int i = E(paramInt1); paramInt3 > 0; i++)
      {
        int j;
        if (i == 0) {
          j = 0;
        } else {
          j = this.m[(i - 1)];
        }
        int k = Math.min(paramInt3, this.m[i] - j + j - paramInt1);
        int[] arrayOfInt = this.m;
        byte[][] arrayOfByte = this.l;
        int n = arrayOfInt[(arrayOfByte.length + i)];
        if (!paramf.u(paramInt2, arrayOfByte[i], paramInt1 - j + n, k)) {
          return false;
        }
        paramInt1 += k;
        paramInt2 += k;
        paramInt3 -= k;
      }
      return true;
    }
    return false;
  }
  
  public String toString()
  {
    return F().toString();
  }
  
  public boolean u(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3)
  {
    if ((paramInt1 >= 0) && (paramInt1 <= x() - paramInt3) && (paramInt2 >= 0) && (paramInt2 <= paramArrayOfByte.length - paramInt3))
    {
      int i = E(paramInt1);
      int j = paramInt1;
      for (paramInt1 = i; paramInt3 > 0; paramInt1++)
      {
        if (paramInt1 == 0) {
          i = 0;
        } else {
          i = this.m[(paramInt1 - 1)];
        }
        int k = Math.min(paramInt3, this.m[paramInt1] - i + i - j);
        int[] arrayOfInt = this.m;
        byte[][] arrayOfByte = this.l;
        int n = arrayOfInt[(arrayOfByte.length + paramInt1)];
        if (!v.a(arrayOfByte[paramInt1], j - i + n, paramArrayOfByte, paramInt2, k)) {
          return false;
        }
        j += k;
        paramInt2 += k;
        paramInt3 -= k;
      }
      return true;
    }
    return false;
  }
  
  public f v()
  {
    return F().v();
  }
  
  public f w()
  {
    return F().w();
  }
  
  public int x()
  {
    return this.m[(this.l.length - 1)];
  }
  
  public f z(int paramInt1, int paramInt2)
  {
    return F().z(paramInt1, paramInt2);
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/l/r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */