package k;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import javax.net.ssl.SSLSocket;
import k.k0.e;

public final class p
{
  public static final m[] a;
  public static final m[] b;
  public static final p c;
  public static final p d;
  public static final p e;
  public static final p f = new a(false).a();
  public final boolean g;
  public final boolean h;
  public final String[] i;
  public final String[] j;
  
  static
  {
    m[] arrayOfm1 = new m[9];
    m localm1 = m.m1;
    arrayOfm1[0] = localm1;
    m localm2 = m.n1;
    arrayOfm1[1] = localm2;
    Object localObject1 = m.o1;
    arrayOfm1[2] = localObject1;
    m localm3 = m.Y0;
    arrayOfm1[3] = localm3;
    m localm4 = m.c1;
    arrayOfm1[4] = localm4;
    Object localObject2 = m.Z0;
    arrayOfm1[5] = localObject2;
    m localm5 = m.d1;
    arrayOfm1[6] = localm5;
    Object localObject3 = m.j1;
    arrayOfm1[7] = localObject3;
    m localm6 = m.i1;
    arrayOfm1[8] = localm6;
    a = arrayOfm1;
    m[] arrayOfm2 = new m[16];
    arrayOfm2[0] = localm1;
    arrayOfm2[1] = localm2;
    arrayOfm2[2] = localObject1;
    arrayOfm2[3] = localm3;
    arrayOfm2[4] = localm4;
    arrayOfm2[5] = localObject2;
    arrayOfm2[6] = localm5;
    arrayOfm2[7] = localObject3;
    arrayOfm2[8] = localm6;
    arrayOfm2[9] = m.J0;
    arrayOfm2[10] = m.K0;
    arrayOfm2[11] = m.h0;
    arrayOfm2[12] = m.i0;
    arrayOfm2[13] = m.F;
    arrayOfm2[14] = m.J;
    arrayOfm2[15] = m.j;
    b = arrayOfm2;
    localObject2 = new a(true).c(arrayOfm1);
    localObject1 = j0.g;
    localObject3 = j0.h;
    c = ((a)localObject2).f(new j0[] { localObject1, localObject3 }).d(true).a();
    d = new a(true).c(arrayOfm2).f(new j0[] { localObject1, localObject3 }).d(true).a();
    e = new a(true).c(arrayOfm2).f(new j0[] { localObject1, localObject3, j0.i, j0.j }).d(true).a();
  }
  
  public p(a parama)
  {
    this.g = parama.a;
    this.i = parama.b;
    this.j = parama.c;
    this.h = parama.d;
  }
  
  public void a(SSLSocket paramSSLSocket, boolean paramBoolean)
  {
    Object localObject = e(paramSSLSocket, paramBoolean);
    String[] arrayOfString = ((p)localObject).j;
    if (arrayOfString != null) {
      paramSSLSocket.setEnabledProtocols(arrayOfString);
    }
    localObject = ((p)localObject).i;
    if (localObject != null) {
      paramSSLSocket.setEnabledCipherSuites((String[])localObject);
    }
  }
  
  public List<m> b()
  {
    Object localObject = this.i;
    if (localObject != null) {
      localObject = m.b((String[])localObject);
    } else {
      localObject = null;
    }
    return (List<m>)localObject;
  }
  
  public boolean c(SSLSocket paramSSLSocket)
  {
    if (!this.g) {
      return false;
    }
    String[] arrayOfString = this.j;
    if ((arrayOfString != null) && (!e.A(e.j, arrayOfString, paramSSLSocket.getEnabledProtocols()))) {
      return false;
    }
    arrayOfString = this.i;
    return (arrayOfString == null) || (e.A(m.a, arrayOfString, paramSSLSocket.getEnabledCipherSuites()));
  }
  
  public boolean d()
  {
    return this.g;
  }
  
  public final p e(SSLSocket paramSSLSocket, boolean paramBoolean)
  {
    String[] arrayOfString1;
    if (this.i != null) {
      arrayOfString1 = e.x(m.a, paramSSLSocket.getEnabledCipherSuites(), this.i);
    } else {
      arrayOfString1 = paramSSLSocket.getEnabledCipherSuites();
    }
    String[] arrayOfString2;
    if (this.j != null) {
      arrayOfString2 = e.x(e.j, paramSSLSocket.getEnabledProtocols(), this.j);
    } else {
      arrayOfString2 = paramSSLSocket.getEnabledProtocols();
    }
    String[] arrayOfString3 = paramSSLSocket.getSupportedCipherSuites();
    int k = e.u(m.a, arrayOfString3, "TLS_FALLBACK_SCSV");
    paramSSLSocket = arrayOfString1;
    if (paramBoolean)
    {
      paramSSLSocket = arrayOfString1;
      if (k != -1) {
        paramSSLSocket = e.g(arrayOfString1, arrayOfString3[k]);
      }
    }
    return new a(this).b(paramSSLSocket).e(arrayOfString2).a();
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof p)) {
      return false;
    }
    if (paramObject == this) {
      return true;
    }
    paramObject = (p)paramObject;
    boolean bool = this.g;
    if (bool != ((p)paramObject).g) {
      return false;
    }
    if (bool)
    {
      if (!Arrays.equals(this.i, ((p)paramObject).i)) {
        return false;
      }
      if (!Arrays.equals(this.j, ((p)paramObject).j)) {
        return false;
      }
      if (this.h != ((p)paramObject).h) {
        return false;
      }
    }
    return true;
  }
  
  public boolean f()
  {
    return this.h;
  }
  
  public List<j0> g()
  {
    Object localObject = this.j;
    if (localObject != null) {
      localObject = j0.g((String[])localObject);
    } else {
      localObject = null;
    }
    return (List<j0>)localObject;
  }
  
  public int hashCode()
  {
    int k;
    if (this.g) {
      k = ((527 + Arrays.hashCode(this.i)) * 31 + Arrays.hashCode(this.j)) * 31 + (this.h ^ true);
    } else {
      k = 17;
    }
    return k;
  }
  
  public String toString()
  {
    if (!this.g) {
      return "ConnectionSpec()";
    }
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("ConnectionSpec(cipherSuites=");
    localStringBuilder.append(Objects.toString(b(), "[all enabled]"));
    localStringBuilder.append(", tlsVersions=");
    localStringBuilder.append(Objects.toString(g(), "[all enabled]"));
    localStringBuilder.append(", supportsTlsExtensions=");
    localStringBuilder.append(this.h);
    localStringBuilder.append(")");
    return localStringBuilder.toString();
  }
  
  public static final class a
  {
    public boolean a;
    public String[] b;
    public String[] c;
    public boolean d;
    
    public a(p paramp)
    {
      this.a = paramp.g;
      this.b = paramp.i;
      this.c = paramp.j;
      this.d = paramp.h;
    }
    
    public a(boolean paramBoolean)
    {
      this.a = paramBoolean;
    }
    
    public p a()
    {
      return new p(this);
    }
    
    public a b(String... paramVarArgs)
    {
      if (this.a)
      {
        if (paramVarArgs.length != 0)
        {
          this.b = ((String[])paramVarArgs.clone());
          return this;
        }
        throw new IllegalArgumentException("At least one cipher suite is required");
      }
      throw new IllegalStateException("no cipher suites for cleartext connections");
    }
    
    public a c(m... paramVarArgs)
    {
      if (this.a)
      {
        String[] arrayOfString = new String[paramVarArgs.length];
        for (int i = 0; i < paramVarArgs.length; i++) {
          arrayOfString[i] = paramVarArgs[i].r1;
        }
        return b(arrayOfString);
      }
      paramVarArgs = new IllegalStateException("no cipher suites for cleartext connections");
      for (;;)
      {
        throw paramVarArgs;
      }
    }
    
    public a d(boolean paramBoolean)
    {
      if (this.a)
      {
        this.d = paramBoolean;
        return this;
      }
      throw new IllegalStateException("no TLS extensions for cleartext connections");
    }
    
    public a e(String... paramVarArgs)
    {
      if (this.a)
      {
        if (paramVarArgs.length != 0)
        {
          this.c = ((String[])paramVarArgs.clone());
          return this;
        }
        throw new IllegalArgumentException("At least one TLS version is required");
      }
      throw new IllegalStateException("no TLS versions for cleartext connections");
    }
    
    public a f(j0... paramVarArgs)
    {
      if (this.a)
      {
        String[] arrayOfString = new String[paramVarArgs.length];
        for (int i = 0; i < paramVarArgs.length; i++) {
          arrayOfString[i] = paramVarArgs[i].m;
        }
        return e(arrayOfString);
      }
      paramVarArgs = new IllegalStateException("no TLS versions for cleartext connections");
      for (;;)
      {
        throw paramVarArgs;
      }
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/k/p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */