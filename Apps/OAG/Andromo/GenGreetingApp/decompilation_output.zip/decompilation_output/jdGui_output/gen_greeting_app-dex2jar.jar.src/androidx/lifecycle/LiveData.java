package androidx.lifecycle;

import c.c.a.a.a;
import c.c.a.b.b;
import c.c.a.b.b.d;
import c.k.f;
import c.k.f.a;
import c.k.f.b;
import c.k.h;
import c.k.j;
import c.k.q;
import java.util.Iterator;
import java.util.Map.Entry;

public abstract class LiveData<T>
{
  public static final Object a = new Object();
  public final Object b = new Object();
  public b<q<? super T>, LiveData<T>.b> c = new b();
  public int d = 0;
  public volatile Object e;
  public volatile Object f;
  public int g;
  public boolean h;
  public boolean i;
  public final Runnable j;
  
  public LiveData()
  {
    Object localObject = a;
    this.f = localObject;
    this.j = new a();
    this.e = localObject;
    this.g = -1;
  }
  
  public static void a(String paramString)
  {
    if (a.e().b()) {
      return;
    }
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("Cannot invoke ");
    localStringBuilder.append(paramString);
    localStringBuilder.append(" on a background thread");
    throw new IllegalStateException(localStringBuilder.toString());
  }
  
  public final void b(LiveData<T>.b paramLiveData)
  {
    if (!paramLiveData.b) {
      return;
    }
    if (!paramLiveData.e())
    {
      paramLiveData.b(false);
      return;
    }
    int k = paramLiveData.c;
    int m = this.g;
    if (k >= m) {
      return;
    }
    paramLiveData.c = m;
    paramLiveData.a.a(this.e);
  }
  
  public void c(LiveData<T>.b paramLiveData)
  {
    if (this.h)
    {
      this.i = true;
      return;
    }
    this.h = true;
    LiveData<T>.b localLiveData = paramLiveData;
    do
    {
      this.i = false;
      if (localLiveData != null)
      {
        b(localLiveData);
        paramLiveData = null;
      }
      else
      {
        b.d locald = this.c.t();
        do
        {
          paramLiveData = localLiveData;
          if (!locald.hasNext()) {
            break;
          }
          b((b)((Map.Entry)locald.next()).getValue());
        } while (!this.i);
        paramLiveData = localLiveData;
      }
      localLiveData = paramLiveData;
    } while (this.i);
    this.h = false;
  }
  
  public void d(j paramj, q<? super T> paramq)
  {
    a("observe");
    if (paramj.getLifecycle().b() == f.b.g) {
      return;
    }
    LifecycleBoundObserver localLifecycleBoundObserver = new LifecycleBoundObserver(paramj, paramq);
    paramq = (b)this.c.w(paramq, localLifecycleBoundObserver);
    if ((paramq != null) && (!paramq.d(paramj))) {
      throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
    }
    if (paramq != null) {
      return;
    }
    paramj.getLifecycle().a(localLifecycleBoundObserver);
  }
  
  public void e() {}
  
  public void f() {}
  
  public void g(T paramT)
  {
    synchronized (this.b)
    {
      int k;
      if (this.f == a) {
        k = 1;
      } else {
        k = 0;
      }
      this.f = paramT;
      if (k == 0) {
        return;
      }
      a.e().c(this.j);
      return;
    }
  }
  
  public void h(q<? super T> paramq)
  {
    a("removeObserver");
    paramq = (b)this.c.x(paramq);
    if (paramq == null) {
      return;
    }
    paramq.c();
    paramq.b(false);
  }
  
  public void i(T paramT)
  {
    a("setValue");
    this.g += 1;
    this.e = paramT;
    c(null);
  }
  
  public class LifecycleBoundObserver
    extends LiveData<T>.b
    implements h
  {
    public final j e;
    
    public LifecycleBoundObserver(q<? super T> paramq)
    {
      super(localq);
      this.e = paramq;
    }
    
    public void a(j paramj, f.a parama)
    {
      if (this.e.getLifecycle().b() == f.b.g)
      {
        LiveData.this.h(this.a);
        return;
      }
      b(e());
    }
    
    public void c()
    {
      this.e.getLifecycle().c(this);
    }
    
    public boolean d(j paramj)
    {
      boolean bool;
      if (this.e == paramj) {
        bool = true;
      } else {
        bool = false;
      }
      return bool;
    }
    
    public boolean e()
    {
      return this.e.getLifecycle().b().e(f.b.j);
    }
  }
  
  public class a
    implements Runnable
  {
    public a() {}
    
    public void run()
    {
      synchronized (LiveData.this.b)
      {
        Object localObject2 = LiveData.this.f;
        LiveData.this.f = LiveData.a;
        LiveData.this.i(localObject2);
        return;
      }
    }
  }
  
  public abstract class b
  {
    public final q<? super T> a;
    public boolean b;
    public int c = -1;
    
    public b()
    {
      q localq;
      this.a = localq;
    }
    
    public void b(boolean paramBoolean)
    {
      if (paramBoolean == this.b) {
        return;
      }
      this.b = paramBoolean;
      LiveData localLiveData = LiveData.this;
      int i = localLiveData.d;
      int j = 1;
      int k;
      if (i == 0) {
        k = 1;
      } else {
        k = 0;
      }
      if (!paramBoolean) {
        j = -1;
      }
      localLiveData.d = (i + j);
      if ((k != 0) && (paramBoolean)) {
        localLiveData.e();
      }
      localLiveData = LiveData.this;
      if ((localLiveData.d == 0) && (!this.b)) {
        localLiveData.f();
      }
      if (this.b) {
        LiveData.this.c(this);
      }
    }
    
    public void c() {}
    
    public boolean d(j paramj)
    {
      return false;
    }
    
    public abstract boolean e();
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/androidx/lifecycle/LiveData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */