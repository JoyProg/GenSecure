package androidx.lifecycle;

import c.k.e;
import c.k.f.a;
import c.k.h;
import c.k.j;
import c.k.o;

public class CompositeGeneratedAdaptersObserver
  implements h
{
  public final e[] a;
  
  public CompositeGeneratedAdaptersObserver(e[] paramArrayOfe)
  {
    this.a = paramArrayOfe;
  }
  
  public void a(j paramj, f.a parama)
  {
    o localo = new o();
    e[] arrayOfe = this.a;
    int i = arrayOfe.length;
    int j = 0;
    for (int k = 0; k < i; k++) {
      arrayOfe[k].a(paramj, parama, false, localo);
    }
    arrayOfe = this.a;
    i = arrayOfe.length;
    for (k = j; k < i; k++) {
      arrayOfe[k].a(paramj, parama, true, localo);
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/androidx/lifecycle/CompositeGeneratedAdaptersObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */