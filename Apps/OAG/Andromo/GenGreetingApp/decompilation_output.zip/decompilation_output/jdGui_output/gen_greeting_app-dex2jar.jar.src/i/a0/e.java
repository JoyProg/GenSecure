package i.a0;

import i.q.g;
import i.q.h;
import i.v.d.i;
import i.v.d.j;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public class e
  extends d
{
  public static final i.v.c.l<String, String> b(String paramString)
  {
    int i;
    if (paramString.length() == 0) {
      i = 1;
    } else {
      i = 0;
    }
    if (i != 0) {
      paramString = a.g;
    } else {
      paramString = new b(paramString);
    }
    return paramString;
  }
  
  public static final int c(String paramString)
  {
    int i = paramString.length();
    for (int j = 0; j < i; j++) {
      if ((a.c(paramString.charAt(j)) ^ true)) {
        break label40;
      }
    }
    j = -1;
    label40:
    i = j;
    if (j == -1) {
      i = paramString.length();
    }
    return i;
  }
  
  public static final String d(String paramString1, String paramString2)
  {
    i.e(paramString1, "<this>");
    i.e(paramString2, "newIndent");
    Object localObject1 = m.I(paramString1);
    Object localObject2 = new ArrayList();
    Object localObject3 = ((Iterable)localObject1).iterator();
    Object localObject4;
    while (((Iterator)localObject3).hasNext())
    {
      localObject4 = ((Iterator)localObject3).next();
      if ((l.l((String)localObject4) ^ true)) {
        ((Collection)localObject2).add(localObject4);
      }
    }
    localObject3 = new ArrayList(h.g((Iterable)localObject2, 10));
    localObject2 = ((Iterable)localObject2).iterator();
    while (((Iterator)localObject2).hasNext()) {
      ((Collection)localObject3).add(Integer.valueOf(c((String)((Iterator)localObject2).next())));
    }
    localObject2 = (Integer)i.q.o.n((Iterable)localObject3);
    int i = 0;
    int j;
    if (localObject2 != null) {
      j = ((Integer)localObject2).intValue();
    } else {
      j = 0;
    }
    int k = paramString1.length();
    int m = paramString2.length();
    int n = ((List)localObject1).size();
    localObject3 = b(paramString2);
    int i1 = g.c((List)localObject1);
    localObject2 = new ArrayList();
    localObject1 = ((Iterable)localObject1).iterator();
    while (((Iterator)localObject1).hasNext())
    {
      paramString1 = ((Iterator)localObject1).next();
      if (i < 0) {
        g.f();
      }
      paramString2 = (String)paramString1;
      if (((i == 0) || (i == i1)) && (l.l(paramString2)))
      {
        paramString1 = null;
      }
      else
      {
        localObject4 = o.b0(paramString2, j);
        paramString1 = paramString2;
        if (localObject4 != null)
        {
          paramString1 = (String)((i.v.c.l)localObject3).invoke(localObject4);
          if (paramString1 == null) {
            paramString1 = paramString2;
          }
        }
      }
      if (paramString1 != null) {
        ((Collection)localObject2).add(paramString1);
      }
      i++;
    }
    paramString1 = ((StringBuilder)i.q.o.k((Iterable)localObject2, new StringBuilder(k + m * n), "\n", null, null, 0, null, null, 124, null)).toString();
    i.d(paramString1, "mapIndexedNotNull { inde…\"\\n\")\n        .toString()");
    return paramString1;
  }
  
  public static final String e(String paramString)
  {
    i.e(paramString, "<this>");
    return d(paramString, "");
  }
  
  public static final class a
    extends j
    implements i.v.c.l<String, String>
  {
    public static final a g = new a();
    
    public a()
    {
      super();
    }
    
    public final String a(String paramString)
    {
      i.e(paramString, "line");
      return paramString;
    }
  }
  
  public static final class b
    extends j
    implements i.v.c.l<String, String>
  {
    public b(String paramString)
    {
      super();
    }
    
    public final String a(String paramString)
    {
      i.e(paramString, "line");
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append(this.g);
      localStringBuilder.append(paramString);
      return localStringBuilder.toString();
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/i/a0/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */