package k;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import k.k0.e;
import k.k0.i.d;
import okhttp3.internal.publicsuffix.PublicSuffixDatabase;

public final class q
{
  public static final Pattern a = Pattern.compile("(\\d{2,4})[^\\d]*");
  public static final Pattern b = Pattern.compile("(?i)(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec).*");
  public static final Pattern c = Pattern.compile("(\\d{1,2})[^\\d]*");
  public static final Pattern d = Pattern.compile("(\\d{1,2}):(\\d{1,2}):(\\d{1,2})[^\\d]*");
  public final String e;
  public final String f;
  public final long g;
  public final String h;
  public final String i;
  public final boolean j;
  public final boolean k;
  public final boolean l;
  public final boolean m;
  
  public q(String paramString1, String paramString2, long paramLong, String paramString3, String paramString4, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4)
  {
    this.e = paramString1;
    this.f = paramString2;
    this.g = paramLong;
    this.h = paramString3;
    this.i = paramString4;
    this.j = paramBoolean1;
    this.k = paramBoolean2;
    this.m = paramBoolean3;
    this.l = paramBoolean4;
  }
  
  public static int a(String paramString, int paramInt1, int paramInt2, boolean paramBoolean)
  {
    while (paramInt1 < paramInt2)
    {
      int n = paramString.charAt(paramInt1);
      if (((n >= 32) || (n == 9)) && (n < 127) && ((n < 48) || (n > 57)) && ((n < 97) || (n > 122)) && ((n < 65) || (n > 90)) && (n != 58)) {
        n = 0;
      } else {
        n = 1;
      }
      if (n == (paramBoolean ^ true)) {
        return paramInt1;
      }
      paramInt1++;
    }
    return paramInt2;
  }
  
  public static boolean b(String paramString1, String paramString2)
  {
    if (paramString1.equals(paramString2)) {
      return true;
    }
    return (paramString1.endsWith(paramString2)) && (paramString1.charAt(paramString1.length() - paramString2.length() - 1) == '.') && (!e.K(paramString1));
  }
  
  public static q d(long paramLong, y paramy, String paramString)
  {
    int n = paramString.length();
    int i1 = e.l(paramString, 0, n, ';');
    int i2 = e.l(paramString, 0, i1, '=');
    if (i2 == i1) {
      return null;
    }
    String str1 = e.J(paramString, 0, i2);
    if ((!str1.isEmpty()) && (e.v(str1) == -1))
    {
      String str2 = e.J(paramString, i2 + 1, i1);
      if (e.v(str2) != -1) {
        return null;
      }
      i2 = i1 + 1;
      localObject1 = null;
      localObject2 = localObject1;
      l1 = -1L;
      l2 = 253402300799999L;
      bool1 = false;
      boolean bool2 = false;
      bool3 = true;
      bool4 = false;
      while (i2 < n)
      {
        int i3 = e.l(paramString, i2, n, ';');
        i1 = e.l(paramString, i2, i3, '=');
        String str3 = e.J(paramString, i2, i1);
        if (i1 < i3) {
          localObject3 = e.J(paramString, i1 + 1, i3);
        } else {
          localObject3 = "";
        }
        if (str3.equalsIgnoreCase("expires")) {}
        try
        {
          l3 = h((String)localObject3, 0, ((String)localObject3).length());
          l2 = l3;
          if (str3.equalsIgnoreCase("max-age"))
          {
            l3 = i((String)localObject3);
            l1 = l3;
            bool5 = true;
            localObject3 = localObject1;
            localObject5 = localObject2;
            bool6 = bool1;
            bool7 = bool3;
            l3 = l1;
            l4 = l2;
          }
          else if (str3.equalsIgnoreCase("domain"))
          {
            localObject5 = g((String)localObject3);
            bool7 = false;
            localObject3 = localObject1;
            bool6 = bool1;
            bool5 = bool4;
            l3 = l1;
            l4 = l2;
          }
          else if (str3.equalsIgnoreCase("path"))
          {
            localObject5 = localObject2;
            bool6 = bool1;
            bool7 = bool3;
            bool5 = bool4;
            l3 = l1;
            l4 = l2;
          }
          else if (str3.equalsIgnoreCase("secure"))
          {
            bool6 = true;
            localObject3 = localObject1;
            localObject5 = localObject2;
            bool7 = bool3;
            bool5 = bool4;
            l3 = l1;
            l4 = l2;
          }
          else
          {
            localObject3 = localObject1;
            localObject5 = localObject2;
            bool6 = bool1;
            bool7 = bool3;
            bool5 = bool4;
            l3 = l1;
            l4 = l2;
            if (str3.equalsIgnoreCase("httponly"))
            {
              bool2 = true;
              l4 = l2;
              l3 = l1;
              bool5 = bool4;
              bool7 = bool3;
              bool6 = bool1;
              localObject5 = localObject2;
              localObject3 = localObject1;
            }
          }
        }
        catch (IllegalArgumentException|NumberFormatException localIllegalArgumentException)
        {
          for (;;)
          {
            Object localObject4 = localObject1;
            Object localObject5 = localObject2;
            boolean bool6 = bool1;
            boolean bool7 = bool3;
            boolean bool5 = bool4;
            long l3 = l1;
            long l4 = l2;
          }
        }
        i2 = i3 + 1;
        localObject1 = localObject3;
        localObject2 = localObject5;
        bool1 = bool6;
        bool3 = bool7;
        bool4 = bool5;
        l1 = l3;
        l2 = l4;
      }
      l3 = Long.MIN_VALUE;
      if (l1 == Long.MIN_VALUE) {
        paramLong = l3;
      }
      for (;;)
      {
        break;
        if (l1 != -1L)
        {
          if (l1 <= 9223372036854775L) {
            l2 = l1 * 1000L;
          } else {
            l2 = Long.MAX_VALUE;
          }
          l2 = paramLong + l2;
          if (l2 >= paramLong)
          {
            paramLong = l2;
            if (l2 <= 253402300799999L) {
              break;
            }
          }
          else
          {
            paramLong = 253402300799999L;
          }
        }
        else
        {
          paramLong = l2;
        }
      }
      Object localObject3 = paramy.l();
      if (localObject2 == null)
      {
        paramString = (String)localObject3;
      }
      else
      {
        if (!b((String)localObject3, (String)localObject2)) {
          return null;
        }
        paramString = (String)localObject2;
      }
      if ((((String)localObject3).length() != paramString.length()) && (PublicSuffixDatabase.c().d(paramString) == null)) {
        return null;
      }
      localObject2 = "/";
      if ((localObject1 != null) && (((String)localObject1).startsWith("/")))
      {
        paramy = (y)localObject1;
      }
      else
      {
        localObject1 = paramy.g();
        i2 = ((String)localObject1).lastIndexOf('/');
        paramy = (y)localObject2;
        if (i2 != 0) {
          paramy = ((String)localObject1).substring(0, i2);
        }
      }
      return new q(str1, str2, paramLong, paramString, paramy, bool1, bool2, bool3, bool4);
    }
    return null;
  }
  
  public static q e(y paramy, String paramString)
  {
    return d(System.currentTimeMillis(), paramy, paramString);
  }
  
  public static List<q> f(y paramy, x paramx)
  {
    List localList = paramx.j("Set-Cookie");
    int n = localList.size();
    x localx = null;
    int i1 = 0;
    while (i1 < n)
    {
      q localq = e(paramy, (String)localList.get(i1));
      if (localq == null)
      {
        paramx = localx;
      }
      else
      {
        paramx = localx;
        if (localx == null) {
          paramx = new ArrayList();
        }
        paramx.add(localq);
      }
      i1++;
      localx = paramx;
    }
    if (localx != null) {
      paramy = Collections.unmodifiableList(localx);
    } else {
      paramy = Collections.emptyList();
    }
    return paramy;
  }
  
  public static String g(String paramString)
  {
    if (!paramString.endsWith("."))
    {
      String str = paramString;
      if (paramString.startsWith(".")) {
        str = paramString.substring(1);
      }
      paramString = e.b(str);
      if (paramString != null) {
        return paramString;
      }
      throw new IllegalArgumentException();
    }
    throw new IllegalArgumentException();
  }
  
  public static long h(String paramString, int paramInt1, int paramInt2)
  {
    int n = a(paramString, paramInt1, paramInt2, false);
    Matcher localMatcher = d.matcher(paramString);
    paramInt1 = -1;
    int i1 = -1;
    int i2 = -1;
    int i3 = -1;
    int i4 = -1;
    int i5 = -1;
    while (n < paramInt2)
    {
      int i6 = a(paramString, n + 1, paramInt2, true);
      localMatcher.region(n, i6);
      int i7;
      int i8;
      int i9;
      int i10;
      int i11;
      if ((i1 == -1) && (localMatcher.usePattern(d).matches()))
      {
        n = Integer.parseInt(localMatcher.group(1));
        i7 = Integer.parseInt(localMatcher.group(2));
        i8 = Integer.parseInt(localMatcher.group(3));
        i9 = paramInt1;
        i10 = i2;
        i11 = i3;
      }
      else if ((i2 == -1) && (localMatcher.usePattern(c).matches()))
      {
        i10 = Integer.parseInt(localMatcher.group(1));
        i9 = paramInt1;
        n = i1;
        i11 = i3;
        i7 = i4;
        i8 = i5;
      }
      else
      {
        if (i3 == -1)
        {
          Pattern localPattern = b;
          if (localMatcher.usePattern(localPattern).matches())
          {
            String str = localMatcher.group(1).toLowerCase(Locale.US);
            i11 = localPattern.pattern().indexOf(str) / 4;
            i9 = paramInt1;
            n = i1;
            i10 = i2;
            i7 = i4;
            i8 = i5;
            break label343;
          }
        }
        i9 = paramInt1;
        n = i1;
        i10 = i2;
        i11 = i3;
        i7 = i4;
        i8 = i5;
        if (paramInt1 == -1)
        {
          i9 = paramInt1;
          n = i1;
          i10 = i2;
          i11 = i3;
          i7 = i4;
          i8 = i5;
          if (localMatcher.usePattern(a).matches())
          {
            i9 = Integer.parseInt(localMatcher.group(1));
            i8 = i5;
            i7 = i4;
            i11 = i3;
            i10 = i2;
            n = i1;
          }
        }
      }
      label343:
      i6 = a(paramString, i6 + 1, paramInt2, false);
      paramInt1 = i9;
      i1 = n;
      i2 = i10;
      i3 = i11;
      i4 = i7;
      i5 = i8;
      n = i6;
    }
    paramInt2 = paramInt1;
    if (paramInt1 >= 70)
    {
      paramInt2 = paramInt1;
      if (paramInt1 <= 99) {
        paramInt2 = paramInt1 + 1900;
      }
    }
    paramInt1 = paramInt2;
    if (paramInt2 >= 0)
    {
      paramInt1 = paramInt2;
      if (paramInt2 <= 69) {
        paramInt1 = paramInt2 + 2000;
      }
    }
    if (paramInt1 >= 1601)
    {
      if (i3 != -1)
      {
        if ((i2 >= 1) && (i2 <= 31))
        {
          if ((i1 >= 0) && (i1 <= 23))
          {
            if ((i4 >= 0) && (i4 <= 59))
            {
              if ((i5 >= 0) && (i5 <= 59))
              {
                paramString = new GregorianCalendar(e.i);
                paramString.setLenient(false);
                paramString.set(1, paramInt1);
                paramString.set(2, i3 - 1);
                paramString.set(5, i2);
                paramString.set(11, i1);
                paramString.set(12, i4);
                paramString.set(13, i5);
                paramString.set(14, 0);
                return paramString.getTimeInMillis();
              }
              throw new IllegalArgumentException();
            }
            throw new IllegalArgumentException();
          }
          throw new IllegalArgumentException();
        }
        throw new IllegalArgumentException();
      }
      throw new IllegalArgumentException();
    }
    paramString = new IllegalArgumentException();
    for (;;)
    {
      throw paramString;
    }
  }
  
  public static long i(String paramString)
  {
    long l1 = Long.MIN_VALUE;
    try
    {
      long l2 = Long.parseLong(paramString);
      if (l2 > 0L) {
        l1 = l2;
      }
      return l1;
    }
    catch (NumberFormatException localNumberFormatException)
    {
      if (paramString.matches("-?\\d+"))
      {
        if (!paramString.startsWith("-")) {
          l1 = Long.MAX_VALUE;
        }
        return l1;
      }
      throw localNumberFormatException;
    }
  }
  
  public String c()
  {
    return this.e;
  }
  
  public boolean equals(Object paramObject)
  {
    boolean bool1 = paramObject instanceof q;
    boolean bool2 = false;
    if (!bool1) {
      return false;
    }
    paramObject = (q)paramObject;
    bool1 = bool2;
    if (((q)paramObject).e.equals(this.e))
    {
      bool1 = bool2;
      if (((q)paramObject).f.equals(this.f))
      {
        bool1 = bool2;
        if (((q)paramObject).h.equals(this.h))
        {
          bool1 = bool2;
          if (((q)paramObject).i.equals(this.i))
          {
            bool1 = bool2;
            if (((q)paramObject).g == this.g)
            {
              bool1 = bool2;
              if (((q)paramObject).j == this.j)
              {
                bool1 = bool2;
                if (((q)paramObject).k == this.k)
                {
                  bool1 = bool2;
                  if (((q)paramObject).l == this.l)
                  {
                    bool1 = bool2;
                    if (((q)paramObject).m == this.m) {
                      bool1 = true;
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    return bool1;
  }
  
  public int hashCode()
  {
    int n = this.e.hashCode();
    int i1 = this.f.hashCode();
    int i2 = this.h.hashCode();
    int i3 = this.i.hashCode();
    long l1 = this.g;
    return ((((((((527 + n) * 31 + i1) * 31 + i2) * 31 + i3) * 31 + (int)(l1 ^ l1 >>> 32)) * 31 + (this.j ^ true)) * 31 + (this.k ^ true)) * 31 + (this.l ^ true)) * 31 + (this.m ^ true);
  }
  
  public String j(boolean paramBoolean)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(this.e);
    localStringBuilder.append('=');
    localStringBuilder.append(this.f);
    if (this.l) {
      if (this.g == Long.MIN_VALUE)
      {
        localStringBuilder.append("; max-age=0");
      }
      else
      {
        localStringBuilder.append("; expires=");
        localStringBuilder.append(d.a(new Date(this.g)));
      }
    }
    if (!this.m)
    {
      localStringBuilder.append("; domain=");
      if (paramBoolean) {
        localStringBuilder.append(".");
      }
      localStringBuilder.append(this.h);
    }
    localStringBuilder.append("; path=");
    localStringBuilder.append(this.i);
    if (this.j) {
      localStringBuilder.append("; secure");
    }
    if (this.k) {
      localStringBuilder.append("; httponly");
    }
    return localStringBuilder.toString();
  }
  
  public String k()
  {
    return this.f;
  }
  
  public String toString()
  {
    return j(false);
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/k/q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */