package i.q;

import i.a0.d;
import i.v.c.l;
import i.v.d.i;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;

public class o
  extends n
{
  public static final <T> T i(List<? extends T> paramList)
  {
    i.e(paramList, "<this>");
    if (!paramList.isEmpty()) {
      return (T)paramList.get(0);
    }
    throw new NoSuchElementException("List is empty.");
  }
  
  public static final <T, A extends Appendable> A j(Iterable<? extends T> paramIterable, A paramA, CharSequence paramCharSequence1, CharSequence paramCharSequence2, CharSequence paramCharSequence3, int paramInt, CharSequence paramCharSequence4, l<? super T, ? extends CharSequence> paraml)
  {
    i.e(paramIterable, "<this>");
    i.e(paramA, "buffer");
    i.e(paramCharSequence1, "separator");
    i.e(paramCharSequence2, "prefix");
    i.e(paramCharSequence3, "postfix");
    i.e(paramCharSequence4, "truncated");
    paramA.append(paramCharSequence2);
    paramIterable = paramIterable.iterator();
    int i = 0;
    int j;
    for (;;)
    {
      j = i;
      if (!paramIterable.hasNext()) {
        break;
      }
      paramCharSequence2 = paramIterable.next();
      i++;
      if (i > 1) {
        paramA.append(paramCharSequence1);
      }
      if (paramInt >= 0)
      {
        j = i;
        if (i > paramInt) {
          break;
        }
      }
      d.a(paramA, paramCharSequence2, paraml);
    }
    if ((paramInt >= 0) && (j > paramInt)) {
      paramA.append(paramCharSequence4);
    }
    paramA.append(paramCharSequence3);
    return paramA;
  }
  
  public static final <T> String l(Iterable<? extends T> paramIterable, CharSequence paramCharSequence1, CharSequence paramCharSequence2, CharSequence paramCharSequence3, int paramInt, CharSequence paramCharSequence4, l<? super T, ? extends CharSequence> paraml)
  {
    i.e(paramIterable, "<this>");
    i.e(paramCharSequence1, "separator");
    i.e(paramCharSequence2, "prefix");
    i.e(paramCharSequence3, "postfix");
    i.e(paramCharSequence4, "truncated");
    paramIterable = ((StringBuilder)j(paramIterable, new StringBuilder(), paramCharSequence1, paramCharSequence2, paramCharSequence3, paramInt, paramCharSequence4, paraml)).toString();
    i.d(paramIterable, "joinTo(StringBuilder(), …ed, transform).toString()");
    return paramIterable;
  }
  
  public static final <T extends Comparable<? super T>> T n(Iterable<? extends T> paramIterable)
  {
    i.e(paramIterable, "<this>");
    Iterator localIterator = paramIterable.iterator();
    if (!localIterator.hasNext()) {
      return null;
    }
    paramIterable = (Comparable)localIterator.next();
    while (localIterator.hasNext())
    {
      Comparable localComparable = (Comparable)localIterator.next();
      if (paramIterable.compareTo(localComparable) > 0) {
        paramIterable = localComparable;
      }
    }
    return paramIterable;
  }
  
  public static final <T> T o(Iterable<? extends T> paramIterable)
  {
    i.e(paramIterable, "<this>");
    if ((paramIterable instanceof List)) {
      return (T)p((List)paramIterable);
    }
    Iterator localIterator = paramIterable.iterator();
    if (localIterator.hasNext())
    {
      paramIterable = localIterator.next();
      if (!localIterator.hasNext()) {
        return paramIterable;
      }
      throw new IllegalArgumentException("Collection has more than one element.");
    }
    throw new NoSuchElementException("Collection is empty.");
  }
  
  public static final <T> T p(List<? extends T> paramList)
  {
    i.e(paramList, "<this>");
    int i = paramList.size();
    if (i != 0)
    {
      if (i == 1) {
        return (T)paramList.get(0);
      }
      throw new IllegalArgumentException("List has more than one element.");
    }
    throw new NoSuchElementException("List is empty.");
  }
  
  public static final <T, C extends Collection<? super T>> C q(Iterable<? extends T> paramIterable, C paramC)
  {
    i.e(paramIterable, "<this>");
    i.e(paramC, "destination");
    paramIterable = paramIterable.iterator();
    while (paramIterable.hasNext()) {
      paramC.add(paramIterable.next());
    }
    return paramC;
  }
  
  public static final <T> List<T> r(Iterable<? extends T> paramIterable)
  {
    i.e(paramIterable, "<this>");
    if ((paramIterable instanceof Collection))
    {
      Collection localCollection = (Collection)paramIterable;
      int i = localCollection.size();
      if (i != 0)
      {
        if (i != 1)
        {
          paramIterable = t(localCollection);
        }
        else
        {
          if ((paramIterable instanceof List)) {
            paramIterable = ((List)paramIterable).get(0);
          } else {
            paramIterable = paramIterable.iterator().next();
          }
          paramIterable = f.a(paramIterable);
        }
      }
      else {
        paramIterable = g.b();
      }
      return paramIterable;
    }
    return g.e(s(paramIterable));
  }
  
  public static final <T> List<T> s(Iterable<? extends T> paramIterable)
  {
    i.e(paramIterable, "<this>");
    if ((paramIterable instanceof Collection)) {
      return t((Collection)paramIterable);
    }
    return (List)q(paramIterable, new ArrayList());
  }
  
  public static final <T> List<T> t(Collection<? extends T> paramCollection)
  {
    i.e(paramCollection, "<this>");
    return new ArrayList(paramCollection);
  }
  
  public static final <T> Set<T> u(Iterable<? extends T> paramIterable)
  {
    i.e(paramIterable, "<this>");
    if ((paramIterable instanceof Collection))
    {
      Collection localCollection = (Collection)paramIterable;
      int i = localCollection.size();
      if (i != 0)
      {
        if (i != 1)
        {
          paramIterable = (Set)q(paramIterable, new LinkedHashSet(v.a(localCollection.size())));
        }
        else
        {
          if ((paramIterable instanceof List)) {
            paramIterable = ((List)paramIterable).get(0);
          } else {
            paramIterable = paramIterable.iterator().next();
          }
          paramIterable = x.a(paramIterable);
        }
      }
      else {
        paramIterable = y.b();
      }
      return paramIterable;
    }
    return y.c((Set)q(paramIterable, new LinkedHashSet()));
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/i/q/o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */