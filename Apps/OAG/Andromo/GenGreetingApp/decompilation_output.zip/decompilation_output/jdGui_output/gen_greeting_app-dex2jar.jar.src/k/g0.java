package k;

import java.io.Closeable;
import k.k0.h.d;

public final class g0
  implements Closeable
{
  public final e0 g;
  public final c0 h;
  public final int i;
  public final String j;
  public final w k;
  public final x l;
  public final h0 m;
  public final g0 n;
  public final g0 o;
  public final g0 p;
  public final long q;
  public final long r;
  public final d s;
  public volatile i t;
  
  public g0(a parama)
  {
    this.g = parama.a;
    this.h = parama.b;
    this.i = parama.c;
    this.j = parama.d;
    this.k = parama.e;
    this.l = parama.f.d();
    this.m = parama.g;
    this.n = parama.h;
    this.o = parama.i;
    this.p = parama.j;
    this.q = parama.k;
    this.r = parama.l;
    this.s = parama.m;
  }
  
  public h0 a()
  {
    return this.m;
  }
  
  public i b()
  {
    i locali = this.t;
    if (locali == null)
    {
      locali = i.k(this.l);
      this.t = locali;
    }
    return locali;
  }
  
  public void close()
  {
    h0 localh0 = this.m;
    if (localh0 != null)
    {
      localh0.close();
      return;
    }
    throw new IllegalStateException("response is not eligible for a body and must not be closed");
  }
  
  public int d()
  {
    return this.i;
  }
  
  public w g()
  {
    return this.k;
  }
  
  public String h(String paramString)
  {
    return i(paramString, null);
  }
  
  public String i(String paramString1, String paramString2)
  {
    paramString1 = this.l.c(paramString1);
    if (paramString1 != null) {
      paramString2 = paramString1;
    }
    return paramString2;
  }
  
  public x m()
  {
    return this.l;
  }
  
  public a o()
  {
    return new a(this);
  }
  
  public g0 q()
  {
    return this.p;
  }
  
  public long s()
  {
    return this.r;
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("Response{protocol=");
    localStringBuilder.append(this.h);
    localStringBuilder.append(", code=");
    localStringBuilder.append(this.i);
    localStringBuilder.append(", message=");
    localStringBuilder.append(this.j);
    localStringBuilder.append(", url=");
    localStringBuilder.append(this.g.h());
    localStringBuilder.append('}');
    return localStringBuilder.toString();
  }
  
  public e0 u()
  {
    return this.g;
  }
  
  public long v()
  {
    return this.q;
  }
  
  public static class a
  {
    public e0 a;
    public c0 b;
    public int c = -1;
    public String d;
    public w e;
    public x.a f;
    public h0 g;
    public g0 h;
    public g0 i;
    public g0 j;
    public long k;
    public long l;
    public d m;
    
    public a()
    {
      this.f = new x.a();
    }
    
    public a(g0 paramg0)
    {
      this.a = paramg0.g;
      this.b = paramg0.h;
      this.c = paramg0.i;
      this.d = paramg0.j;
      this.e = paramg0.k;
      this.f = paramg0.l.f();
      this.g = paramg0.m;
      this.h = paramg0.n;
      this.i = paramg0.o;
      this.j = paramg0.p;
      this.k = paramg0.q;
      this.l = paramg0.r;
      this.m = paramg0.s;
    }
    
    public a a(String paramString1, String paramString2)
    {
      this.f.a(paramString1, paramString2);
      return this;
    }
    
    public a b(h0 paramh0)
    {
      this.g = paramh0;
      return this;
    }
    
    public g0 c()
    {
      if (this.a != null)
      {
        if (this.b != null)
        {
          if (this.c >= 0)
          {
            if (this.d != null) {
              return new g0(this);
            }
            throw new IllegalStateException("message == null");
          }
          StringBuilder localStringBuilder = new StringBuilder();
          localStringBuilder.append("code < 0: ");
          localStringBuilder.append(this.c);
          throw new IllegalStateException(localStringBuilder.toString());
        }
        throw new IllegalStateException("protocol == null");
      }
      throw new IllegalStateException("request == null");
    }
    
    public a d(g0 paramg0)
    {
      if (paramg0 != null) {
        f("cacheResponse", paramg0);
      }
      this.i = paramg0;
      return this;
    }
    
    public final void e(g0 paramg0)
    {
      if (paramg0.m == null) {
        return;
      }
      throw new IllegalArgumentException("priorResponse.body != null");
    }
    
    public final void f(String paramString, g0 paramg0)
    {
      if (paramg0.m == null)
      {
        if (paramg0.n == null)
        {
          if (paramg0.o == null)
          {
            if (paramg0.p == null) {
              return;
            }
            paramg0 = new StringBuilder();
            paramg0.append(paramString);
            paramg0.append(".priorResponse != null");
            throw new IllegalArgumentException(paramg0.toString());
          }
          paramg0 = new StringBuilder();
          paramg0.append(paramString);
          paramg0.append(".cacheResponse != null");
          throw new IllegalArgumentException(paramg0.toString());
        }
        paramg0 = new StringBuilder();
        paramg0.append(paramString);
        paramg0.append(".networkResponse != null");
        throw new IllegalArgumentException(paramg0.toString());
      }
      paramg0 = new StringBuilder();
      paramg0.append(paramString);
      paramg0.append(".body != null");
      throw new IllegalArgumentException(paramg0.toString());
    }
    
    public a g(int paramInt)
    {
      this.c = paramInt;
      return this;
    }
    
    public a h(w paramw)
    {
      this.e = paramw;
      return this;
    }
    
    public a i(String paramString1, String paramString2)
    {
      this.f.f(paramString1, paramString2);
      return this;
    }
    
    public a j(x paramx)
    {
      this.f = paramx.f();
      return this;
    }
    
    public void k(d paramd)
    {
      this.m = paramd;
    }
    
    public a l(String paramString)
    {
      this.d = paramString;
      return this;
    }
    
    public a m(g0 paramg0)
    {
      if (paramg0 != null) {
        f("networkResponse", paramg0);
      }
      this.h = paramg0;
      return this;
    }
    
    public a n(g0 paramg0)
    {
      if (paramg0 != null) {
        e(paramg0);
      }
      this.j = paramg0;
      return this;
    }
    
    public a o(c0 paramc0)
    {
      this.b = paramc0;
      return this;
    }
    
    public a p(long paramLong)
    {
      this.l = paramLong;
      return this;
    }
    
    public a q(e0 parame0)
    {
      this.a = parame0;
      return this;
    }
    
    public a r(long paramLong)
    {
      this.k = paramLong;
      return this;
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/k/g0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */