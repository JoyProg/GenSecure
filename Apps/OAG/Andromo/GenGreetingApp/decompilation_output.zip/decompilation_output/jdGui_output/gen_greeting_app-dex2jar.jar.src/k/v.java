package k;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.util.List;

public abstract class v
{
  public static final v a = new a();
  
  public static b k(v paramv)
  {
    return new d(paramv);
  }
  
  public void a(j paramj) {}
  
  public void b(j paramj, IOException paramIOException) {}
  
  public void c(j paramj) {}
  
  public void d(j paramj, InetSocketAddress paramInetSocketAddress, Proxy paramProxy, c0 paramc0) {}
  
  public void e(j paramj, InetSocketAddress paramInetSocketAddress, Proxy paramProxy, c0 paramc0, IOException paramIOException) {}
  
  public void f(j paramj, InetSocketAddress paramInetSocketAddress, Proxy paramProxy) {}
  
  public void g(j paramj, n paramn) {}
  
  public void h(j paramj, n paramn) {}
  
  public void i(j paramj, String paramString, List<InetAddress> paramList) {}
  
  public void j(j paramj, String paramString) {}
  
  public void m(j paramj, long paramLong) {}
  
  public void n(j paramj) {}
  
  public void o(j paramj, IOException paramIOException) {}
  
  public void p(j paramj, e0 parame0) {}
  
  public void q(j paramj) {}
  
  public void r(j paramj, long paramLong) {}
  
  public void s(j paramj) {}
  
  public void t(j paramj, IOException paramIOException) {}
  
  public void u(j paramj, g0 paramg0) {}
  
  public void v(j paramj) {}
  
  public void w(j paramj, w paramw) {}
  
  public void x(j paramj) {}
  
  public class a
    extends v
  {}
  
  public static abstract interface b
  {
    public abstract v a(j paramj);
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/k/v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */