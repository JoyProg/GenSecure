package i;

import i.v.c.a;
import i.v.d.i;
import java.io.Serializable;

public final class l<T>
  implements f<T>, Serializable
{
  public a<? extends T> g;
  public volatile Object h;
  public final Object i;
  
  public l(a<? extends T> parama, Object paramObject)
  {
    this.g = parama;
    this.h = n.a;
    parama = (a<? extends T>)paramObject;
    if (paramObject == null) {
      parama = this;
    }
    this.i = parama;
  }
  
  public boolean a()
  {
    boolean bool;
    if (this.h != n.a) {
      bool = true;
    } else {
      bool = false;
    }
    return bool;
  }
  
  public T getValue()
  {
    Object localObject1 = this.h;
    n localn = n.a;
    if (localObject1 != localn) {
      return (T)localObject1;
    }
    synchronized (this.i)
    {
      localObject1 = this.h;
      if (localObject1 == localn)
      {
        localObject1 = this.g;
        i.b(localObject1);
        localObject1 = ((a)localObject1).invoke();
        this.h = localObject1;
        this.g = null;
      }
      return (T)localObject1;
    }
  }
  
  public String toString()
  {
    String str;
    if (a()) {
      str = String.valueOf(getValue());
    } else {
      str = "Lazy value not initialized yet.";
    }
    return str;
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/i/l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */