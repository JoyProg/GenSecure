package i.a0;

import i.q.t;
import i.v.d.i;
import java.util.Collection;
import java.util.Iterator;

public class l
  extends k
{
  public static final boolean j(String paramString1, String paramString2, boolean paramBoolean)
  {
    i.e(paramString1, "<this>");
    i.e(paramString2, "suffix");
    if (!paramBoolean) {
      return paramString1.endsWith(paramString2);
    }
    return m(paramString1, paramString1.length() - paramString2.length(), paramString2, 0, paramString2.length(), true);
  }
  
  public static final boolean l(CharSequence paramCharSequence)
  {
    i.e(paramCharSequence, "<this>");
    int i = paramCharSequence.length();
    boolean bool = false;
    if (i != 0)
    {
      Object localObject = m.t(paramCharSequence);
      if (((localObject instanceof Collection)) && (((Collection)localObject).isEmpty())) {}
      do
      {
        while (!((Iterator)localObject).hasNext())
        {
          i = 1;
          break;
          localObject = ((Iterable)localObject).iterator();
        }
      } while (a.c(paramCharSequence.charAt(((t)localObject).b())));
      i = 0;
      if (i == 0) {}
    }
    else
    {
      bool = true;
    }
    return bool;
  }
  
  public static final boolean m(String paramString1, int paramInt1, String paramString2, int paramInt2, int paramInt3, boolean paramBoolean)
  {
    i.e(paramString1, "<this>");
    i.e(paramString2, "other");
    if (!paramBoolean) {
      paramBoolean = paramString1.regionMatches(paramInt1, paramString2, paramInt2, paramInt3);
    } else {
      paramBoolean = paramString1.regionMatches(paramBoolean, paramInt1, paramString2, paramInt2, paramInt3);
    }
    return paramBoolean;
  }
  
  public static final boolean n(String paramString1, String paramString2, boolean paramBoolean)
  {
    i.e(paramString1, "<this>");
    i.e(paramString2, "prefix");
    if (!paramBoolean) {
      return paramString1.startsWith(paramString2);
    }
    return m(paramString1, 0, paramString2, 0, paramString2.length(), paramBoolean);
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/i/a0/l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */