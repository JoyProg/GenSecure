package k;

import java.util.concurrent.TimeUnit;
import k.k0.i.e;

public final class i
{
  public static final i a = new a().c().a();
  public static final i b = new a().d().b(Integer.MAX_VALUE, TimeUnit.SECONDS).a();
  public final boolean c;
  public final boolean d;
  public final int e;
  public final int f;
  public final boolean g;
  public final boolean h;
  public final boolean i;
  public final int j;
  public final int k;
  public final boolean l;
  public final boolean m;
  public final boolean n;
  public String o;
  
  public i(a parama)
  {
    this.c = parama.a;
    this.d = parama.b;
    this.e = parama.c;
    this.f = -1;
    this.g = false;
    this.h = false;
    this.i = false;
    this.j = parama.d;
    this.k = parama.e;
    this.l = parama.f;
    this.m = parama.g;
    this.n = parama.h;
  }
  
  public i(boolean paramBoolean1, boolean paramBoolean2, int paramInt1, int paramInt2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5, int paramInt3, int paramInt4, boolean paramBoolean6, boolean paramBoolean7, boolean paramBoolean8, String paramString)
  {
    this.c = paramBoolean1;
    this.d = paramBoolean2;
    this.e = paramInt1;
    this.f = paramInt2;
    this.g = paramBoolean3;
    this.h = paramBoolean4;
    this.i = paramBoolean5;
    this.j = paramInt3;
    this.k = paramInt4;
    this.l = paramBoolean6;
    this.m = paramBoolean7;
    this.n = paramBoolean8;
    this.o = paramString;
  }
  
  public static i k(x paramx)
  {
    int i1 = paramx.h();
    int i2 = 0;
    int i3 = 1;
    Object localObject1 = null;
    boolean bool1 = false;
    boolean bool2 = false;
    int i4 = -1;
    int i5 = -1;
    boolean bool3 = false;
    boolean bool4 = false;
    boolean bool5 = false;
    int i6 = -1;
    int i7 = -1;
    boolean bool6 = false;
    boolean bool7 = false;
    boolean bool16;
    for (boolean bool8 = false;; bool8 = bool16)
    {
      Object localObject2 = paramx;
      if (i2 >= i1) {
        break;
      }
      String str1 = ((x)localObject2).e(i2);
      String str2 = ((x)localObject2).i(i2);
      int i8;
      boolean bool9;
      boolean bool10;
      int i9;
      int i10;
      boolean bool11;
      boolean bool12;
      boolean bool13;
      int i11;
      int i12;
      boolean bool14;
      boolean bool15;
      if (str1.equalsIgnoreCase("Cache-Control"))
      {
        if (localObject1 == null)
        {
          localObject1 = str2;
          break label164;
        }
      }
      else
      {
        i8 = i3;
        localObject2 = localObject1;
        bool9 = bool1;
        bool10 = bool2;
        i9 = i4;
        i10 = i5;
        bool11 = bool3;
        bool12 = bool4;
        bool13 = bool5;
        i11 = i6;
        i12 = i7;
        bool14 = bool6;
        bool15 = bool7;
        bool16 = bool8;
        if (!str1.equalsIgnoreCase("Pragma")) {
          break label1187;
        }
      }
      i3 = 0;
      label164:
      int i13 = 0;
      for (;;)
      {
        i8 = i3;
        localObject2 = localObject1;
        bool9 = bool1;
        bool10 = bool2;
        i9 = i4;
        i10 = i5;
        bool11 = bool3;
        bool12 = bool4;
        bool13 = bool5;
        i11 = i6;
        i12 = i7;
        bool14 = bool6;
        bool15 = bool7;
        bool16 = bool8;
        if (i13 >= str2.length()) {
          break;
        }
        i12 = e.f(str2, i13, "=,;");
        str1 = str2.substring(i13, i12).trim();
        if ((i12 != str2.length()) && (str2.charAt(i12) != ',') && (str2.charAt(i12) != ';'))
        {
          i11 = e.g(str2, i12 + 1);
          if ((i11 < str2.length()) && (str2.charAt(i11) == '"'))
          {
            i12 = i11 + 1;
            i11 = e.f(str2, i12, "\"");
            localObject2 = str2.substring(i12, i11);
            i12 = i11 + 1;
          }
          else
          {
            i12 = e.f(str2, i11, ",;");
            localObject2 = str2.substring(i11, i12).trim();
          }
        }
        else
        {
          i12++;
          localObject2 = null;
        }
        if ("no-cache".equalsIgnoreCase(str1))
        {
          bool16 = true;
          bool14 = bool2;
          i11 = i4;
          i9 = i5;
          bool13 = bool3;
          bool10 = bool4;
          bool9 = bool5;
          i10 = i6;
          i8 = i7;
          bool11 = bool6;
          bool15 = bool7;
        }
        else if ("no-store".equalsIgnoreCase(str1))
        {
          bool14 = true;
          bool16 = bool1;
          i11 = i4;
          i9 = i5;
          bool13 = bool3;
          bool10 = bool4;
          bool9 = bool5;
          i10 = i6;
          i8 = i7;
          bool11 = bool6;
          bool15 = bool7;
        }
        else if ("max-age".equalsIgnoreCase(str1))
        {
          i11 = e.d((String)localObject2, -1);
          bool16 = bool1;
          bool14 = bool2;
          i9 = i5;
          bool13 = bool3;
          bool10 = bool4;
          bool9 = bool5;
          i10 = i6;
          i8 = i7;
          bool11 = bool6;
          bool15 = bool7;
        }
        else if ("s-maxage".equalsIgnoreCase(str1))
        {
          i9 = e.d((String)localObject2, -1);
          bool16 = bool1;
          bool14 = bool2;
          i11 = i4;
          bool13 = bool3;
          bool10 = bool4;
          bool9 = bool5;
          i10 = i6;
          i8 = i7;
          bool11 = bool6;
          bool15 = bool7;
        }
        else if ("private".equalsIgnoreCase(str1))
        {
          bool13 = true;
          bool16 = bool1;
          bool14 = bool2;
          i11 = i4;
          i9 = i5;
          bool10 = bool4;
          bool9 = bool5;
          i10 = i6;
          i8 = i7;
          bool11 = bool6;
          bool15 = bool7;
        }
        else if ("public".equalsIgnoreCase(str1))
        {
          bool10 = true;
          bool16 = bool1;
          bool14 = bool2;
          i11 = i4;
          i9 = i5;
          bool13 = bool3;
          bool9 = bool5;
          i10 = i6;
          i8 = i7;
          bool11 = bool6;
          bool15 = bool7;
        }
        else if ("must-revalidate".equalsIgnoreCase(str1))
        {
          bool9 = true;
          bool16 = bool1;
          bool14 = bool2;
          i11 = i4;
          i9 = i5;
          bool13 = bool3;
          bool10 = bool4;
          i10 = i6;
          i8 = i7;
          bool11 = bool6;
          bool15 = bool7;
        }
        else if ("max-stale".equalsIgnoreCase(str1))
        {
          i10 = e.d((String)localObject2, Integer.MAX_VALUE);
          bool16 = bool1;
          bool14 = bool2;
          i11 = i4;
          i9 = i5;
          bool13 = bool3;
          bool10 = bool4;
          bool9 = bool5;
          i8 = i7;
          bool11 = bool6;
          bool15 = bool7;
        }
        else if ("min-fresh".equalsIgnoreCase(str1))
        {
          i8 = e.d((String)localObject2, -1);
          bool16 = bool1;
          bool14 = bool2;
          i11 = i4;
          i9 = i5;
          bool13 = bool3;
          bool10 = bool4;
          bool9 = bool5;
          i10 = i6;
          bool11 = bool6;
          bool15 = bool7;
        }
        else if ("only-if-cached".equalsIgnoreCase(str1))
        {
          bool11 = true;
          bool16 = bool1;
          bool14 = bool2;
          i11 = i4;
          i9 = i5;
          bool13 = bool3;
          bool10 = bool4;
          bool9 = bool5;
          i10 = i6;
          i8 = i7;
          bool15 = bool7;
        }
        else if ("no-transform".equalsIgnoreCase(str1))
        {
          bool15 = true;
          bool16 = bool1;
          bool14 = bool2;
          i11 = i4;
          i9 = i5;
          bool13 = bool3;
          bool10 = bool4;
          bool9 = bool5;
          i10 = i6;
          i8 = i7;
          bool11 = bool6;
        }
        else
        {
          bool16 = bool1;
          bool14 = bool2;
          i11 = i4;
          i9 = i5;
          bool13 = bool3;
          bool10 = bool4;
          bool9 = bool5;
          i10 = i6;
          i8 = i7;
          bool11 = bool6;
          bool15 = bool7;
          if ("immutable".equalsIgnoreCase(str1))
          {
            bool8 = true;
            bool15 = bool7;
            bool11 = bool6;
            i8 = i7;
            i10 = i6;
            bool9 = bool5;
            bool10 = bool4;
            bool13 = bool3;
            i9 = i5;
            i11 = i4;
            bool14 = bool2;
            bool16 = bool1;
          }
        }
        i13 = i12;
        bool1 = bool16;
        bool2 = bool14;
        i4 = i11;
        i5 = i9;
        bool3 = bool13;
        bool4 = bool10;
        bool5 = bool9;
        i6 = i10;
        i7 = i8;
        bool6 = bool11;
        bool7 = bool15;
      }
      label1187:
      i2++;
      i3 = i8;
      localObject1 = localObject2;
      bool1 = bool9;
      bool2 = bool10;
      i4 = i9;
      i5 = i10;
      bool3 = bool11;
      bool4 = bool12;
      bool5 = bool13;
      i6 = i11;
      i7 = i12;
      bool6 = bool14;
      bool7 = bool15;
    }
    if (i3 == 0) {
      paramx = null;
    } else {
      paramx = (x)localObject1;
    }
    return new i(bool1, bool2, i4, i5, bool3, bool4, bool5, i6, i7, bool6, bool7, bool8, paramx);
  }
  
  public final String a()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    if (this.c) {
      localStringBuilder.append("no-cache, ");
    }
    if (this.d) {
      localStringBuilder.append("no-store, ");
    }
    if (this.e != -1)
    {
      localStringBuilder.append("max-age=");
      localStringBuilder.append(this.e);
      localStringBuilder.append(", ");
    }
    if (this.f != -1)
    {
      localStringBuilder.append("s-maxage=");
      localStringBuilder.append(this.f);
      localStringBuilder.append(", ");
    }
    if (this.g) {
      localStringBuilder.append("private, ");
    }
    if (this.h) {
      localStringBuilder.append("public, ");
    }
    if (this.i) {
      localStringBuilder.append("must-revalidate, ");
    }
    if (this.j != -1)
    {
      localStringBuilder.append("max-stale=");
      localStringBuilder.append(this.j);
      localStringBuilder.append(", ");
    }
    if (this.k != -1)
    {
      localStringBuilder.append("min-fresh=");
      localStringBuilder.append(this.k);
      localStringBuilder.append(", ");
    }
    if (this.l) {
      localStringBuilder.append("only-if-cached, ");
    }
    if (this.m) {
      localStringBuilder.append("no-transform, ");
    }
    if (this.n) {
      localStringBuilder.append("immutable, ");
    }
    if (localStringBuilder.length() == 0) {
      return "";
    }
    localStringBuilder.delete(localStringBuilder.length() - 2, localStringBuilder.length());
    return localStringBuilder.toString();
  }
  
  public boolean b()
  {
    return this.g;
  }
  
  public boolean c()
  {
    return this.h;
  }
  
  public int d()
  {
    return this.e;
  }
  
  public int e()
  {
    return this.j;
  }
  
  public int f()
  {
    return this.k;
  }
  
  public boolean g()
  {
    return this.i;
  }
  
  public boolean h()
  {
    return this.c;
  }
  
  public boolean i()
  {
    return this.d;
  }
  
  public boolean j()
  {
    return this.l;
  }
  
  public String toString()
  {
    String str = this.o;
    if (str == null)
    {
      str = a();
      this.o = str;
    }
    return str;
  }
  
  public static final class a
  {
    public boolean a;
    public boolean b;
    public int c = -1;
    public int d = -1;
    public int e = -1;
    public boolean f;
    public boolean g;
    public boolean h;
    
    public i a()
    {
      return new i(this);
    }
    
    public a b(int paramInt, TimeUnit paramTimeUnit)
    {
      if (paramInt >= 0)
      {
        long l = paramTimeUnit.toSeconds(paramInt);
        if (l > 2147483647L) {
          paramInt = Integer.MAX_VALUE;
        } else {
          paramInt = (int)l;
        }
        this.d = paramInt;
        return this;
      }
      paramTimeUnit = new StringBuilder();
      paramTimeUnit.append("maxStale < 0: ");
      paramTimeUnit.append(paramInt);
      throw new IllegalArgumentException(paramTimeUnit.toString());
    }
    
    public a c()
    {
      this.a = true;
      return this;
    }
    
    public a d()
    {
      this.f = true;
      return this;
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/k/i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */