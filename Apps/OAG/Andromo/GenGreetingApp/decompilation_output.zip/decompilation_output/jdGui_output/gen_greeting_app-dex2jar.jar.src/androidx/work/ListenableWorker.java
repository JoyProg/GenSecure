package androidx.work;

import android.annotation.SuppressLint;
import android.content.Context;
import androidx.annotation.Keep;
import c.y.g;
import c.y.x;
import c.y.y.p.o.c;
import java.util.UUID;
import java.util.concurrent.Executor;

public abstract class ListenableWorker
{
  public Context g;
  public WorkerParameters h;
  public volatile boolean i;
  public boolean j;
  public boolean k;
  
  @SuppressLint({"BanKeepAnnotation"})
  @Keep
  public ListenableWorker(Context paramContext, WorkerParameters paramWorkerParameters)
  {
    if (paramContext != null)
    {
      if (paramWorkerParameters != null)
      {
        this.g = paramContext;
        this.h = paramWorkerParameters;
        return;
      }
      throw new IllegalArgumentException("WorkerParameters is null");
    }
    throw new IllegalArgumentException("Application Context is null");
  }
  
  public final Context a()
  {
    return this.g;
  }
  
  public Executor b()
  {
    return this.h.a();
  }
  
  public d.c.b.e.a.e<g> c()
  {
    c localc = c.t();
    localc.q(new IllegalStateException("Expedited WorkRequests require a ListenableWorker to provide an implementation for `getForegroundInfoAsync()`"));
    return localc;
  }
  
  public final UUID f()
  {
    return this.h.c();
  }
  
  public final c.y.e g()
  {
    return this.h.d();
  }
  
  public x h()
  {
    return this.h.e();
  }
  
  public boolean i()
  {
    return this.k;
  }
  
  public final boolean j()
  {
    return this.i;
  }
  
  public final boolean k()
  {
    return this.j;
  }
  
  public void l() {}
  
  public void m(boolean paramBoolean)
  {
    this.k = paramBoolean;
  }
  
  public final void n()
  {
    this.j = true;
  }
  
  public abstract d.c.b.e.a.e<a> o();
  
  public final void p()
  {
    this.i = true;
    l();
  }
  
  public static abstract class a
  {
    public static a a()
    {
      return new a();
    }
    
    public static a b()
    {
      return new b();
    }
    
    public static a c()
    {
      return new c();
    }
    
    public static a d(c.y.e parame)
    {
      return new c(parame);
    }
    
    public static final class a
      extends ListenableWorker.a
    {
      public final c.y.e a;
      
      public a()
      {
        this(c.y.e.b);
      }
      
      public a(c.y.e parame)
      {
        this.a = parame;
      }
      
      public c.y.e e()
      {
        return this.a;
      }
      
      public boolean equals(Object paramObject)
      {
        if (this == paramObject) {
          return true;
        }
        if ((paramObject != null) && (a.class == paramObject.getClass()))
        {
          paramObject = (a)paramObject;
          return this.a.equals(((a)paramObject).a);
        }
        return false;
      }
      
      public int hashCode()
      {
        return a.class.getName().hashCode() * 31 + this.a.hashCode();
      }
      
      public String toString()
      {
        StringBuilder localStringBuilder = new StringBuilder();
        localStringBuilder.append("Failure {mOutputData=");
        localStringBuilder.append(this.a);
        localStringBuilder.append('}');
        return localStringBuilder.toString();
      }
    }
    
    public static final class b
      extends ListenableWorker.a
    {
      public boolean equals(Object paramObject)
      {
        boolean bool = true;
        if (this == paramObject) {
          return true;
        }
        if ((paramObject == null) || (b.class != paramObject.getClass())) {
          bool = false;
        }
        return bool;
      }
      
      public int hashCode()
      {
        return b.class.getName().hashCode();
      }
      
      public String toString()
      {
        return "Retry";
      }
    }
    
    public static final class c
      extends ListenableWorker.a
    {
      public final c.y.e a;
      
      public c()
      {
        this(c.y.e.b);
      }
      
      public c(c.y.e parame)
      {
        this.a = parame;
      }
      
      public c.y.e e()
      {
        return this.a;
      }
      
      public boolean equals(Object paramObject)
      {
        if (this == paramObject) {
          return true;
        }
        if ((paramObject != null) && (c.class == paramObject.getClass()))
        {
          paramObject = (c)paramObject;
          return this.a.equals(((c)paramObject).a);
        }
        return false;
      }
      
      public int hashCode()
      {
        return c.class.getName().hashCode() * 31 + this.a.hashCode();
      }
      
      public String toString()
      {
        StringBuilder localStringBuilder = new StringBuilder();
        localStringBuilder.append("Success {mOutputData=");
        localStringBuilder.append(this.a);
        localStringBuilder.append('}');
        return localStringBuilder.toString();
      }
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/androidx/work/ListenableWorker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */