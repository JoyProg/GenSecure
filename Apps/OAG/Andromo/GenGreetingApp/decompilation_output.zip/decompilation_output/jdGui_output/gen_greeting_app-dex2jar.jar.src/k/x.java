package k;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import k.k0.e;

public final class x
{
  public final String[] a;
  
  public x(a parama)
  {
    parama = parama.a;
    this.a = ((String[])parama.toArray(new String[parama.size()]));
  }
  
  public x(String[] paramArrayOfString)
  {
    this.a = paramArrayOfString;
  }
  
  public static void a(String paramString)
  {
    Objects.requireNonNull(paramString, "name == null");
    if (!paramString.isEmpty())
    {
      int i = paramString.length();
      int j = 0;
      while (j < i)
      {
        int k = paramString.charAt(j);
        if ((k > 32) && (k < 127)) {
          j++;
        } else {
          throw new IllegalArgumentException(e.o("Unexpected char %#04x at %d in header name: %s", new Object[] { Integer.valueOf(k), Integer.valueOf(j), paramString }));
        }
      }
      return;
    }
    paramString = new IllegalArgumentException("name is empty");
    for (;;)
    {
      throw paramString;
    }
  }
  
  public static void b(String paramString1, String paramString2)
  {
    if (paramString1 != null)
    {
      int i = paramString1.length();
      int j = 0;
      while (j < i)
      {
        int k = paramString1.charAt(j);
        if (((k > 31) || (k == 9)) && (k < 127)) {
          j++;
        } else {
          throw new IllegalArgumentException(e.o("Unexpected char %#04x at %d in %s value: %s", new Object[] { Integer.valueOf(k), Integer.valueOf(j), paramString2, paramString1 }));
        }
      }
      return;
    }
    paramString1 = new StringBuilder();
    paramString1.append("value for name ");
    paramString1.append(paramString2);
    paramString1.append(" == null");
    paramString1 = new NullPointerException(paramString1.toString());
    for (;;)
    {
      throw paramString1;
    }
  }
  
  public static String d(String[] paramArrayOfString, String paramString)
  {
    for (int i = paramArrayOfString.length - 2; i >= 0; i -= 2) {
      if (paramString.equalsIgnoreCase(paramArrayOfString[i])) {
        return paramArrayOfString[(i + 1)];
      }
    }
    return null;
  }
  
  public static x g(String... paramVarArgs)
  {
    Objects.requireNonNull(paramVarArgs, "namesAndValues == null");
    if (paramVarArgs.length % 2 == 0)
    {
      paramVarArgs = (String[])paramVarArgs.clone();
      int i = 0;
      int k;
      for (int j = 0;; j++)
      {
        k = i;
        if (j >= paramVarArgs.length) {
          break label65;
        }
        if (paramVarArgs[j] == null) {
          break;
        }
        paramVarArgs[j] = paramVarArgs[j].trim();
      }
      throw new IllegalArgumentException("Headers cannot be null");
      label65:
      while (k < paramVarArgs.length)
      {
        String str1 = paramVarArgs[k];
        String str2 = paramVarArgs[(k + 1)];
        a(str1);
        b(str2, str1);
        k += 2;
      }
      return new x(paramVarArgs);
    }
    paramVarArgs = new IllegalArgumentException("Expected alternating header names and values");
    for (;;)
    {
      throw paramVarArgs;
    }
  }
  
  public String c(String paramString)
  {
    return d(this.a, paramString);
  }
  
  public String e(int paramInt)
  {
    return this.a[(paramInt * 2)];
  }
  
  public boolean equals(Object paramObject)
  {
    boolean bool;
    if (((paramObject instanceof x)) && (Arrays.equals(((x)paramObject).a, this.a))) {
      bool = true;
    } else {
      bool = false;
    }
    return bool;
  }
  
  public a f()
  {
    a locala = new a();
    Collections.addAll(locala.a, this.a);
    return locala;
  }
  
  public int h()
  {
    return this.a.length / 2;
  }
  
  public int hashCode()
  {
    return Arrays.hashCode(this.a);
  }
  
  public String i(int paramInt)
  {
    return this.a[(paramInt * 2 + 1)];
  }
  
  public List<String> j(String paramString)
  {
    int i = h();
    Object localObject1 = null;
    int j = 0;
    while (j < i)
    {
      Object localObject2 = localObject1;
      if (paramString.equalsIgnoreCase(e(j)))
      {
        localObject2 = localObject1;
        if (localObject1 == null) {
          localObject2 = new ArrayList(2);
        }
        ((List)localObject2).add(i(j));
      }
      j++;
      localObject1 = localObject2;
    }
    if (localObject1 != null) {
      paramString = Collections.unmodifiableList((List)localObject1);
    } else {
      paramString = Collections.emptyList();
    }
    return paramString;
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    int i = h();
    for (int j = 0; j < i; j++)
    {
      localStringBuilder.append(e(j));
      localStringBuilder.append(": ");
      localStringBuilder.append(i(j));
      localStringBuilder.append("\n");
    }
    return localStringBuilder.toString();
  }
  
  public static final class a
  {
    public final List<String> a = new ArrayList(20);
    
    public a a(String paramString1, String paramString2)
    {
      x.a(paramString1);
      x.b(paramString2, paramString1);
      return c(paramString1, paramString2);
    }
    
    public a b(String paramString)
    {
      int i = paramString.indexOf(":", 1);
      if (i != -1) {
        return c(paramString.substring(0, i), paramString.substring(i + 1));
      }
      if (paramString.startsWith(":")) {
        return c("", paramString.substring(1));
      }
      return c("", paramString);
    }
    
    public a c(String paramString1, String paramString2)
    {
      this.a.add(paramString1);
      this.a.add(paramString2.trim());
      return this;
    }
    
    public x d()
    {
      return new x(this);
    }
    
    public a e(String paramString)
    {
      int j;
      for (int i = 0; i < this.a.size(); i = j + 2)
      {
        j = i;
        if (paramString.equalsIgnoreCase((String)this.a.get(i)))
        {
          this.a.remove(i);
          this.a.remove(i);
          j = i - 2;
        }
      }
      return this;
    }
    
    public a f(String paramString1, String paramString2)
    {
      x.a(paramString1);
      x.b(paramString2, paramString1);
      e(paramString1);
      c(paramString1, paramString2);
      return this;
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/k/x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */