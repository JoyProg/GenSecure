package k;

import java.io.IOException;

public enum c0
{
  public final String n;
  
  static
  {
    c0 localc01 = new c0("HTTP_1_0", 0, "http/1.0");
    g = localc01;
    c0 localc02 = new c0("HTTP_1_1", 1, "http/1.1");
    h = localc02;
    c0 localc03 = new c0("SPDY_3", 2, "spdy/3.1");
    i = localc03;
    c0 localc04 = new c0("HTTP_2", 3, "h2");
    j = localc04;
    c0 localc05 = new c0("H2_PRIOR_KNOWLEDGE", 4, "h2_prior_knowledge");
    k = localc05;
    c0 localc06 = new c0("QUIC", 5, "quic");
    l = localc06;
    m = new c0[] { localc01, localc02, localc03, localc04, localc05, localc06 };
  }
  
  public c0(String paramString)
  {
    this.n = paramString;
  }
  
  public static c0 e(String paramString)
  {
    Object localObject = g;
    if (paramString.equals(((c0)localObject).n)) {
      return (c0)localObject;
    }
    localObject = h;
    if (paramString.equals(((c0)localObject).n)) {
      return (c0)localObject;
    }
    localObject = k;
    if (paramString.equals(((c0)localObject).n)) {
      return (c0)localObject;
    }
    localObject = j;
    if (paramString.equals(((c0)localObject).n)) {
      return (c0)localObject;
    }
    localObject = i;
    if (paramString.equals(((c0)localObject).n)) {
      return (c0)localObject;
    }
    localObject = l;
    if (paramString.equals(((c0)localObject).n)) {
      return (c0)localObject;
    }
    localObject = new StringBuilder();
    ((StringBuilder)localObject).append("Unexpected protocol: ");
    ((StringBuilder)localObject).append(paramString);
    throw new IOException(((StringBuilder)localObject).toString());
  }
  
  public String toString()
  {
    return this.n;
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/k/c0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */