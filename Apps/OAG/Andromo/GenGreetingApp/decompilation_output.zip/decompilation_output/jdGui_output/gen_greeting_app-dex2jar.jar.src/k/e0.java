package k;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import k.k0.e;
import k.k0.i.f;

public final class e0
{
  public final y a;
  public final String b;
  public final x c;
  public final f0 d;
  public final Map<Class<?>, Object> e;
  public volatile i f;
  
  public e0(a parama)
  {
    this.a = parama.a;
    this.b = parama.b;
    this.c = parama.c.d();
    this.d = parama.d;
    this.e = e.t(parama.e);
  }
  
  public f0 a()
  {
    return this.d;
  }
  
  public i b()
  {
    i locali = this.f;
    if (locali == null)
    {
      locali = i.k(this.c);
      this.f = locali;
    }
    return locali;
  }
  
  public String c(String paramString)
  {
    return this.c.c(paramString);
  }
  
  public x d()
  {
    return this.c;
  }
  
  public boolean e()
  {
    return this.a.m();
  }
  
  public String f()
  {
    return this.b;
  }
  
  public a g()
  {
    return new a(this);
  }
  
  public y h()
  {
    return this.a;
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("Request{method=");
    localStringBuilder.append(this.b);
    localStringBuilder.append(", url=");
    localStringBuilder.append(this.a);
    localStringBuilder.append(", tags=");
    localStringBuilder.append(this.e);
    localStringBuilder.append('}');
    return localStringBuilder.toString();
  }
  
  public static class a
  {
    public y a;
    public String b;
    public x.a c;
    public f0 d;
    public Map<Class<?>, Object> e = Collections.emptyMap();
    
    public a()
    {
      this.b = "GET";
      this.c = new x.a();
    }
    
    public a(e0 parame0)
    {
      this.a = parame0.a;
      this.b = parame0.b;
      this.d = parame0.d;
      Object localObject;
      if (parame0.e.isEmpty()) {
        localObject = Collections.emptyMap();
      } else {
        localObject = new LinkedHashMap(parame0.e);
      }
      this.e = ((Map)localObject);
      this.c = parame0.c.f();
    }
    
    public e0 a()
    {
      if (this.a != null) {
        return new e0(this);
      }
      throw new IllegalStateException("url == null");
    }
    
    public a b()
    {
      return e("HEAD", null);
    }
    
    public a c(String paramString1, String paramString2)
    {
      this.c.f(paramString1, paramString2);
      return this;
    }
    
    public a d(x paramx)
    {
      this.c = paramx.f();
      return this;
    }
    
    public a e(String paramString, f0 paramf0)
    {
      Objects.requireNonNull(paramString, "method == null");
      if (paramString.length() != 0)
      {
        if ((paramf0 != null) && (!f.b(paramString)))
        {
          paramf0 = new StringBuilder();
          paramf0.append("method ");
          paramf0.append(paramString);
          paramf0.append(" must not have a request body.");
          throw new IllegalArgumentException(paramf0.toString());
        }
        if ((paramf0 == null) && (f.e(paramString)))
        {
          paramf0 = new StringBuilder();
          paramf0.append("method ");
          paramf0.append(paramString);
          paramf0.append(" must have a request body.");
          throw new IllegalArgumentException(paramf0.toString());
        }
        this.b = paramString;
        this.d = paramf0;
        return this;
      }
      throw new IllegalArgumentException("method.length() == 0");
    }
    
    public a f(String paramString)
    {
      this.c.e(paramString);
      return this;
    }
    
    public a g(String paramString)
    {
      Objects.requireNonNull(paramString, "url == null");
      Object localObject;
      if (paramString.regionMatches(true, 0, "ws:", 0, 3))
      {
        localObject = new StringBuilder();
        ((StringBuilder)localObject).append("http:");
        ((StringBuilder)localObject).append(paramString.substring(3));
        localObject = ((StringBuilder)localObject).toString();
      }
      else
      {
        localObject = paramString;
        if (paramString.regionMatches(true, 0, "wss:", 0, 4))
        {
          localObject = new StringBuilder();
          ((StringBuilder)localObject).append("https:");
          ((StringBuilder)localObject).append(paramString.substring(4));
          localObject = ((StringBuilder)localObject).toString();
        }
      }
      return h(y.k((String)localObject));
    }
    
    public a h(y paramy)
    {
      Objects.requireNonNull(paramy, "url == null");
      this.a = paramy;
      return this;
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/k/e0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */