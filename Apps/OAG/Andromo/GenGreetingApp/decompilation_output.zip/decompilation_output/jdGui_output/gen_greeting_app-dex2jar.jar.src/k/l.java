package k;

import java.security.Principal;
import java.security.PublicKey;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import javax.net.ssl.SSLPeerUnverifiedException;
import k.k0.n.c;
import l.f;

public final class l
{
  public static final l a = new a().a();
  public final Set<b> b;
  public final c c;
  
  public l(Set<b> paramSet, c paramc)
  {
    this.b = paramSet;
    this.c = paramc;
  }
  
  public static String c(Certificate paramCertificate)
  {
    if ((paramCertificate instanceof X509Certificate))
    {
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append("sha256/");
      localStringBuilder.append(e((X509Certificate)paramCertificate).e());
      return localStringBuilder.toString();
    }
    throw new IllegalArgumentException("Certificate pinning requires X509 certificates");
  }
  
  public static f d(X509Certificate paramX509Certificate)
  {
    return f.s(paramX509Certificate.getPublicKey().getEncoded()).v();
  }
  
  public static f e(X509Certificate paramX509Certificate)
  {
    return f.s(paramX509Certificate.getPublicKey().getEncoded()).w();
  }
  
  public void a(String paramString, List<Certificate> paramList)
  {
    List localList = b(paramString);
    if (localList.isEmpty()) {
      return;
    }
    Object localObject1 = this.c;
    Object localObject2 = paramList;
    if (localObject1 != null) {
      localObject2 = ((c)localObject1).a(paramList, paramString);
    }
    int i = ((List)localObject2).size();
    int j = 0;
    for (int k = 0; k < i; k++)
    {
      X509Certificate localX509Certificate = (X509Certificate)((List)localObject2).get(k);
      int m = localList.size();
      localObject1 = null;
      paramList = null;
      n = 0;
      while (n < m)
      {
        b localb = (b)localList.get(n);
        Object localObject3;
        if (localb.c.equals("sha256/"))
        {
          localObject3 = localObject1;
          if (localObject1 == null) {
            localObject3 = e(localX509Certificate);
          }
          localObject1 = localObject3;
          if (!localb.d.equals(localObject3)) {}
        }
        else
        {
          if (!localb.c.equals("sha1/")) {
            break label208;
          }
          localObject3 = paramList;
          if (paramList == null) {
            localObject3 = d(localX509Certificate);
          }
          paramList = (List<Certificate>)localObject3;
          if (localb.d.equals(localObject3)) {
            return;
          }
        }
        n++;
        continue;
        label208:
        paramString = new StringBuilder();
        paramString.append("unsupported hashAlgorithm: ");
        paramString.append(localb.c);
        throw new AssertionError(paramString.toString());
      }
    }
    paramList = new StringBuilder();
    paramList.append("Certificate pinning failure!");
    paramList.append("\n  Peer certificate chain:");
    int n = ((List)localObject2).size();
    for (k = 0; k < n; k++)
    {
      localObject1 = (X509Certificate)((List)localObject2).get(k);
      paramList.append("\n    ");
      paramList.append(c((Certificate)localObject1));
      paramList.append(": ");
      paramList.append(((X509Certificate)localObject1).getSubjectDN().getName());
    }
    paramList.append("\n  Pinned certificates for ");
    paramList.append(paramString);
    paramList.append(":");
    n = localList.size();
    for (k = j; k < n; k++)
    {
      paramString = (b)localList.get(k);
      paramList.append("\n    ");
      paramList.append(paramString);
    }
    paramString = new SSLPeerUnverifiedException(paramList.toString());
    for (;;)
    {
      throw paramString;
    }
  }
  
  public List<b> b(String paramString)
  {
    Object localObject1 = Collections.emptyList();
    Iterator localIterator = this.b.iterator();
    while (localIterator.hasNext())
    {
      b localb = (b)localIterator.next();
      if (localb.a(paramString))
      {
        Object localObject2 = localObject1;
        if (((List)localObject1).isEmpty()) {
          localObject2 = new ArrayList();
        }
        ((List)localObject2).add(localb);
        localObject1 = localObject2;
      }
    }
    return (List<b>)localObject1;
  }
  
  public boolean equals(Object paramObject)
  {
    boolean bool = true;
    if (paramObject == this) {
      return true;
    }
    if ((paramObject instanceof l))
    {
      c localc = this.c;
      paramObject = (l)paramObject;
      if ((Objects.equals(localc, ((l)paramObject).c)) && (this.b.equals(((l)paramObject).b))) {}
    }
    else
    {
      bool = false;
    }
    return bool;
  }
  
  public l f(c paramc)
  {
    if (Objects.equals(this.c, paramc)) {
      paramc = this;
    } else {
      paramc = new l(this.b, paramc);
    }
    return paramc;
  }
  
  public int hashCode()
  {
    return Objects.hashCode(this.c) * 31 + this.b.hashCode();
  }
  
  public static final class a
  {
    public final List<l.b> a = new ArrayList();
    
    public l a()
    {
      return new l(new LinkedHashSet(this.a), null);
    }
  }
  
  public static final class b
  {
    public final String a;
    public final String b;
    public final String c;
    public final f d;
    
    public boolean a(String paramString)
    {
      if (this.a.startsWith("*."))
      {
        int i = paramString.indexOf('.');
        int j = paramString.length();
        boolean bool = true;
        if (j - i - 1 == this.b.length())
        {
          String str = this.b;
          if (paramString.regionMatches(false, i + 1, str, 0, str.length())) {}
        }
        else
        {
          bool = false;
        }
        return bool;
      }
      return paramString.equals(this.b);
    }
    
    public boolean equals(Object paramObject)
    {
      if ((paramObject instanceof b))
      {
        String str = this.a;
        paramObject = (b)paramObject;
        if ((str.equals(((b)paramObject).a)) && (this.c.equals(((b)paramObject).c)) && (this.d.equals(((b)paramObject).d))) {
          return true;
        }
      }
      boolean bool = false;
      return bool;
    }
    
    public int hashCode()
    {
      return ((527 + this.a.hashCode()) * 31 + this.c.hashCode()) * 31 + this.d.hashCode();
    }
    
    public String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append(this.c);
      localStringBuilder.append(this.d.e());
      return localStringBuilder.toString();
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/k/l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */