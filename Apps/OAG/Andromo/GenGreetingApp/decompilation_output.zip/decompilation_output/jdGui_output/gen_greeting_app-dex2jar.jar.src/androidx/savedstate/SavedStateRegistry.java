package androidx.savedstate;

import android.annotation.SuppressLint;
import android.os.Bundle;
import c.c.a.b.b.d;
import c.k.f;
import c.k.f.a;
import c.k.h;
import c.k.j;
import java.util.Iterator;
import java.util.Map.Entry;

@SuppressLint({"RestrictedApi"})
public final class SavedStateRegistry
{
  public c.c.a.b.b<String, b> a = new c.c.a.b.b();
  public Bundle b;
  public boolean c;
  public boolean d = true;
  
  public Bundle a(String paramString)
  {
    if (this.c)
    {
      Bundle localBundle = this.b;
      if (localBundle != null)
      {
        localBundle = localBundle.getBundle(paramString);
        this.b.remove(paramString);
        if (this.b.isEmpty()) {
          this.b = null;
        }
        return localBundle;
      }
      return null;
    }
    throw new IllegalStateException("You can consumeRestoredStateForKey only after super.onCreate of corresponding component");
  }
  
  public void b(f paramf, Bundle paramBundle)
  {
    if (!this.c)
    {
      if (paramBundle != null) {
        this.b = paramBundle.getBundle("androidx.lifecycle.BundlableSavedStateRegistry.key");
      }
      paramf.a(new h()
      {
        public void a(j paramAnonymousj, f.a paramAnonymousa)
        {
          if (paramAnonymousa == f.a.ON_START) {
            SavedStateRegistry.this.d = true;
          } else if (paramAnonymousa == f.a.ON_STOP) {
            SavedStateRegistry.this.d = false;
          }
        }
      });
      this.c = true;
      return;
    }
    throw new IllegalStateException("SavedStateRegistry was already restored.");
  }
  
  public void c(Bundle paramBundle)
  {
    Bundle localBundle = new Bundle();
    Object localObject = this.b;
    if (localObject != null) {
      localBundle.putAll((Bundle)localObject);
    }
    b.d locald = this.a.t();
    while (locald.hasNext())
    {
      localObject = (Map.Entry)locald.next();
      localBundle.putBundle((String)((Map.Entry)localObject).getKey(), ((b)((Map.Entry)localObject).getValue()).a());
    }
    paramBundle.putBundle("androidx.lifecycle.BundlableSavedStateRegistry.key", localBundle);
  }
  
  public static abstract interface a
  {
    public abstract void a(c.o.b paramb);
  }
  
  public static abstract interface b
  {
    public abstract Bundle a();
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/androidx/savedstate/SavedStateRegistry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */