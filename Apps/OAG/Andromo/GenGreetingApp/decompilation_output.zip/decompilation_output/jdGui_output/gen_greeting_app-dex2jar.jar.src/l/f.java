package l;

import java.io.Serializable;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

public class f
  implements Serializable, Comparable<f>
{
  public static final char[] g = { 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 97, 98, 99, 100, 101, 102 };
  public static final f h = s(new byte[0]);
  public final byte[] i;
  public transient int j;
  public transient String k;
  
  public f(byte[] paramArrayOfByte)
  {
    this.i = paramArrayOfByte;
  }
  
  public static int g(String paramString, int paramInt)
  {
    int m = paramString.length();
    int n = 0;
    int i1 = 0;
    while (n < m)
    {
      if (i1 == paramInt) {
        return n;
      }
      int i2 = paramString.codePointAt(n);
      if (((Character.isISOControl(i2)) && (i2 != 10) && (i2 != 13)) || (i2 == 65533)) {
        return -1;
      }
      i1++;
      n += Character.charCount(i2);
    }
    return paramString.length();
  }
  
  public static f j(String paramString)
  {
    if (paramString != null)
    {
      if (paramString.length() % 2 == 0)
      {
        int m = paramString.length() / 2;
        localObject = new byte[m];
        for (int n = 0; n < m; n++)
        {
          int i1 = n * 2;
          localObject[n] = ((byte)(byte)((k(paramString.charAt(i1)) << 4) + k(paramString.charAt(i1 + 1))));
        }
        return s((byte[])localObject);
      }
      Object localObject = new StringBuilder();
      ((StringBuilder)localObject).append("Unexpected hex string: ");
      ((StringBuilder)localObject).append(paramString);
      throw new IllegalArgumentException(((StringBuilder)localObject).toString());
    }
    paramString = new IllegalArgumentException("hex == null");
    for (;;)
    {
      throw paramString;
    }
  }
  
  public static int k(char paramChar)
  {
    if ((paramChar >= '0') && (paramChar <= '9')) {
      return paramChar - '0';
    }
    char c = 'a';
    if ((paramChar >= 'a') && (paramChar <= 'f')) {}
    do
    {
      return paramChar - c + 10;
      c = 'A';
    } while ((paramChar >= 'A') && (paramChar <= 'F'));
    Object localObject = new StringBuilder();
    ((StringBuilder)localObject).append("Unexpected hex digit: ");
    ((StringBuilder)localObject).append(paramChar);
    localObject = new IllegalArgumentException(((StringBuilder)localObject).toString());
    for (;;)
    {
      throw ((Throwable)localObject);
    }
  }
  
  public static f p(String paramString)
  {
    if (paramString != null)
    {
      f localf = new f(paramString.getBytes(v.a));
      localf.k = paramString;
      return localf;
    }
    throw new IllegalArgumentException("s == null");
  }
  
  public static f s(byte... paramVarArgs)
  {
    if (paramVarArgs != null) {
      return new f((byte[])paramVarArgs.clone());
    }
    throw new IllegalArgumentException("data == null");
  }
  
  public f A()
  {
    for (int m = 0;; m++)
    {
      byte[] arrayOfByte = this.i;
      if (m >= arrayOfByte.length) {
        break;
      }
      int n = arrayOfByte[m];
      if ((n >= 65) && (n <= 90))
      {
        arrayOfByte = (byte[])arrayOfByte.clone();
        int i1 = m + 1;
        arrayOfByte[m] = ((byte)(byte)(n + 32));
        for (m = i1; m < arrayOfByte.length; m++)
        {
          i1 = arrayOfByte[m];
          if ((i1 >= 65) && (i1 <= 90)) {
            arrayOfByte[m] = ((byte)(byte)(i1 + 32));
          }
        }
        return new f(arrayOfByte);
      }
    }
    return this;
  }
  
  public byte[] B()
  {
    return (byte[])this.i.clone();
  }
  
  public String C()
  {
    String str = this.k;
    if (str == null)
    {
      str = new String(this.i, v.a);
      this.k = str;
    }
    return str;
  }
  
  public void D(c paramc)
  {
    byte[] arrayOfByte = this.i;
    paramc.q0(arrayOfByte, 0, arrayOfByte.length);
  }
  
  public String e()
  {
    return b.a(this.i);
  }
  
  public boolean equals(Object paramObject)
  {
    boolean bool = true;
    if (paramObject == this) {
      return true;
    }
    if ((paramObject instanceof f))
    {
      paramObject = (f)paramObject;
      int m = ((f)paramObject).x();
      byte[] arrayOfByte = this.i;
      if ((m == arrayOfByte.length) && (((f)paramObject).u(0, arrayOfByte, 0, arrayOfByte.length))) {}
    }
    else
    {
      bool = false;
    }
    return bool;
  }
  
  public int hashCode()
  {
    int m = this.j;
    if (m == 0)
    {
      m = Arrays.hashCode(this.i);
      this.j = m;
    }
    return m;
  }
  
  public int i(f paramf)
  {
    int m = x();
    int n = paramf.x();
    int i1 = Math.min(m, n);
    int i3;
    int i4;
    int i5;
    for (int i2 = 0;; i2++)
    {
      i3 = -1;
      if (i2 >= i1) {
        break label83;
      }
      i4 = q(i2) & 0xFF;
      i5 = paramf.q(i2) & 0xFF;
      if (i4 != i5) {
        break;
      }
    }
    if (i4 >= i5) {
      i3 = 1;
    }
    return i3;
    label83:
    if (m == n) {
      return 0;
    }
    if (m >= n) {
      i3 = 1;
    }
    return i3;
  }
  
  public final f o(String paramString)
  {
    try
    {
      paramString = s(MessageDigest.getInstance(paramString).digest(this.i));
      return paramString;
    }
    catch (NoSuchAlgorithmException paramString)
    {
      throw new AssertionError(paramString);
    }
  }
  
  public byte q(int paramInt)
  {
    return this.i[paramInt];
  }
  
  public String r()
  {
    byte[] arrayOfByte = this.i;
    char[] arrayOfChar1 = new char[arrayOfByte.length * 2];
    int m = arrayOfByte.length;
    int n = 0;
    int i1 = 0;
    while (n < m)
    {
      int i2 = arrayOfByte[n];
      int i3 = i1 + 1;
      char[] arrayOfChar2 = g;
      arrayOfChar1[i1] = ((char)arrayOfChar2[(i2 >> 4 & 0xF)]);
      i1 = i3 + 1;
      arrayOfChar1[i3] = ((char)arrayOfChar2[(i2 & 0xF)]);
      n++;
    }
    return new String(arrayOfChar1);
  }
  
  public boolean t(int paramInt1, f paramf, int paramInt2, int paramInt3)
  {
    return paramf.u(paramInt2, this.i, paramInt1, paramInt3);
  }
  
  public String toString()
  {
    if (this.i.length == 0) {
      return "[size=0]";
    }
    Object localObject1 = C();
    int m = g((String)localObject1, 64);
    if (m == -1)
    {
      if (this.i.length <= 64)
      {
        localObject2 = new StringBuilder();
        ((StringBuilder)localObject2).append("[hex=");
        ((StringBuilder)localObject2).append(r());
        ((StringBuilder)localObject2).append("]");
        localObject2 = ((StringBuilder)localObject2).toString();
      }
      else
      {
        localObject2 = new StringBuilder();
        ((StringBuilder)localObject2).append("[size=");
        ((StringBuilder)localObject2).append(this.i.length);
        ((StringBuilder)localObject2).append(" hex=");
        ((StringBuilder)localObject2).append(z(0, 64).r());
        ((StringBuilder)localObject2).append("…]");
        localObject2 = ((StringBuilder)localObject2).toString();
      }
      return (String)localObject2;
    }
    Object localObject2 = ((String)localObject1).substring(0, m).replace("\\", "\\\\").replace("\n", "\\n").replace("\r", "\\r");
    if (m < ((String)localObject1).length())
    {
      localObject1 = new StringBuilder();
      ((StringBuilder)localObject1).append("[size=");
      ((StringBuilder)localObject1).append(this.i.length);
      ((StringBuilder)localObject1).append(" text=");
      ((StringBuilder)localObject1).append((String)localObject2);
      ((StringBuilder)localObject1).append("…]");
      localObject2 = ((StringBuilder)localObject1).toString();
    }
    else
    {
      localObject1 = new StringBuilder();
      ((StringBuilder)localObject1).append("[text=");
      ((StringBuilder)localObject1).append((String)localObject2);
      ((StringBuilder)localObject1).append("]");
      localObject2 = ((StringBuilder)localObject1).toString();
    }
    return (String)localObject2;
  }
  
  public boolean u(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3)
  {
    if (paramInt1 >= 0)
    {
      byte[] arrayOfByte = this.i;
      if ((paramInt1 <= arrayOfByte.length - paramInt3) && (paramInt2 >= 0) && (paramInt2 <= paramArrayOfByte.length - paramInt3) && (v.a(arrayOfByte, paramInt1, paramArrayOfByte, paramInt2, paramInt3)))
      {
        bool = true;
        break label55;
      }
    }
    boolean bool = false;
    label55:
    return bool;
  }
  
  public f v()
  {
    return o("SHA-1");
  }
  
  public f w()
  {
    return o("SHA-256");
  }
  
  public int x()
  {
    return this.i.length;
  }
  
  public final boolean y(f paramf)
  {
    return t(0, paramf, 0, paramf.x());
  }
  
  public f z(int paramInt1, int paramInt2)
  {
    if (paramInt1 >= 0)
    {
      byte[] arrayOfByte = this.i;
      if (paramInt2 <= arrayOfByte.length)
      {
        int m = paramInt2 - paramInt1;
        if (m >= 0)
        {
          if ((paramInt1 == 0) && (paramInt2 == arrayOfByte.length)) {
            return this;
          }
          localObject = new byte[m];
          System.arraycopy(arrayOfByte, paramInt1, localObject, 0, m);
          return new f((byte[])localObject);
        }
        throw new IllegalArgumentException("endIndex < beginIndex");
      }
      Object localObject = new StringBuilder();
      ((StringBuilder)localObject).append("endIndex > length(");
      ((StringBuilder)localObject).append(this.i.length);
      ((StringBuilder)localObject).append(")");
      throw new IllegalArgumentException(((StringBuilder)localObject).toString());
    }
    throw new IllegalArgumentException("beginIndex < 0");
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/l/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */