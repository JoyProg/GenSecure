package l;

import java.nio.channels.ReadableByteChannel;

public abstract interface e
  extends t, ReadableByteChannel
{
  public abstract byte A0();
  
  public abstract int E();
  
  public abstract String J();
  
  public abstract byte[] L();
  
  public abstract int N();
  
  public abstract c O();
  
  public abstract boolean Q();
  
  public abstract byte[] T(long paramLong);
  
  public abstract short b0();
  
  @Deprecated
  public abstract c c();
  
  public abstract String h0(long paramLong);
  
  public abstract short j0();
  
  public abstract void p(byte[] paramArrayOfByte);
  
  public abstract void p0(long paramLong);
  
  public abstract f w(long paramLong);
  
  public abstract long w0(byte paramByte);
  
  public abstract long y0();
  
  public abstract void z(long paramLong);
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/l/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */