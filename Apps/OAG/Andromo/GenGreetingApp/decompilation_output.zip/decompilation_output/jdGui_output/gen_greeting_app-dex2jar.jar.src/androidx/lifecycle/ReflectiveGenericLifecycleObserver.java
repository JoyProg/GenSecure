package androidx.lifecycle;

import c.k.a;
import c.k.a.a;
import c.k.f.a;
import c.k.h;
import c.k.j;

public class ReflectiveGenericLifecycleObserver
  implements h
{
  public final Object a;
  public final a.a b;
  
  public ReflectiveGenericLifecycleObserver(Object paramObject)
  {
    this.a = paramObject;
    this.b = a.a.c(paramObject.getClass());
  }
  
  public void a(j paramj, f.a parama)
  {
    this.b.a(paramj, parama, this.a);
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/androidx/lifecycle/ReflectiveGenericLifecycleObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */