package l;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.RandomAccess;

public final class m
  extends AbstractList<f>
  implements RandomAccess
{
  public final f[] g;
  public final int[] h;
  
  public m(f[] paramArrayOff, int[] paramArrayOfInt)
  {
    this.g = paramArrayOff;
    this.h = paramArrayOfInt;
  }
  
  public static void g(long paramLong, c paramc, int paramInt1, List<f> paramList, int paramInt2, int paramInt3, List<Integer> paramList1)
  {
    int i = paramInt2;
    if (i < paramInt3)
    {
      int j = i;
      while (j < paramInt3) {
        if (((f)paramList.get(j)).x() >= paramInt1) {
          j++;
        } else {
          throw new AssertionError();
        }
      }
      f localf1 = (f)paramList.get(paramInt2);
      f localf2 = (f)paramList.get(paramInt3 - 1);
      j = -1;
      paramInt2 = i;
      Object localObject = localf1;
      if (paramInt1 == localf1.x())
      {
        j = ((Integer)paramList1.get(i)).intValue();
        paramInt2 = i + 1;
        localObject = (f)paramList.get(paramInt2);
      }
      int k;
      int m;
      if (((f)localObject).q(paramInt1) != localf2.q(paramInt1))
      {
        k = paramInt2 + 1;
        for (i = 1; k < paramInt3; i = m)
        {
          m = i;
          if (((f)paramList.get(k - 1)).q(paramInt1) != ((f)paramList.get(k)).q(paramInt1)) {
            m = i + 1;
          }
          k++;
        }
        paramLong = paramLong + t(paramc) + 2L + i * 2;
        paramc.C0(i);
        paramc.C0(j);
        for (i = paramInt2; i < paramInt3; i++)
        {
          j = ((f)paramList.get(i)).q(paramInt1);
          if ((i == paramInt2) || (j != ((f)paramList.get(i - 1)).q(paramInt1))) {
            paramc.C0(j & 0xFF);
          }
        }
        localObject = new c();
        for (i = paramInt2; i < paramInt3; i = paramInt2)
        {
          k = ((f)paramList.get(i)).q(paramInt1);
          j = i + 1;
          for (paramInt2 = j; paramInt2 < paramInt3; paramInt2++) {
            if (k != ((f)paramList.get(paramInt2)).q(paramInt1)) {
              break label427;
            }
          }
          paramInt2 = paramInt3;
          label427:
          if ((j == paramInt2) && (paramInt1 + 1 == ((f)paramList.get(i)).x()))
          {
            paramc.C0(((Integer)paramList1.get(i)).intValue());
          }
          else
          {
            paramc.C0((int)((t((c)localObject) + paramLong) * -1L));
            g(paramLong, (c)localObject, paramInt1 + 1, paramList, i, paramInt2, paramList1);
          }
        }
        paramc.n((c)localObject, ((c)localObject).a0());
      }
      else
      {
        i = 0;
        m = Math.min(((f)localObject).x(), localf2.x());
        for (k = paramInt1; (k < m) && (((f)localObject).q(k) == localf2.q(k)); k++) {
          i++;
        }
        paramLong = 1L + (paramLong + t(paramc) + 2L + i);
        paramc.C0(-i);
        paramc.C0(j);
        for (j = paramInt1;; j++)
        {
          k = paramInt1 + i;
          if (j >= k) {
            break;
          }
          paramc.C0(((f)localObject).q(j) & 0xFF);
        }
        if (paramInt2 + 1 == paramInt3)
        {
          if (k == ((f)paramList.get(paramInt2)).x()) {
            paramc.C0(((Integer)paramList1.get(paramInt2)).intValue());
          } else {
            throw new AssertionError();
          }
        }
        else
        {
          localObject = new c();
          paramc.C0((int)((t((c)localObject) + paramLong) * -1L));
          g(paramLong, (c)localObject, k, paramList, paramInt2, paramInt3, paramList1);
          paramc.n((c)localObject, ((c)localObject).a0());
        }
      }
      return;
    }
    paramc = new AssertionError();
    for (;;)
    {
      throw paramc;
    }
  }
  
  public static int t(c paramc)
  {
    return (int)(paramc.a0() / 4L);
  }
  
  public static m u(f... paramVarArgs)
  {
    int i = paramVarArgs.length;
    int j = 0;
    if (i == 0) {
      return new m(new f[0], new int[] { 0, -1 });
    }
    Object localObject1 = new ArrayList(Arrays.asList(paramVarArgs));
    Collections.sort((List)localObject1);
    ArrayList localArrayList = new ArrayList();
    for (i = 0; i < ((List)localObject1).size(); i++) {
      localArrayList.add(Integer.valueOf(-1));
    }
    for (i = 0; i < ((List)localObject1).size(); i++) {
      localArrayList.set(Collections.binarySearch((List)localObject1, paramVarArgs[i]), Integer.valueOf(i));
    }
    if (((f)((List)localObject1).get(0)).x() != 0)
    {
      for (int k = 0; k < ((List)localObject1).size(); k = i)
      {
        f localf = (f)((List)localObject1).get(k);
        i = k + 1;
        int m = i;
        while (m < ((List)localObject1).size())
        {
          localObject2 = (f)((List)localObject1).get(m);
          if (((f)localObject2).y(localf)) {
            if (((f)localObject2).x() != localf.x())
            {
              if (((Integer)localArrayList.get(m)).intValue() > ((Integer)localArrayList.get(k)).intValue())
              {
                ((List)localObject1).remove(m);
                localArrayList.remove(m);
              }
              else
              {
                m++;
              }
            }
            else
            {
              paramVarArgs = new StringBuilder();
              paramVarArgs.append("duplicate option: ");
              paramVarArgs.append(localObject2);
              throw new IllegalArgumentException(paramVarArgs.toString());
            }
          }
        }
      }
      Object localObject2 = new c();
      g(0L, (c)localObject2, 0, (List)localObject1, 0, ((List)localObject1).size(), localArrayList);
      k = t((c)localObject2);
      localObject1 = new int[k];
      for (i = j; i < k; i++) {
        localObject1[i] = ((c)localObject2).E();
      }
      if (((c)localObject2).Q()) {
        return new m((f[])paramVarArgs.clone(), (int[])localObject1);
      }
      throw new AssertionError();
    }
    paramVarArgs = new IllegalArgumentException("the empty byte string is not a supported option");
    for (;;)
    {
      throw paramVarArgs;
    }
  }
  
  public f m(int paramInt)
  {
    return this.g[paramInt];
  }
  
  public final int size()
  {
    return this.g.length;
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/l/m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */