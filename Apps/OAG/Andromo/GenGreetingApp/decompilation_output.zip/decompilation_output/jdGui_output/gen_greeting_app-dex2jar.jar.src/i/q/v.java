package i.q;

import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class v
  extends u
{
  public static final int a(int paramInt)
  {
    if (paramInt >= 0) {
      if (paramInt < 3) {
        paramInt++;
      } else if (paramInt < 1073741824) {
        paramInt = (int)(paramInt / 0.75F + 1.0F);
      } else {
        paramInt = Integer.MAX_VALUE;
      }
    }
    return paramInt;
  }
  
  public static final <K, V> Map<K, V> b(i.i<? extends K, ? extends V> parami)
  {
    i.v.d.i.e(parami, "pair");
    parami = Collections.singletonMap(parami.c(), parami.d());
    i.v.d.i.d(parami, "singletonMap(pair.first, pair.second)");
    return parami;
  }
  
  public static final <K, V> Map<K, V> c(Map<? extends K, ? extends V> paramMap)
  {
    i.v.d.i.e(paramMap, "<this>");
    paramMap = (Map.Entry)paramMap.entrySet().iterator().next();
    paramMap = Collections.singletonMap(paramMap.getKey(), paramMap.getValue());
    i.v.d.i.d(paramMap, "with(entries.iterator().…ingletonMap(key, value) }");
    return paramMap;
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/i/q/v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */