package androidx.savedstate;

import android.annotation.SuppressLint;
import android.os.Bundle;
import c.k.f;
import c.k.f.a;
import c.k.h;
import c.k.j;
import c.o.b;
import java.util.ArrayList;
import java.util.Iterator;

@SuppressLint({"RestrictedApi"})
public final class Recreator
  implements h
{
  public final b a;
  
  public Recreator(b paramb)
  {
    this.a = paramb;
  }
  
  public void a(j paramj, f.a parama)
  {
    if (parama == f.a.ON_CREATE)
    {
      paramj.getLifecycle().c(this);
      paramj = this.a.getSavedStateRegistry().a("androidx.savedstate.Restarter");
      if (paramj == null) {
        return;
      }
      paramj = paramj.getStringArrayList("classes_to_restore");
      if (paramj != null)
      {
        paramj = paramj.iterator();
        while (paramj.hasNext()) {
          b((String)paramj.next());
        }
        return;
      }
      throw new IllegalStateException("Bundle with restored state for the component \"androidx.savedstate.Restarter\" must contain list of strings by the key \"classes_to_restore\"");
    }
    paramj = new AssertionError("Next event must be ON_CREATE");
    for (;;)
    {
      throw paramj;
    }
  }
  
  /* Error */
  public final void b(String paramString)
  {
    // Byte code:
    //   0: aload_1
    //   1: iconst_0
    //   2: ldc 2
    //   4: invokevirtual 106	java/lang/Class:getClassLoader	()Ljava/lang/ClassLoader;
    //   7: invokestatic 110	java/lang/Class:forName	(Ljava/lang/String;ZLjava/lang/ClassLoader;)Ljava/lang/Class;
    //   10: ldc 112
    //   12: invokevirtual 116	java/lang/Class:asSubclass	(Ljava/lang/Class;)Ljava/lang/Class;
    //   15: astore_2
    //   16: aload_2
    //   17: iconst_0
    //   18: anewarray 102	java/lang/Class
    //   21: invokevirtual 120	java/lang/Class:getDeclaredConstructor	([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;
    //   24: astore_3
    //   25: aload_3
    //   26: iconst_1
    //   27: invokevirtual 126	java/lang/reflect/Constructor:setAccessible	(Z)V
    //   30: aload_3
    //   31: iconst_0
    //   32: anewarray 4	java/lang/Object
    //   35: invokevirtual 130	java/lang/reflect/Constructor:newInstance	([Ljava/lang/Object;)Ljava/lang/Object;
    //   38: checkcast 112	androidx/savedstate/SavedStateRegistry$a
    //   41: astore_2
    //   42: aload_2
    //   43: aload_0
    //   44: getfield 18	androidx/savedstate/Recreator:a	Lc/o/b;
    //   47: invokeinterface 132 2 0
    //   52: return
    //   53: astore_3
    //   54: new 134	java/lang/StringBuilder
    //   57: dup
    //   58: invokespecial 135	java/lang/StringBuilder:<init>	()V
    //   61: astore_2
    //   62: aload_2
    //   63: ldc -119
    //   65: invokevirtual 141	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   68: pop
    //   69: aload_2
    //   70: aload_1
    //   71: invokevirtual 141	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   74: pop
    //   75: new 143	java/lang/RuntimeException
    //   78: dup
    //   79: aload_2
    //   80: invokevirtual 147	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   83: aload_3
    //   84: invokespecial 150	java/lang/RuntimeException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   87: athrow
    //   88: astore_1
    //   89: new 134	java/lang/StringBuilder
    //   92: dup
    //   93: invokespecial 135	java/lang/StringBuilder:<init>	()V
    //   96: astore_3
    //   97: aload_3
    //   98: ldc -104
    //   100: invokevirtual 141	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   103: pop
    //   104: aload_3
    //   105: aload_2
    //   106: invokevirtual 155	java/lang/Class:getSimpleName	()Ljava/lang/String;
    //   109: invokevirtual 141	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   112: pop
    //   113: aload_3
    //   114: ldc -99
    //   116: invokevirtual 141	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   119: pop
    //   120: new 83	java/lang/IllegalStateException
    //   123: dup
    //   124: aload_3
    //   125: invokevirtual 147	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   128: aload_1
    //   129: invokespecial 158	java/lang/IllegalStateException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   132: athrow
    //   133: astore_2
    //   134: new 134	java/lang/StringBuilder
    //   137: dup
    //   138: invokespecial 135	java/lang/StringBuilder:<init>	()V
    //   141: astore_3
    //   142: aload_3
    //   143: ldc -96
    //   145: invokevirtual 141	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   148: pop
    //   149: aload_3
    //   150: aload_1
    //   151: invokevirtual 141	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   154: pop
    //   155: aload_3
    //   156: ldc -94
    //   158: invokevirtual 141	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   161: pop
    //   162: new 143	java/lang/RuntimeException
    //   165: dup
    //   166: aload_3
    //   167: invokevirtual 147	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   170: aload_2
    //   171: invokespecial 150	java/lang/RuntimeException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   174: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	175	0	this	Recreator
    //   0	175	1	paramString	String
    //   15	91	2	localObject	Object
    //   133	38	2	localClassNotFoundException	ClassNotFoundException
    //   24	7	3	localConstructor	java.lang.reflect.Constructor
    //   53	31	3	localException	Exception
    //   96	71	3	localStringBuilder	StringBuilder
    // Exception table:
    //   from	to	target	type
    //   30	42	53	java/lang/Exception
    //   16	25	88	java/lang/NoSuchMethodException
    //   0	16	133	java/lang/ClassNotFoundException
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/androidx/savedstate/Recreator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */