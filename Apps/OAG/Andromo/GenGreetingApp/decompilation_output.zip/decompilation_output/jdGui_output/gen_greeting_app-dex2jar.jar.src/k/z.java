package k;

public abstract interface z
{
  public abstract g0 a(a parama);
  
  public static abstract interface a
  {
    public abstract int a();
    
    public abstract int b();
    
    public abstract int c();
    
    public abstract g0 d(e0 parame0);
    
    public abstract e0 e();
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/k/z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */