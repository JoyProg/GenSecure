package androidx.lifecycle;

import c.k.d;
import c.k.f.a;
import c.k.h;
import c.k.j;

public class FullLifecycleObserverAdapter
  implements h
{
  public final d a;
  public final h b;
  
  public FullLifecycleObserverAdapter(d paramd, h paramh)
  {
    this.a = paramd;
    this.b = paramh;
  }
  
  public void a(j paramj, f.a parama)
  {
    switch (a.a[parama.ordinal()])
    {
    default: 
      break;
    case 7: 
      throw new IllegalArgumentException("ON_ANY must not been send by anybody");
    case 6: 
      this.a.onDestroy(paramj);
      break;
    case 5: 
      this.a.onStop(paramj);
      break;
    case 4: 
      this.a.onPause(paramj);
      break;
    case 3: 
      this.a.onResume(paramj);
      break;
    case 2: 
      this.a.onStart(paramj);
      break;
    case 1: 
      this.a.onCreate(paramj);
    }
    h localh = this.b;
    if (localh != null) {
      localh.a(paramj, parama);
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/androidx/lifecycle/FullLifecycleObserverAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */