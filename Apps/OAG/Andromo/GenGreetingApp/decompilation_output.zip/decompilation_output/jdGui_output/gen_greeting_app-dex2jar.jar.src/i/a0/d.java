package i.a0;

import i.v.c.l;
import i.v.d.i;

public class d
{
  public static final <T> void a(Appendable paramAppendable, T paramT, l<? super T, ? extends CharSequence> paraml)
  {
    i.e(paramAppendable, "<this>");
    if (paraml != null)
    {
      paramAppendable.append((CharSequence)paraml.invoke(paramT));
    }
    else
    {
      boolean bool;
      if (paramT == null) {
        bool = true;
      } else {
        bool = paramT instanceof CharSequence;
      }
      if (bool) {
        paramAppendable.append((CharSequence)paramT);
      } else if ((paramT instanceof Character)) {
        paramAppendable.append(((Character)paramT).charValue());
      } else {
        paramAppendable.append(String.valueOf(paramT));
      }
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/i/a0/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */