package androidx.work;

import android.annotation.SuppressLint;
import android.content.Context;
import androidx.annotation.Keep;
import c.y.y.p.o.c;
import d.c.b.e.a.e;
import java.util.concurrent.Executor;

public abstract class Worker
  extends ListenableWorker
{
  public c<ListenableWorker.a> l;
  
  @SuppressLint({"BanKeepAnnotation"})
  @Keep
  public Worker(Context paramContext, WorkerParameters paramWorkerParameters)
  {
    super(paramContext, paramWorkerParameters);
  }
  
  public final e<ListenableWorker.a> o()
  {
    this.l = c.t();
    b().execute(new a());
    return this.l;
  }
  
  public abstract ListenableWorker.a q();
  
  public class a
    implements Runnable
  {
    public a() {}
    
    /* Error */
    public void run()
    {
      // Byte code:
      //   0: aload_0
      //   1: getfield 17	androidx/work/Worker$a:g	Landroidx/work/Worker;
      //   4: invokevirtual 26	androidx/work/Worker:q	()Landroidx/work/ListenableWorker$a;
      //   7: astore_1
      //   8: aload_0
      //   9: getfield 17	androidx/work/Worker$a:g	Landroidx/work/Worker;
      //   12: getfield 30	androidx/work/Worker:l	Lc/y/y/p/o/c;
      //   15: aload_1
      //   16: invokevirtual 36	c/y/y/p/o/c:p	(Ljava/lang/Object;)Z
      //   19: pop
      //   20: goto +16 -> 36
      //   23: astore_1
      //   24: aload_0
      //   25: getfield 17	androidx/work/Worker$a:g	Landroidx/work/Worker;
      //   28: getfield 30	androidx/work/Worker:l	Lc/y/y/p/o/c;
      //   31: aload_1
      //   32: invokevirtual 39	c/y/y/p/o/c:q	(Ljava/lang/Throwable;)Z
      //   35: pop
      //   36: return
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	37	0	this	a
      //   7	9	1	locala	ListenableWorker.a
      //   23	9	1	localThrowable	Throwable
      // Exception table:
      //   from	to	target	type
      //   0	20	23	finally
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/androidx/work/Worker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */