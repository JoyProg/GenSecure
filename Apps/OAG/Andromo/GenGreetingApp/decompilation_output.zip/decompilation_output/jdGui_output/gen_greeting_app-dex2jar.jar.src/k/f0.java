package k;

import java.util.Objects;
import k.k0.e;
import l.d;

public abstract class f0
{
  public static f0 c(a0 parama0, byte[] paramArrayOfByte)
  {
    return d(parama0, paramArrayOfByte, 0, paramArrayOfByte.length);
  }
  
  public static f0 d(a0 parama0, final byte[] paramArrayOfByte, final int paramInt1, final int paramInt2)
  {
    Objects.requireNonNull(paramArrayOfByte, "content == null");
    e.d(paramArrayOfByte.length, paramInt1, paramInt2);
    return new a(paramInt2, paramArrayOfByte, paramInt1);
  }
  
  public abstract long a();
  
  public abstract a0 b();
  
  public boolean e()
  {
    return false;
  }
  
  public boolean f()
  {
    return false;
  }
  
  public abstract void g(d paramd);
  
  public class a
    extends f0
  {
    public a(int paramInt1, byte[] paramArrayOfByte, int paramInt2) {}
    
    public long a()
    {
      return paramInt2;
    }
    
    public a0 b()
    {
      return this.a;
    }
    
    public void g(d paramd)
    {
      paramd.j(paramArrayOfByte, paramInt1, paramInt2);
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/k/f0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */