package l;

import java.util.concurrent.TimeUnit;

public class i
  extends u
{
  public u e;
  
  public i(u paramu)
  {
    if (paramu != null)
    {
      this.e = paramu;
      return;
    }
    throw new IllegalArgumentException("delegate == null");
  }
  
  public u a()
  {
    return this.e.a();
  }
  
  public u b()
  {
    return this.e.b();
  }
  
  public long c()
  {
    return this.e.c();
  }
  
  public u d(long paramLong)
  {
    return this.e.d(paramLong);
  }
  
  public boolean e()
  {
    return this.e.e();
  }
  
  public void f()
  {
    this.e.f();
  }
  
  public u g(long paramLong, TimeUnit paramTimeUnit)
  {
    return this.e.g(paramLong, paramTimeUnit);
  }
  
  public final u i()
  {
    return this.e;
  }
  
  public final i j(u paramu)
  {
    if (paramu != null)
    {
      this.e = paramu;
      return this;
    }
    throw new IllegalArgumentException("delegate == null");
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/l/i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */