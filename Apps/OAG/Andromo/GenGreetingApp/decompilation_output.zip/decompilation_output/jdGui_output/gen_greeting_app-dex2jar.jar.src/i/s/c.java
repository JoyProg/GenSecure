package i.s;

import i.v.c.p;
import i.v.d.i;
import i.v.d.j;
import java.io.Serializable;

public final class c
  implements g, Serializable
{
  public final g g;
  public final g.b h;
  
  public c(g paramg, g.b paramb)
  {
    this.g = paramg;
    this.h = paramb;
  }
  
  public final boolean a(g.b paramb)
  {
    return i.a(get(paramb.getKey()), paramb);
  }
  
  public final boolean c(c paramc)
  {
    for (;;)
    {
      if (!a(paramc.h)) {
        return false;
      }
      paramc = paramc.g;
      if (!(paramc instanceof c)) {
        break;
      }
      paramc = (c)paramc;
    }
    i.c(paramc, "null cannot be cast to non-null type kotlin.coroutines.CoroutineContext.Element");
    return a((g.b)paramc);
  }
  
  public final int e()
  {
    int i = 2;
    Object localObject = this;
    for (;;)
    {
      localObject = ((c)localObject).g;
      if ((localObject instanceof c)) {
        localObject = (c)localObject;
      } else {
        localObject = null;
      }
      if (localObject == null) {
        return i;
      }
      i++;
    }
  }
  
  public boolean equals(Object paramObject)
  {
    if (this != paramObject) {
      if ((paramObject instanceof c))
      {
        paramObject = (c)paramObject;
        if ((((c)paramObject).e() == e()) && (((c)paramObject).c(this))) {}
      }
      else
      {
        return false;
      }
    }
    boolean bool = true;
    return bool;
  }
  
  public <R> R fold(R paramR, p<? super R, ? super g.b, ? extends R> paramp)
  {
    i.e(paramp, "operation");
    return (R)paramp.invoke(this.g.fold(paramR, paramp), this.h);
  }
  
  public <E extends g.b> E get(g.c<E> paramc)
  {
    i.e(paramc, "key");
    for (Object localObject = this;; localObject = (c)localObject)
    {
      g.b localb = ((c)localObject).h.get(paramc);
      if (localb != null) {
        return localb;
      }
      localObject = ((c)localObject).g;
      if (!(localObject instanceof c)) {
        break;
      }
    }
    return ((g)localObject).get(paramc);
  }
  
  public int hashCode()
  {
    return this.g.hashCode() + this.h.hashCode();
  }
  
  public g minusKey(g.c<?> paramc)
  {
    i.e(paramc, "key");
    if (this.h.get(paramc) != null) {
      return this.g;
    }
    paramc = this.g.minusKey(paramc);
    if (paramc == this.g) {
      paramc = this;
    } else if (paramc == h.g) {
      paramc = this.h;
    } else {
      paramc = new c(paramc, this.h);
    }
    return paramc;
  }
  
  public g plus(g paramg)
  {
    return g.a.a(this, paramg);
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append('[');
    localStringBuilder.append((String)fold("", a.g));
    localStringBuilder.append(']');
    return localStringBuilder.toString();
  }
  
  public static final class a
    extends j
    implements p<String, g.b, String>
  {
    public static final a g = new a();
    
    public a()
    {
      super();
    }
    
    public final String a(String paramString, g.b paramb)
    {
      i.e(paramString, "acc");
      i.e(paramb, "element");
      int i;
      if (paramString.length() == 0) {
        i = 1;
      } else {
        i = 0;
      }
      if (i != 0)
      {
        paramString = paramb.toString();
      }
      else
      {
        StringBuilder localStringBuilder = new StringBuilder();
        localStringBuilder.append(paramString);
        localStringBuilder.append(", ");
        localStringBuilder.append(paramb);
        paramString = localStringBuilder.toString();
      }
      return paramString;
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/i/s/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */