package i.t;

import i.a0.m;
import i.v.d.i;

public final class b
{
  public static final a a;
  
  static
  {
    int i = a();
    Object localObject1;
    label59:
    Object localObject3;
    Object localObject4;
    Object localObject5;
    if ((i >= 65544) || (i < 65536))
    {
      try
      {
        localObject1 = Class.forName("i.t.e.a").newInstance();
        i.d(localObject1, "forName(\"kotlin.internal…entations\").newInstance()");
        if (localObject1 != null)
        {
          try
          {
            a locala1 = (a)localObject1;
          }
          catch (ClassCastException localClassCastException1)
          {
            break label59;
          }
        }
        else
        {
          localNullPointerException1 = new java/lang/NullPointerException;
          localNullPointerException1.<init>("null cannot be cast to non-null type kotlin.internal.PlatformImplementations");
          throw localNullPointerException1;
        }
      }
      catch (ClassNotFoundException localClassNotFoundException1)
      {
        for (;;)
        {
          NullPointerException localNullPointerException2;
          try
          {
            NullPointerException localNullPointerException1;
            localObject1 = Class.forName("kotlin.internal.JRE8PlatformImplementations").newInstance();
            i.d(localObject1, "forName(\"kotlin.internal…entations\").newInstance()");
            if (localObject1 != null)
            {
              try
              {
                a locala2 = (a)localObject1;
              }
              catch (ClassCastException localClassCastException2)
              {
                break label186;
              }
            }
            else
            {
              localNullPointerException2 = new java/lang/NullPointerException;
              localNullPointerException2.<init>("null cannot be cast to non-null type kotlin.internal.PlatformImplementations");
              throw localNullPointerException2;
            }
          }
          catch (ClassNotFoundException localClassNotFoundException2) {}
        }
        localObject4 = localObject1.getClass().getClassLoader();
        localObject1 = a.class.getClassLoader();
        if (i.a(localObject4, localObject1)) {
          break label267;
        }
        localObject3 = new java/lang/ClassNotFoundException;
        localObject5 = new java/lang/StringBuilder;
        ((StringBuilder)localObject5).<init>();
        ((StringBuilder)localObject5).append("Instance class was loaded from a different classloader: ");
        ((StringBuilder)localObject5).append(localObject4);
        ((StringBuilder)localObject5).append(", base type classloader: ");
        ((StringBuilder)localObject5).append(localObject1);
        ((ClassNotFoundException)localObject3).<init>(((StringBuilder)localObject5).toString(), localNullPointerException2);
        throw ((Throwable)localObject3);
        throw localNullPointerException2;
      }
      localObject3 = localObject1.getClass().getClassLoader();
      localObject4 = a.class.getClassLoader();
      if (!i.a(localObject3, localObject4))
      {
        localObject1 = new java/lang/ClassNotFoundException;
        localObject5 = new java/lang/StringBuilder;
        ((StringBuilder)localObject5).<init>();
        ((StringBuilder)localObject5).append("Instance class was loaded from a different classloader: ");
        ((StringBuilder)localObject5).append(localObject3);
        ((StringBuilder)localObject5).append(", base type classloader: ");
        ((StringBuilder)localObject5).append(localObject4);
        ((ClassNotFoundException)localObject1).<init>(((StringBuilder)localObject5).toString(), localNullPointerException1);
        throw ((Throwable)localObject1);
      }
      throw localNullPointerException1;
    }
    label186:
    label267:
    if ((i >= 65543) || (i < 65536))
    {
      try
      {
        localObject1 = Class.forName("i.t.d.a").newInstance();
        i.d(localObject1, "forName(\"kotlin.internal…entations\").newInstance()");
        if (localObject1 != null)
        {
          try
          {
            a locala3 = (a)localObject1;
          }
          catch (ClassCastException localClassCastException3)
          {
            break label325;
          }
        }
        else
        {
          localNullPointerException3 = new java/lang/NullPointerException;
          localNullPointerException3.<init>("null cannot be cast to non-null type kotlin.internal.PlatformImplementations");
          throw localNullPointerException3;
        }
      }
      catch (ClassNotFoundException localClassNotFoundException3)
      {
        try
        {
          NullPointerException localNullPointerException3;
          label325:
          localObject1 = Class.forName("kotlin.internal.JRE7PlatformImplementations").newInstance();
          i.d(localObject1, "forName(\"kotlin.internal…entations\").newInstance()");
          if (localObject1 != null)
          {
            try
            {
              a locala4 = (a)localObject1;
            }
            catch (ClassCastException localClassCastException4)
            {
              break label448;
            }
          }
          else
          {
            localObject2 = new java/lang/NullPointerException;
            ((NullPointerException)localObject2).<init>("null cannot be cast to non-null type kotlin.internal.PlatformImplementations");
            throw ((Throwable)localObject2);
          }
        }
        catch (ClassNotFoundException localClassNotFoundException4)
        {
          Object localObject2;
          for (;;) {}
        }
        localObject5 = localObject1.getClass().getClassLoader();
        localObject3 = a.class.getClassLoader();
        if (i.a(localObject5, localObject3)) {
          break label529;
        }
        localObject1 = new java/lang/ClassNotFoundException;
        localObject4 = new java/lang/StringBuilder;
        ((StringBuilder)localObject4).<init>();
        ((StringBuilder)localObject4).append("Instance class was loaded from a different classloader: ");
        ((StringBuilder)localObject4).append(localObject5);
        ((StringBuilder)localObject4).append(", base type classloader: ");
        ((StringBuilder)localObject4).append(localObject3);
        ((ClassNotFoundException)localObject1).<init>(((StringBuilder)localObject4).toString(), (Throwable)localObject2);
        throw ((Throwable)localObject1);
        throw ((Throwable)localObject2);
      }
      localObject5 = localObject1.getClass().getClassLoader();
      localObject4 = a.class.getClassLoader();
      if (!i.a(localObject5, localObject4))
      {
        localObject1 = new java/lang/ClassNotFoundException;
        localObject3 = new java/lang/StringBuilder;
        ((StringBuilder)localObject3).<init>();
        ((StringBuilder)localObject3).append("Instance class was loaded from a different classloader: ");
        ((StringBuilder)localObject3).append(localObject5);
        ((StringBuilder)localObject3).append(", base type classloader: ");
        ((StringBuilder)localObject3).append(localObject4);
        ((ClassNotFoundException)localObject1).<init>(((StringBuilder)localObject3).toString(), localNullPointerException3);
        throw ((Throwable)localObject1);
      }
      throw localNullPointerException3;
    }
    label448:
    label529:
    localObject2 = new a();
    a = (a)localObject2;
  }
  
  public static final int a()
  {
    String str1 = System.getProperty("java.specification.version");
    int i = 65542;
    if (str1 == null) {
      return 65542;
    }
    int j = m.z(str1, '.', 0, false, 6, null);
    if (j < 0) {}
    try
    {
      k = Integer.parseInt(str1);
      i = k * 65536;
    }
    catch (NumberFormatException localNumberFormatException1)
    {
      int k;
      int m;
      int n;
      String str2;
      for (;;) {}
    }
    return i;
    m = j + 1;
    n = m.z(str1, '.', m, false, 4, null);
    k = n;
    if (n < 0) {
      k = str1.length();
    }
    str2 = str1.substring(0, j);
    i.d(str2, "this as java.lang.String…ing(startIndex, endIndex)");
    str1 = str1.substring(m, k);
    i.d(str1, "this as java.lang.String…ing(startIndex, endIndex)");
    try
    {
      k = Integer.parseInt(str2);
      n = Integer.parseInt(str1);
      i = k * 65536 + n;
    }
    catch (NumberFormatException localNumberFormatException2)
    {
      for (;;) {}
    }
    return i;
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/i/t/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */