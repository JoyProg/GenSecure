package i.a0;

import i.x.c;

public class a
{
  public static final int a(int paramInt)
  {
    if (new c(2, 36).w(paramInt)) {
      return paramInt;
    }
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("radix ");
    localStringBuilder.append(paramInt);
    localStringBuilder.append(" was not in valid range ");
    localStringBuilder.append(new c(2, 36));
    throw new IllegalArgumentException(localStringBuilder.toString());
  }
  
  public static final int b(char paramChar, int paramInt)
  {
    return Character.digit(paramChar, paramInt);
  }
  
  public static final boolean c(char paramChar)
  {
    boolean bool;
    if ((!Character.isWhitespace(paramChar)) && (!Character.isSpaceChar(paramChar))) {
      bool = false;
    } else {
      bool = true;
    }
    return bool;
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/i/a0/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */