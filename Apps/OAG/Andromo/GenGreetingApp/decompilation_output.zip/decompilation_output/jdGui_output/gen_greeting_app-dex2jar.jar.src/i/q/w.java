package i.q;

import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class w
  extends v
{
  public static final <K, V> Map<K, V> d()
  {
    r localr = r.g;
    i.v.d.i.c(localr, "null cannot be cast to non-null type kotlin.collections.Map<K of kotlin.collections.MapsKt__MapsKt.emptyMap, V of kotlin.collections.MapsKt__MapsKt.emptyMap>");
    return localr;
  }
  
  public static final <K, V> Map<K, V> e(i.i<? extends K, ? extends V>... paramVarArgs)
  {
    i.v.d.i.e(paramVarArgs, "pairs");
    if (paramVarArgs.length > 0) {
      paramVarArgs = k(paramVarArgs, new LinkedHashMap(v.a(paramVarArgs.length)));
    } else {
      paramVarArgs = d();
    }
    return paramVarArgs;
  }
  
  public static final <K, V> Map<K, V> f(Map<K, ? extends V> paramMap)
  {
    i.v.d.i.e(paramMap, "<this>");
    int i = paramMap.size();
    if (i != 0)
    {
      if (i == 1) {
        paramMap = v.c(paramMap);
      }
    }
    else {
      paramMap = d();
    }
    return paramMap;
  }
  
  public static final <K, V> void g(Map<? super K, ? super V> paramMap, Iterable<? extends i.i<? extends K, ? extends V>> paramIterable)
  {
    i.v.d.i.e(paramMap, "<this>");
    i.v.d.i.e(paramIterable, "pairs");
    Iterator localIterator = paramIterable.iterator();
    while (localIterator.hasNext())
    {
      paramIterable = (i.i)localIterator.next();
      paramMap.put(paramIterable.a(), paramIterable.b());
    }
  }
  
  public static final <K, V> void h(Map<? super K, ? super V> paramMap, i.i<? extends K, ? extends V>[] paramArrayOfi)
  {
    i.v.d.i.e(paramMap, "<this>");
    i.v.d.i.e(paramArrayOfi, "pairs");
    int i = paramArrayOfi.length;
    for (int j = 0; j < i; j++)
    {
      i.i<? extends K, ? extends V> locali = paramArrayOfi[j];
      paramMap.put(locali.a(), locali.b());
    }
  }
  
  public static final <K, V> Map<K, V> i(Iterable<? extends i.i<? extends K, ? extends V>> paramIterable)
  {
    i.v.d.i.e(paramIterable, "<this>");
    if ((paramIterable instanceof Collection))
    {
      Collection localCollection = (Collection)paramIterable;
      int i = localCollection.size();
      if (i != 0)
      {
        if (i != 1)
        {
          paramIterable = j(paramIterable, new LinkedHashMap(v.a(localCollection.size())));
        }
        else
        {
          if ((paramIterable instanceof List)) {
            paramIterable = ((List)paramIterable).get(0);
          } else {
            paramIterable = paramIterable.iterator().next();
          }
          paramIterable = v.b((i.i)paramIterable);
        }
      }
      else {
        paramIterable = d();
      }
      return paramIterable;
    }
    return f(j(paramIterable, new LinkedHashMap()));
  }
  
  public static final <K, V, M extends Map<? super K, ? super V>> M j(Iterable<? extends i.i<? extends K, ? extends V>> paramIterable, M paramM)
  {
    i.v.d.i.e(paramIterable, "<this>");
    i.v.d.i.e(paramM, "destination");
    g(paramM, paramIterable);
    return paramM;
  }
  
  public static final <K, V, M extends Map<? super K, ? super V>> M k(i.i<? extends K, ? extends V>[] paramArrayOfi, M paramM)
  {
    i.v.d.i.e(paramArrayOfi, "<this>");
    i.v.d.i.e(paramM, "destination");
    h(paramM, paramArrayOfi);
    return paramM;
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/i/q/w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */