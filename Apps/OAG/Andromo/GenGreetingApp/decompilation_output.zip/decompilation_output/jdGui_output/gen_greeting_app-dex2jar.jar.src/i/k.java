package i;

import i.v.d.i;

public final class k
{
  public static final Object a(Throwable paramThrowable)
  {
    i.e(paramThrowable, "exception");
    return new j.b(paramThrowable);
  }
  
  public static final void b(Object paramObject)
  {
    if (!(paramObject instanceof j.b)) {
      return;
    }
    throw ((j.b)paramObject).g;
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/i/k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */