package l;

public abstract class h
  implements t
{
  public final t g;
  
  public h(t paramt)
  {
    if (paramt != null)
    {
      this.g = paramt;
      return;
    }
    throw new IllegalArgumentException("delegate == null");
  }
  
  public final t a()
  {
    return this.g;
  }
  
  public void close()
  {
    this.g.close();
  }
  
  public u f()
  {
    return this.g.f();
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(getClass().getSimpleName());
    localStringBuilder.append("(");
    localStringBuilder.append(this.g.toString());
    localStringBuilder.append(")");
    return localStringBuilder.toString();
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/l/h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */