package androidx.lifecycle;

import c.k.d;
import c.k.j;

public abstract interface DefaultLifecycleObserver
  extends d
{
  public abstract void onCreate(j paramj);
  
  public abstract void onDestroy(j paramj);
  
  public abstract void onPause(j paramj);
  
  public abstract void onResume(j paramj);
  
  public abstract void onStart(j paramj);
  
  public abstract void onStop(j paramj);
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/androidx/lifecycle/DefaultLifecycleObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */