package k;

import java.io.IOException;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.SSLSession;
import k.k0.e;

public final class w
{
  public final j0 a;
  public final m b;
  public final List<Certificate> c;
  public final List<Certificate> d;
  
  public w(j0 paramj0, m paramm, List<Certificate> paramList1, List<Certificate> paramList2)
  {
    this.a = paramj0;
    this.b = paramm;
    this.c = paramList1;
    this.d = paramList2;
  }
  
  public static w b(SSLSession paramSSLSession)
  {
    Object localObject1 = paramSSLSession.getCipherSuite();
    if (localObject1 != null)
    {
      if (!"SSL_NULL_WITH_NULL_NULL".equals(localObject1))
      {
        m localm = m.a((String)localObject1);
        localObject1 = paramSSLSession.getProtocol();
        if (localObject1 != null)
        {
          if (!"NONE".equals(localObject1))
          {
            j0 localj0 = j0.e((String)localObject1);
            Object localObject2;
            try
            {
              localObject1 = paramSSLSession.getPeerCertificates();
            }
            catch (SSLPeerUnverifiedException localSSLPeerUnverifiedException)
            {
              localObject2 = null;
            }
            if (localObject2 != null) {
              localObject2 = e.s((Object[])localObject2);
            } else {
              localObject2 = Collections.emptyList();
            }
            paramSSLSession = paramSSLSession.getLocalCertificates();
            if (paramSSLSession != null) {
              paramSSLSession = e.s(paramSSLSession);
            } else {
              paramSSLSession = Collections.emptyList();
            }
            return new w(localj0, localm, (List)localObject2, paramSSLSession);
          }
          throw new IOException("tlsVersion == NONE");
        }
        throw new IllegalStateException("tlsVersion == null");
      }
      throw new IOException("cipherSuite == SSL_NULL_WITH_NULL_NULL");
    }
    throw new IllegalStateException("cipherSuite == null");
  }
  
  public m a()
  {
    return this.b;
  }
  
  public final List<String> c(List<Certificate> paramList)
  {
    ArrayList localArrayList = new ArrayList();
    paramList = paramList.iterator();
    while (paramList.hasNext())
    {
      Certificate localCertificate = (Certificate)paramList.next();
      if ((localCertificate instanceof X509Certificate)) {
        localArrayList.add(String.valueOf(((X509Certificate)localCertificate).getSubjectDN()));
      } else {
        localArrayList.add(localCertificate.getType());
      }
    }
    return localArrayList;
  }
  
  public List<Certificate> d()
  {
    return this.c;
  }
  
  public boolean equals(Object paramObject)
  {
    boolean bool1 = paramObject instanceof w;
    boolean bool2 = false;
    if (!bool1) {
      return false;
    }
    paramObject = (w)paramObject;
    bool1 = bool2;
    if (this.a.equals(((w)paramObject).a))
    {
      bool1 = bool2;
      if (this.b.equals(((w)paramObject).b))
      {
        bool1 = bool2;
        if (this.c.equals(((w)paramObject).c))
        {
          bool1 = bool2;
          if (this.d.equals(((w)paramObject).d)) {
            bool1 = true;
          }
        }
      }
    }
    return bool1;
  }
  
  public int hashCode()
  {
    return (((527 + this.a.hashCode()) * 31 + this.b.hashCode()) * 31 + this.c.hashCode()) * 31 + this.d.hashCode();
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("Handshake{tlsVersion=");
    localStringBuilder.append(this.a);
    localStringBuilder.append(" cipherSuite=");
    localStringBuilder.append(this.b);
    localStringBuilder.append(" peerCertificates=");
    localStringBuilder.append(c(this.c));
    localStringBuilder.append(" localCertificates=");
    localStringBuilder.append(c(this.d));
    localStringBuilder.append('}');
    return localStringBuilder.toString();
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/k/w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */