package l;

import java.nio.ByteBuffer;
import java.util.Objects;

public final class n
  implements d
{
  public final c g = new c();
  public final s h;
  public boolean i;
  
  public n(s params)
  {
    Objects.requireNonNull(params, "sink == null");
    this.h = params;
  }
  
  public d A(int paramInt)
  {
    if (!this.i)
    {
      this.g.D0(paramInt);
      return d0();
    }
    throw new IllegalStateException("closed");
  }
  
  public d F(int paramInt)
  {
    if (!this.i)
    {
      this.g.C0(paramInt);
      return d0();
    }
    throw new IllegalStateException("closed");
  }
  
  public d R(int paramInt)
  {
    if (!this.i)
    {
      this.g.z0(paramInt);
      return d0();
    }
    throw new IllegalStateException("closed");
  }
  
  public d Z(byte[] paramArrayOfByte)
  {
    if (!this.i)
    {
      this.g.o0(paramArrayOfByte);
      return d0();
    }
    throw new IllegalStateException("closed");
  }
  
  public c c()
  {
    return this.g;
  }
  
  /* Error */
  public void close()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 37	l/n:i	Z
    //   4: ifeq +4 -> 8
    //   7: return
    //   8: aconst_null
    //   9: astore_1
    //   10: aload_0
    //   11: getfield 22	l/n:g	Ll/c;
    //   14: astore_2
    //   15: aload_2
    //   16: getfield 71	l/c:i	J
    //   19: lstore_3
    //   20: aload_1
    //   21: astore 5
    //   23: lload_3
    //   24: lconst_0
    //   25: lcmp
    //   26: ifle +22 -> 48
    //   29: aload_0
    //   30: getfield 32	l/n:h	Ll/s;
    //   33: aload_2
    //   34: lload_3
    //   35: invokeinterface 77 4 0
    //   40: aload_1
    //   41: astore 5
    //   43: goto +5 -> 48
    //   46: astore 5
    //   48: aload_0
    //   49: getfield 32	l/n:h	Ll/s;
    //   52: invokeinterface 79 1 0
    //   57: aload 5
    //   59: astore_1
    //   60: goto +14 -> 74
    //   63: astore_2
    //   64: aload 5
    //   66: astore_1
    //   67: aload 5
    //   69: ifnonnull +5 -> 74
    //   72: aload_2
    //   73: astore_1
    //   74: aload_0
    //   75: iconst_1
    //   76: putfield 37	l/n:i	Z
    //   79: aload_1
    //   80: ifnull +7 -> 87
    //   83: aload_1
    //   84: invokestatic 85	l/v:e	(Ljava/lang/Throwable;)V
    //   87: return
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	88	0	this	n
    //   9	75	1	localObject1	Object
    //   14	20	2	localc	c
    //   63	10	2	localObject2	Object
    //   19	16	3	l	long
    //   21	21	5	localObject3	Object
    //   46	22	5	localObject4	Object
    // Exception table:
    //   from	to	target	type
    //   10	20	46	finally
    //   29	40	46	finally
    //   48	57	63	finally
  }
  
  public d d0()
  {
    if (!this.i)
    {
      long l = this.g.d();
      if (l > 0L) {
        this.h.n(this.g, l);
      }
      return this;
    }
    throw new IllegalStateException("closed");
  }
  
  public u f()
  {
    return this.h.f();
  }
  
  public void flush()
  {
    if (!this.i)
    {
      c localc = this.g;
      long l = localc.i;
      if (l > 0L) {
        this.h.n(localc, l);
      }
      this.h.flush();
      return;
    }
    throw new IllegalStateException("closed");
  }
  
  public boolean isOpen()
  {
    return this.i ^ true;
  }
  
  public d j(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    if (!this.i)
    {
      this.g.q0(paramArrayOfByte, paramInt1, paramInt2);
      return d0();
    }
    throw new IllegalStateException("closed");
  }
  
  public void n(c paramc, long paramLong)
  {
    if (!this.i)
    {
      this.g.n(paramc, paramLong);
      d0();
      return;
    }
    throw new IllegalStateException("closed");
  }
  
  public d r(long paramLong)
  {
    if (!this.i)
    {
      this.g.B0(paramLong);
      return d0();
    }
    throw new IllegalStateException("closed");
  }
  
  public d s0(String paramString)
  {
    if (!this.i)
    {
      this.g.F0(paramString);
      return d0();
    }
    throw new IllegalStateException("closed");
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("buffer(");
    localStringBuilder.append(this.h);
    localStringBuilder.append(")");
    return localStringBuilder.toString();
  }
  
  public int write(ByteBuffer paramByteBuffer)
  {
    if (!this.i)
    {
      int j = this.g.write(paramByteBuffer);
      d0();
      return j;
    }
    throw new IllegalStateException("closed");
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/l/n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */