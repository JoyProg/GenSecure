package i;

public abstract interface f<T>
{
  public abstract T getValue();
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/i/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */