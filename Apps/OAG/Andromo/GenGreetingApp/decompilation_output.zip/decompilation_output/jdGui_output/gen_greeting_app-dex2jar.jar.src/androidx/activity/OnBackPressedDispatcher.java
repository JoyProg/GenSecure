package androidx.activity;

import c.a.a;
import c.a.b;
import c.k.f;
import c.k.f.a;
import c.k.f.b;
import c.k.h;
import c.k.j;
import java.util.ArrayDeque;
import java.util.Iterator;

public final class OnBackPressedDispatcher
{
  public final Runnable a;
  public final ArrayDeque<b> b = new ArrayDeque();
  
  public OnBackPressedDispatcher(Runnable paramRunnable)
  {
    this.a = paramRunnable;
  }
  
  public void a(j paramj, b paramb)
  {
    paramj = paramj.getLifecycle();
    if (paramj.b() == f.b.g) {
      return;
    }
    paramb.a(new LifecycleOnBackPressedCancellable(paramj, paramb));
  }
  
  public a b(b paramb)
  {
    this.b.add(paramb);
    a locala = new a(paramb);
    paramb.a(locala);
    return locala;
  }
  
  public void c()
  {
    Iterator localIterator = this.b.descendingIterator();
    while (localIterator.hasNext())
    {
      localObject = (b)localIterator.next();
      if (((b)localObject).c())
      {
        ((b)localObject).b();
        return;
      }
    }
    Object localObject = this.a;
    if (localObject != null) {
      ((Runnable)localObject).run();
    }
  }
  
  public class LifecycleOnBackPressedCancellable
    implements h, a
  {
    public final f a;
    public final b b;
    public a c;
    
    public LifecycleOnBackPressedCancellable(f paramf, b paramb)
    {
      this.a = paramf;
      this.b = paramb;
      paramf.a(this);
    }
    
    public void a(j paramj, f.a parama)
    {
      if (parama == f.a.ON_START)
      {
        this.c = OnBackPressedDispatcher.this.b(this.b);
      }
      else if (parama == f.a.ON_STOP)
      {
        paramj = this.c;
        if (paramj != null) {
          paramj.cancel();
        }
      }
      else if (parama == f.a.ON_DESTROY)
      {
        cancel();
      }
    }
    
    public void cancel()
    {
      this.a.c(this);
      this.b.e(this);
      a locala = this.c;
      if (locala != null)
      {
        locala.cancel();
        this.c = null;
      }
    }
  }
  
  public class a
    implements a
  {
    public final b a;
    
    public a(b paramb)
    {
      this.a = paramb;
    }
    
    public void cancel()
    {
      OnBackPressedDispatcher.this.b.remove(this.a);
      this.a.e(this);
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/androidx/activity/OnBackPressedDispatcher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */