package i.z;

import i.v.c.l;
import java.util.Iterator;

public final class h<T, R>
  implements b<R>
{
  public final b<T> a;
  public final l<T, R> b;
  
  public h(b<? extends T> paramb, l<? super T, ? extends R> paraml)
  {
    this.a = paramb;
    this.b = paraml;
  }
  
  public Iterator<R> iterator()
  {
    return new a(this);
  }
  
  public static final class a
    implements Iterator<R>
  {
    public final Iterator<T> g;
    
    public a(h<T, R> paramh)
    {
      this.g = h.a(paramh).iterator();
    }
    
    public boolean hasNext()
    {
      return this.g.hasNext();
    }
    
    public R next()
    {
      return (R)h.b(this.h).invoke(this.g.next());
    }
    
    public void remove()
    {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/i/z/h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */