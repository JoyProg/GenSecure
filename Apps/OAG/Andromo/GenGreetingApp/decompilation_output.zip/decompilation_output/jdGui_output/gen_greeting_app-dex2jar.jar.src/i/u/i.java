package i.u;

import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class i
  extends h
{
  public static final File b(File paramFile1, File paramFile2, boolean paramBoolean, int paramInt)
  {
    i.v.d.i.e(paramFile1, "<this>");
    i.v.d.i.e(paramFile2, "target");
    if (paramFile1.exists())
    {
      if (paramFile2.exists()) {
        if (paramBoolean)
        {
          if (!paramFile2.delete()) {
            throw new d(paramFile1, paramFile2, "Tried to overwrite the destination, but failed to delete it.");
          }
        }
        else {
          throw new d(paramFile1, paramFile2, "The destination file already exists.");
        }
      }
      Object localObject1;
      if (paramFile1.isDirectory())
      {
        if (!paramFile2.mkdirs()) {
          throw new e(paramFile1, paramFile2, "Failed to create target directory.");
        }
      }
      else
      {
        localObject1 = paramFile2.getParentFile();
        if (localObject1 != null) {
          ((File)localObject1).mkdirs();
        }
        paramFile1 = new FileInputStream(paramFile1);
      }
      try
      {
        localObject1 = new java/io/FileOutputStream;
        ((FileOutputStream)localObject1).<init>(paramFile2);
        try
        {
          a.a(paramFile1, (OutputStream)localObject1, paramInt);
          b.a((Closeable)localObject1, null);
          b.a(paramFile1, null);
          return paramFile2;
        }
        finally
        {
          try
          {
            throw paramFile2;
          }
          finally
          {
            b.a((Closeable)localObject1, paramFile2);
          }
        }
        throw new j(paramFile1, null, "The source file doesn't exist.", 2, null);
      }
      finally
      {
        try
        {
          throw localThrowable;
        }
        finally
        {
          b.a(paramFile1, localThrowable);
        }
      }
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/i/u/i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */