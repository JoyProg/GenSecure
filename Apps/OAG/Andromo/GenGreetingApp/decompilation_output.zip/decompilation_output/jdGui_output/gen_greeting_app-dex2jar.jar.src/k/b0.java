package k;

import java.net.Proxy;
import java.net.ProxySelector;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import javax.net.SocketFactory;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import k.k0.l.f;
import k.k0.m.a;

public class b0
  implements Cloneable
{
  public static final List<c0> g = k.k0.e.s(new c0[] { c0.j, c0.h });
  public static final List<p> h = k.k0.e.s(new p[] { p.d, p.f });
  public final o A;
  public final u B;
  public final boolean C;
  public final boolean D;
  public final boolean E;
  public final int F;
  public final int G;
  public final int H;
  public final int I;
  public final int J;
  public final s i;
  public final Proxy j;
  public final List<c0> k;
  public final List<p> l;
  public final List<z> m;
  public final List<z> n;
  public final v.b o;
  public final ProxySelector p;
  public final r q;
  public final h r;
  public final k.k0.g.d s;
  public final SocketFactory t;
  public final SSLSocketFactory u;
  public final k.k0.n.c v;
  public final HostnameVerifier w;
  public final l x;
  public final g y;
  public final g z;
  
  static
  {
    k.k0.c.a = new a();
  }
  
  public b0()
  {
    this(new b());
  }
  
  public b0(b paramb)
  {
    this.i = paramb.a;
    this.j = paramb.b;
    this.k = paramb.c;
    Object localObject = paramb.d;
    this.l = ((List)localObject);
    this.m = k.k0.e.r(paramb.e);
    this.n = k.k0.e.r(paramb.f);
    this.o = paramb.g;
    this.p = paramb.h;
    this.q = paramb.i;
    this.s = paramb.j;
    this.t = paramb.k;
    Iterator localIterator = ((List)localObject).iterator();
    for (int i1 = 0;; i1 = 1)
    {
      if (!localIterator.hasNext()) {
        break label147;
      }
      localObject = (p)localIterator.next();
      if ((i1 == 0) && (!((p)localObject).d())) {
        break;
      }
    }
    label147:
    localObject = paramb.l;
    if ((localObject == null) && (i1 != 0))
    {
      localObject = k.k0.e.B();
      this.u = u((X509TrustManager)localObject);
      this.v = k.k0.n.c.b((X509TrustManager)localObject);
    }
    else
    {
      this.u = ((SSLSocketFactory)localObject);
      this.v = paramb.m;
    }
    if (this.u != null) {
      f.j().f(this.u);
    }
    this.w = paramb.n;
    this.x = paramb.o.f(this.v);
    this.y = paramb.p;
    this.z = paramb.q;
    this.A = paramb.r;
    this.B = paramb.s;
    this.C = paramb.t;
    this.D = paramb.u;
    this.E = paramb.v;
    this.F = paramb.w;
    this.G = paramb.x;
    this.H = paramb.y;
    this.I = paramb.z;
    this.J = paramb.A;
    if (!this.m.contains(null))
    {
      if (!this.n.contains(null)) {
        return;
      }
      paramb = new StringBuilder();
      paramb.append("Null network interceptor: ");
      paramb.append(this.n);
      throw new IllegalStateException(paramb.toString());
    }
    paramb = new StringBuilder();
    paramb.append("Null interceptor: ");
    paramb.append(this.m);
    paramb = new IllegalStateException(paramb.toString());
    for (;;)
    {
      throw paramb;
    }
  }
  
  public static SSLSocketFactory u(X509TrustManager paramX509TrustManager)
  {
    try
    {
      SSLContext localSSLContext = f.j().k();
      localSSLContext.init(null, new TrustManager[] { paramX509TrustManager }, null);
      paramX509TrustManager = localSSLContext.getSocketFactory();
      return paramX509TrustManager;
    }
    catch (GeneralSecurityException paramX509TrustManager)
    {
      throw new AssertionError("No System TLS", paramX509TrustManager);
    }
  }
  
  public ProxySelector A()
  {
    return this.p;
  }
  
  public int B()
  {
    return this.H;
  }
  
  public boolean C()
  {
    return this.E;
  }
  
  public SocketFactory D()
  {
    return this.t;
  }
  
  public SSLSocketFactory E()
  {
    return this.u;
  }
  
  public int F()
  {
    return this.I;
  }
  
  public g a()
  {
    return this.z;
  }
  
  public int b()
  {
    return this.F;
  }
  
  public l c()
  {
    return this.x;
  }
  
  public int d()
  {
    return this.G;
  }
  
  public o e()
  {
    return this.A;
  }
  
  public List<p> f()
  {
    return this.l;
  }
  
  public r h()
  {
    return this.q;
  }
  
  public s i()
  {
    return this.i;
  }
  
  public u j()
  {
    return this.B;
  }
  
  public v.b k()
  {
    return this.o;
  }
  
  public boolean l()
  {
    return this.D;
  }
  
  public boolean n()
  {
    return this.C;
  }
  
  public HostnameVerifier o()
  {
    return this.w;
  }
  
  public List<z> p()
  {
    return this.m;
  }
  
  public k.k0.g.d q()
  {
    if (this.r == null) {
      return this.s;
    }
    throw null;
  }
  
  public List<z> r()
  {
    return this.n;
  }
  
  public b s()
  {
    return new b(this);
  }
  
  public j t(e0 parame0)
  {
    return d0.f(this, parame0, false);
  }
  
  public int w()
  {
    return this.J;
  }
  
  public List<c0> x()
  {
    return this.k;
  }
  
  public Proxy y()
  {
    return this.j;
  }
  
  public g z()
  {
    return this.y;
  }
  
  public class a
    extends k.k0.c
  {
    public void a(x.a parama, String paramString)
    {
      parama.b(paramString);
    }
    
    public void b(x.a parama, String paramString1, String paramString2)
    {
      parama.c(paramString1, paramString2);
    }
    
    public void c(p paramp, SSLSocket paramSSLSocket, boolean paramBoolean)
    {
      paramp.a(paramSSLSocket, paramBoolean);
    }
    
    public int d(g0.a parama)
    {
      return parama.c;
    }
    
    public boolean e(e parame1, e parame2)
    {
      return parame1.d(parame2);
    }
    
    public k.k0.h.d f(g0 paramg0)
    {
      return paramg0.s;
    }
    
    public void g(g0.a parama, k.k0.h.d paramd)
    {
      parama.k(paramd);
    }
    
    public k.k0.h.g h(o paramo)
    {
      return paramo.a;
    }
  }
  
  public static final class b
  {
    public int A;
    public s a;
    public Proxy b;
    public List<c0> c;
    public List<p> d;
    public final List<z> e;
    public final List<z> f;
    public v.b g;
    public ProxySelector h;
    public r i;
    public k.k0.g.d j;
    public SocketFactory k;
    public SSLSocketFactory l;
    public k.k0.n.c m;
    public HostnameVerifier n;
    public l o;
    public g p;
    public g q;
    public o r;
    public u s;
    public boolean t;
    public boolean u;
    public boolean v;
    public int w;
    public int x;
    public int y;
    public int z;
    
    public b()
    {
      this.e = new ArrayList();
      this.f = new ArrayList();
      this.a = new s();
      this.c = b0.g;
      this.d = b0.h;
      this.g = v.k(v.a);
      Object localObject = ProxySelector.getDefault();
      this.h = ((ProxySelector)localObject);
      if (localObject == null) {
        this.h = new a();
      }
      this.i = r.a;
      this.k = SocketFactory.getDefault();
      this.n = k.k0.n.d.a;
      this.o = l.a;
      localObject = g.a;
      this.p = ((g)localObject);
      this.q = ((g)localObject);
      this.r = new o();
      this.s = u.a;
      this.t = true;
      this.u = true;
      this.v = true;
      this.w = 0;
      this.x = 10000;
      this.y = 10000;
      this.z = 10000;
      this.A = 0;
    }
    
    public b(b0 paramb0)
    {
      ArrayList localArrayList1 = new ArrayList();
      this.e = localArrayList1;
      ArrayList localArrayList2 = new ArrayList();
      this.f = localArrayList2;
      this.a = paramb0.i;
      this.b = paramb0.j;
      this.c = paramb0.k;
      this.d = paramb0.l;
      localArrayList1.addAll(paramb0.m);
      localArrayList2.addAll(paramb0.n);
      this.g = paramb0.o;
      this.h = paramb0.p;
      this.i = paramb0.q;
      this.j = paramb0.s;
      this.k = paramb0.t;
      this.l = paramb0.u;
      this.m = paramb0.v;
      this.n = paramb0.w;
      this.o = paramb0.x;
      this.p = paramb0.y;
      this.q = paramb0.z;
      this.r = paramb0.A;
      this.s = paramb0.B;
      this.t = paramb0.C;
      this.u = paramb0.D;
      this.v = paramb0.E;
      this.w = paramb0.F;
      this.x = paramb0.G;
      this.y = paramb0.H;
      this.z = paramb0.I;
      this.A = paramb0.J;
    }
    
    public b0 a()
    {
      return new b0(this);
    }
    
    public b b(long paramLong, TimeUnit paramTimeUnit)
    {
      this.x = k.k0.e.c("timeout", paramLong, paramTimeUnit);
      return this;
    }
    
    public b c(HostnameVerifier paramHostnameVerifier)
    {
      Objects.requireNonNull(paramHostnameVerifier, "hostnameVerifier == null");
      this.n = paramHostnameVerifier;
      return this;
    }
    
    public b d(long paramLong, TimeUnit paramTimeUnit)
    {
      this.y = k.k0.e.c("timeout", paramLong, paramTimeUnit);
      return this;
    }
    
    public b e(SSLSocketFactory paramSSLSocketFactory, X509TrustManager paramX509TrustManager)
    {
      Objects.requireNonNull(paramSSLSocketFactory, "sslSocketFactory == null");
      Objects.requireNonNull(paramX509TrustManager, "trustManager == null");
      this.l = paramSSLSocketFactory;
      this.m = k.k0.n.c.b(paramX509TrustManager);
      return this;
    }
    
    public b f(long paramLong, TimeUnit paramTimeUnit)
    {
      this.z = k.k0.e.c("timeout", paramLong, paramTimeUnit);
      return this;
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/k/b0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */