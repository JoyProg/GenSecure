package i.z;

import i.v.c.l;
import i.v.d.i;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public class g
  extends f
{
  public static final <T, R> b<R> c(b<? extends T> paramb, l<? super T, ? extends R> paraml)
  {
    i.e(paramb, "<this>");
    i.e(paraml, "transform");
    return new h(paramb, paraml);
  }
  
  public static final <T, C extends Collection<? super T>> C d(b<? extends T> paramb, C paramC)
  {
    i.e(paramb, "<this>");
    i.e(paramC, "destination");
    paramb = paramb.iterator();
    while (paramb.hasNext()) {
      paramC.add(paramb.next());
    }
    return paramC;
  }
  
  public static final <T> List<T> e(b<? extends T> paramb)
  {
    i.e(paramb, "<this>");
    return i.q.g.e(f(paramb));
  }
  
  public static final <T> List<T> f(b<? extends T> paramb)
  {
    i.e(paramb, "<this>");
    return (List)d(paramb, new ArrayList());
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/i/z/g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */