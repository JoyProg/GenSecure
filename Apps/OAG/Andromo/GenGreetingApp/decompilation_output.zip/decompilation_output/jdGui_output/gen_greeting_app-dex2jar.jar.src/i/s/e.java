package i.s;

import i.v.d.i;

public abstract interface e
  extends g.b
{
  public static final b d = b.g;
  
  public abstract void d(d<?> paramd);
  
  public abstract <T> d<T> g(d<? super T> paramd);
  
  public static final class a
  {
    public static <E extends g.b> E a(e parame, g.c<E> paramc)
    {
      i.e(paramc, "key");
      boolean bool = paramc instanceof b;
      Object localObject = null;
      if (bool)
      {
        b localb = (b)paramc;
        paramc = (g.c<E>)localObject;
        if (localb.a(parame.getKey()))
        {
          parame = localb.b(parame);
          paramc = (g.c<E>)localObject;
          if ((parame instanceof g.b)) {
            paramc = parame;
          }
        }
        return paramc;
      }
      if (e.d == paramc) {
        i.c(parame, "null cannot be cast to non-null type E of kotlin.coroutines.ContinuationInterceptor.get");
      } else {
        parame = null;
      }
      return parame;
    }
    
    public static g b(e parame, g.c<?> paramc)
    {
      i.e(paramc, "key");
      if ((paramc instanceof b))
      {
        b localb = (b)paramc;
        paramc = parame;
        if (localb.a(parame.getKey()))
        {
          paramc = parame;
          if (localb.b(parame) != null) {
            paramc = h.g;
          }
        }
        return paramc;
      }
      if (e.d == paramc) {
        parame = h.g;
      }
      return parame;
    }
  }
  
  public static final class b
    implements g.c<e>
  {}
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/i/s/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */