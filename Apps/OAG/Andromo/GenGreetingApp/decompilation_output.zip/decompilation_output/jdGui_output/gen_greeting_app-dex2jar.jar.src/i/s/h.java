package i.s;

import i.v.c.p;
import i.v.d.i;
import java.io.Serializable;

public final class h
  implements g, Serializable
{
  public static final h g = new h();
  
  public <R> R fold(R paramR, p<? super R, ? super g.b, ? extends R> paramp)
  {
    i.e(paramp, "operation");
    return paramR;
  }
  
  public <E extends g.b> E get(g.c<E> paramc)
  {
    i.e(paramc, "key");
    return null;
  }
  
  public int hashCode()
  {
    return 0;
  }
  
  public g minusKey(g.c<?> paramc)
  {
    i.e(paramc, "key");
    return this;
  }
  
  public g plus(g paramg)
  {
    i.e(paramg, "context");
    return paramg;
  }
  
  public String toString()
  {
    return "EmptyCoroutineContext";
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/i/s/h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */