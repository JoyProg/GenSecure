package k;

import java.util.Collections;
import java.util.List;

public abstract interface r
{
  public static final r a = new a();
  
  public abstract List<q> a(y paramy);
  
  public abstract void b(y paramy, List<q> paramList);
  
  public class a
    implements r
  {
    public List<q> a(y paramy)
    {
      return Collections.emptyList();
    }
    
    public void b(y paramy, List<q> paramList) {}
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/k/r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */