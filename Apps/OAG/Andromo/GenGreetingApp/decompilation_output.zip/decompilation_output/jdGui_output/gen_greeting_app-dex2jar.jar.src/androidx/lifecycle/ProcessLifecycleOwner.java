package androidx.lifecycle;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import c.k.c;
import c.k.f;
import c.k.f.a;
import c.k.j;
import c.k.k;
import c.k.s;
import c.k.s.a;

public class ProcessLifecycleOwner
  implements j
{
  public static final ProcessLifecycleOwner g = new ProcessLifecycleOwner();
  public int h = 0;
  public int i = 0;
  public boolean j = true;
  public boolean k = true;
  public Handler l;
  public final k m = new k(this);
  public Runnable n = new a();
  public s.a o = new b();
  
  public static j h()
  {
    return g;
  }
  
  public static void i(Context paramContext)
  {
    g.e(paramContext);
  }
  
  public void a()
  {
    int i1 = this.i - 1;
    this.i = i1;
    if (i1 == 0) {
      this.l.postDelayed(this.n, 700L);
    }
  }
  
  public void b()
  {
    int i1 = this.i + 1;
    this.i = i1;
    if (i1 == 1) {
      if (this.j)
      {
        this.m.i(f.a.ON_RESUME);
        this.j = false;
      }
      else
      {
        this.l.removeCallbacks(this.n);
      }
    }
  }
  
  public void c()
  {
    int i1 = this.h + 1;
    this.h = i1;
    if ((i1 == 1) && (this.k))
    {
      this.m.i(f.a.ON_START);
      this.k = false;
    }
  }
  
  public void d()
  {
    this.h -= 1;
    g();
  }
  
  public void e(Context paramContext)
  {
    this.l = new Handler();
    this.m.i(f.a.ON_CREATE);
    ((Application)paramContext.getApplicationContext()).registerActivityLifecycleCallbacks(new c());
  }
  
  public void f()
  {
    if (this.i == 0)
    {
      this.j = true;
      this.m.i(f.a.ON_PAUSE);
    }
  }
  
  public void g()
  {
    if ((this.h == 0) && (this.j))
    {
      this.m.i(f.a.ON_STOP);
      this.k = true;
    }
  }
  
  public f getLifecycle()
  {
    return this.m;
  }
  
  public class a
    implements Runnable
  {
    public a() {}
    
    public void run()
    {
      ProcessLifecycleOwner.this.f();
      ProcessLifecycleOwner.this.g();
    }
  }
  
  public class b
    implements s.a
  {
    public b() {}
    
    public void a() {}
    
    public void b()
    {
      ProcessLifecycleOwner.this.b();
    }
    
    public void c()
    {
      ProcessLifecycleOwner.this.c();
    }
  }
  
  public class c
    extends c
  {
    public c() {}
    
    public void onActivityCreated(Activity paramActivity, Bundle paramBundle)
    {
      if (Build.VERSION.SDK_INT < 29) {
        s.f(paramActivity).h(ProcessLifecycleOwner.this.o);
      }
    }
    
    public void onActivityPaused(Activity paramActivity)
    {
      ProcessLifecycleOwner.this.a();
    }
    
    public void onActivityPreCreated(Activity paramActivity, Bundle paramBundle)
    {
      paramActivity.registerActivityLifecycleCallbacks(new a());
    }
    
    public void onActivityStopped(Activity paramActivity)
    {
      ProcessLifecycleOwner.this.d();
    }
    
    public class a
      extends c
    {
      public a() {}
      
      public void onActivityPostResumed(Activity paramActivity)
      {
        ProcessLifecycleOwner.this.b();
      }
      
      public void onActivityPostStarted(Activity paramActivity)
      {
        ProcessLifecycleOwner.this.c();
      }
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/androidx/lifecycle/ProcessLifecycleOwner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */