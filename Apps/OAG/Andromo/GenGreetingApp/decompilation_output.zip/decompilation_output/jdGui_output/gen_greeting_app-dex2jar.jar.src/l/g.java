package l;

public abstract class g
  implements s
{
  public final s g;
  
  public g(s params)
  {
    if (params != null)
    {
      this.g = params;
      return;
    }
    throw new IllegalArgumentException("delegate == null");
  }
  
  public void close()
  {
    this.g.close();
  }
  
  public u f()
  {
    return this.g.f();
  }
  
  public void flush()
  {
    this.g.flush();
  }
  
  public void n(c paramc, long paramLong)
  {
    this.g.n(paramc, paramLong);
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(getClass().getSimpleName());
    localStringBuilder.append("(");
    localStringBuilder.append(this.g.toString());
    localStringBuilder.append(")");
    return localStringBuilder.toString();
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/l/g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */