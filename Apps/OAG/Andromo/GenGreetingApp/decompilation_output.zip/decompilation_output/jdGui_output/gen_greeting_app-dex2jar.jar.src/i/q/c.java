package i.q;

import i.v.d.i;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class c
  extends b
{
  public static final <T> List<T> a(T[] paramArrayOfT)
  {
    i.e(paramArrayOfT, "<this>");
    paramArrayOfT = e.a(paramArrayOfT);
    i.d(paramArrayOfT, "asList(this)");
    return paramArrayOfT;
  }
  
  public static final <T> T[] b(T[] paramArrayOfT1, T[] paramArrayOfT2, int paramInt1, int paramInt2, int paramInt3)
  {
    i.e(paramArrayOfT1, "<this>");
    i.e(paramArrayOfT2, "destination");
    System.arraycopy(paramArrayOfT1, paramInt2, paramArrayOfT2, paramInt1, paramInt3 - paramInt2);
    return paramArrayOfT2;
  }
  
  public static final <T> void d(T[] paramArrayOfT, T paramT, int paramInt1, int paramInt2)
  {
    i.e(paramArrayOfT, "<this>");
    Arrays.fill(paramArrayOfT, paramInt1, paramInt2, paramT);
  }
  
  public static final <T> void f(T[] paramArrayOfT, Comparator<? super T> paramComparator)
  {
    i.e(paramArrayOfT, "<this>");
    i.e(paramComparator, "comparator");
    if (paramArrayOfT.length > 1) {
      Arrays.sort(paramArrayOfT, paramComparator);
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AndromoApps/GenGreetingApp/dex2jar_output/gen_greeting_app-dex2jar.jar!/i/q/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */