package gnu.mapping;

import gnu.lists.Consumer;
import gnu.lists.TreeList;
import gnu.text.Printable;
import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.io.ObjectStreamException;
import java.util.Iterator;
import java.util.List;

public class Values
  extends TreeList
  implements Printable, Externalizable
{
  public static final Values empty = new Values(noArgs);
  public static final Object[] noArgs = new Object[0];
  
  public Values() {}
  
  public Values(Object[] paramArrayOfObject)
  {
    for (int i = 0; i < paramArrayOfObject.length; i++) {
      writeObject(paramArrayOfObject[i]);
    }
  }
  
  public static int countValues(Object paramObject)
  {
    if ((paramObject instanceof Values)) {}
    for (int i = ((Values)paramObject).size();; i = 1) {
      return i;
    }
  }
  
  public static Values make()
  {
    return new Values();
  }
  
  public static Object make(TreeList paramTreeList)
  {
    return make(paramTreeList, 0, paramTreeList.data.length);
  }
  
  public static Object make(TreeList paramTreeList, int paramInt1, int paramInt2)
  {
    int i;
    if (paramInt1 != paramInt2)
    {
      i = paramTreeList.nextDataIndex(paramInt1);
      if (i > 0) {}
    }
    else
    {
      paramTreeList = empty;
    }
    for (;;)
    {
      return paramTreeList;
      if ((i == paramInt2) || (paramTreeList.nextDataIndex(i) < 0))
      {
        paramTreeList = paramTreeList.getPosNext(paramInt1 << 1);
      }
      else
      {
        Values localValues = new Values();
        paramTreeList.consumeIRange(paramInt1, paramInt2, localValues);
        paramTreeList = localValues;
      }
    }
  }
  
  public static Object make(List paramList)
  {
    int i;
    if (paramList == null)
    {
      i = 0;
      if (i != 0) {
        break label26;
      }
    }
    for (paramList = empty;; paramList = paramList.get(0))
    {
      return paramList;
      i = paramList.size();
      break;
      label26:
      if (i != 1) {
        break label42;
      }
    }
    label42:
    Values localValues = new Values();
    Iterator localIterator = paramList.iterator();
    for (;;)
    {
      paramList = localValues;
      if (!localIterator.hasNext()) {
        break;
      }
      localValues.writeObject(localIterator.next());
    }
  }
  
  public static Object make(Object[] paramArrayOfObject)
  {
    if (paramArrayOfObject.length == 1) {
      paramArrayOfObject = paramArrayOfObject[0];
    }
    for (;;)
    {
      return paramArrayOfObject;
      if (paramArrayOfObject.length == 0) {
        paramArrayOfObject = empty;
      } else {
        paramArrayOfObject = new Values(paramArrayOfObject);
      }
    }
  }
  
  public static int nextIndex(Object paramObject, int paramInt)
  {
    if ((paramObject instanceof Values)) {
      paramInt = ((Values)paramObject).nextDataIndex(paramInt);
    }
    for (;;)
    {
      return paramInt;
      if (paramInt == 0) {
        paramInt = 1;
      } else {
        paramInt = -1;
      }
    }
  }
  
  public static Object nextValue(Object paramObject, int paramInt)
  {
    Object localObject = paramObject;
    if ((paramObject instanceof Values))
    {
      localObject = (Values)paramObject;
      int i = paramInt;
      if (paramInt >= ((Values)localObject).gapEnd) {
        i = paramInt - (((Values)localObject).gapEnd - ((Values)localObject).gapStart);
      }
      localObject = ((Values)paramObject).getPosNext(i << 1);
    }
    return localObject;
  }
  
  public static Object values(Object... paramVarArgs)
  {
    return make(paramVarArgs);
  }
  
  public static void writeValues(Object paramObject, Consumer paramConsumer)
  {
    if ((paramObject instanceof Values)) {
      ((Values)paramObject).consume(paramConsumer);
    }
    for (;;)
    {
      return;
      paramConsumer.writeObject(paramObject);
    }
  }
  
  public Object call_with(Procedure paramProcedure)
    throws Throwable
  {
    return paramProcedure.applyN(toArray());
  }
  
  public final Object canonicalize()
  {
    Object localObject = this;
    if (this.gapEnd == this.data.length)
    {
      if (this.gapStart != 0) {
        break label27;
      }
      localObject = empty;
    }
    for (;;)
    {
      return localObject;
      label27:
      localObject = this;
      if (nextDataIndex(0) == this.gapStart) {
        localObject = getPosNext(0);
      }
    }
  }
  
  public Object[] getValues()
  {
    if (isEmpty()) {}
    for (Object[] arrayOfObject = noArgs;; arrayOfObject = toArray()) {
      return arrayOfObject;
    }
  }
  
  public void print(Consumer paramConsumer)
  {
    if (this == empty) {
      paramConsumer.write("#!void");
    }
    int i;
    int j;
    for (;;)
    {
      return;
      i = toArray().length;
      if (1 != 0) {
        paramConsumer.write("#<values");
      }
      i = 0;
      j = nextDataIndex(i);
      if (j >= 0) {
        break;
      }
      if (1 != 0) {
        paramConsumer.write(62);
      }
    }
    paramConsumer.write(32);
    int k = i;
    if (i >= this.gapEnd) {
      k = i - (this.gapEnd - this.gapStart);
    }
    Object localObject = getPosNext(k << 1);
    if ((localObject instanceof Printable)) {
      ((Printable)localObject).print(paramConsumer);
    }
    for (;;)
    {
      i = j;
      break;
      paramConsumer.writeObject(localObject);
    }
  }
  
  public void readExternal(ObjectInput paramObjectInput)
    throws IOException, ClassNotFoundException
  {
    int i = paramObjectInput.readInt();
    for (int j = 0; j < i; j++) {
      writeObject(paramObjectInput.readObject());
    }
  }
  
  public Object readResolve()
    throws ObjectStreamException
  {
    Values localValues = this;
    if (isEmpty()) {
      localValues = empty;
    }
    return localValues;
  }
  
  public void writeExternal(ObjectOutput paramObjectOutput)
    throws IOException
  {
    Object[] arrayOfObject = toArray();
    int i = arrayOfObject.length;
    paramObjectOutput.writeInt(i);
    for (int j = 0; j < i; j++) {
      paramObjectOutput.writeObject(arrayOfObject[j]);
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AppInventorApps/MyLocationApp/dex2jar_output/MyLocationApp-dex2jar.jar!/gnu/mapping/Values.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */