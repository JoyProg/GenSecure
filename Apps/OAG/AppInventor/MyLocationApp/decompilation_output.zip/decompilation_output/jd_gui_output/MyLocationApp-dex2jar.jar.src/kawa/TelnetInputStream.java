package kawa;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;

public class TelnetInputStream
  extends FilterInputStream
{
  static final int SB_IAC = 400;
  protected byte[] buf = new byte['Ȁ'];
  Telnet connection;
  int count;
  int pos;
  int state = 0;
  int subCommandLength = 0;
  
  public TelnetInputStream(InputStream paramInputStream, Telnet paramTelnet)
    throws IOException
  {
    super(paramInputStream);
    this.connection = paramTelnet;
  }
  
  public int read()
    throws IOException
  {
    for (;;)
    {
      int i;
      int j;
      if (this.pos >= this.count)
      {
        i = this.in.available();
        if (i <= 0)
        {
          j = 1;
          label25:
          j = this.in.read(this.buf, this.subCommandLength, j);
          this.pos = this.subCommandLength;
          this.count = j;
          if (j > 0) {
            break label93;
          }
          j = -1;
        }
      }
      label93:
      byte[] arrayOfByte;
      for (;;)
      {
        return j;
        j = i;
        if (i <= this.buf.length - this.subCommandLength) {
          break label25;
        }
        j = this.buf.length - this.subCommandLength;
        break label25;
        arrayOfByte = this.buf;
        j = this.pos;
        this.pos = (j + 1);
        i = arrayOfByte[j] & 0xFF;
        if (this.state == 0)
        {
          j = i;
          if (i != 255) {
            continue;
          }
          this.state = 255;
          break;
        }
        if (this.state != 255) {
          break label259;
        }
        if (i == 255)
        {
          this.state = 0;
          j = 255;
        }
        else
        {
          if ((i == 251) || (i == 252) || (i == 253) || (i == 254) || (i == 250))
          {
            this.state = i;
            break;
          }
          if (i == 244)
          {
            System.err.println("Interrupt Process");
            this.state = 0;
            break;
          }
          if (i != 236) {
            break label251;
          }
          j = -1;
        }
      }
      label251:
      this.state = 0;
      continue;
      label259:
      if ((this.state == 251) || (this.state == 252) || (this.state == 253) || (this.state == 254))
      {
        this.connection.handle(this.state, i);
        this.state = 0;
      }
      else if (this.state == 250)
      {
        if (i == 255)
        {
          this.state = 400;
        }
        else
        {
          arrayOfByte = this.buf;
          j = this.subCommandLength;
          this.subCommandLength = (j + 1);
          arrayOfByte[j] = ((byte)(byte)i);
        }
      }
      else if (this.state == 400)
      {
        if (i == 255)
        {
          arrayOfByte = this.buf;
          j = this.subCommandLength;
          this.subCommandLength = (j + 1);
          arrayOfByte[j] = ((byte)(byte)i);
          this.state = 250;
        }
        else if (i == 240)
        {
          this.connection.subCommand(this.buf, 0, this.subCommandLength);
          this.state = 0;
          this.subCommandLength = 0;
        }
        else
        {
          this.state = 0;
          this.subCommandLength = 0;
        }
      }
      else
      {
        System.err.println("Bad state " + this.state);
      }
    }
  }
  
  public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    if (paramInt2 <= 0) {
      i = 0;
    }
    do
    {
      return i;
      i = 0;
      if (this.state == 0)
      {
        j = paramInt1;
        if (this.pos < this.count) {
          break;
        }
      }
      j = read();
      i = j;
    } while (j < 0);
    paramArrayOfByte[paramInt1] = ((byte)(byte)j);
    int i = 0 + 1;
    int j = paramInt1 + 1;
    paramInt1 = i;
    if (this.state == 0) {}
    for (;;)
    {
      paramInt1 = i;
      if (this.pos < this.count)
      {
        paramInt1 = i;
        if (i < paramInt2)
        {
          paramInt1 = this.buf[this.pos];
          if (paramInt1 != -1) {
            break label123;
          }
          paramInt1 = i;
        }
      }
      i = paramInt1;
      break;
      label123:
      paramArrayOfByte[j] = ((byte)paramInt1);
      i++;
      this.pos += 1;
      j++;
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AppInventorApps/MyLocationApp/dex2jar_output/MyLocationApp-dex2jar.jar!/kawa/TelnetInputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */