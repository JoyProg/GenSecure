package gnu.mapping;

import java.util.Map.Entry;

public abstract class NamedLocation
  extends IndirectableLocation
  implements Map.Entry, EnvironmentKey
{
  final Symbol name;
  NamedLocation next;
  final Object property;
  
  public NamedLocation(NamedLocation paramNamedLocation)
  {
    this.name = paramNamedLocation.name;
    this.property = paramNamedLocation.property;
  }
  
  public NamedLocation(Symbol paramSymbol, Object paramObject)
  {
    this.name = paramSymbol;
    this.property = paramObject;
  }
  
  public boolean entered()
  {
    if (this.next != null) {}
    for (boolean bool = true;; bool = false) {
      return bool;
    }
  }
  
  public boolean equals(Object paramObject)
  {
    boolean bool1 = false;
    boolean bool2;
    if (!(paramObject instanceof NamedLocation)) {
      bool2 = bool1;
    }
    for (;;)
    {
      return bool2;
      Object localObject = (NamedLocation)paramObject;
      if (this.name == null)
      {
        bool2 = bool1;
        if (((NamedLocation)localObject).name != null) {}
      }
      else
      {
        while (this.name.equals(((NamedLocation)localObject).name))
        {
          bool2 = bool1;
          if (this.property != ((NamedLocation)localObject).property) {
            break;
          }
          paramObject = getValue();
          localObject = ((NamedLocation)localObject).getValue();
          if (paramObject != localObject) {
            break label93;
          }
          bool2 = true;
          break;
        }
        bool2 = bool1;
        continue;
        label93:
        bool2 = bool1;
        if (paramObject != null)
        {
          bool2 = bool1;
          if (localObject != null) {
            bool2 = paramObject.equals(localObject);
          }
        }
      }
    }
  }
  
  public Environment getEnvironment()
  {
    Object localObject = this;
    Environment localEnvironment;
    if (localObject != null) {
      if (((NamedLocation)localObject).name == null)
      {
        localEnvironment = (Environment)((NamedLocation)localObject).value;
        if (localEnvironment == null) {}
      }
    }
    for (localObject = localEnvironment;; localObject = super.getEnvironment())
    {
      return (Environment)localObject;
      localObject = ((NamedLocation)localObject).next;
      break;
    }
  }
  
  public final Object getKey()
  {
    Object localObject = this;
    if (this.property == null) {
      localObject = this.name;
    }
    return localObject;
  }
  
  public final Object getKeyProperty()
  {
    return this.property;
  }
  
  public final Symbol getKeySymbol()
  {
    return this.name;
  }
  
  public int hashCode()
  {
    int i = this.name.hashCode() ^ System.identityHashCode(this.property);
    Object localObject = getValue();
    int j = i;
    if (localObject != null) {
      j = i ^ localObject.hashCode();
    }
    return j;
  }
  
  public final boolean matches(EnvironmentKey paramEnvironmentKey)
  {
    if ((Symbol.equals(paramEnvironmentKey.getKeySymbol(), this.name)) && (paramEnvironmentKey.getKeyProperty() == this.property)) {}
    for (boolean bool = true;; bool = false) {
      return bool;
    }
  }
  
  public final boolean matches(Symbol paramSymbol, Object paramObject)
  {
    if ((Symbol.equals(paramSymbol, this.name)) && (paramObject == this.property)) {}
    for (boolean bool = true;; bool = false) {
      return bool;
    }
  }
  
  public void setRestore(Object paramObject)
  {
    for (;;)
    {
      try
      {
        if (this.value == INDIRECT_FLUIDS)
        {
          this.base.setRestore(paramObject);
          return;
        }
        if ((paramObject instanceof Location))
        {
          this.value = null;
          this.base = ((Location)paramObject);
          continue;
        }
        this.value = paramObject;
      }
      finally {}
      this.base = null;
    }
  }
  
  /* Error */
  public Object setWithSave(Object paramObject)
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 47	gnu/mapping/NamedLocation:value	Ljava/lang/Object;
    //   6: getstatic 81	gnu/mapping/NamedLocation:INDIRECT_FLUIDS	Ljava/lang/Object;
    //   9: if_acmpne +16 -> 25
    //   12: aload_0
    //   13: getfield 85	gnu/mapping/NamedLocation:base	Lgnu/mapping/Location;
    //   16: aload_1
    //   17: invokevirtual 93	gnu/mapping/Location:setWithSave	(Ljava/lang/Object;)Ljava/lang/Object;
    //   20: astore_1
    //   21: aload_0
    //   22: monitorexit
    //   23: aload_1
    //   24: areturn
    //   25: aload_0
    //   26: getfield 21	gnu/mapping/NamedLocation:name	Lgnu/mapping/Symbol;
    //   29: invokestatic 99	gnu/mapping/ThreadLocation:makeAnonymous	(Lgnu/mapping/Symbol;)Lgnu/mapping/ThreadLocation;
    //   32: astore_2
    //   33: aload_2
    //   34: getfield 103	gnu/mapping/ThreadLocation:global	Lgnu/mapping/SharedLocation;
    //   37: aload_0
    //   38: getfield 85	gnu/mapping/NamedLocation:base	Lgnu/mapping/Location;
    //   41: putfield 106	gnu/mapping/SharedLocation:base	Lgnu/mapping/Location;
    //   44: aload_2
    //   45: getfield 103	gnu/mapping/ThreadLocation:global	Lgnu/mapping/SharedLocation;
    //   48: aload_0
    //   49: getfield 47	gnu/mapping/NamedLocation:value	Ljava/lang/Object;
    //   52: putfield 107	gnu/mapping/SharedLocation:value	Ljava/lang/Object;
    //   55: aload_0
    //   56: aload_2
    //   57: invokevirtual 111	gnu/mapping/NamedLocation:setAlias	(Lgnu/mapping/Location;)V
    //   60: aload_2
    //   61: invokevirtual 115	gnu/mapping/ThreadLocation:getLocation	()Lgnu/mapping/NamedLocation;
    //   64: astore_3
    //   65: aload_3
    //   66: aload_1
    //   67: putfield 47	gnu/mapping/NamedLocation:value	Ljava/lang/Object;
    //   70: aload_3
    //   71: aconst_null
    //   72: putfield 85	gnu/mapping/NamedLocation:base	Lgnu/mapping/Location;
    //   75: aload_2
    //   76: getfield 103	gnu/mapping/ThreadLocation:global	Lgnu/mapping/SharedLocation;
    //   79: astore_1
    //   80: goto -59 -> 21
    //   83: astore_1
    //   84: aload_0
    //   85: monitorexit
    //   86: aload_1
    //   87: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	88	0	this	NamedLocation
    //   0	88	1	paramObject	Object
    //   32	44	2	localThreadLocation	ThreadLocation
    //   64	7	3	localNamedLocation	NamedLocation
    // Exception table:
    //   from	to	target	type
    //   2	21	83	finally
    //   25	80	83	finally
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AppInventorApps/MyLocationApp/dex2jar_output/MyLocationApp-dex2jar.jar!/gnu/mapping/NamedLocation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */