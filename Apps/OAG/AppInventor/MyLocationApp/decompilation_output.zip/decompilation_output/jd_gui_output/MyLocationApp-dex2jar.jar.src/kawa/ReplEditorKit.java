package kawa;

import gnu.kawa.models.Paintable;
import gnu.kawa.models.Viewable;
import gnu.kawa.swingviews.SwingDisplay;
import java.awt.Component;
import javax.swing.JPanel;
import javax.swing.text.AttributeSet;
import javax.swing.text.ComponentView;
import javax.swing.text.Element;
import javax.swing.text.StyledEditorKit;
import javax.swing.text.View;
import javax.swing.text.ViewFactory;

class ReplEditorKit
  extends StyledEditorKit
{
  ViewFactory factory;
  final ReplPane pane;
  ViewFactory styledFactory;
  
  public ReplEditorKit(final ReplPane paramReplPane)
  {
    this.pane = paramReplPane;
    this.styledFactory = super.getViewFactory();
    this.factory = new ViewFactory()
    {
      public View create(Element paramAnonymousElement)
      {
        String str = paramAnonymousElement.getName();
        if (str == "Viewable") {
          paramAnonymousElement = new ComponentView(paramAnonymousElement)
          {
            protected Component createComponent()
            {
              Object localObject1 = getElement().getAttributes();
              Object localObject2 = new JPanel();
              ((Viewable)((AttributeSet)localObject1).getAttribute(ReplPane.ViewableAttribute)).makeView(SwingDisplay.getInstance(), localObject2);
              if (((JPanel)localObject2).getComponentCount() == 1)
              {
                localObject1 = ((JPanel)localObject2).getComponent(0);
                ((JPanel)localObject2).removeAll();
                localObject2 = localObject1;
              }
              for (;;)
              {
                return (Component)localObject2;
                ((JPanel)localObject2).setBackground(ReplEditorKit.1.this.val$pane.getBackground());
              }
            }
          };
        }
        for (;;)
        {
          return paramAnonymousElement;
          if (str == "Paintable") {
            paramAnonymousElement = new PaintableView(paramAnonymousElement, (Paintable)paramAnonymousElement.getAttributes().getAttribute(ReplPane.PaintableAttribute));
          } else {
            paramAnonymousElement = ReplEditorKit.this.styledFactory.create(paramAnonymousElement);
          }
        }
      }
    };
  }
  
  public ViewFactory getViewFactory()
  {
    return this.factory;
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AppInventorApps/MyLocationApp/dex2jar_output/MyLocationApp-dex2jar.jar!/kawa/ReplEditorKit.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */