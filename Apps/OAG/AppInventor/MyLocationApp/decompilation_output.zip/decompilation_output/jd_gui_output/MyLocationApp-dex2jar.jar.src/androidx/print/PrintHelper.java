package androidx.print;

import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.pdf.PdfDocument.Page;
import android.graphics.pdf.PdfDocument.PageInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.CancellationSignal.OnCancelListener;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintAttributes.Builder;
import android.print.PrintAttributes.Margins;
import android.print.PrintAttributes.MediaSize;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentAdapter.LayoutResultCallback;
import android.print.PrintDocumentAdapter.WriteResultCallback;
import android.print.PrintDocumentInfo.Builder;
import android.print.PrintManager;
import android.print.pdf.PrintedPdfDocument;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public final class PrintHelper
{
  @SuppressLint({"InlinedApi"})
  public static final int COLOR_MODE_COLOR = 2;
  @SuppressLint({"InlinedApi"})
  public static final int COLOR_MODE_MONOCHROME = 1;
  static final boolean IS_MIN_MARGINS_HANDLING_CORRECT;
  private static final String LOG_TAG = "PrintHelper";
  private static final int MAX_PRINT_SIZE = 3500;
  public static final int ORIENTATION_LANDSCAPE = 1;
  public static final int ORIENTATION_PORTRAIT = 2;
  static final boolean PRINT_ACTIVITY_RESPECTS_ORIENTATION;
  public static final int SCALE_MODE_FILL = 2;
  public static final int SCALE_MODE_FIT = 1;
  int mColorMode = 2;
  final Context mContext;
  BitmapFactory.Options mDecodeOptions = null;
  final Object mLock = new Object();
  int mOrientation = 1;
  int mScaleMode = 2;
  
  static
  {
    boolean bool1 = true;
    if ((Build.VERSION.SDK_INT < 20) || (Build.VERSION.SDK_INT > 23))
    {
      bool2 = true;
      PRINT_ACTIVITY_RESPECTS_ORIENTATION = bool2;
      if (Build.VERSION.SDK_INT == 23) {
        break label44;
      }
    }
    label44:
    for (boolean bool2 = bool1;; bool2 = false)
    {
      IS_MIN_MARGINS_HANDLING_CORRECT = bool2;
      return;
      bool2 = false;
      break;
    }
  }
  
  public PrintHelper(@NonNull Context paramContext)
  {
    this.mContext = paramContext;
  }
  
  static Bitmap convertBitmapForColorMode(Bitmap paramBitmap, int paramInt)
  {
    if (paramInt != 1) {}
    for (;;)
    {
      return paramBitmap;
      Bitmap localBitmap = Bitmap.createBitmap(paramBitmap.getWidth(), paramBitmap.getHeight(), Bitmap.Config.ARGB_8888);
      Canvas localCanvas = new Canvas(localBitmap);
      Paint localPaint = new Paint();
      ColorMatrix localColorMatrix = new ColorMatrix();
      localColorMatrix.setSaturation(0.0F);
      localPaint.setColorFilter(new ColorMatrixColorFilter(localColorMatrix));
      localCanvas.drawBitmap(paramBitmap, 0.0F, 0.0F, localPaint);
      localCanvas.setBitmap(null);
      paramBitmap = localBitmap;
    }
  }
  
  @RequiresApi(19)
  private static PrintAttributes.Builder copyAttributes(PrintAttributes paramPrintAttributes)
  {
    PrintAttributes.Builder localBuilder = new PrintAttributes.Builder().setMediaSize(paramPrintAttributes.getMediaSize()).setResolution(paramPrintAttributes.getResolution()).setMinMargins(paramPrintAttributes.getMinMargins());
    if (paramPrintAttributes.getColorMode() != 0) {
      localBuilder.setColorMode(paramPrintAttributes.getColorMode());
    }
    if ((Build.VERSION.SDK_INT >= 23) && (paramPrintAttributes.getDuplexMode() != 0)) {
      localBuilder.setDuplexMode(paramPrintAttributes.getDuplexMode());
    }
    return localBuilder;
  }
  
  static Matrix getMatrix(int paramInt1, int paramInt2, RectF paramRectF, int paramInt3)
  {
    Matrix localMatrix = new Matrix();
    float f = paramRectF.width() / paramInt1;
    if (paramInt3 == 2) {}
    for (f = Math.max(f, paramRectF.height() / paramInt2);; f = Math.min(f, paramRectF.height() / paramInt2))
    {
      localMatrix.postScale(f, f);
      localMatrix.postTranslate((paramRectF.width() - paramInt1 * f) / 2.0F, (paramRectF.height() - paramInt2 * f) / 2.0F);
      return localMatrix;
    }
  }
  
  static boolean isPortrait(Bitmap paramBitmap)
  {
    if (paramBitmap.getWidth() <= paramBitmap.getHeight()) {}
    for (boolean bool = true;; bool = false) {
      return bool;
    }
  }
  
  private Bitmap loadBitmap(Uri paramUri, BitmapFactory.Options paramOptions)
    throws FileNotFoundException
  {
    if ((paramUri == null) || (this.mContext == null)) {
      throw new IllegalArgumentException("bad argument to loadBitmap");
    }
    localUri = null;
    try
    {
      paramUri = this.mContext.getContentResolver().openInputStream(paramUri);
      localUri = paramUri;
      paramOptions = BitmapFactory.decodeStream(paramUri, null, paramOptions);
      if (paramUri != null) {}
      try
      {
        paramUri.close();
        return paramOptions;
      }
      catch (IOException paramUri)
      {
        for (;;)
        {
          Log.w("PrintHelper", "close fail ", paramUri);
        }
      }
      try
      {
        localUri.close();
        throw paramUri;
      }
      catch (IOException paramOptions)
      {
        for (;;)
        {
          Log.w("PrintHelper", "close fail ", paramOptions);
        }
      }
    }
    finally
    {
      if (localUri == null) {}
    }
  }
  
  public static boolean systemSupportsPrint()
  {
    if (Build.VERSION.SDK_INT >= 19) {}
    for (boolean bool = true;; bool = false) {
      return bool;
    }
  }
  
  public int getColorMode()
  {
    return this.mColorMode;
  }
  
  public int getOrientation()
  {
    if ((Build.VERSION.SDK_INT >= 19) && (this.mOrientation == 0)) {}
    for (int i = 1;; i = this.mOrientation) {
      return i;
    }
  }
  
  public int getScaleMode()
  {
    return this.mScaleMode;
  }
  
  Bitmap loadConstrainedBitmap(Uri arg1)
    throws FileNotFoundException
  {
    BitmapFactory.Options localOptions = null;
    if ((??? == null) || (this.mContext == null)) {
      throw new IllegalArgumentException("bad argument to getScaledBitmap");
    }
    ??? = new BitmapFactory.Options();
    ((BitmapFactory.Options)???).inJustDecodeBounds = true;
    loadBitmap(???, (BitmapFactory.Options)???);
    int i = ((BitmapFactory.Options)???).outWidth;
    int j = ((BitmapFactory.Options)???).outHeight;
    ??? = localOptions;
    if (i > 0)
    {
      if (j > 0) {
        break label72;
      }
      ??? = localOptions;
    }
    label72:
    int m;
    do
    {
      do
      {
        return (Bitmap)???;
        int k = Math.max(i, j);
        m = 1;
        while (k > 3500)
        {
          k >>>= 1;
          m <<= 1;
        }
        ??? = localOptions;
      } while (m <= 0);
      ??? = localOptions;
    } while (Math.min(i, j) / m <= 0);
    synchronized (this.mLock)
    {
      localOptions = new android/graphics/BitmapFactory$Options;
      localOptions.<init>();
      this.mDecodeOptions = localOptions;
      this.mDecodeOptions.inMutable = true;
      this.mDecodeOptions.inSampleSize = m;
      localOptions = this.mDecodeOptions;
    }
    try
    {
      ??? = loadBitmap(???, localOptions);
      synchronized (this.mLock)
      {
        this.mDecodeOptions = null;
      }
      ??? = finally;
      throw ???;
    }
    finally {}
  }
  
  public void printBitmap(@NonNull String paramString, @NonNull Bitmap paramBitmap)
  {
    printBitmap(paramString, paramBitmap, null);
  }
  
  public void printBitmap(@NonNull String paramString, @NonNull Bitmap paramBitmap, @Nullable OnPrintFinishCallback paramOnPrintFinishCallback)
  {
    if ((Build.VERSION.SDK_INT < 19) || (paramBitmap == null)) {
      return;
    }
    PrintManager localPrintManager = (PrintManager)this.mContext.getSystemService("print");
    if (isPortrait(paramBitmap)) {}
    for (Object localObject = PrintAttributes.MediaSize.UNKNOWN_PORTRAIT;; localObject = PrintAttributes.MediaSize.UNKNOWN_LANDSCAPE)
    {
      localObject = new PrintAttributes.Builder().setMediaSize((PrintAttributes.MediaSize)localObject).setColorMode(this.mColorMode).build();
      localPrintManager.print(paramString, new PrintBitmapAdapter(paramString, this.mScaleMode, paramBitmap, paramOnPrintFinishCallback), (PrintAttributes)localObject);
      break;
    }
  }
  
  public void printBitmap(@NonNull String paramString, @NonNull Uri paramUri)
    throws FileNotFoundException
  {
    printBitmap(paramString, paramUri, null);
  }
  
  public void printBitmap(@NonNull String paramString, @NonNull Uri paramUri, @Nullable OnPrintFinishCallback paramOnPrintFinishCallback)
    throws FileNotFoundException
  {
    if (Build.VERSION.SDK_INT < 19) {
      return;
    }
    paramUri = new PrintUriAdapter(paramString, paramUri, paramOnPrintFinishCallback, this.mScaleMode);
    PrintManager localPrintManager = (PrintManager)this.mContext.getSystemService("print");
    paramOnPrintFinishCallback = new PrintAttributes.Builder();
    paramOnPrintFinishCallback.setColorMode(this.mColorMode);
    if ((this.mOrientation == 1) || (this.mOrientation == 0)) {
      paramOnPrintFinishCallback.setMediaSize(PrintAttributes.MediaSize.UNKNOWN_LANDSCAPE);
    }
    for (;;)
    {
      localPrintManager.print(paramString, paramUri, paramOnPrintFinishCallback.build());
      break;
      if (this.mOrientation == 2) {
        paramOnPrintFinishCallback.setMediaSize(PrintAttributes.MediaSize.UNKNOWN_PORTRAIT);
      }
    }
  }
  
  public void setColorMode(int paramInt)
  {
    this.mColorMode = paramInt;
  }
  
  public void setOrientation(int paramInt)
  {
    this.mOrientation = paramInt;
  }
  
  public void setScaleMode(int paramInt)
  {
    this.mScaleMode = paramInt;
  }
  
  @RequiresApi(19)
  void writeBitmap(final PrintAttributes paramPrintAttributes, final int paramInt, final Bitmap paramBitmap, final ParcelFileDescriptor paramParcelFileDescriptor, final CancellationSignal paramCancellationSignal, final PrintDocumentAdapter.WriteResultCallback paramWriteResultCallback)
  {
    if (IS_MIN_MARGINS_HANDLING_CORRECT) {}
    for (final PrintAttributes localPrintAttributes = paramPrintAttributes;; localPrintAttributes = copyAttributes(paramPrintAttributes).setMinMargins(new PrintAttributes.Margins(0, 0, 0, 0)).build())
    {
      new AsyncTask()
      {
        protected Throwable doInBackground(Void... paramAnonymousVarArgs)
        {
          localParcelFileDescriptor = null;
          label16:
          do
          {
            try
            {
              if (!paramCancellationSignal.isCanceled()) {
                break label16;
              }
              paramAnonymousVarArgs = localParcelFileDescriptor;
            }
            catch (Throwable localIOException)
            {
              try
              {
                localPage = localPrintedPdfDocument1.startPage(1);
                if (!PrintHelper.IS_MIN_MARGINS_HANDLING_CORRECT) {
                  break label200;
                }
                paramAnonymousVarArgs = new android/graphics/RectF;
                paramAnonymousVarArgs.<init>(localPage.getInfo().getContentRect());
                localObject = PrintHelper.getMatrix(localBitmap.getWidth(), localBitmap.getHeight(), paramAnonymousVarArgs, paramInt);
                if (!PrintHelper.IS_MIN_MARGINS_HANDLING_CORRECT) {
                  break label297;
                }
                localPage.getCanvas().drawBitmap(localBitmap, (Matrix)localObject, null);
                localPrintedPdfDocument1.finishPage(localPage);
                boolean bool = paramCancellationSignal.isCanceled();
                if (!bool) {
                  break label324;
                }
                localPrintedPdfDocument1.close();
                paramAnonymousVarArgs = paramParcelFileDescriptor;
                if (paramAnonymousVarArgs == null) {
                  break label175;
                }
              }
              finally
              {
                try
                {
                  for (;;)
                  {
                    PrintedPdfDocument localPrintedPdfDocument1;
                    Bitmap localBitmap;
                    PdfDocument.Page localPage;
                    paramParcelFileDescriptor.close();
                    paramAnonymousVarArgs = localParcelFileDescriptor;
                    if (localBitmap == paramBitmap) {
                      continue;
                    }
                    localBitmap.recycle();
                    paramAnonymousVarArgs = localParcelFileDescriptor;
                    continue;
                    paramAnonymousVarArgs = paramAnonymousVarArgs;
                    continue;
                    PrintedPdfDocument localPrintedPdfDocument2 = new android/print/pdf/PrintedPdfDocument;
                    localPrintedPdfDocument2.<init>(PrintHelper.this.mContext, paramPrintAttributes);
                    Object localObject = localPrintedPdfDocument2.startPage(1);
                    paramAnonymousVarArgs = new android/graphics/RectF;
                    paramAnonymousVarArgs.<init>(((PdfDocument.Page)localObject).getInfo().getContentRect());
                    localPrintedPdfDocument2.finishPage((PdfDocument.Page)localObject);
                    localPrintedPdfDocument2.close();
                    continue;
                    paramAnonymousVarArgs = finally;
                    localPrintedPdfDocument1.close();
                    localParcelFileDescriptor = paramParcelFileDescriptor;
                    if (localParcelFileDescriptor == null) {
                      break label281;
                    }
                    try
                    {
                      paramParcelFileDescriptor.close();
                      if (localBitmap == paramBitmap) {
                        break label295;
                      }
                      localBitmap.recycle();
                      throw paramAnonymousVarArgs;
                      ((Matrix)localObject).postTranslate(paramAnonymousVarArgs.left, paramAnonymousVarArgs.top);
                      localPage.getCanvas().clipRect(paramAnonymousVarArgs);
                      continue;
                      paramAnonymousVarArgs = new java/io/FileOutputStream;
                      paramAnonymousVarArgs.<init>(paramParcelFileDescriptor.getFileDescriptor());
                      localPrintedPdfDocument1.writeTo(paramAnonymousVarArgs);
                      localPrintedPdfDocument1.close();
                      paramAnonymousVarArgs = paramParcelFileDescriptor;
                      if (paramAnonymousVarArgs == null) {
                        break label364;
                      }
                    }
                    catch (IOException localIOException)
                    {
                      try
                      {
                        paramParcelFileDescriptor.close();
                        paramAnonymousVarArgs = localParcelFileDescriptor;
                        if (localBitmap == paramBitmap) {
                          continue;
                        }
                        localBitmap.recycle();
                        paramAnonymousVarArgs = localParcelFileDescriptor;
                        continue;
                        localIOException = localIOException;
                      }
                      catch (IOException paramAnonymousVarArgs)
                      {
                        for (;;) {}
                      }
                    }
                  }
                }
                catch (IOException paramAnonymousVarArgs)
                {
                  for (;;) {}
                }
              }
            }
            return paramAnonymousVarArgs;
            localPrintedPdfDocument1 = new android/print/pdf/PrintedPdfDocument;
            localPrintedPdfDocument1.<init>(PrintHelper.this.mContext, localPrintAttributes);
            localBitmap = PrintHelper.convertBitmapForColorMode(paramBitmap, localPrintAttributes.getColorMode());
            bool = paramCancellationSignal.isCanceled();
            paramAnonymousVarArgs = localParcelFileDescriptor;
          } while (bool);
        }
        
        protected void onPostExecute(Throwable paramAnonymousThrowable)
        {
          if (paramCancellationSignal.isCanceled()) {
            paramWriteResultCallback.onWriteCancelled();
          }
          for (;;)
          {
            return;
            if (paramAnonymousThrowable == null)
            {
              paramWriteResultCallback.onWriteFinished(new PageRange[] { PageRange.ALL_PAGES });
            }
            else
            {
              Log.e("PrintHelper", "Error writing printed content", paramAnonymousThrowable);
              paramWriteResultCallback.onWriteFailed(null);
            }
          }
        }
      }.execute(new Void[0]);
      return;
    }
  }
  
  public static abstract interface OnPrintFinishCallback
  {
    public abstract void onFinish();
  }
  
  @RequiresApi(19)
  private class PrintBitmapAdapter
    extends PrintDocumentAdapter
  {
    private PrintAttributes mAttributes;
    private final Bitmap mBitmap;
    private final PrintHelper.OnPrintFinishCallback mCallback;
    private final int mFittingMode;
    private final String mJobName;
    
    PrintBitmapAdapter(String paramString, int paramInt, Bitmap paramBitmap, PrintHelper.OnPrintFinishCallback paramOnPrintFinishCallback)
    {
      this.mJobName = paramString;
      this.mFittingMode = paramInt;
      this.mBitmap = paramBitmap;
      this.mCallback = paramOnPrintFinishCallback;
    }
    
    public void onFinish()
    {
      if (this.mCallback != null) {
        this.mCallback.onFinish();
      }
    }
    
    public void onLayout(PrintAttributes paramPrintAttributes1, PrintAttributes paramPrintAttributes2, CancellationSignal paramCancellationSignal, PrintDocumentAdapter.LayoutResultCallback paramLayoutResultCallback, Bundle paramBundle)
    {
      boolean bool = true;
      this.mAttributes = paramPrintAttributes2;
      paramCancellationSignal = new PrintDocumentInfo.Builder(this.mJobName).setContentType(1).setPageCount(1).build();
      if (!paramPrintAttributes2.equals(paramPrintAttributes1)) {}
      for (;;)
      {
        paramLayoutResultCallback.onLayoutFinished(paramCancellationSignal, bool);
        return;
        bool = false;
      }
    }
    
    public void onWrite(PageRange[] paramArrayOfPageRange, ParcelFileDescriptor paramParcelFileDescriptor, CancellationSignal paramCancellationSignal, PrintDocumentAdapter.WriteResultCallback paramWriteResultCallback)
    {
      PrintHelper.this.writeBitmap(this.mAttributes, this.mFittingMode, this.mBitmap, paramParcelFileDescriptor, paramCancellationSignal, paramWriteResultCallback);
    }
  }
  
  @RequiresApi(19)
  private class PrintUriAdapter
    extends PrintDocumentAdapter
  {
    PrintAttributes mAttributes;
    Bitmap mBitmap;
    final PrintHelper.OnPrintFinishCallback mCallback;
    final int mFittingMode;
    final Uri mImageFile;
    final String mJobName;
    AsyncTask<Uri, Boolean, Bitmap> mLoadBitmap;
    
    PrintUriAdapter(String paramString, Uri paramUri, PrintHelper.OnPrintFinishCallback paramOnPrintFinishCallback, int paramInt)
    {
      this.mJobName = paramString;
      this.mImageFile = paramUri;
      this.mCallback = paramOnPrintFinishCallback;
      this.mFittingMode = paramInt;
      this.mBitmap = null;
    }
    
    void cancelLoad()
    {
      synchronized (PrintHelper.this.mLock)
      {
        if (PrintHelper.this.mDecodeOptions != null)
        {
          if (Build.VERSION.SDK_INT < 24) {
            PrintHelper.this.mDecodeOptions.requestCancelDecode();
          }
          PrintHelper.this.mDecodeOptions = null;
        }
        return;
      }
    }
    
    public void onFinish()
    {
      super.onFinish();
      cancelLoad();
      if (this.mLoadBitmap != null) {
        this.mLoadBitmap.cancel(true);
      }
      if (this.mCallback != null) {
        this.mCallback.onFinish();
      }
      if (this.mBitmap != null)
      {
        this.mBitmap.recycle();
        this.mBitmap = null;
      }
    }
    
    public void onLayout(final PrintAttributes paramPrintAttributes1, final PrintAttributes paramPrintAttributes2, final CancellationSignal paramCancellationSignal, final PrintDocumentAdapter.LayoutResultCallback paramLayoutResultCallback, Bundle paramBundle)
    {
      boolean bool = true;
      for (;;)
      {
        try
        {
          this.mAttributes = paramPrintAttributes2;
          if (paramCancellationSignal.isCanceled())
          {
            paramLayoutResultCallback.onLayoutCancelled();
            return;
          }
        }
        finally {}
        if (this.mBitmap != null)
        {
          paramCancellationSignal = new PrintDocumentInfo.Builder(this.mJobName).setContentType(1).setPageCount(1).build();
          if (!paramPrintAttributes2.equals(paramPrintAttributes1)) {}
          for (;;)
          {
            paramLayoutResultCallback.onLayoutFinished(paramCancellationSignal, bool);
            break;
            bool = false;
          }
        }
        this.mLoadBitmap = new AsyncTask()
        {
          protected Bitmap doInBackground(Uri... paramAnonymousVarArgs)
          {
            try
            {
              paramAnonymousVarArgs = PrintHelper.this.loadConstrainedBitmap(PrintHelper.PrintUriAdapter.this.mImageFile);
              return paramAnonymousVarArgs;
            }
            catch (FileNotFoundException paramAnonymousVarArgs)
            {
              for (;;)
              {
                paramAnonymousVarArgs = null;
              }
            }
          }
          
          protected void onCancelled(Bitmap paramAnonymousBitmap)
          {
            paramLayoutResultCallback.onLayoutCancelled();
            PrintHelper.PrintUriAdapter.this.mLoadBitmap = null;
          }
          
          protected void onPostExecute(Bitmap paramAnonymousBitmap)
          {
            super.onPostExecute(paramAnonymousBitmap);
            Object localObject = paramAnonymousBitmap;
            if (paramAnonymousBitmap != null) {
              if (PrintHelper.PRINT_ACTIVITY_RESPECTS_ORIENTATION)
              {
                localObject = paramAnonymousBitmap;
                if (PrintHelper.this.mOrientation != 0) {
                  break label98;
                }
              }
            }
            for (;;)
            {
              try
              {
                PrintAttributes.MediaSize localMediaSize = PrintHelper.PrintUriAdapter.this.mAttributes.getMediaSize();
                localObject = paramAnonymousBitmap;
                if (localMediaSize != null)
                {
                  localObject = paramAnonymousBitmap;
                  if (localMediaSize.isPortrait() != PrintHelper.isPortrait(paramAnonymousBitmap))
                  {
                    localObject = new Matrix();
                    ((Matrix)localObject).postRotate(90.0F);
                    localObject = Bitmap.createBitmap(paramAnonymousBitmap, 0, 0, paramAnonymousBitmap.getWidth(), paramAnonymousBitmap.getHeight(), (Matrix)localObject, true);
                  }
                }
                label98:
                PrintHelper.PrintUriAdapter.this.mBitmap = ((Bitmap)localObject);
                if (localObject == null) {
                  break label183;
                }
                paramAnonymousBitmap = new PrintDocumentInfo.Builder(PrintHelper.PrintUriAdapter.this.mJobName).setContentType(1).setPageCount(1).build();
                if (!paramPrintAttributes2.equals(paramPrintAttributes1))
                {
                  bool = true;
                  paramLayoutResultCallback.onLayoutFinished(paramAnonymousBitmap, bool);
                  PrintHelper.PrintUriAdapter.this.mLoadBitmap = null;
                  return;
                }
              }
              finally {}
              boolean bool = false;
              continue;
              label183:
              paramLayoutResultCallback.onLayoutFailed(null);
            }
          }
          
          protected void onPreExecute()
          {
            paramCancellationSignal.setOnCancelListener(new CancellationSignal.OnCancelListener()
            {
              public void onCancel()
              {
                PrintHelper.PrintUriAdapter.this.cancelLoad();
                PrintHelper.PrintUriAdapter.1.this.cancel(false);
              }
            });
          }
        }.execute(new Uri[0]);
      }
    }
    
    public void onWrite(PageRange[] paramArrayOfPageRange, ParcelFileDescriptor paramParcelFileDescriptor, CancellationSignal paramCancellationSignal, PrintDocumentAdapter.WriteResultCallback paramWriteResultCallback)
    {
      PrintHelper.this.writeBitmap(this.mAttributes, this.mFittingMode, this.mBitmap, paramParcelFileDescriptor, paramCancellationSignal, paramWriteResultCallback);
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AppInventorApps/MyLocationApp/dex2jar_output/MyLocationApp-dex2jar.jar!/androidx/print/PrintHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */