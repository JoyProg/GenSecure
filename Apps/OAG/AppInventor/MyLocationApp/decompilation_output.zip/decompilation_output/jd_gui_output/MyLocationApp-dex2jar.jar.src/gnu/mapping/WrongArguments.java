package gnu.mapping;

public class WrongArguments
  extends IllegalArgumentException
{
  public int number;
  Procedure proc;
  public String procname;
  public String usage;
  
  public WrongArguments(Procedure paramProcedure, int paramInt)
  {
    this.proc = paramProcedure;
    this.number = paramInt;
  }
  
  public WrongArguments(String paramString1, int paramInt, String paramString2)
  {
    this.procname = paramString1;
    this.number = paramInt;
    this.usage = paramString2;
  }
  
  public static String checkArgCount(Procedure paramProcedure, int paramInt)
  {
    int i = paramProcedure.numArgs();
    String str1 = paramProcedure.getName();
    String str2 = str1;
    if (str1 == null) {
      str2 = paramProcedure.getClass().getName();
    }
    return checkArgCount(str2, i & 0xFFF, i >> 12, paramInt);
  }
  
  public static String checkArgCount(String paramString, int paramInt1, int paramInt2, int paramInt3)
  {
    int i;
    StringBuffer localStringBuffer;
    if (paramInt3 < paramInt1)
    {
      i = 0;
      localStringBuffer = new StringBuffer(100);
      localStringBuffer.append("call to ");
      if (paramString != null) {
        break label125;
      }
      localStringBuffer.append("unnamed procedure");
      label39:
      if (i == 0) {
        break label151;
      }
      paramString = " has too many";
      label47:
      localStringBuffer.append(paramString);
      localStringBuffer.append(" arguments (");
      localStringBuffer.append(paramInt3);
      if (paramInt1 != paramInt2) {
        break label157;
      }
      localStringBuffer.append("; must be ");
      localStringBuffer.append(paramInt1);
    }
    for (;;)
    {
      localStringBuffer.append(')');
      for (paramString = localStringBuffer.toString();; paramString = null)
      {
        return paramString;
        if ((paramInt2 >= 0) && (paramInt3 > paramInt2))
        {
          i = 1;
          break;
        }
      }
      label125:
      localStringBuffer.append('\'');
      localStringBuffer.append(paramString);
      localStringBuffer.append('\'');
      break label39;
      label151:
      paramString = " has too few";
      break label47;
      label157:
      localStringBuffer.append("; min=");
      localStringBuffer.append(paramInt1);
      if (paramInt2 >= 0)
      {
        localStringBuffer.append(", max=");
        localStringBuffer.append(paramInt2);
      }
    }
  }
  
  public String getMessage()
  {
    String str;
    if (this.proc != null)
    {
      str = checkArgCount(this.proc, this.number);
      if (str == null) {}
    }
    for (;;)
    {
      return str;
      str = super.getMessage();
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AppInventorApps/MyLocationApp/dex2jar_output/MyLocationApp-dex2jar.jar!/gnu/mapping/WrongArguments.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */