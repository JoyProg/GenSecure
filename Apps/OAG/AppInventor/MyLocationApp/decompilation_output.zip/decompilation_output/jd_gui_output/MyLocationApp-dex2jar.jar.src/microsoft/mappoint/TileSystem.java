package microsoft.mappoint;

import android.graphics.Point;
import org.osmdroid.util.GeoPoint;

public final class TileSystem
{
  private static final double EarthRadius = 6378137.0D;
  private static final double MaxLatitude = 85.05112878D;
  private static final double MaxLongitude = 180.0D;
  private static final double MinLatitude = -85.05112878D;
  private static final double MinLongitude = -180.0D;
  private static int mMaxZoomLevel = 22;
  protected static int mTileSize = 256;
  
  private static double Clip(double paramDouble1, double paramDouble2, double paramDouble3)
  {
    return Math.min(Math.max(paramDouble1, paramDouble2), paramDouble3);
  }
  
  public static double GroundResolution(double paramDouble, int paramInt)
  {
    return Math.cos(Clip(paramDouble, -85.05112878D, 85.05112878D) * 3.141592653589793D / 180.0D) * 2.0D * 3.141592653589793D * 6378137.0D / MapSize(paramInt);
  }
  
  public static Point LatLongToPixelXY(double paramDouble1, double paramDouble2, int paramInt, Point paramPoint)
  {
    if (paramPoint == null) {
      paramPoint = new Point();
    }
    for (;;)
    {
      double d = Clip(paramDouble1, -85.05112878D, 85.05112878D);
      paramDouble1 = (180.0D + Clip(paramDouble2, -180.0D, 180.0D)) / 360.0D;
      paramDouble2 = Math.sin(3.141592653589793D * d / 180.0D);
      paramDouble2 = Math.log((1.0D + paramDouble2) / (1.0D - paramDouble2)) / 12.566370614359172D;
      paramInt = MapSize(paramInt);
      paramPoint.x = ((int)Clip(paramInt * paramDouble1 + 0.5D, 0.0D, paramInt - 1));
      paramPoint.y = ((int)Clip(paramInt * (0.5D - paramDouble2) + 0.5D, 0.0D, paramInt - 1));
      return paramPoint;
    }
  }
  
  public static double MapScale(double paramDouble, int paramInt1, int paramInt2)
  {
    return GroundResolution(paramDouble, paramInt1) * paramInt2 / 0.0254D;
  }
  
  public static int MapSize(int paramInt)
  {
    int i = mTileSize;
    if (paramInt < getMaximumZoomLevel()) {}
    for (;;)
    {
      return i << paramInt;
      paramInt = getMaximumZoomLevel();
    }
  }
  
  public static GeoPoint PixelXYToLatLong(int paramInt1, int paramInt2, int paramInt3, GeoPoint paramGeoPoint)
  {
    if (paramGeoPoint == null) {
      paramGeoPoint = new GeoPoint(0, 0);
    }
    for (;;)
    {
      double d1 = MapSize(paramInt3);
      double d2 = Clip(paramInt1, 0.0D, d1 - 1.0D) / d1;
      paramGeoPoint.setLatitude(90.0D - 360.0D * Math.atan(Math.exp(-(0.5D - Clip(paramInt2, 0.0D, d1 - 1.0D) / d1) * 2.0D * 3.141592653589793D)) / 3.141592653589793D);
      paramGeoPoint.setLongitude(360.0D * (d2 - 0.5D));
      return paramGeoPoint;
    }
  }
  
  public static Point PixelXYToTileXY(int paramInt1, int paramInt2, Point paramPoint)
  {
    if (paramPoint == null) {
      paramPoint = new Point();
    }
    for (;;)
    {
      paramPoint.x = (paramInt1 / mTileSize);
      paramPoint.y = (paramInt2 / mTileSize);
      return paramPoint;
    }
  }
  
  public static Point QuadKeyToTileXY(String paramString, Point paramPoint)
  {
    if (paramPoint == null) {
      paramPoint = new Point();
    }
    int i;
    int j;
    int m;
    int n;
    for (;;)
    {
      i = 0;
      j = 0;
      int k = paramString.length();
      m = k;
      if (m <= 0) {
        break;
      }
      n = 1 << m - 1;
      i1 = i;
      i2 = j;
      switch (paramString.charAt(k - m))
      {
      default: 
        throw new IllegalArgumentException("Invalid QuadKey digit sequence.");
      }
    }
    int i1 = i | n;
    int i2 = j;
    for (;;)
    {
      m--;
      i = i1;
      j = i2;
      break;
      i2 = j | n;
      i1 = i;
      continue;
      i1 = i | n;
      i2 = j | n;
    }
    paramPoint.set(i, j);
    return paramPoint;
  }
  
  public static Point TileXYToPixelXY(int paramInt1, int paramInt2, Point paramPoint)
  {
    if (paramPoint == null) {
      paramPoint = new Point();
    }
    for (;;)
    {
      paramPoint.x = (mTileSize * paramInt1);
      paramPoint.y = (mTileSize * paramInt2);
      return paramPoint;
    }
  }
  
  public static String TileXYToQuadKey(int paramInt1, int paramInt2, int paramInt3)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    while (paramInt3 > 0)
    {
      char c1 = '0';
      int i = 1 << paramInt3 - 1;
      if ((paramInt1 & i) != 0) {
        c1 = (char)49;
      }
      char c2 = c1;
      if ((paramInt2 & i) != 0)
      {
        c1 = (char)((char)(c1 + '\001') + '\001');
        c2 = c1;
      }
      localStringBuilder.append(c2);
      paramInt3--;
    }
    return localStringBuilder.toString();
  }
  
  public static int getMaximumZoomLevel()
  {
    return mMaxZoomLevel;
  }
  
  public static int getTileSize()
  {
    return mTileSize;
  }
  
  public static void setTileSize(int paramInt)
  {
    mMaxZoomLevel = 31 - (int)(Math.log(paramInt) / Math.log(2.0D)) - 1;
    mTileSize = paramInt;
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AppInventorApps/MyLocationApp/dex2jar_output/MyLocationApp-dex2jar.jar!/microsoft/mappoint/TileSystem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */