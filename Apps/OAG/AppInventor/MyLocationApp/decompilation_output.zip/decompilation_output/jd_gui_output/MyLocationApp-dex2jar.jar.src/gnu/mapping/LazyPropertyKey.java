package gnu.mapping;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class LazyPropertyKey<T>
  extends PropertyKey<T>
{
  public LazyPropertyKey(String paramString)
  {
    super(paramString);
  }
  
  public T get(PropertySet paramPropertySet, T paramT)
  {
    paramT = paramPropertySet.getProperty(this, paramT);
    Object localObject1;
    int i;
    Object localObject2;
    if ((paramT instanceof String))
    {
      localObject1 = (String)paramT;
      if (((String)localObject1).charAt(0) == '*') {}
      int j;
      for (i = 1;; i = 0)
      {
        j = ((String)localObject1).indexOf(':');
        if ((j > i) && (j < ((String)localObject1).length() - 1)) {
          break;
        }
        throw new RuntimeException("lazy property " + this + " must have the form \"ClassName:fieldName\" or \"ClassName:staticMethodName\"");
      }
      localObject2 = ((String)localObject1).substring(i, j);
      paramT = ((String)localObject1).substring(j + 1);
    }
    for (;;)
    {
      try
      {
        localObject2 = Class.forName((String)localObject2, true, paramPropertySet.getClass().getClassLoader());
        if (i == 0)
        {
          paramT = ((Class)localObject2).getField(paramT).get(null);
          paramPropertySet.setProperty(this, paramT);
          paramPropertySet = paramT;
          return paramPropertySet;
        }
        paramT = ((Class)localObject2).getDeclaredMethod(paramT, new Class[] { Object.class }).invoke(null, new Object[] { paramPropertySet });
        continue;
        paramPropertySet = "field";
      }
      catch (Throwable paramT)
      {
        localObject1 = new StringBuilder().append("lazy property ").append(this).append(" has specifier \"").append((String)localObject1).append("\" but there is no such ");
        if (i != 0) {}
      }
      for (;;)
      {
        throw new RuntimeException(paramPropertySet, paramT);
        paramPropertySet = "method";
      }
      paramPropertySet = paramT;
    }
  }
  
  public void set(PropertySet paramPropertySet, String paramString)
  {
    paramPropertySet.setProperty(this, paramString);
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AppInventorApps/MyLocationApp/dex2jar_output/MyLocationApp-dex2jar.jar!/gnu/mapping/LazyPropertyKey.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */