package androidx.versionedparcelable;

import android.os.BadParcelableException;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.NetworkOnMainThreadException;
import android.os.Parcelable;
import android.util.Size;
import android.util.SizeF;
import android.util.SparseBooleanArray;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import androidx.collection.ArraySet;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectStreamClass;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

@RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
public abstract class VersionedParcel
{
  private static final int EX_BAD_PARCELABLE = -2;
  private static final int EX_ILLEGAL_ARGUMENT = -3;
  private static final int EX_ILLEGAL_STATE = -5;
  private static final int EX_NETWORK_MAIN_THREAD = -6;
  private static final int EX_NULL_POINTER = -4;
  private static final int EX_PARCELABLE = -9;
  private static final int EX_SECURITY = -1;
  private static final int EX_UNSUPPORTED_OPERATION = -7;
  private static final String TAG = "VersionedParcel";
  private static final int TYPE_BINDER = 5;
  private static final int TYPE_PARCELABLE = 2;
  private static final int TYPE_SERIALIZABLE = 3;
  private static final int TYPE_STRING = 4;
  private static final int TYPE_VERSIONED_PARCELABLE = 1;
  
  private Exception createException(int paramInt, String paramString)
  {
    switch (paramInt)
    {
    case -8: 
    default: 
      paramString = new RuntimeException("Unknown exception code: " + paramInt + " msg " + paramString);
    }
    for (;;)
    {
      return paramString;
      paramString = (Exception)readParcelable();
      continue;
      paramString = new SecurityException(paramString);
      continue;
      paramString = new BadParcelableException(paramString);
      continue;
      paramString = new IllegalArgumentException(paramString);
      continue;
      paramString = new NullPointerException(paramString);
      continue;
      paramString = new IllegalStateException(paramString);
      continue;
      paramString = new NetworkOnMainThreadException();
      continue;
      paramString = new UnsupportedOperationException(paramString);
    }
  }
  
  private static <T extends VersionedParcelable> Class findParcelClass(T paramT)
    throws ClassNotFoundException
  {
    return findParcelClass(paramT.getClass());
  }
  
  private static Class findParcelClass(Class<? extends VersionedParcelable> paramClass)
    throws ClassNotFoundException
  {
    return Class.forName(String.format("%s.%sParcelizer", new Object[] { paramClass.getPackage().getName(), paramClass.getSimpleName() }), false, paramClass.getClassLoader());
  }
  
  @NonNull
  protected static Throwable getRootCause(@NonNull Throwable paramThrowable)
  {
    while (paramThrowable.getCause() != null) {
      paramThrowable = paramThrowable.getCause();
    }
    return paramThrowable;
  }
  
  private <T> int getType(T paramT)
  {
    int i;
    if ((paramT instanceof String)) {
      i = 4;
    }
    for (;;)
    {
      return i;
      if ((paramT instanceof Parcelable))
      {
        i = 2;
      }
      else if ((paramT instanceof VersionedParcelable))
      {
        i = 1;
      }
      else if ((paramT instanceof Serializable))
      {
        i = 3;
      }
      else
      {
        if (!(paramT instanceof IBinder)) {
          break;
        }
        i = 5;
      }
    }
    throw new IllegalArgumentException(paramT.getClass().getName() + " cannot be VersionedParcelled");
  }
  
  private <T, S extends Collection<T>> S readCollection(int paramInt, S paramS)
  {
    paramInt = readInt();
    S ?;
    if (paramInt < 0) {
      ? = null;
    }
    int j;
    int k;
    int m;
    int n;
    for (;;)
    {
      return ?;
      ? = paramS;
      if (paramInt != 0)
      {
        int i = readInt();
        if (paramInt < 0)
        {
          ? = null;
        }
        else
        {
          j = paramInt;
          k = paramInt;
          m = paramInt;
          n = paramInt;
          switch (i)
          {
          default: 
            ? = paramS;
          }
        }
      }
    }
    for (;;)
    {
      ? = paramS;
      if (j <= 0) {
        break;
      }
      paramS.add(readVersionedParcelable());
      j--;
    }
    for (;;)
    {
      ? = paramS;
      if (k <= 0) {
        break;
      }
      paramS.add(readString());
      k--;
    }
    for (;;)
    {
      ? = paramS;
      if (m <= 0) {
        break;
      }
      paramS.add(readParcelable());
      m--;
    }
    for (;;)
    {
      ? = paramS;
      if (n <= 0) {
        break;
      }
      paramS.add(readSerializable());
      n--;
    }
    for (;;)
    {
      ? = paramS;
      if (paramInt <= 0) {
        break;
      }
      paramS.add(readStrongBinder());
      paramInt--;
    }
  }
  
  private Exception readException(int paramInt, String paramString)
  {
    return createException(paramInt, paramString);
  }
  
  private int readExceptionCode()
  {
    return readInt();
  }
  
  protected static <T extends VersionedParcelable> T readFromParcel(String paramString, VersionedParcel paramVersionedParcel)
  {
    try
    {
      paramString = (VersionedParcelable)Class.forName(paramString, true, VersionedParcel.class.getClassLoader()).getDeclaredMethod("read", new Class[] { VersionedParcel.class }).invoke(null, new Object[] { paramVersionedParcel });
      return paramString;
    }
    catch (IllegalAccessException paramString)
    {
      throw new RuntimeException("VersionedParcel encountered IllegalAccessException", paramString);
    }
    catch (InvocationTargetException paramString)
    {
      if ((paramString.getCause() instanceof RuntimeException)) {
        throw ((RuntimeException)paramString.getCause());
      }
      throw new RuntimeException("VersionedParcel encountered InvocationTargetException", paramString);
    }
    catch (NoSuchMethodException paramString)
    {
      throw new RuntimeException("VersionedParcel encountered NoSuchMethodException", paramString);
    }
    catch (ClassNotFoundException paramString)
    {
      throw new RuntimeException("VersionedParcel encountered ClassNotFoundException", paramString);
    }
  }
  
  private <T> void writeCollection(Collection<T> paramCollection, int paramInt)
  {
    setOutputField(paramInt);
    if (paramCollection == null) {
      writeInt(-1);
    }
    for (;;)
    {
      return;
      paramInt = paramCollection.size();
      writeInt(paramInt);
      if (paramInt > 0)
      {
        paramInt = getType(paramCollection.iterator().next());
        writeInt(paramInt);
        switch (paramInt)
        {
        default: 
          break;
        case 1: 
          paramCollection = paramCollection.iterator();
          while (paramCollection.hasNext()) {
            writeVersionedParcelable((VersionedParcelable)paramCollection.next());
          }
        case 4: 
          paramCollection = paramCollection.iterator();
          while (paramCollection.hasNext()) {
            writeString((String)paramCollection.next());
          }
        case 2: 
          paramCollection = paramCollection.iterator();
          while (paramCollection.hasNext()) {
            writeParcelable((Parcelable)paramCollection.next());
          }
        case 3: 
          paramCollection = paramCollection.iterator();
          while (paramCollection.hasNext()) {
            writeSerializable((Serializable)paramCollection.next());
          }
        case 5: 
          paramCollection = paramCollection.iterator();
          while (paramCollection.hasNext()) {
            writeStrongBinder((IBinder)paramCollection.next());
          }
        }
      }
    }
  }
  
  private void writeSerializable(Serializable paramSerializable)
  {
    if (paramSerializable == null) {
      writeString(null);
    }
    for (;;)
    {
      return;
      String str = paramSerializable.getClass().getName();
      writeString(str);
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
      try
      {
        ObjectOutputStream localObjectOutputStream = new java/io/ObjectOutputStream;
        localObjectOutputStream.<init>(localByteArrayOutputStream);
        localObjectOutputStream.writeObject(paramSerializable);
        localObjectOutputStream.close();
        writeByteArray(localByteArrayOutputStream.toByteArray());
      }
      catch (IOException paramSerializable)
      {
        throw new RuntimeException("VersionedParcelable encountered IOException writing serializable object (name = " + str + ")", paramSerializable);
      }
    }
  }
  
  protected static <T extends VersionedParcelable> void writeToParcel(T paramT, VersionedParcel paramVersionedParcel)
  {
    try
    {
      findParcelClass(paramT).getDeclaredMethod("write", new Class[] { paramT.getClass(), VersionedParcel.class }).invoke(null, new Object[] { paramT, paramVersionedParcel });
      return;
    }
    catch (IllegalAccessException paramT)
    {
      throw new RuntimeException("VersionedParcel encountered IllegalAccessException", paramT);
    }
    catch (InvocationTargetException paramT)
    {
      if ((paramT.getCause() instanceof RuntimeException)) {
        throw ((RuntimeException)paramT.getCause());
      }
      throw new RuntimeException("VersionedParcel encountered InvocationTargetException", paramT);
    }
    catch (NoSuchMethodException paramT)
    {
      throw new RuntimeException("VersionedParcel encountered NoSuchMethodException", paramT);
    }
    catch (ClassNotFoundException paramT)
    {
      throw new RuntimeException("VersionedParcel encountered ClassNotFoundException", paramT);
    }
  }
  
  private void writeVersionedParcelableCreator(VersionedParcelable paramVersionedParcelable)
  {
    try
    {
      Class localClass = findParcelClass(paramVersionedParcelable.getClass());
      writeString(localClass.getName());
      return;
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      throw new RuntimeException(paramVersionedParcelable.getClass().getSimpleName() + " does not have a Parcelizer", localClassNotFoundException);
    }
  }
  
  protected abstract void closeField();
  
  protected abstract VersionedParcel createSubParcel();
  
  public boolean isStream()
  {
    return false;
  }
  
  protected <T> T[] readArray(T[] paramArrayOfT)
  {
    Object localObject = null;
    int i = readInt();
    if (i < 0) {}
    ArrayList localArrayList;
    int j;
    do
    {
      return (T[])localObject;
      localArrayList = new ArrayList(i);
      if (i == 0) {
        break;
      }
      j = readInt();
    } while (i < 0);
    int k = i;
    int m = i;
    int n = i;
    int i1 = i;
    switch (j)
    {
    }
    for (;;)
    {
      localObject = localArrayList.toArray(paramArrayOfT);
      break;
      while (k > 0)
      {
        localArrayList.add(readString());
        k--;
      }
      while (m > 0)
      {
        localArrayList.add(readParcelable());
        m--;
      }
      while (n > 0)
      {
        localArrayList.add(readVersionedParcelable());
        n--;
      }
      while (i1 > 0)
      {
        localArrayList.add(readSerializable());
        i1--;
      }
      while (i > 0)
      {
        localArrayList.add(readStrongBinder());
        i--;
      }
    }
  }
  
  public <T> T[] readArray(T[] paramArrayOfT, int paramInt)
  {
    if (!readField(paramInt)) {}
    for (;;)
    {
      return paramArrayOfT;
      paramArrayOfT = readArray(paramArrayOfT);
    }
  }
  
  protected abstract boolean readBoolean();
  
  public boolean readBoolean(boolean paramBoolean, int paramInt)
  {
    if (!readField(paramInt)) {}
    for (;;)
    {
      return paramBoolean;
      paramBoolean = readBoolean();
    }
  }
  
  protected boolean[] readBooleanArray()
  {
    int i = readInt();
    Object localObject;
    if (i < 0) {
      localObject = null;
    }
    boolean[] arrayOfBoolean;
    int j;
    do
    {
      return (boolean[])localObject;
      arrayOfBoolean = new boolean[i];
      j = 0;
      localObject = arrayOfBoolean;
    } while (j >= i);
    if (readInt() != 0) {}
    for (int k = 1;; k = 0)
    {
      arrayOfBoolean[j] = k;
      j++;
      break;
    }
  }
  
  public boolean[] readBooleanArray(boolean[] paramArrayOfBoolean, int paramInt)
  {
    if (!readField(paramInt)) {}
    for (;;)
    {
      return paramArrayOfBoolean;
      paramArrayOfBoolean = readBooleanArray();
    }
  }
  
  protected abstract Bundle readBundle();
  
  public Bundle readBundle(Bundle paramBundle, int paramInt)
  {
    if (!readField(paramInt)) {}
    for (;;)
    {
      return paramBundle;
      paramBundle = readBundle();
    }
  }
  
  public byte readByte(byte paramByte, int paramInt)
  {
    if (!readField(paramInt)) {}
    for (byte b = paramByte;; b = paramByte)
    {
      return b;
      paramByte = (byte)(readInt() & 0xFF);
    }
  }
  
  protected abstract byte[] readByteArray();
  
  public byte[] readByteArray(byte[] paramArrayOfByte, int paramInt)
  {
    if (!readField(paramInt)) {}
    for (;;)
    {
      return paramArrayOfByte;
      paramArrayOfByte = readByteArray();
    }
  }
  
  public char[] readCharArray(char[] paramArrayOfChar, int paramInt)
  {
    if (!readField(paramInt)) {}
    for (;;)
    {
      return paramArrayOfChar;
      int i = readInt();
      if (i < 0)
      {
        paramArrayOfChar = null;
      }
      else
      {
        paramArrayOfChar = new char[i];
        for (paramInt = 0; paramInt < i; paramInt++) {
          paramArrayOfChar[paramInt] = ((char)(char)readInt());
        }
      }
    }
  }
  
  protected abstract double readDouble();
  
  public double readDouble(double paramDouble, int paramInt)
  {
    if (!readField(paramInt)) {}
    for (;;)
    {
      return paramDouble;
      paramDouble = readDouble();
    }
  }
  
  protected double[] readDoubleArray()
  {
    int i = readInt();
    Object localObject;
    if (i < 0)
    {
      localObject = null;
      return (double[])localObject;
    }
    double[] arrayOfDouble = new double[i];
    for (int j = 0;; j++)
    {
      localObject = arrayOfDouble;
      if (j >= i) {
        break;
      }
      arrayOfDouble[j] = readDouble();
    }
  }
  
  public double[] readDoubleArray(double[] paramArrayOfDouble, int paramInt)
  {
    if (!readField(paramInt)) {}
    for (;;)
    {
      return paramArrayOfDouble;
      paramArrayOfDouble = readDoubleArray();
    }
  }
  
  public Exception readException(Exception paramException, int paramInt)
  {
    if (!readField(paramInt)) {}
    for (;;)
    {
      return paramException;
      paramInt = readExceptionCode();
      if (paramInt != 0) {
        paramException = readException(paramInt, readString());
      }
    }
  }
  
  protected abstract boolean readField(int paramInt);
  
  protected abstract float readFloat();
  
  public float readFloat(float paramFloat, int paramInt)
  {
    if (!readField(paramInt)) {}
    for (;;)
    {
      return paramFloat;
      paramFloat = readFloat();
    }
  }
  
  protected float[] readFloatArray()
  {
    int i = readInt();
    Object localObject;
    if (i < 0)
    {
      localObject = null;
      return (float[])localObject;
    }
    float[] arrayOfFloat = new float[i];
    for (int j = 0;; j++)
    {
      localObject = arrayOfFloat;
      if (j >= i) {
        break;
      }
      arrayOfFloat[j] = readFloat();
    }
  }
  
  public float[] readFloatArray(float[] paramArrayOfFloat, int paramInt)
  {
    if (!readField(paramInt)) {}
    for (;;)
    {
      return paramArrayOfFloat;
      paramArrayOfFloat = readFloatArray();
    }
  }
  
  protected abstract int readInt();
  
  public int readInt(int paramInt1, int paramInt2)
  {
    if (!readField(paramInt2)) {}
    for (;;)
    {
      return paramInt1;
      paramInt1 = readInt();
    }
  }
  
  protected int[] readIntArray()
  {
    int i = readInt();
    Object localObject;
    if (i < 0)
    {
      localObject = null;
      return (int[])localObject;
    }
    int[] arrayOfInt = new int[i];
    for (int j = 0;; j++)
    {
      localObject = arrayOfInt;
      if (j >= i) {
        break;
      }
      arrayOfInt[j] = readInt();
    }
  }
  
  public int[] readIntArray(int[] paramArrayOfInt, int paramInt)
  {
    if (!readField(paramInt)) {}
    for (;;)
    {
      return paramArrayOfInt;
      paramArrayOfInt = readIntArray();
    }
  }
  
  public <T> List<T> readList(List<T> paramList, int paramInt)
  {
    if (!readField(paramInt)) {}
    for (;;)
    {
      return paramList;
      paramList = (List)readCollection(paramInt, new ArrayList());
    }
  }
  
  protected abstract long readLong();
  
  public long readLong(long paramLong, int paramInt)
  {
    if (!readField(paramInt)) {}
    for (;;)
    {
      return paramLong;
      paramLong = readLong();
    }
  }
  
  protected long[] readLongArray()
  {
    int i = readInt();
    Object localObject;
    if (i < 0)
    {
      localObject = null;
      return (long[])localObject;
    }
    long[] arrayOfLong = new long[i];
    for (int j = 0;; j++)
    {
      localObject = arrayOfLong;
      if (j >= i) {
        break;
      }
      arrayOfLong[j] = readLong();
    }
  }
  
  public long[] readLongArray(long[] paramArrayOfLong, int paramInt)
  {
    if (!readField(paramInt)) {}
    for (;;)
    {
      return paramArrayOfLong;
      paramArrayOfLong = readLongArray();
    }
  }
  
  protected abstract <T extends Parcelable> T readParcelable();
  
  public <T extends Parcelable> T readParcelable(T paramT, int paramInt)
  {
    if (!readField(paramInt)) {}
    for (;;)
    {
      return paramT;
      paramT = readParcelable();
    }
  }
  
  protected Serializable readSerializable()
  {
    String str = readString();
    Object localObject;
    if (str == null) {
      localObject = null;
    }
    for (;;)
    {
      return (Serializable)localObject;
      localObject = new ByteArrayInputStream(readByteArray());
      try
      {
        ObjectInputStream local1 = new androidx/versionedparcelable/VersionedParcel$1;
        local1.<init>(this, (InputStream)localObject);
        localObject = (Serializable)local1.readObject();
      }
      catch (IOException localIOException)
      {
        throw new RuntimeException("VersionedParcelable encountered IOException reading a Serializable object (name = " + str + ")", localIOException);
      }
      catch (ClassNotFoundException localClassNotFoundException)
      {
        throw new RuntimeException("VersionedParcelable encountered ClassNotFoundException reading a Serializable object (name = " + str + ")", localClassNotFoundException);
      }
    }
  }
  
  public <T> Set<T> readSet(Set<T> paramSet, int paramInt)
  {
    if (!readField(paramInt)) {}
    for (;;)
    {
      return paramSet;
      paramSet = (Set)readCollection(paramInt, new ArraySet());
    }
  }
  
  @RequiresApi(api=21)
  public Size readSize(Size paramSize, int paramInt)
  {
    if (!readField(paramInt)) {}
    for (;;)
    {
      return paramSize;
      if (readBoolean()) {
        paramSize = new Size(readInt(), readInt());
      } else {
        paramSize = null;
      }
    }
  }
  
  @RequiresApi(api=21)
  public SizeF readSizeF(SizeF paramSizeF, int paramInt)
  {
    if (!readField(paramInt)) {}
    for (;;)
    {
      return paramSizeF;
      if (readBoolean()) {
        paramSizeF = new SizeF(readFloat(), readFloat());
      } else {
        paramSizeF = null;
      }
    }
  }
  
  public SparseBooleanArray readSparseBooleanArray(SparseBooleanArray paramSparseBooleanArray, int paramInt)
  {
    if (!readField(paramInt)) {}
    for (;;)
    {
      return paramSparseBooleanArray;
      int i = readInt();
      if (i < 0)
      {
        paramSparseBooleanArray = null;
      }
      else
      {
        paramSparseBooleanArray = new SparseBooleanArray(i);
        for (paramInt = 0; paramInt < i; paramInt++) {
          paramSparseBooleanArray.put(readInt(), readBoolean());
        }
      }
    }
  }
  
  protected abstract String readString();
  
  public String readString(String paramString, int paramInt)
  {
    if (!readField(paramInt)) {}
    for (;;)
    {
      return paramString;
      paramString = readString();
    }
  }
  
  protected abstract IBinder readStrongBinder();
  
  public IBinder readStrongBinder(IBinder paramIBinder, int paramInt)
  {
    if (!readField(paramInt)) {}
    for (;;)
    {
      return paramIBinder;
      paramIBinder = readStrongBinder();
    }
  }
  
  protected <T extends VersionedParcelable> T readVersionedParcelable()
  {
    Object localObject = readString();
    if (localObject == null) {}
    for (localObject = null;; localObject = readFromParcel((String)localObject, createSubParcel())) {
      return (T)localObject;
    }
  }
  
  public <T extends VersionedParcelable> T readVersionedParcelable(T paramT, int paramInt)
  {
    if (!readField(paramInt)) {}
    for (;;)
    {
      return paramT;
      paramT = readVersionedParcelable();
    }
  }
  
  protected abstract void setOutputField(int paramInt);
  
  public void setSerializationFlags(boolean paramBoolean1, boolean paramBoolean2) {}
  
  protected <T> void writeArray(T[] paramArrayOfT)
  {
    if (paramArrayOfT == null) {
      writeInt(-1);
    }
    for (;;)
    {
      return;
      int i = paramArrayOfT.length;
      int j = 0;
      int k = 0;
      int m = 0;
      int n = 0;
      int i1 = 0;
      writeInt(i);
      if (i > 0)
      {
        int i2 = getType(paramArrayOfT[0]);
        writeInt(i2);
        switch (i2)
        {
        default: 
          break;
        case 1: 
          while (i1 < i)
          {
            writeVersionedParcelable((VersionedParcelable)paramArrayOfT[i1]);
            i1++;
          }
        case 4: 
          while (j < i)
          {
            writeString((String)paramArrayOfT[j]);
            j++;
          }
        case 2: 
          while (k < i)
          {
            writeParcelable((Parcelable)paramArrayOfT[k]);
            k++;
          }
        case 3: 
          while (m < i)
          {
            writeSerializable((Serializable)paramArrayOfT[m]);
            m++;
          }
        case 5: 
          while (n < i)
          {
            writeStrongBinder((IBinder)paramArrayOfT[n]);
            n++;
          }
        }
      }
    }
  }
  
  public <T> void writeArray(T[] paramArrayOfT, int paramInt)
  {
    setOutputField(paramInt);
    writeArray(paramArrayOfT);
  }
  
  protected abstract void writeBoolean(boolean paramBoolean);
  
  public void writeBoolean(boolean paramBoolean, int paramInt)
  {
    setOutputField(paramInt);
    writeBoolean(paramBoolean);
  }
  
  protected void writeBooleanArray(boolean[] paramArrayOfBoolean)
  {
    if (paramArrayOfBoolean != null)
    {
      int i = paramArrayOfBoolean.length;
      writeInt(i);
      int j = 0;
      if (j < i)
      {
        if (paramArrayOfBoolean[j] != 0) {}
        for (int k = 1;; k = 0)
        {
          writeInt(k);
          j++;
          break;
        }
      }
    }
    else
    {
      writeInt(-1);
    }
  }
  
  public void writeBooleanArray(boolean[] paramArrayOfBoolean, int paramInt)
  {
    setOutputField(paramInt);
    writeBooleanArray(paramArrayOfBoolean);
  }
  
  protected abstract void writeBundle(Bundle paramBundle);
  
  public void writeBundle(Bundle paramBundle, int paramInt)
  {
    setOutputField(paramInt);
    writeBundle(paramBundle);
  }
  
  public void writeByte(byte paramByte, int paramInt)
  {
    setOutputField(paramInt);
    writeInt(paramByte);
  }
  
  protected abstract void writeByteArray(byte[] paramArrayOfByte);
  
  public void writeByteArray(byte[] paramArrayOfByte, int paramInt)
  {
    setOutputField(paramInt);
    writeByteArray(paramArrayOfByte);
  }
  
  protected abstract void writeByteArray(byte[] paramArrayOfByte, int paramInt1, int paramInt2);
  
  public void writeByteArray(byte[] paramArrayOfByte, int paramInt1, int paramInt2, int paramInt3)
  {
    setOutputField(paramInt3);
    writeByteArray(paramArrayOfByte, paramInt1, paramInt2);
  }
  
  public void writeCharArray(char[] paramArrayOfChar, int paramInt)
  {
    setOutputField(paramInt);
    if (paramArrayOfChar != null)
    {
      int i = paramArrayOfChar.length;
      writeInt(i);
      for (paramInt = 0; paramInt < i; paramInt++) {
        writeInt(paramArrayOfChar[paramInt]);
      }
    }
    writeInt(-1);
  }
  
  protected abstract void writeDouble(double paramDouble);
  
  public void writeDouble(double paramDouble, int paramInt)
  {
    setOutputField(paramInt);
    writeDouble(paramDouble);
  }
  
  protected void writeDoubleArray(double[] paramArrayOfDouble)
  {
    if (paramArrayOfDouble != null)
    {
      int i = paramArrayOfDouble.length;
      writeInt(i);
      for (int j = 0; j < i; j++) {
        writeDouble(paramArrayOfDouble[j]);
      }
    }
    writeInt(-1);
  }
  
  public void writeDoubleArray(double[] paramArrayOfDouble, int paramInt)
  {
    setOutputField(paramInt);
    writeDoubleArray(paramArrayOfDouble);
  }
  
  public void writeException(Exception paramException, int paramInt)
  {
    setOutputField(paramInt);
    if (paramException == null) {
      writeNoException();
    }
    for (;;)
    {
      return;
      paramInt = 0;
      if (((paramException instanceof Parcelable)) && (paramException.getClass().getClassLoader() == Parcelable.class.getClassLoader())) {
        paramInt = -9;
      }
      for (;;)
      {
        writeInt(paramInt);
        if (paramInt != 0) {
          break label161;
        }
        if (!(paramException instanceof RuntimeException)) {
          break;
        }
        throw ((RuntimeException)paramException);
        if ((paramException instanceof SecurityException)) {
          paramInt = -1;
        } else if ((paramException instanceof BadParcelableException)) {
          paramInt = -2;
        } else if ((paramException instanceof IllegalArgumentException)) {
          paramInt = -3;
        } else if ((paramException instanceof NullPointerException)) {
          paramInt = -4;
        } else if ((paramException instanceof IllegalStateException)) {
          paramInt = -5;
        } else if ((paramException instanceof NetworkOnMainThreadException)) {
          paramInt = -6;
        } else if ((paramException instanceof UnsupportedOperationException)) {
          paramInt = -7;
        }
      }
      throw new RuntimeException(paramException);
      label161:
      writeString(paramException.getMessage());
      switch (paramInt)
      {
      default: 
        break;
      case -9: 
        writeParcelable((Parcelable)paramException);
      }
    }
  }
  
  protected abstract void writeFloat(float paramFloat);
  
  public void writeFloat(float paramFloat, int paramInt)
  {
    setOutputField(paramInt);
    writeFloat(paramFloat);
  }
  
  protected void writeFloatArray(float[] paramArrayOfFloat)
  {
    if (paramArrayOfFloat != null)
    {
      int i = paramArrayOfFloat.length;
      writeInt(i);
      for (int j = 0; j < i; j++) {
        writeFloat(paramArrayOfFloat[j]);
      }
    }
    writeInt(-1);
  }
  
  public void writeFloatArray(float[] paramArrayOfFloat, int paramInt)
  {
    setOutputField(paramInt);
    writeFloatArray(paramArrayOfFloat);
  }
  
  protected abstract void writeInt(int paramInt);
  
  public void writeInt(int paramInt1, int paramInt2)
  {
    setOutputField(paramInt2);
    writeInt(paramInt1);
  }
  
  protected void writeIntArray(int[] paramArrayOfInt)
  {
    if (paramArrayOfInt != null)
    {
      int i = paramArrayOfInt.length;
      writeInt(i);
      for (int j = 0; j < i; j++) {
        writeInt(paramArrayOfInt[j]);
      }
    }
    writeInt(-1);
  }
  
  public void writeIntArray(int[] paramArrayOfInt, int paramInt)
  {
    setOutputField(paramInt);
    writeIntArray(paramArrayOfInt);
  }
  
  public <T> void writeList(List<T> paramList, int paramInt)
  {
    writeCollection(paramList, paramInt);
  }
  
  protected abstract void writeLong(long paramLong);
  
  public void writeLong(long paramLong, int paramInt)
  {
    setOutputField(paramInt);
    writeLong(paramLong);
  }
  
  protected void writeLongArray(long[] paramArrayOfLong)
  {
    if (paramArrayOfLong != null)
    {
      int i = paramArrayOfLong.length;
      writeInt(i);
      for (int j = 0; j < i; j++) {
        writeLong(paramArrayOfLong[j]);
      }
    }
    writeInt(-1);
  }
  
  public void writeLongArray(long[] paramArrayOfLong, int paramInt)
  {
    setOutputField(paramInt);
    writeLongArray(paramArrayOfLong);
  }
  
  protected void writeNoException()
  {
    writeInt(0);
  }
  
  protected abstract void writeParcelable(Parcelable paramParcelable);
  
  public void writeParcelable(Parcelable paramParcelable, int paramInt)
  {
    setOutputField(paramInt);
    writeParcelable(paramParcelable);
  }
  
  public void writeSerializable(Serializable paramSerializable, int paramInt)
  {
    setOutputField(paramInt);
    writeSerializable(paramSerializable);
  }
  
  public <T> void writeSet(Set<T> paramSet, int paramInt)
  {
    writeCollection(paramSet, paramInt);
  }
  
  @RequiresApi(api=21)
  public void writeSize(Size paramSize, int paramInt)
  {
    setOutputField(paramInt);
    if (paramSize != null) {}
    for (boolean bool = true;; bool = false)
    {
      writeBoolean(bool);
      if (paramSize != null)
      {
        writeInt(paramSize.getWidth());
        writeInt(paramSize.getHeight());
      }
      return;
    }
  }
  
  @RequiresApi(api=21)
  public void writeSizeF(SizeF paramSizeF, int paramInt)
  {
    setOutputField(paramInt);
    if (paramSizeF != null) {}
    for (boolean bool = true;; bool = false)
    {
      writeBoolean(bool);
      if (paramSizeF != null)
      {
        writeFloat(paramSizeF.getWidth());
        writeFloat(paramSizeF.getHeight());
      }
      return;
    }
  }
  
  public void writeSparseBooleanArray(SparseBooleanArray paramSparseBooleanArray, int paramInt)
  {
    setOutputField(paramInt);
    if (paramSparseBooleanArray == null) {
      writeInt(-1);
    }
    for (;;)
    {
      return;
      int i = paramSparseBooleanArray.size();
      writeInt(i);
      for (paramInt = 0; paramInt < i; paramInt++)
      {
        writeInt(paramSparseBooleanArray.keyAt(paramInt));
        writeBoolean(paramSparseBooleanArray.valueAt(paramInt));
      }
    }
  }
  
  protected abstract void writeString(String paramString);
  
  public void writeString(String paramString, int paramInt)
  {
    setOutputField(paramInt);
    writeString(paramString);
  }
  
  protected abstract void writeStrongBinder(IBinder paramIBinder);
  
  public void writeStrongBinder(IBinder paramIBinder, int paramInt)
  {
    setOutputField(paramInt);
    writeStrongBinder(paramIBinder);
  }
  
  protected abstract void writeStrongInterface(IInterface paramIInterface);
  
  public void writeStrongInterface(IInterface paramIInterface, int paramInt)
  {
    setOutputField(paramInt);
    writeStrongInterface(paramIInterface);
  }
  
  protected void writeVersionedParcelable(VersionedParcelable paramVersionedParcelable)
  {
    if (paramVersionedParcelable == null) {
      writeString(null);
    }
    for (;;)
    {
      return;
      writeVersionedParcelableCreator(paramVersionedParcelable);
      VersionedParcel localVersionedParcel = createSubParcel();
      writeToParcel(paramVersionedParcelable, localVersionedParcel);
      localVersionedParcel.closeField();
    }
  }
  
  public void writeVersionedParcelable(VersionedParcelable paramVersionedParcelable, int paramInt)
  {
    setOutputField(paramInt);
    writeVersionedParcelable(paramVersionedParcelable);
  }
  
  public static class ParcelException
    extends RuntimeException
  {
    public ParcelException(Throwable paramThrowable)
    {
      super();
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AppInventorApps/MyLocationApp/dex2jar_output/MyLocationApp-dex2jar.jar!/androidx/versionedparcelable/VersionedParcel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */