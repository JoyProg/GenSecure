package gnu.mapping;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.io.ObjectStreamException;

public class Symbol
  implements EnvironmentKey, Comparable, Externalizable
{
  public static final Symbol FUNCTION = makeUninterned("(function)");
  public static final Symbol PLIST = makeUninterned("(property-list)");
  protected String name;
  Namespace namespace;
  
  public Symbol() {}
  
  public Symbol(Namespace paramNamespace, String paramString)
  {
    this.name = paramString;
    this.namespace = paramNamespace;
  }
  
  public static boolean equals(Symbol paramSymbol1, Symbol paramSymbol2)
  {
    boolean bool = true;
    if (paramSymbol1 == paramSymbol2) {}
    for (;;)
    {
      return bool;
      if ((paramSymbol1 == null) || (paramSymbol2 == null))
      {
        bool = false;
      }
      else
      {
        if (paramSymbol1.name == paramSymbol2.name)
        {
          paramSymbol1 = paramSymbol1.namespace;
          paramSymbol2 = paramSymbol2.namespace;
          if ((paramSymbol1 != null) && (paramSymbol2 != null))
          {
            if (paramSymbol1.name == paramSymbol2.name) {
              continue;
            }
            bool = false;
            continue;
          }
        }
        bool = false;
      }
    }
  }
  
  public static Symbol make(Object paramObject, String paramString)
  {
    if ((paramObject instanceof String))
    {
      paramObject = Namespace.valueOf((String)paramObject);
      if ((paramObject != null) && (paramString != null)) {
        break label38;
      }
    }
    label38:
    for (paramObject = makeUninterned(paramString);; paramObject = ((Namespace)paramObject).getSymbol(paramString.intern()))
    {
      return (Symbol)paramObject;
      paramObject = (Namespace)paramObject;
      break;
    }
  }
  
  public static Symbol make(String paramString1, String paramString2, String paramString3)
  {
    return Namespace.valueOf(paramString1, paramString3).getSymbol(paramString2.intern());
  }
  
  public static Symbol makeUninterned(String paramString)
  {
    return new Symbol(null, paramString);
  }
  
  public static Symbol makeWithUnknownNamespace(String paramString1, String paramString2)
  {
    return Namespace.makeUnknownNamespace(paramString2).getSymbol(paramString1.intern());
  }
  
  public static Symbol parse(String paramString)
  {
    int i = paramString.length();
    int j = -1;
    int k = -1;
    int m = 0;
    int n = 0;
    int i1 = 0;
    int i2 = 0;
    int i3 = j;
    int i4 = n;
    int i5 = i1;
    int i6 = k;
    label77:
    String str2;
    if (i2 < i)
    {
      i6 = paramString.charAt(i2);
      if ((i6 == 58) && (m == 0))
      {
        i5 = i2;
        i4 = i2 + 1;
        i6 = k;
        i3 = j;
      }
    }
    else
    {
      if ((i3 < 0) || (i6 <= 0)) {
        break label279;
      }
      String str1 = paramString.substring(i3 + 1, i6);
      if (i5 <= 0) {
        break label273;
      }
      str2 = paramString.substring(0, i5);
      label113:
      paramString = valueOf(paramString.substring(i4), str1, str2);
    }
    for (;;)
    {
      return paramString;
      i3 = m;
      i4 = j;
      i5 = i1;
      if (i6 == 123)
      {
        i4 = j;
        i5 = i1;
        if (j < 0)
        {
          i5 = i2;
          i4 = i2;
        }
        i3 = m + 1;
      }
      m = i3;
      if (i6 == 125)
      {
        j = i3 - 1;
        if (j == 0)
        {
          i6 = i2;
          if ((i2 < i) && (paramString.charAt(i2 + 1) == ':')) {
            i2 += 2;
          }
          for (;;)
          {
            i3 = i4;
            i4 = i2;
            break;
            i2++;
          }
        }
        m = j;
        if (j < 0)
        {
          i2 = i5;
          i3 = i4;
          i4 = i2;
          i6 = k;
          break label77;
        }
      }
      i2++;
      j = i4;
      i1 = i5;
      break;
      label273:
      str2 = null;
      break label113;
      label279:
      if (i5 > 0) {
        paramString = makeWithUnknownNamespace(paramString.substring(i4), paramString.substring(0, i5));
      } else {
        paramString = valueOf(paramString);
      }
    }
  }
  
  public static SimpleSymbol valueOf(String paramString)
  {
    return (SimpleSymbol)Namespace.EmptyNamespace.getSymbol(paramString.intern());
  }
  
  public static Symbol valueOf(String paramString, Object paramObject)
  {
    if ((paramObject == null) || (paramObject == Boolean.FALSE))
    {
      paramString = makeUninterned(paramString);
      return paramString;
    }
    if ((paramObject instanceof Namespace)) {
      paramObject = (Namespace)paramObject;
    }
    for (;;)
    {
      paramString = ((Namespace)paramObject).getSymbol(paramString.intern());
      break;
      if (paramObject == Boolean.TRUE) {
        paramObject = Namespace.EmptyNamespace;
      } else {
        paramObject = Namespace.valueOf(((CharSequence)paramObject).toString());
      }
    }
  }
  
  public static Symbol valueOf(String paramString1, String paramString2, String paramString3)
  {
    return Namespace.valueOf(paramString2, paramString3).getSymbol(paramString1.intern());
  }
  
  public int compareTo(Object paramObject)
  {
    paramObject = (Symbol)paramObject;
    if (getNamespaceURI() != ((Symbol)paramObject).getNamespaceURI()) {
      throw new IllegalArgumentException("comparing Symbols in different namespaces");
    }
    return getLocalName().compareTo(((Symbol)paramObject).getLocalName());
  }
  
  public final boolean equals(Object paramObject)
  {
    if (((paramObject instanceof Symbol)) && (equals(this, (Symbol)paramObject))) {}
    for (boolean bool = true;; bool = false) {
      return bool;
    }
  }
  
  public final Object getKeyProperty()
  {
    return null;
  }
  
  public final Symbol getKeySymbol()
  {
    return this;
  }
  
  public final String getLocalName()
  {
    return this.name;
  }
  
  public final String getLocalPart()
  {
    return this.name;
  }
  
  public final String getName()
  {
    return this.name;
  }
  
  public final Namespace getNamespace()
  {
    return this.namespace;
  }
  
  public final String getNamespaceURI()
  {
    Object localObject = getNamespace();
    if (localObject == null) {}
    for (localObject = null;; localObject = ((Namespace)localObject).getName()) {
      return (String)localObject;
    }
  }
  
  public final String getPrefix()
  {
    Object localObject = this.namespace;
    if (localObject == null) {}
    for (localObject = "";; localObject = ((Namespace)localObject).prefix) {
      return (String)localObject;
    }
  }
  
  public final boolean hasEmptyNamespace()
  {
    Object localObject = getNamespace();
    if (localObject != null)
    {
      localObject = ((Namespace)localObject).getName();
      if ((localObject != null) && (((String)localObject).length() != 0)) {
        break label29;
      }
    }
    label29:
    for (boolean bool = true;; bool = false) {
      return bool;
    }
  }
  
  public int hashCode()
  {
    if (this.name == null) {}
    for (int i = 0;; i = this.name.hashCode()) {
      return i;
    }
  }
  
  public boolean matches(EnvironmentKey paramEnvironmentKey)
  {
    if ((equals(paramEnvironmentKey.getKeySymbol(), this)) && (paramEnvironmentKey.getKeyProperty() == null)) {}
    for (boolean bool = true;; bool = false) {
      return bool;
    }
  }
  
  public boolean matches(Symbol paramSymbol, Object paramObject)
  {
    if ((equals(paramSymbol, this)) && (paramObject == null)) {}
    for (boolean bool = true;; bool = false) {
      return bool;
    }
  }
  
  public void readExternal(ObjectInput paramObjectInput)
    throws IOException, ClassNotFoundException
  {
    this.namespace = ((Namespace)paramObjectInput.readObject());
    this.name = ((String)paramObjectInput.readObject());
  }
  
  public Object readResolve()
    throws ObjectStreamException
  {
    if (this.namespace == null) {}
    for (Symbol localSymbol = this;; localSymbol = make(this.namespace, getName())) {
      return localSymbol;
    }
  }
  
  public final void setNamespace(Namespace paramNamespace)
  {
    this.namespace = paramNamespace;
  }
  
  public String toString()
  {
    return toString('P');
  }
  
  public String toString(char paramChar)
  {
    int i = 1;
    Object localObject = getNamespaceURI();
    String str1 = getPrefix();
    int j;
    if ((localObject != null) && (((String)localObject).length() > 0))
    {
      j = 1;
      if ((str1 == null) || (str1.length() <= 0)) {
        break label153;
      }
    }
    for (;;)
    {
      String str2 = getName();
      if (j == 0)
      {
        localObject = str2;
        if (i == 0) {}
      }
      else
      {
        localObject = new StringBuilder();
        if ((i != 0) && ((paramChar != 'U') || (j == 0))) {
          ((StringBuilder)localObject).append(str1);
        }
        if ((j != 0) && ((paramChar != 'P') || (i == 0)))
        {
          ((StringBuilder)localObject).append('{');
          ((StringBuilder)localObject).append(getNamespaceURI());
          ((StringBuilder)localObject).append('}');
        }
        ((StringBuilder)localObject).append(':');
        ((StringBuilder)localObject).append(str2);
        localObject = ((StringBuilder)localObject).toString();
      }
      return (String)localObject;
      j = 0;
      break;
      label153:
      i = 0;
    }
  }
  
  public void writeExternal(ObjectOutput paramObjectOutput)
    throws IOException
  {
    paramObjectOutput.writeObject(getNamespace());
    paramObjectOutput.writeObject(getName());
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AppInventorApps/MyLocationApp/dex2jar_output/MyLocationApp-dex2jar.jar!/gnu/mapping/Symbol.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */