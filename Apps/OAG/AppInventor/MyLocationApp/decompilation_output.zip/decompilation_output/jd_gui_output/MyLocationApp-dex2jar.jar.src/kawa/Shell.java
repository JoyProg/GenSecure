package kawa;

import gnu.bytecode.ArrayClassLoader;
import gnu.bytecode.ZipLoader;
import gnu.expr.Compilation;
import gnu.expr.CompiledModule;
import gnu.expr.Language;
import gnu.expr.ModuleBody;
import gnu.expr.ModuleExp;
import gnu.expr.ModuleManager;
import gnu.lists.AbstractFormat;
import gnu.lists.Consumer;
import gnu.lists.VoidConsumer;
import gnu.mapping.CallContext;
import gnu.mapping.Environment;
import gnu.mapping.InPort;
import gnu.mapping.OutPort;
import gnu.mapping.Procedure;
import gnu.mapping.TtyInPort;
import gnu.mapping.Values;
import gnu.mapping.WrappedException;
import gnu.mapping.WrongArguments;
import gnu.text.FilePath;
import gnu.text.Lexer;
import gnu.text.Path;
import gnu.text.SourceMessages;
import gnu.text.SyntaxException;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.io.Writer;
import java.lang.reflect.Method;
import java.net.URL;

public class Shell
{
  private static Class[] boolClasses;
  public static ThreadLocal currentLoadPath = new ThreadLocal();
  public static Object[] defaultFormatInfo;
  public static Method defaultFormatMethod;
  public static String defaultFormatName;
  static Object[][] formats;
  private static Class[] httpPrinterClasses;
  private static Class[] noClasses = new Class[0];
  private static Object portArg;
  private static Class[] xmlPrinterClasses;
  
  static
  {
    boolClasses = new Class[] { Boolean.TYPE };
    xmlPrinterClasses = new Class[] { OutPort.class, Object.class };
    httpPrinterClasses = new Class[] { OutPort.class };
    portArg = "(port)";
    Class[] arrayOfClass1 = boolClasses;
    Boolean localBoolean1 = Boolean.FALSE;
    Class[] arrayOfClass2 = boolClasses;
    Boolean localBoolean2 = Boolean.TRUE;
    Object[] arrayOfObject1 = { "elisp", "gnu.kawa.functions.DisplayFormat", "getEmacsLispFormat", boolClasses, Boolean.FALSE };
    Object[] arrayOfObject2 = { "readable-elisp", "gnu.kawa.functions.DisplayFormat", "getEmacsLispFormat", boolClasses, Boolean.TRUE };
    Class[] arrayOfClass3 = boolClasses;
    Boolean localBoolean3 = Boolean.FALSE;
    Class[] arrayOfClass4 = boolClasses;
    Boolean localBoolean4 = Boolean.TRUE;
    Class[] arrayOfClass5 = boolClasses;
    Boolean localBoolean5 = Boolean.FALSE;
    Class[] arrayOfClass6 = boolClasses;
    Boolean localBoolean6 = Boolean.TRUE;
    Object[] arrayOfObject3 = { "xml", "gnu.xml.XMLPrinter", "make", xmlPrinterClasses, portArg, null };
    Class[] arrayOfClass7 = xmlPrinterClasses;
    Object localObject1 = portArg;
    Class[] arrayOfClass8 = xmlPrinterClasses;
    Object localObject2 = portArg;
    Class[] arrayOfClass9 = httpPrinterClasses;
    Object localObject3 = portArg;
    Class[] arrayOfClass10 = noClasses;
    formats = new Object[][] { { "scheme", "gnu.kawa.functions.DisplayFormat", "getSchemeFormat", arrayOfClass1, localBoolean1 }, { "readable-scheme", "gnu.kawa.functions.DisplayFormat", "getSchemeFormat", arrayOfClass2, localBoolean2 }, arrayOfObject1, arrayOfObject2, { "clisp", "gnu.kawa.functions.DisplayFormat", "getCommonLispFormat", arrayOfClass3, localBoolean3 }, { "readable-clisp", "gnu.kawa.functions.DisplayFormat", "getCommonLispFormat", arrayOfClass4, localBoolean4 }, { "commonlisp", "gnu.kawa.functions.DisplayFormat", "getCommonLispFormat", arrayOfClass5, localBoolean5 }, { "readable-commonlisp", "gnu.kawa.functions.DisplayFormat", "getCommonLispFormat", arrayOfClass6, localBoolean6 }, arrayOfObject3, { "html", "gnu.xml.XMLPrinter", "make", arrayOfClass7, localObject1, "html" }, { "xhtml", "gnu.xml.XMLPrinter", "make", arrayOfClass8, localObject2, "xhtml" }, { "cgi", "gnu.kawa.xml.HttpPrinter", "make", arrayOfClass9, localObject3 }, { "ignore", "gnu.lists.VoidConsumer", "getInstance", arrayOfClass10 }, { null } };
  }
  
  public static final CompiledModule checkCompiledZip(InputStream paramInputStream, Path paramPath, Environment paramEnvironment, Language paramLanguage)
    throws IOException
  {
    localEnvironment = null;
    for (;;)
    {
      try
      {
        paramInputStream.mark(5);
        if ((paramInputStream.read() != 80) || (paramInputStream.read() != 75) || (paramInputStream.read() != 3) || (paramInputStream.read() != 4)) {
          continue;
        }
        i = 1;
        paramInputStream.reset();
        if (i != 0) {
          continue;
        }
        paramInputStream = localEnvironment;
      }
      catch (IOException paramInputStream)
      {
        int i;
        paramInputStream = localEnvironment;
        continue;
        paramInputStream.close();
        localEnvironment = Environment.getCurrent();
        paramInputStream = paramPath.toString();
        if (paramEnvironment == localEnvironment) {
          continue;
        }
        try
        {
          Environment.setCurrent(paramEnvironment);
          if (!(paramPath instanceof FilePath))
          {
            paramLanguage = new java/lang/RuntimeException;
            paramPath = new java/lang/StringBuilder;
            paramPath.<init>();
            paramLanguage.<init>("load: " + paramInputStream + " - not a file path");
            throw paramLanguage;
          }
        }
        catch (IOException paramPath)
        {
          paramLanguage = new gnu/mapping/WrappedException;
          StringBuilder localStringBuilder = new java/lang/StringBuilder;
          localStringBuilder.<init>();
          paramLanguage.<init>("load: " + paramInputStream + " - " + paramPath.toString(), paramPath);
          throw paramLanguage;
        }
        finally
        {
          if (paramEnvironment != localEnvironment) {
            Environment.setCurrent(localEnvironment);
          }
        }
        paramPath = ((FilePath)paramPath).toFile();
        if (paramPath.exists()) {
          continue;
        }
        paramLanguage = new java/lang/RuntimeException;
        paramPath = new java/lang/StringBuilder;
        paramPath.<init>();
        paramLanguage.<init>("load: " + paramInputStream + " - not found");
        throw paramLanguage;
        if (paramPath.canRead()) {
          continue;
        }
        paramLanguage = new java/lang/RuntimeException;
        paramPath = new java/lang/StringBuilder;
        paramPath.<init>();
        paramLanguage.<init>("load: " + paramInputStream + " - not readable");
        throw paramLanguage;
        paramPath = new gnu/bytecode/ZipLoader;
        paramPath.<init>(paramInputStream);
        paramPath = CompiledModule.make(paramPath.loadAllClasses(), paramLanguage);
        paramInputStream = paramPath;
        if (paramEnvironment == localEnvironment) {
          continue;
        }
        Environment.setCurrent(localEnvironment);
        paramInputStream = paramPath;
        continue;
      }
      return paramInputStream;
      i = 0;
    }
  }
  
  static CompiledModule compileSource(InPort paramInPort, Environment paramEnvironment, URL paramURL, Language paramLanguage, SourceMessages paramSourceMessages)
    throws SyntaxException, IOException
  {
    Object localObject = null;
    Compilation localCompilation = paramLanguage.parse(paramInPort, paramSourceMessages, 1, ModuleManager.getInstance().findWithSourcePath(paramInPort.getName()));
    CallContext.getInstance().values = Values.noArgs;
    paramEnvironment = ModuleExp.evalModule1(paramEnvironment, localCompilation, paramURL, null);
    paramInPort = (InPort)localObject;
    if (paramEnvironment != null) {
      if (!paramSourceMessages.seenErrors()) {
        break label61;
      }
    }
    label61:
    for (paramInPort = (InPort)localObject;; paramInPort = new CompiledModule(localCompilation.getModule(), paramEnvironment, paramLanguage)) {
      return paramInPort;
    }
  }
  
  public static Consumer getOutputConsumer(OutPort paramOutPort)
  {
    Object localObject = defaultFormatInfo;
    if (paramOutPort == null) {
      paramOutPort = VoidConsumer.getInstance();
    }
    for (;;)
    {
      return paramOutPort;
      if (localObject == null)
      {
        paramOutPort = Language.getDefaultLanguage().getOutputConsumer(paramOutPort);
      }
      else
      {
        try
        {
          Object[] arrayOfObject = new Object[localObject.length - 4];
          System.arraycopy(localObject, 4, arrayOfObject, 0, arrayOfObject.length);
          int i = arrayOfObject.length;
          for (;;)
          {
            int j = i - 1;
            if (j < 0) {
              break;
            }
            i = j;
            if (arrayOfObject[j] == portArg)
            {
              arrayOfObject[j] = paramOutPort;
              i = j;
            }
          }
          localObject = defaultFormatMethod.invoke(null, arrayOfObject);
        }
        catch (Throwable paramOutPort)
        {
          throw new RuntimeException("cannot get output-format '" + defaultFormatName + "' - caught " + paramOutPort);
        }
        if ((localObject instanceof AbstractFormat)) {
          paramOutPort.objectFormat = ((AbstractFormat)localObject);
        } else {
          paramOutPort = (Consumer)localObject;
        }
      }
    }
  }
  
  public static void printError(Throwable paramThrowable, SourceMessages paramSourceMessages, OutPort paramOutPort)
  {
    if ((paramThrowable instanceof WrongArguments))
    {
      paramThrowable = (WrongArguments)paramThrowable;
      paramSourceMessages.printAll(paramOutPort, 20);
      if (paramThrowable.usage != null) {
        paramOutPort.println("usage: " + paramThrowable.usage);
      }
      paramThrowable.printStackTrace(paramOutPort);
    }
    for (;;)
    {
      return;
      if ((paramThrowable instanceof ClassCastException))
      {
        paramSourceMessages.printAll(paramOutPort, 20);
        paramOutPort.println("Invalid parameter, was: " + paramThrowable.getMessage());
        paramThrowable.printStackTrace(paramOutPort);
      }
      else
      {
        if ((paramThrowable instanceof SyntaxException))
        {
          SyntaxException localSyntaxException = (SyntaxException)paramThrowable;
          if (localSyntaxException.getMessages() == paramSourceMessages)
          {
            localSyntaxException.printAll(paramOutPort, 20);
            localSyntaxException.clear();
            continue;
          }
        }
        paramSourceMessages.printAll(paramOutPort, 20);
        paramThrowable.printStackTrace(paramOutPort);
      }
    }
  }
  
  public static Throwable run(Language paramLanguage, Environment paramEnvironment, InPort paramInPort, Consumer paramConsumer, OutPort paramOutPort, URL paramURL, SourceMessages paramSourceMessages)
  {
    Language localLanguage = Language.setSaveCurrent(paramLanguage);
    Lexer localLexer = paramLanguage.getLexer(paramInPort, paramSourceMessages);
    boolean bool1;
    if (paramOutPort != null) {
      bool1 = true;
    }
    for (;;)
    {
      localLexer.setInteractive(bool1);
      CallContext localCallContext = CallContext.getInstance();
      Consumer localConsumer = null;
      if (paramConsumer != null)
      {
        localConsumer = localCallContext.consumer;
        localCallContext.consumer = paramConsumer;
      }
      try
      {
        Object localObject1 = Thread.currentThread();
        Object localObject2 = ((Thread)localObject1).getContextClassLoader();
        Object localObject3;
        if (!(localObject2 instanceof ArrayClassLoader))
        {
          localObject3 = new gnu/bytecode/ArrayClassLoader;
          ((ArrayClassLoader)localObject3).<init>((ClassLoader)localObject2);
          ((Thread)localObject1).setContextClassLoader((ClassLoader)localObject3);
        }
        for (;;)
        {
          ModuleExp localModuleExp;
          try
          {
            localObject1 = paramLanguage.parse(localLexer, 7, null);
            if (bool1)
            {
              bool2 = paramSourceMessages.checkErrors(paramOutPort, 20);
              if (localObject1 != null) {
                continue;
              }
              if (paramConsumer != null) {
                localCallContext.consumer = localConsumer;
              }
              Language.restoreCurrent(localLanguage);
              localObject3 = null;
              return (Throwable)localObject3;
              bool1 = false;
              break;
            }
            if (paramSourceMessages.seenErrors())
            {
              localObject3 = new gnu/text/SyntaxException;
              ((SyntaxException)localObject3).<init>(paramSourceMessages);
              throw ((Throwable)localObject3);
            }
          }
          catch (Throwable localThrowable)
          {
            boolean bool2;
            if (!bool1)
            {
              if (paramConsumer != null) {
                localCallContext.consumer = localConsumer;
              }
              Language.restoreCurrent(localLanguage);
              continue;
              bool2 = false;
              continue;
              if (bool2) {
                continue;
              }
              localModuleExp = ((Compilation)localObject1).getModule();
              localObject2 = new java/lang/StringBuilder;
              ((StringBuilder)localObject2).<init>();
              localObject2 = ((StringBuilder)localObject2).append("atInteractiveLevel$");
              int i = ModuleExp.interactiveCounter + 1;
              ModuleExp.interactiveCounter = i;
              localModuleExp.setName(i);
              i = paramInPort.read();
              if ((i < 0) || (i == 13) || (i == 10))
              {
                if (!ModuleExp.evalModule(paramEnvironment, localCallContext, (Compilation)localObject1, paramURL, paramOutPort)) {
                  continue;
                }
                if ((paramConsumer instanceof Writer)) {
                  ((Writer)paramConsumer).flush();
                }
                if (i >= 0) {
                  continue;
                }
                continue;
              }
              if ((i == 32) || (i == 9)) {
                continue;
              }
              paramInPort.unread();
              continue;
            }
          }
          finally
          {
            if (paramConsumer != null) {
              localCallContext.consumer = localConsumer;
            }
            Language.restoreCurrent(localLanguage);
          }
          printError(localModuleExp, paramSourceMessages, paramOutPort);
        }
      }
      catch (SecurityException localSecurityException)
      {
        for (;;) {}
      }
    }
  }
  
  public static Throwable run(Language paramLanguage, Environment paramEnvironment, InPort paramInPort, OutPort paramOutPort1, OutPort paramOutPort2, SourceMessages paramSourceMessages)
  {
    AbstractFormat localAbstractFormat = null;
    if (paramOutPort1 != null) {
      localAbstractFormat = paramOutPort1.objectFormat;
    }
    Consumer localConsumer = getOutputConsumer(paramOutPort1);
    try
    {
      paramLanguage = run(paramLanguage, paramEnvironment, paramInPort, localConsumer, paramOutPort2, null, paramSourceMessages);
      return paramLanguage;
    }
    finally
    {
      if (paramOutPort1 != null) {
        paramOutPort1.objectFormat = localAbstractFormat;
      }
    }
  }
  
  public static boolean run(Language paramLanguage, Environment paramEnvironment)
  {
    InPort localInPort = InPort.inDefault();
    SourceMessages localSourceMessages = new SourceMessages();
    Object localObject;
    if ((localInPort instanceof TtyInPort))
    {
      localObject = paramLanguage.getPrompter();
      if (localObject != null) {
        ((TtyInPort)localInPort).setPrompter((Procedure)localObject);
      }
      localObject = OutPort.errDefault();
      paramLanguage = run(paramLanguage, paramEnvironment, localInPort, OutPort.outDefault(), (OutPort)localObject, localSourceMessages);
      if (paramLanguage != null) {
        break label73;
      }
    }
    for (boolean bool = true;; bool = false)
    {
      return bool;
      localObject = null;
      break;
      label73:
      printError(paramLanguage, localSourceMessages, OutPort.errDefault());
    }
  }
  
  public static boolean run(Language paramLanguage, Environment paramEnvironment, InPort paramInPort, Consumer paramConsumer, OutPort paramOutPort, URL paramURL)
  {
    SourceMessages localSourceMessages = new SourceMessages();
    paramLanguage = run(paramLanguage, paramEnvironment, paramInPort, paramConsumer, paramOutPort, paramURL, localSourceMessages);
    if (paramLanguage != null) {
      printError(paramLanguage, localSourceMessages, paramOutPort);
    }
    if (paramLanguage == null) {}
    for (boolean bool = true;; bool = false) {
      return bool;
    }
  }
  
  public static final boolean runFile(InputStream paramInputStream, Path paramPath, Environment paramEnvironment, boolean paramBoolean, int paramInt)
    throws Throwable
  {
    Object localObject1 = paramInputStream;
    if (!(paramInputStream instanceof BufferedInputStream)) {
      localObject1 = new BufferedInputStream(paramInputStream);
    }
    Language localLanguage = Language.getDefaultLanguage();
    Path localPath = (Path)currentLoadPath.get();
    Object localObject2;
    try
    {
      currentLoadPath.set(paramPath);
      paramInputStream = checkCompiledZip((InputStream)localObject1, paramPath, paramEnvironment, localLanguage);
      localObject2 = paramInputStream;
      if (paramInputStream != null) {
        break label222;
      }
      localObject1 = InPort.openFile((InputStream)localObject1, paramPath);
      for (;;)
      {
        paramInt--;
        if (paramInt < 0) {
          break;
        }
        ((InPort)localObject1).skipRestOfLine();
      }
      try
      {
        localObject2 = new gnu/text/SourceMessages;
        ((SourceMessages)localObject2).<init>();
        localURL = paramPath.toURL();
        if (!paramBoolean) {
          break label168;
        }
        if (ModuleBody.getMainPrintValues())
        {
          paramPath = getOutputConsumer(OutPort.outDefault());
          paramPath = run(localLanguage, paramEnvironment, (InPort)localObject1, paramPath, null, localURL, (SourceMessages)localObject2);
          if (paramPath == null) {
            break label214;
          }
          throw paramPath;
        }
      }
      finally
      {
        ((InPort)localObject1).close();
      }
    }
    finally
    {
      currentLoadPath.set(localPath);
    }
    URL localURL;
    for (;;)
    {
      paramPath = new VoidConsumer();
    }
    label168:
    paramPath = compileSource((InPort)localObject1, paramEnvironment, localURL, localLanguage, (SourceMessages)localObject2);
    ((SourceMessages)localObject2).printAll(OutPort.errDefault(), 20);
    paramInputStream = paramPath;
    if (paramPath == null)
    {
      paramBoolean = false;
      ((InPort)localObject1).close();
      currentLoadPath.set(localPath);
    }
    for (;;)
    {
      return paramBoolean;
      label214:
      ((InPort)localObject1).close();
      localObject2 = paramInputStream;
      label222:
      if (localObject2 != null) {
        ((CompiledModule)localObject2).evalModule(paramEnvironment, OutPort.outDefault());
      }
      currentLoadPath.set(localPath);
      paramBoolean = true;
    }
  }
  
  /* Error */
  public static boolean runFileOrClass(String paramString, boolean paramBoolean, int paramInt)
  {
    // Byte code:
    //   0: iconst_0
    //   1: istore_3
    //   2: invokestatic 271	gnu/expr/Language:getDefaultLanguage	()Lgnu/expr/Language;
    //   5: astore 4
    //   7: aload_0
    //   8: ldc_w 499
    //   11: invokevirtual 505	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   14: ifeq +31 -> 45
    //   17: ldc_w 507
    //   20: invokestatic 511	gnu/text/Path:valueOf	(Ljava/lang/Object;)Lgnu/text/Path;
    //   23: astore 5
    //   25: getstatic 515	java/lang/System:in	Ljava/io/InputStream;
    //   28: astore 6
    //   30: aload 6
    //   32: aload 5
    //   34: invokestatic 134	gnu/mapping/Environment:getCurrent	()Lgnu/mapping/Environment;
    //   37: iload_1
    //   38: iload_2
    //   39: invokestatic 517	kawa/Shell:runFile	(Ljava/io/InputStream;Lgnu/text/Path;Lgnu/mapping/Environment;ZI)Z
    //   42: istore_1
    //   43: iload_1
    //   44: ireturn
    //   45: aload_0
    //   46: invokestatic 511	gnu/text/Path:valueOf	(Ljava/lang/Object;)Lgnu/text/Path;
    //   49: astore 5
    //   51: aload 5
    //   53: invokevirtual 521	gnu/text/Path:openInputStream	()Ljava/io/InputStream;
    //   56: astore 6
    //   58: goto -28 -> 30
    //   61: astore 6
    //   63: aload 6
    //   65: getstatic 525	java/lang/System:err	Ljava/io/PrintStream;
    //   68: invokevirtual 528	java/lang/Throwable:printStackTrace	(Ljava/io/PrintStream;)V
    //   71: iload_3
    //   72: istore_1
    //   73: goto -30 -> 43
    //   76: astore 6
    //   78: aload_0
    //   79: invokestatic 532	java/lang/Class:forName	(Ljava/lang/String;)Ljava/lang/Class;
    //   82: astore_0
    //   83: aload_0
    //   84: aload 4
    //   86: invokestatic 198	gnu/expr/CompiledModule:make	(Ljava/lang/Class;Lgnu/expr/Language;)Lgnu/expr/CompiledModule;
    //   89: invokestatic 134	gnu/mapping/Environment:getCurrent	()Lgnu/mapping/Environment;
    //   92: invokestatic 450	gnu/mapping/OutPort:outDefault	()Lgnu/mapping/OutPort;
    //   95: invokevirtual 495	gnu/expr/CompiledModule:evalModule	(Lgnu/mapping/Environment;Lgnu/mapping/OutPort;)V
    //   98: iconst_1
    //   99: istore_1
    //   100: goto -57 -> 43
    //   103: astore_0
    //   104: getstatic 525	java/lang/System:err	Ljava/io/PrintStream;
    //   107: new 148	java/lang/StringBuilder
    //   110: dup
    //   111: invokespecial 149	java/lang/StringBuilder:<init>	()V
    //   114: ldc_w 534
    //   117: invokevirtual 155	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   120: aload 6
    //   122: invokevirtual 332	java/lang/Throwable:getMessage	()Ljava/lang/String;
    //   125: invokevirtual 155	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   128: invokevirtual 158	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   131: invokevirtual 537	java/io/PrintStream:println	(Ljava/lang/String;)V
    //   134: iload_3
    //   135: istore_1
    //   136: goto -93 -> 43
    //   139: astore_0
    //   140: aload_0
    //   141: invokevirtual 539	java/lang/Throwable:printStackTrace	()V
    //   144: iload_3
    //   145: istore_1
    //   146: goto -103 -> 43
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	149	0	paramString	String
    //   0	149	1	paramBoolean	boolean
    //   0	149	2	paramInt	int
    //   1	144	3	bool	boolean
    //   5	80	4	localLanguage	Language
    //   23	29	5	localPath	Path
    //   28	29	6	localInputStream	InputStream
    //   61	3	6	localThrowable1	Throwable
    //   76	45	6	localThrowable2	Throwable
    // Exception table:
    //   from	to	target	type
    //   30	43	61	java/lang/Throwable
    //   7	30	76	java/lang/Throwable
    //   45	58	76	java/lang/Throwable
    //   63	71	76	java/lang/Throwable
    //   78	83	103	java/lang/Throwable
    //   83	98	139	java/lang/Throwable
  }
  
  public static void setDefaultFormat(String paramString)
  {
    paramString = paramString.intern();
    defaultFormatName = paramString;
    int i = 0;
    Object[] arrayOfObject = formats[i];
    Object localObject = arrayOfObject[0];
    if (localObject == null)
    {
      System.err.println("kawa: unknown output format '" + paramString + "'");
      System.exit(-1);
    }
    while (localObject != paramString)
    {
      i++;
      break;
    }
    defaultFormatInfo = arrayOfObject;
    try
    {
      defaultFormatMethod = Class.forName((String)arrayOfObject[1]).getMethod((String)arrayOfObject[2], (Class[])arrayOfObject[3]);
      if (!defaultFormatInfo[1].equals("gnu.lists.VoidConsumer")) {
        ModuleBody.setMainPrintValues(true);
      }
      return;
    }
    catch (Throwable localThrowable)
    {
      for (;;)
      {
        System.err.println("kawa:  caught " + localThrowable + " while looking for format '" + paramString + "'");
        System.exit(-1);
      }
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AppInventorApps/MyLocationApp/dex2jar_output/MyLocationApp-dex2jar.jar!/kawa/Shell.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */