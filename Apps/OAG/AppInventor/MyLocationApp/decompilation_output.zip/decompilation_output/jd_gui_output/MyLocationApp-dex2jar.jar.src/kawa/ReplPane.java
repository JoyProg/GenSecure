package kawa;

import gnu.kawa.swingviews.SwingContent;
import gnu.lists.CharBuffer;
import gnu.mapping.OutPort;
import gnu.text.QueueReader;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JTextPane;
import javax.swing.text.AttributeSet;
import javax.swing.text.EditorKit;
import javax.swing.text.Element;
import javax.swing.text.MutableAttributeSet;

public class ReplPane
  extends JTextPane
  implements KeyListener
{
  public static final Object PaintableAttribute = new String("Paintable");
  public static final String PaintableElementName = "Paintable";
  public static final Object ViewableAttribute = new String("Viewable");
  public static final String ViewableElementName = "Viewable";
  ReplDocument document;
  
  public ReplPane(ReplDocument paramReplDocument)
  {
    super(paramReplDocument);
    this.document = paramReplDocument;
    paramReplDocument.pane = this;
    paramReplDocument.paneCount += 1;
    addKeyListener(this);
    addFocusListener(paramReplDocument);
    getEditorKit();
    setCaretPosition(paramReplDocument.outputMark);
  }
  
  protected EditorKit createDefaultEditorKit()
  {
    return new ReplEditorKit(this);
  }
  
  void enter()
  {
    int i = getCaretPosition();
    CharBuffer localCharBuffer = this.document.content.buffer;
    int j = localCharBuffer.length() - 1;
    this.document.endMark = -1;
    int k;
    int m;
    if (i >= this.document.outputMark)
    {
      k = localCharBuffer.indexOf(10, i);
      m = k;
      if (k == j)
      {
        if ((j <= this.document.outputMark) || (localCharBuffer.charAt(j - 1) != '\n')) {
          break label139;
        }
        m = k - 1;
      }
      for (;;)
      {
        this.document.endMark = m;
        synchronized (this.document.in_r)
        {
          this.document.in_r.notifyAll();
          if (i <= m) {
            setCaretPosition(m + 1);
          }
          return;
          label139:
          this.document.insertString(j, "\n", null);
          m = k;
        }
      }
    }
    if (i == 0)
    {
      m = 0;
      label170:
      ??? = this.document.getCharacterElement(m);
      k = ((CharBuffer)localObject1).indexOf(10, i);
      if (((Element)???).getAttributes().isEqual(ReplDocument.promptStyle)) {
        m = ((Element)???).getEndOffset();
      }
      if (k >= 0) {
        break label320;
      }
    }
    label320:
    for (??? = ((CharBuffer)localObject1).substring(m, j) + '\n';; ??? = ((CharBuffer)localObject1).substring(m, k + 1))
    {
      setCaretPosition(this.document.outputMark);
      this.document.write((String)???, ReplDocument.inputStyle);
      if (this.document.in_r == null) {
        break;
      }
      this.document.in_r.append((CharSequence)???, 0, ((String)???).length());
      break;
      m = ((CharBuffer)localObject1).lastIndexOf(10, i - 1) + 1;
      break label170;
    }
  }
  
  public MutableAttributeSet getInputAttributes()
  {
    return ReplDocument.inputStyle;
  }
  
  public OutPort getStderr()
  {
    return this.document.err_stream;
  }
  
  public OutPort getStdout()
  {
    return this.document.out_stream;
  }
  
  public void keyPressed(KeyEvent paramKeyEvent)
  {
    if (paramKeyEvent.getKeyCode() == 10)
    {
      enter();
      paramKeyEvent.consume();
    }
  }
  
  public void keyReleased(KeyEvent paramKeyEvent) {}
  
  public void keyTyped(KeyEvent paramKeyEvent) {}
  
  public void removeNotify()
  {
    super.removeNotify();
    ReplDocument localReplDocument = this.document;
    int i = localReplDocument.paneCount - 1;
    localReplDocument.paneCount = i;
    if (i == 0) {
      this.document.close();
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AppInventorApps/MyLocationApp/dex2jar_output/MyLocationApp-dex2jar.jar!/kawa/ReplPane.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */