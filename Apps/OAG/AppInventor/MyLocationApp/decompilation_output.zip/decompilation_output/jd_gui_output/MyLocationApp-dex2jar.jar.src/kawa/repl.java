package kawa;

import gnu.bytecode.ClassType;
import gnu.expr.ApplicationMainSupport;
import gnu.expr.Compilation;
import gnu.expr.Language;
import gnu.expr.ModuleBody;
import gnu.expr.ModuleExp;
import gnu.expr.ModuleInfo;
import gnu.expr.ModuleManager;
import gnu.lists.FString;
import gnu.mapping.CharArrayInPort;
import gnu.mapping.Environment;
import gnu.mapping.InPort;
import gnu.mapping.OutPort;
import gnu.mapping.Procedure0or1;
import gnu.mapping.Values;
import gnu.text.Options;
import gnu.text.SourceMessages;
import gnu.text.SyntaxException;
import gnu.text.WriterManager;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Vector;

public class repl
  extends Procedure0or1
{
  public static String compilationTopname = null;
  static int defaultParseOptions = 72;
  public static String homeDirectory;
  public static boolean noConsole;
  static Language previousLanguage;
  static boolean shutdownRegistered = WriterManager.instance.registerShutdownHook();
  Language language;
  
  public repl(Language paramLanguage)
  {
    this.language = paramLanguage;
  }
  
  static void bad_option(String paramString)
  {
    System.err.println("kawa: bad option '" + paramString + "'");
    printOptions(System.err);
    System.exit(-1);
  }
  
  static void checkInitFile()
  {
    Object localObject1;
    Object localObject2;
    if (homeDirectory == null)
    {
      localObject1 = null;
      homeDirectory = System.getProperty("user.home");
      if (homeDirectory == null) {
        break label105;
      }
      localObject2 = new FString(homeDirectory);
      if (!"/".equals(System.getProperty("file.separator"))) {
        break label99;
      }
      localObject1 = ".kawarc.scm";
      localObject1 = new File(homeDirectory, (String)localObject1);
    }
    for (;;)
    {
      Environment.getCurrent().put("home-directory", localObject2);
      if ((localObject1 != null) && (((File)localObject1).exists()) && (!Shell.runFileOrClass(((File)localObject1).getPath(), true, 0))) {
        System.exit(-1);
      }
      return;
      label99:
      localObject1 = "kawarc.scm";
      break;
      label105:
      localObject2 = Boolean.FALSE;
    }
  }
  
  public static void compileFiles(String[] paramArrayOfString, int paramInt1, int paramInt2)
  {
    Object localObject1 = ModuleManager.getInstance();
    Compilation[] arrayOfCompilation = new Compilation[paramInt2 - paramInt1];
    ModuleInfo[] arrayOfModuleInfo = new ModuleInfo[paramInt2 - paramInt1];
    SourceMessages localSourceMessages = new SourceMessages();
    Object localObject2;
    Object localObject4;
    Object localObject5;
    for (int i = paramInt1; i < paramInt2; i++)
    {
      localObject2 = paramArrayOfString[i];
      getLanguageFromFilenameExtension((String)localObject2);
      Object localObject3 = Language.getDefaultLanguage();
      localObject4 = null;
      localObject5 = localObject4;
      try
      {
        Object localObject6 = InPort.openFile(localObject2);
        localObject5 = localObject4;
        localObject4 = ((Language)localObject3).parse((InPort)localObject6, localSourceMessages, defaultParseOptions);
        localObject5 = localObject4;
        if (compilationTopname != null)
        {
          localObject5 = localObject4;
          localObject3 = Compilation.mangleNameIfNeeded(compilationTopname);
          localObject5 = localObject4;
          localObject6 = new gnu/bytecode/ClassType;
          localObject5 = localObject4;
          ((ClassType)localObject6).<init>((String)localObject3);
          localObject5 = localObject4;
          localObject3 = ((Compilation)localObject4).getModule();
          localObject5 = localObject4;
          ((ModuleExp)localObject3).setType((ClassType)localObject6);
          localObject5 = localObject4;
          ((ModuleExp)localObject3).setName(compilationTopname);
          localObject5 = localObject4;
          ((Compilation)localObject4).mainClass = ((ClassType)localObject6);
        }
        localObject5 = localObject4;
        arrayOfModuleInfo[(i - paramInt1)] = ((ModuleManager)localObject1).find((Compilation)localObject4);
        arrayOfCompilation[(i - paramInt1)] = localObject4;
      }
      catch (FileNotFoundException localFileNotFoundException)
      {
        localObject5 = localObject4;
        System.err.println(localFileNotFoundException);
        localObject5 = localObject4;
        System.exit(-1);
        i = paramInt1;
        while (i < paramInt2)
        {
          localObject4 = paramArrayOfString[i];
          localObject5 = arrayOfCompilation[(i - paramInt1)];
          try
          {
            localObject1 = System.err;
            localObject2 = new java/lang/StringBuilder;
            ((StringBuilder)localObject2).<init>();
            ((PrintStream)localObject1).println("(compiling " + (String)localObject4 + " to " + ((Compilation)localObject5).mainClass.getName() + ')');
            arrayOfModuleInfo[(i - paramInt1)].loadByStages(14);
            boolean bool = localSourceMessages.seenErrors();
            localSourceMessages.checkErrors(System.err, 50);
            if (bool) {
              System.exit(-1);
            }
            arrayOfCompilation[(i - paramInt1)] = localObject5;
            bool = localSourceMessages.seenErrors();
            localSourceMessages.checkErrors(System.err, 50);
            if (bool) {
              System.exit(-1);
            }
            i++;
          }
          catch (Throwable localThrowable1)
          {
            for (;;)
            {
              internalError(localThrowable1, (Compilation)localObject5, localThrowable2);
            }
          }
        }
      }
      catch (Throwable localThrowable2)
      {
        for (;;)
        {
          if ((!(localThrowable2 instanceof SyntaxException)) || (((SyntaxException)localThrowable2).getMessages() != localSourceMessages)) {
            internalError(localThrowable2, (Compilation)localObject5, localObject2);
          }
        }
      }
      if (localSourceMessages.seenErrorsOrWarnings())
      {
        System.err.println("(compiling " + (String)localObject2 + ')');
        if (localSourceMessages.checkErrors(System.err, 20)) {
          System.exit(1);
        }
      }
    }
  }
  
  public static void getLanguage()
  {
    if (previousLanguage == null)
    {
      previousLanguage = Language.getInstance(null);
      Language.setDefaults(previousLanguage);
    }
  }
  
  public static void getLanguageFromFilenameExtension(String paramString)
  {
    if (previousLanguage == null)
    {
      previousLanguage = Language.getInstanceFromFilenameExtension(paramString);
      if (previousLanguage != null) {
        Language.setDefaults(previousLanguage);
      }
    }
    for (;;)
    {
      return;
      getLanguage();
    }
  }
  
  static void internalError(Throwable paramThrowable, Compilation paramCompilation, Object paramObject)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    if (paramCompilation != null)
    {
      String str = paramCompilation.getFileName();
      int i = paramCompilation.getLineNumber();
      if ((str != null) && (i > 0))
      {
        localStringBuffer.append(str);
        localStringBuffer.append(':');
        localStringBuffer.append(i);
        localStringBuffer.append(": ");
      }
    }
    localStringBuffer.append("internal error while compiling ");
    localStringBuffer.append(paramObject);
    System.err.println(localStringBuffer.toString());
    paramThrowable.printStackTrace(System.err);
    System.exit(-1);
  }
  
  public static void main(String[] paramArrayOfString)
  {
    for (;;)
    {
      try
      {
        int i = processArgs(paramArrayOfString, 0, paramArrayOfString.length);
        if (i < 0) {
          return;
        }
        if (i < paramArrayOfString.length)
        {
          String str = paramArrayOfString[i];
          getLanguageFromFilenameExtension(str);
          setArgs(paramArrayOfString, i + 1);
          checkInitFile();
          Shell.runFileOrClass(str, false, 0);
          if (!shutdownRegistered) {
            OutPort.runCleanups();
          }
          ModuleBody.exitDecrement();
          continue;
        }
        getLanguage();
        setArgs(paramArrayOfString, i);
        checkInitFile();
        if (shouldUseGuiConsole())
        {
          startGuiConsole();
          continue;
        }
        if (Shell.run(Language.getDefaultLanguage(), Environment.getCurrent())) {
          continue;
        }
      }
      finally
      {
        if (!shutdownRegistered) {
          OutPort.runCleanups();
        }
        ModuleBody.exitDecrement();
      }
      System.exit(-1);
    }
  }
  
  public static void printOption(PrintStream paramPrintStream, String paramString1, String paramString2)
  {
    paramPrintStream.print(" ");
    paramPrintStream.print(paramString1);
    int i = paramString1.length();
    for (int j = 0; j < 30 - (i + 1); j++) {
      paramPrintStream.print(" ");
    }
    paramPrintStream.print(" ");
    paramPrintStream.println(paramString2);
  }
  
  public static void printOptions(PrintStream paramPrintStream)
  {
    paramPrintStream.println("Usage: [java kawa.repl | kawa] [options ...]");
    paramPrintStream.println();
    paramPrintStream.println(" Generic options:");
    printOption(paramPrintStream, "--help", "Show help about options");
    printOption(paramPrintStream, "--author", "Show author information");
    printOption(paramPrintStream, "--version", "Show version information");
    paramPrintStream.println();
    paramPrintStream.println(" Options");
    printOption(paramPrintStream, "-e <expr>", "Evaluate expression <expr>");
    printOption(paramPrintStream, "-c <expr>", "Same as -e, but make sure ~/.kawarc.scm is run first");
    printOption(paramPrintStream, "-f <filename>", "File to interpret");
    printOption(paramPrintStream, "-s| --", "Start reading commands interactively from console");
    printOption(paramPrintStream, "-w", "Launch the interpreter in a GUI window");
    printOption(paramPrintStream, "--server <port>", "Start a server accepting telnet connections on <port>");
    printOption(paramPrintStream, "--debug-dump-zip", "Compiled interactive expressions to a zip archive");
    printOption(paramPrintStream, "--debug-print-expr", "Print generated internal expressions");
    printOption(paramPrintStream, "--debug-print-final-expr", "Print expression after any optimizations");
    printOption(paramPrintStream, "--debug-error-prints-stack-trace", "Print stack trace with errors");
    printOption(paramPrintStream, "--debug-warning-prints-stack-trace", "Print stack trace with warnings");
    printOption(paramPrintStream, "--[no-]full-tailcalls", "(Don't) use full tail-calls");
    printOption(paramPrintStream, "-C <filename> ...", "Compile named files to Java class files");
    printOption(paramPrintStream, "--output-format <format>", "Use <format> when printing top-level output");
    printOption(paramPrintStream, "--<language>", "Select source language, one of:");
    Object localObject = Language.getLanguages();
    String str;
    for (int i = 0; i < localObject.length; i++)
    {
      paramPrintStream.print("   ");
      str = localObject[i];
      int j = str.length;
      for (int k = 0; k < j - 1; k++) {
        paramPrintStream.print(str[k] + " ");
      }
      if (i == 0) {
        paramPrintStream.print("[default]");
      }
      paramPrintStream.println();
    }
    paramPrintStream.println(" Compilation options, must be specified before -C");
    printOption(paramPrintStream, "-d <dirname>", "Directory to place .class files in");
    printOption(paramPrintStream, "-P <prefix>", "Prefix to prepand to class names");
    printOption(paramPrintStream, "-T <topname>", "name to give to top-level class");
    printOption(paramPrintStream, "--main", "Generate an application, with a main method");
    printOption(paramPrintStream, "--applet", "Generate an applet");
    printOption(paramPrintStream, "--servlet", "Generate a servlet");
    printOption(paramPrintStream, "--module-static", "Top-level definitions are by default static");
    localObject = Compilation.options.keys();
    for (i = 0; i < ((ArrayList)localObject).size(); i++)
    {
      str = (String)((ArrayList)localObject).get(i);
      printOption(paramPrintStream, "--" + str, Compilation.options.getDoc(str));
    }
    paramPrintStream.println();
    paramPrintStream.println("For more information go to:  http://www.gnu.org/software/kawa/");
  }
  
  public static int processArgs(String[] paramArrayOfString, int paramInt1, int paramInt2)
  {
    int i = 0;
    int j = paramInt1;
    Object localObject1;
    Object localObject2;
    int k;
    if (j < paramInt2)
    {
      localObject1 = paramArrayOfString[j];
      Object localObject3;
      if ((((String)localObject1).equals("-c")) || (((String)localObject1).equals("-e")))
      {
        paramInt1 = j + 1;
        if (paramInt1 == paramInt2) {
          bad_option((String)localObject1);
        }
        getLanguage();
        setArgs(paramArrayOfString, paramInt1 + 1);
        if (((String)localObject1).equals("-c")) {
          checkInitFile();
        }
        localObject2 = Language.getDefaultLanguage();
        localObject3 = new SourceMessages();
        localObject2 = Shell.run((Language)localObject2, Environment.getCurrent(), new CharArrayInPort(paramArrayOfString[paramInt1]), OutPort.outDefault(), null, (SourceMessages)localObject3);
        if (localObject2 != null)
        {
          Shell.printError((Throwable)localObject2, (SourceMessages)localObject3, OutPort.errDefault());
          System.exit(-1);
        }
      }
      for (k = 1;; k = 1)
      {
        j = paramInt1 + 1;
        i = k;
        break;
        if (!((String)localObject1).equals("-f")) {
          break label217;
        }
        paramInt1 = j + 1;
        if (paramInt1 == paramInt2) {
          bad_option((String)localObject1);
        }
        localObject3 = paramArrayOfString[paramInt1];
        getLanguageFromFilenameExtension((String)localObject3);
        setArgs(paramArrayOfString, paramInt1 + 1);
        checkInitFile();
        if (!Shell.runFileOrClass((String)localObject3, true, 0)) {
          System.exit(-1);
        }
      }
      label217:
      if (((String)localObject1).startsWith("--script"))
      {
        localObject3 = ((String)localObject1).substring(8);
        i = j + 1;
        j = 0;
        paramInt1 = j;
        k = i;
        if (((String)localObject3).length() > 0) {}
        try
        {
          paramInt1 = Integer.parseInt((String)localObject3);
          k = i;
        }
        catch (Throwable localThrowable)
        {
          for (;;)
          {
            k = paramInt2;
            paramInt1 = j;
          }
        }
        if (k == paramInt2) {
          bad_option((String)localObject1);
        }
        localObject3 = paramArrayOfString[k];
        getLanguageFromFilenameExtension((String)localObject3);
        setArgs(paramArrayOfString, k + 1);
        checkInitFile();
        if (!Shell.runFileOrClass((String)localObject3, true, paramInt1)) {
          System.exit(-1);
        }
        paramInt1 = -1;
      }
    }
    for (;;)
    {
      return paramInt1;
      Object localObject6;
      Object localObject4;
      Object localObject7;
      if (((String)localObject1).equals("\\"))
      {
        j++;
        if (j == paramInt2) {
          bad_option((String)localObject1);
        }
        localObject6 = paramArrayOfString[j];
        localObject4 = new SourceMessages();
        for (;;)
        {
          StringBuffer localStringBuffer;
          try
          {
            localObject2 = new java/io/BufferedInputStream;
            localObject7 = new java/io/FileInputStream;
            ((FileInputStream)localObject7).<init>((String)localObject6);
            ((BufferedInputStream)localObject2).<init>((InputStream)localObject7);
            paramInt2 = ((InputStream)localObject2).read();
            if (paramInt2 == 35)
            {
              localStringBuffer = new java/lang/StringBuffer;
              localStringBuffer.<init>(100);
              localObject7 = new java/util/Vector;
              ((Vector)localObject7).<init>(10);
              k = 0;
              paramInt1 = k;
              if (paramInt2 != 10)
              {
                paramInt1 = k;
                if (paramInt2 != 13)
                {
                  paramInt1 = k;
                  if (paramInt2 >= 0)
                  {
                    paramInt2 = ((InputStream)localObject2).read();
                    continue;
                  }
                }
              }
              k = ((InputStream)localObject2).read();
              if (k < 0)
              {
                localObject1 = System.err;
                StringBuilder localStringBuilder = new java/lang/StringBuilder;
                localStringBuilder.<init>();
                ((PrintStream)localObject1).println("unexpected end-of-file processing argument line for: '" + (String)localObject6 + '\'');
                System.exit(-1);
              }
              if (paramInt1 != 0) {
                break label821;
              }
              if ((k == 92) || (k == 39) || (k == 34))
              {
                paramInt1 = k;
                continue;
              }
              if ((k != 10) && (k != 13)) {
                break label778;
              }
              if (localStringBuffer.length() > 0) {
                ((Vector)localObject7).addElement(localStringBuffer.toString());
              }
              paramInt2 = ((Vector)localObject7).size();
              if (paramInt2 > 0)
              {
                localObject1 = new String[paramInt2];
                ((Vector)localObject7).copyInto((Object[])localObject1);
                paramInt1 = processArgs((String[])localObject1, 0, paramInt2);
                if ((paramInt1 >= 0) && (paramInt1 < paramInt2))
                {
                  localObject7 = System.err;
                  localObject1 = new java/lang/StringBuilder;
                  ((StringBuilder)localObject1).<init>();
                  ((PrintStream)localObject7).println("" + (paramInt2 - paramInt1) + " unused meta args");
                }
              }
            }
            getLanguageFromFilenameExtension((String)localObject6);
            localObject2 = InPort.openFile((InputStream)localObject2, localObject6);
            setArgs(paramArrayOfString, j + 1);
            checkInitFile();
            paramArrayOfString = OutPort.errDefault();
            localObject2 = Shell.run(Language.getDefaultLanguage(), Environment.getCurrent(), (InPort)localObject2, OutPort.outDefault(), null, (SourceMessages)localObject4);
            ((SourceMessages)localObject4).printAll(paramArrayOfString, 20);
            if (localObject2 != null)
            {
              if (((localObject2 instanceof SyntaxException)) && (((SyntaxException)localObject2).getMessages() == localObject4)) {
                System.exit(1);
              }
              throw ((Throwable)localObject2);
            }
          }
          catch (Throwable paramArrayOfString)
          {
            Shell.printError(paramArrayOfString, (SourceMessages)localObject4, OutPort.errDefault());
            System.exit(1);
            paramInt1 = -1;
          }
          break;
          label778:
          if (k != 32)
          {
            paramInt2 = paramInt1;
            if (k != 9) {}
          }
          else
          {
            if (localStringBuffer.length() <= 0) {
              continue;
            }
            ((Vector)localObject7).addElement(localStringBuffer.toString());
            localStringBuffer.setLength(0);
            continue;
            label821:
            if (paramInt1 != 92) {
              break label843;
            }
            paramInt2 = 0;
          }
          label843:
          do
          {
            localStringBuffer.append((char)k);
            paramInt1 = paramInt2;
            break;
            paramInt2 = paramInt1;
          } while (k != paramInt1);
          paramInt1 = 0;
        }
      }
      if ((((String)localObject1).equals("-s")) || (((String)localObject1).equals("--")))
      {
        getLanguage();
        setArgs(paramArrayOfString, j + 1);
        checkInitFile();
        Shell.run(Language.getDefaultLanguage(), Environment.getCurrent());
        paramInt1 = -1;
      }
      else
      {
        if (((String)localObject1).equals("-w"))
        {
          paramInt1 = j + 1;
          getLanguage();
          setArgs(paramArrayOfString, paramInt1);
          checkInitFile();
          startGuiConsole();
          k = 1;
          break;
        }
        if (((String)localObject1).equals("-d"))
        {
          paramInt1 = j + 1;
          if (paramInt1 == paramInt2) {
            bad_option((String)localObject1);
          }
          ModuleManager.getInstance().setCompilationDirectory(paramArrayOfString[paramInt1]);
          k = i;
          break;
        }
        if ((((String)localObject1).equals("--target")) || (((String)localObject1).equals("target")))
        {
          paramInt1 = j + 1;
          if (paramInt1 == paramInt2) {
            bad_option((String)localObject1);
          }
          localObject4 = paramArrayOfString[paramInt1];
          if (((String)localObject4).equals("7")) {
            Compilation.defaultClassFileVersion = 3342336;
          }
          if ((((String)localObject4).equals("6")) || (((String)localObject4).equals("1.6")))
          {
            Compilation.defaultClassFileVersion = 3276800;
            k = i;
            break;
          }
          if ((((String)localObject4).equals("5")) || (((String)localObject4).equals("1.5")))
          {
            Compilation.defaultClassFileVersion = 3211264;
            k = i;
            break;
          }
          if (((String)localObject4).equals("1.4"))
          {
            Compilation.defaultClassFileVersion = 3145728;
            k = i;
            break;
          }
          if (((String)localObject4).equals("1.3"))
          {
            Compilation.defaultClassFileVersion = 3080192;
            k = i;
            break;
          }
          if (((String)localObject4).equals("1.2"))
          {
            Compilation.defaultClassFileVersion = 3014656;
            k = i;
            break;
          }
          if (((String)localObject4).equals("1.1"))
          {
            Compilation.defaultClassFileVersion = 2949123;
            k = i;
            break;
          }
          bad_option((String)localObject4);
          k = i;
          break;
        }
        if (((String)localObject1).equals("-P"))
        {
          paramInt1 = j + 1;
          if (paramInt1 == paramInt2) {
            bad_option((String)localObject1);
          }
          Compilation.classPrefixDefault = paramArrayOfString[paramInt1];
          k = i;
          break;
        }
        if (((String)localObject1).equals("-T"))
        {
          paramInt1 = j + 1;
          if (paramInt1 == paramInt2) {
            bad_option((String)localObject1);
          }
          compilationTopname = paramArrayOfString[paramInt1];
          k = i;
          break;
        }
        if (((String)localObject1).equals("-C"))
        {
          paramInt1 = j + 1;
          if (paramInt1 == paramInt2) {
            bad_option((String)localObject1);
          }
          compileFiles(paramArrayOfString, paramInt1, paramInt2);
          paramInt1 = -1;
        }
        else
        {
          if ((((String)localObject1).equals("--output-format")) || (((String)localObject1).equals("--format")))
          {
            paramInt1 = j + 1;
            if (paramInt1 == paramInt2) {
              bad_option((String)localObject1);
            }
            Shell.setDefaultFormat(paramArrayOfString[paramInt1]);
            k = i;
            break;
          }
          if (((String)localObject1).equals("--connect"))
          {
            j++;
            if (j == paramInt2) {
              bad_option((String)localObject1);
            }
            if (paramArrayOfString[j].equals("-")) {
              paramInt1 = 0;
            }
            for (;;)
            {
              try
              {
                localObject4 = new java/net/Socket;
                ((Socket)localObject4).<init>(InetAddress.getByName(null), paramInt1);
                localObject2 = new kawa/Telnet;
                ((Telnet)localObject2).<init>((Socket)localObject4, true);
                localObject4 = ((Telnet)localObject2).getInputStream();
                localObject2 = ((Telnet)localObject2).getOutputStream();
                localObject6 = new java/io/PrintStream;
                ((PrintStream)localObject6).<init>((OutputStream)localObject2, true);
                System.setIn((InputStream)localObject4);
                System.setOut((PrintStream)localObject6);
                System.setErr((PrintStream)localObject6);
                k = i;
                paramInt1 = j;
              }
              catch (IOException paramArrayOfString)
              {
                paramArrayOfString.printStackTrace(System.err);
                throw new Error(paramArrayOfString.toString());
              }
              try
              {
                paramInt1 = Integer.parseInt(paramArrayOfString[j]);
              }
              catch (NumberFormatException localNumberFormatException)
              {
                bad_option("--connect port#");
                paramInt1 = -1;
              }
            }
          }
          Object localObject5;
          if (((String)localObject1).equals("--server"))
          {
            getLanguage();
            paramInt1 = j + 1;
            if (paramInt1 == paramInt2) {
              bad_option((String)localObject1);
            }
            if (paramArrayOfString[paramInt1].equals("-")) {
              paramInt1 = 0;
            }
            for (;;)
            {
              try
              {
                paramArrayOfString = new java/net/ServerSocket;
                paramArrayOfString.<init>(paramInt1);
                paramInt1 = paramArrayOfString.getLocalPort();
                localObject5 = System.err;
                localObject2 = new java/lang/StringBuilder;
                ((StringBuilder)localObject2).<init>();
                ((PrintStream)localObject5).println("Listening on port " + paramInt1);
                System.err.print("waiting ... ");
                System.err.flush();
                localObject6 = paramArrayOfString.accept();
                localObject2 = System.err;
                localObject5 = new java/lang/StringBuilder;
                ((StringBuilder)localObject5).<init>();
                ((PrintStream)localObject2).println("got connection from " + ((Socket)localObject6).getInetAddress() + " port:" + ((Socket)localObject6).getPort());
                TelnetRepl.serve(Language.getDefaultLanguage(), (Socket)localObject6);
                continue;
                try
                {
                  paramInt1 = Integer.parseInt(paramArrayOfString[paramInt1]);
                }
                catch (NumberFormatException paramArrayOfString)
                {
                  bad_option("--server port#");
                  paramInt1 = -1;
                }
              }
              catch (IOException paramArrayOfString)
              {
                throw new Error(paramArrayOfString.toString());
              }
            }
          }
          if (((String)localObject1).equals("--http-auto-handler"))
          {
            paramInt1 = j + 2;
            if (paramInt1 >= paramInt2) {
              bad_option((String)localObject1);
            }
            System.err.println("kawa: HttpServer classes not found");
            System.exit(-1);
            k = i;
            break;
          }
          if (((String)localObject1).equals("--http-start"))
          {
            paramInt1 = j + 1;
            if (paramInt1 >= paramInt2) {
              bad_option("missing httpd port argument");
            }
            System.err.println("kawa: HttpServer classes not found");
            System.exit(-1);
            k = i;
            break;
          }
          if (((String)localObject1).equals("--main"))
          {
            Compilation.generateMainDefault = true;
            k = i;
            paramInt1 = j;
            break;
          }
          if (((String)localObject1).equals("--applet"))
          {
            defaultParseOptions |= 0x10;
            k = i;
            paramInt1 = j;
            break;
          }
          if (((String)localObject1).equals("--servlet"))
          {
            defaultParseOptions |= 0x20;
            gnu.kawa.servlet.HttpRequestContext.importServletDefinitions = 2;
            k = i;
            paramInt1 = j;
            break;
          }
          if (((String)localObject1).equals("--debug-dump-zip"))
          {
            ModuleExp.dumpZipPrefix = "kawa-zip-dump-";
            k = i;
            paramInt1 = j;
            break;
          }
          if (((String)localObject1).equals("--debug-print-expr"))
          {
            Compilation.debugPrintExpr = true;
            k = i;
            paramInt1 = j;
            break;
          }
          if (((String)localObject1).equals("--debug-print-final-expr"))
          {
            Compilation.debugPrintFinalExpr = true;
            k = i;
            paramInt1 = j;
            break;
          }
          if (((String)localObject1).equals("--debug-error-prints-stack-trace"))
          {
            SourceMessages.debugStackTraceOnError = true;
            k = i;
            paramInt1 = j;
            break;
          }
          if (((String)localObject1).equals("--debug-warning-prints-stack-trace"))
          {
            SourceMessages.debugStackTraceOnWarning = true;
            k = i;
            paramInt1 = j;
            break;
          }
          if ((((String)localObject1).equals("--module-nonstatic")) || (((String)localObject1).equals("--no-module-static")))
          {
            Compilation.moduleStatic = -1;
            k = i;
            paramInt1 = j;
            break;
          }
          if (((String)localObject1).equals("--module-static"))
          {
            Compilation.moduleStatic = 1;
            k = i;
            paramInt1 = j;
            break;
          }
          if (((String)localObject1).equals("--module-static-run"))
          {
            Compilation.moduleStatic = 2;
            k = i;
            paramInt1 = j;
            break;
          }
          if ((((String)localObject1).equals("--no-inline")) || (((String)localObject1).equals("--inline=none")))
          {
            Compilation.inlineOk = false;
            k = i;
            paramInt1 = j;
            break;
          }
          if (((String)localObject1).equals("--no-console"))
          {
            noConsole = true;
            k = i;
            paramInt1 = j;
            break;
          }
          if (((String)localObject1).equals("--inline"))
          {
            Compilation.inlineOk = true;
            k = i;
            paramInt1 = j;
            break;
          }
          if (((String)localObject1).equals("--cps"))
          {
            Compilation.defaultCallConvention = 4;
            k = i;
            paramInt1 = j;
            break;
          }
          if (((String)localObject1).equals("--full-tailcalls"))
          {
            Compilation.defaultCallConvention = 3;
            k = i;
            paramInt1 = j;
            break;
          }
          if (((String)localObject1).equals("--no-full-tailcalls"))
          {
            Compilation.defaultCallConvention = 1;
            k = i;
            paramInt1 = j;
            break;
          }
          if (((String)localObject1).equals("--pedantic"))
          {
            Language.requirePedantic = true;
            k = i;
            paramInt1 = j;
            break;
          }
          if (((String)localObject1).equals("--help"))
          {
            printOptions(System.out);
            System.exit(0);
            k = i;
            paramInt1 = j;
            break;
          }
          if (((String)localObject1).equals("--author"))
          {
            System.out.println("Per Bothner <per@bothner.com>");
            System.exit(0);
            k = i;
            paramInt1 = j;
            break;
          }
          if (((String)localObject1).equals("--version"))
          {
            System.out.print("Kawa ");
            System.out.print(Version.getVersion());
            System.out.println();
            System.out.println("Copyright (C) 2009 Per Bothner");
            k = 1;
            paramInt1 = j;
            break;
          }
          if ((((String)localObject1).length() > 0) && (((String)localObject1).charAt(0) == '-'))
          {
            localObject2 = localObject1;
            localObject5 = localObject2;
            if (((String)localObject2).length() > 2)
            {
              localObject5 = localObject2;
              if (((String)localObject2).charAt(0) == '-')
              {
                if (((String)localObject2).charAt(1) != '-') {
                  break label2537;
                }
                paramInt1 = 2;
                label2492:
                localObject5 = ((String)localObject2).substring(paramInt1);
              }
            }
            localObject2 = Language.getInstance((String)localObject5);
            if (localObject2 != null)
            {
              if (previousLanguage == null) {
                Language.setDefaults((Language)localObject2);
              }
              for (;;)
              {
                previousLanguage = (Language)localObject2;
                k = i;
                paramInt1 = j;
                break;
                label2537:
                paramInt1 = 1;
                break label2492;
                Language.setCurrentLanguage((Language)localObject2);
              }
            }
            paramInt1 = ((String)localObject5).indexOf("=");
            if (paramInt1 < 0)
            {
              localObject2 = null;
              label2566:
              if ((!((String)localObject5).startsWith("no-")) || (((String)localObject5).length() <= 3)) {
                break label2745;
              }
            }
            label2745:
            for (int m = 1;; m = 0)
            {
              localObject7 = localObject5;
              localObject6 = localObject2;
              if (localObject2 == null)
              {
                localObject7 = localObject5;
                localObject6 = localObject2;
                if (m != 0)
                {
                  localObject6 = "no";
                  localObject7 = ((String)localObject5).substring(3);
                }
              }
              localObject2 = Compilation.options.set((String)localObject7, (String)localObject6);
              k = i;
              paramInt1 = j;
              if (localObject2 == null) {
                break;
              }
              localObject5 = localObject2;
              if (m != 0)
              {
                localObject5 = localObject2;
                if (localObject2 == "unknown option name") {
                  localObject5 = "both '--no-' prefix and '=" + (String)localObject6 + "' specified";
                }
              }
              if (localObject5 != "unknown option name") {
                break label2751;
              }
              bad_option((String)localObject1);
              k = i;
              paramInt1 = j;
              break;
              localObject2 = ((String)localObject5).substring(paramInt1 + 1);
              localObject5 = ((String)localObject5).substring(0, paramInt1);
              break label2566;
            }
            label2751:
            System.err.println("kawa: bad option '" + (String)localObject1 + "': " + (String)localObject5);
            System.exit(-1);
            k = i;
            paramInt1 = j;
            break;
          }
          k = i;
          paramInt1 = j;
          if (ApplicationMainSupport.processSetProperty((String)localObject1)) {
            break;
          }
          if (i != 0) {
            paramInt1 = -1;
          } else {
            paramInt1 = j;
          }
        }
      }
    }
  }
  
  public static void setArgs(String[] paramArrayOfString, int paramInt)
  {
    ApplicationMainSupport.setArgs(paramArrayOfString, paramInt);
  }
  
  public static boolean shouldUseGuiConsole()
  {
    boolean bool = true;
    if (noConsole) {}
    for (;;)
    {
      return bool;
      try
      {
        Object localObject = Class.forName("java.lang.System").getMethod("console", new Class[0]).invoke(new Object[0], new Object[0]);
        if (localObject == null) {
          continue;
        }
      }
      catch (Throwable localThrowable)
      {
        for (;;) {}
      }
      bool = false;
    }
  }
  
  private static void startGuiConsole()
  {
    try
    {
      Class.forName("kawa.GuiConsole").newInstance();
      return;
    }
    catch (Exception localException)
    {
      for (;;)
      {
        System.err.println("failed to create Kawa window: " + localException);
        System.exit(-1);
      }
    }
  }
  
  public Object apply0()
  {
    Shell.run(this.language, Environment.getCurrent());
    return Values.empty;
  }
  
  public Object apply1(Object paramObject)
  {
    Shell.run(this.language, (Environment)paramObject);
    return Values.empty;
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AppInventorApps/MyLocationApp/dex2jar_output/MyLocationApp-dex2jar.jar!/kawa/repl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */