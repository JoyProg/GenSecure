package kawa;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.Socket;

public class Telnet
  implements Runnable
{
  public static final int DO = 253;
  public static final int DONT = 254;
  public static final int ECHO = 1;
  static final int EOF = 236;
  static final int IAC = 255;
  static final int IP = 244;
  static final int LINEMODE = 34;
  static final int NAWS = 31;
  static final int NOP = 241;
  static final int OPTION_NO = 0;
  static final int OPTION_WANTNO = 1;
  static final int OPTION_WANTNO_OPPOSITE = 2;
  static final int OPTION_WANTYES = 3;
  static final int OPTION_WANTYES_OPPOSITE = 4;
  static final int OPTION_YES = 5;
  static final int SB = 250;
  static final int SE = 240;
  public static final int SUPPRESS_GO_AHEAD = 3;
  static final int TM = 6;
  static final int TTYPE = 24;
  public static final int WILL = 251;
  public static final int WONT = 252;
  TelnetInputStream in;
  boolean isServer;
  final byte[] optionsState = new byte['Ā'];
  TelnetOutputStream out;
  final byte preferredLineMode = (byte)3;
  InputStream sin;
  OutputStream sout;
  public byte[] terminalType;
  public short windowHeight;
  public short windowWidth;
  
  public Telnet(Socket paramSocket, boolean paramBoolean)
    throws IOException
  {
    this.sin = paramSocket.getInputStream();
    this.sout = paramSocket.getOutputStream();
    this.out = new TelnetOutputStream(this.sout);
    this.in = new TelnetInputStream(this.sin, this);
    this.isServer = paramBoolean;
  }
  
  public static void main(String[] paramArrayOfString)
  {
    if (paramArrayOfString.length == 0) {
      usage();
    }
    Object localObject = paramArrayOfString[0];
    int i = 23;
    if (paramArrayOfString.length > 1) {
      i = Integer.parseInt(paramArrayOfString[1]);
    }
    for (;;)
    {
      try
      {
        paramArrayOfString = new java/net/Socket;
        paramArrayOfString.<init>((String)localObject, i);
        localObject = new kawa/Telnet;
        ((Telnet)localObject).<init>(paramArrayOfString, false);
        localTelnetOutputStream = ((Telnet)localObject).getOutputStream();
        paramArrayOfString = new java/lang/Thread;
        paramArrayOfString.<init>((Runnable)localObject);
        paramArrayOfString.setPriority(Thread.currentThread().getPriority() + 1);
        paramArrayOfString.start();
        localObject = new byte['Ѐ'];
        i = System.in.read();
        if (i < 0)
        {
          paramArrayOfString.stop();
          return;
        }
      }
      catch (Exception paramArrayOfString)
      {
        TelnetOutputStream localTelnetOutputStream;
        int j;
        System.err.println(paramArrayOfString);
        continue;
      }
      localObject[0] = ((byte)(byte)i);
      i = System.in.available();
      j = i;
      if (i > 0)
      {
        j = i;
        if (i > localObject.length - 1) {
          j = localObject.length - 1;
        }
        j = System.in.read((byte[])localObject, 1, j);
      }
      localTelnetOutputStream.write((byte[])localObject, 0, j + 1);
    }
  }
  
  static void usage()
  {
    System.err.println("Usage:  [java] kawa.Telnet HOST [PORT#]");
    System.exit(-1);
  }
  
  boolean change(int paramInt1, int paramInt2)
  {
    boolean bool1 = true;
    boolean bool2;
    if (paramInt2 == 6) {
      bool2 = bool1;
    }
    for (;;)
    {
      return bool2;
      if (this.isServer)
      {
        bool2 = bool1;
        if (paramInt2 == 31) {}
      }
      else if ((this.isServer) && (paramInt1 == 251) && (paramInt2 == 34))
      {
        try
        {
          this.out.writeSubCommand(34, new byte[] { 1, 3 });
          bool2 = bool1;
        }
        catch (IOException localIOException1)
        {
          bool2 = bool1;
        }
      }
      else if ((this.isServer) && (paramInt1 == 251) && (paramInt2 == 24))
      {
        try
        {
          this.out.writeSubCommand(paramInt2, new byte[] { 1 });
          bool2 = bool1;
        }
        catch (IOException localIOException2)
        {
          bool2 = bool1;
        }
      }
      else if ((!this.isServer) && (paramInt2 == 1))
      {
        if (paramInt1 == 253)
        {
          bool2 = false;
        }
        else
        {
          bool2 = bool1;
          if (paramInt1 == 251) {}
        }
      }
      else
      {
        bool2 = false;
      }
    }
  }
  
  public TelnetInputStream getInputStream()
  {
    return this.in;
  }
  
  public TelnetOutputStream getOutputStream()
  {
    return this.out;
  }
  
  void handle(int paramInt1, int paramInt2)
    throws IOException
  {
    int i = 1;
    int j = 254;
    int k = 253;
    int m;
    label28:
    int i1;
    if (paramInt1 < 253)
    {
      m = 1;
      if ((paramInt1 & 0x1) == 0) {
        break label135;
      }
      int n = this.optionsState[paramInt2];
      i1 = n;
      if (m != 0) {
        i1 = (byte)(n >> 3);
      }
      switch (i1 >> 3 & 0x7)
      {
      default: 
        paramInt1 = i1;
        label99:
        if (m == 0) {
          break;
        }
      }
    }
    for (paramInt1 = (byte)(this.optionsState[paramInt2] & 0xC7 | paramInt1 << 3);; paramInt1 = (byte)(this.optionsState[paramInt2] & 0xF8 | paramInt1))
    {
      this.optionsState[paramInt2] = ((byte)paramInt1);
      label135:
      do
      {
        do
        {
          return;
          m = 0;
          break;
          i = 0;
          break label28;
        } while (i != 0);
        i1 = 0;
        change(paramInt1, paramInt2);
        localTelnetOutputStream = this.out;
        if (m != 0) {}
        for (paramInt1 = 254;; paramInt1 = 252)
        {
          localTelnetOutputStream.writeCommand(paramInt1, paramInt2);
          paramInt1 = i1;
          break;
        }
      } while (i == 0);
      if (change(paramInt1, paramInt2))
      {
        i1 = 5;
        localTelnetOutputStream = this.out;
        if (m != 0) {}
        for (paramInt1 = 253;; paramInt1 = 251)
        {
          localTelnetOutputStream.writeCommand(paramInt1, paramInt2);
          paramInt1 = i1;
          break;
        }
      }
      TelnetOutputStream localTelnetOutputStream = this.out;
      if (m != 0) {}
      for (;;)
      {
        localTelnetOutputStream.writeCommand(j, paramInt2);
        paramInt1 = i1;
        break;
        j = 252;
      }
      paramInt1 = 0;
      break label99;
      i1 = 3;
      localTelnetOutputStream = this.out;
      if (m != 0) {}
      for (paramInt1 = k;; paramInt1 = 251)
      {
        localTelnetOutputStream.writeCommand(paramInt1, paramInt2);
        paramInt1 = i1;
        break;
      }
      if (i != 0)
      {
        i1 = 5;
        change(paramInt1, paramInt2);
        paramInt1 = i1;
        break label99;
      }
      paramInt1 = 0;
      break label99;
      if (i != 0)
      {
        paramInt1 = 1;
        localTelnetOutputStream = this.out;
        if (m != 0) {}
        for (;;)
        {
          localTelnetOutputStream.writeCommand(j, paramInt2);
          break;
          j = 252;
        }
      }
      paramInt1 = 0;
      break label99;
    }
  }
  
  public void request(int paramInt1, int paramInt2)
    throws IOException
  {
    int i = 1;
    int j;
    label18:
    int k;
    int m;
    if (paramInt1 >= 253)
    {
      j = 1;
      if ((paramInt1 & 0x1) == 0) {
        break label125;
      }
      k = this.optionsState[paramInt2];
      m = k;
      if (j != 0) {
        m = (byte)(k >> 3);
      }
      k = m;
      switch (m & 0x7)
      {
      default: 
        label88:
        if (j == 0) {
          break;
        }
      }
    }
    for (paramInt1 = (byte)(this.optionsState[paramInt2] & 0xC7 | m << 3);; paramInt1 = (byte)(this.optionsState[paramInt2] & 0xF8 | m))
    {
      this.optionsState[paramInt2] = ((byte)paramInt1);
      return;
      j = 0;
      break;
      label125:
      i = 0;
      break label18;
      if (i == 0) {
        break label88;
      }
      m = 3;
      this.out.writeCommand(paramInt1, paramInt2);
      break label88;
      if (i != 0) {
        break label88;
      }
      m = 1;
      this.out.writeCommand(paramInt1, paramInt2);
      break label88;
      if (i == 0) {
        break label88;
      }
      m = 2;
      break label88;
      if (i != 0) {
        break label88;
      }
      m = 1;
      break label88;
      k = m;
      if (i == 0) {
        k = 4;
      }
      m = k;
      if (i == 0) {
        break label88;
      }
      m = 3;
      break label88;
    }
  }
  
  public void run()
  {
    for (;;)
    {
      try
      {
        localTelnetInputStream = getInputStream();
        arrayOfByte = new byte['Ѐ'];
        i = localTelnetInputStream.read();
        if (i < 0) {
          return;
        }
      }
      catch (IOException localIOException)
      {
        TelnetInputStream localTelnetInputStream;
        byte[] arrayOfByte;
        int i;
        int j;
        System.err.println(localIOException);
        System.exit(-1);
        continue;
      }
      arrayOfByte[0] = ((byte)(byte)i);
      i = localTelnetInputStream.available();
      j = i;
      if (i > 0)
      {
        j = i;
        if (i > arrayOfByte.length - 1) {
          j = arrayOfByte.length - 1;
        }
        j = localTelnetInputStream.read(arrayOfByte, 1, j);
      }
      System.out.write(arrayOfByte, 0, j + 1);
    }
  }
  
  public void subCommand(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    switch (paramArrayOfByte[paramInt1])
    {
    }
    for (;;)
    {
      return;
      if (paramInt2 == 5)
      {
        this.windowWidth = ((short)(short)((paramArrayOfByte[1] << 8) + (paramArrayOfByte[2] & 0xFF)));
        this.windowHeight = ((short)(short)((paramArrayOfByte[3] << 8) + (paramArrayOfByte[4] & 0xFF)));
        continue;
        byte[] arrayOfByte = new byte[paramInt2 - 1];
        System.arraycopy(paramArrayOfByte, 1, arrayOfByte, 0, paramInt2 - 1);
        this.terminalType = arrayOfByte;
        System.err.println("terminal type: '" + new String(arrayOfByte) + "'");
        continue;
        System.err.println("SBCommand LINEMODE " + paramArrayOfByte[1] + " len:" + paramInt2);
        if (paramArrayOfByte[1] == 3) {
          for (paramInt1 = 2; paramInt1 + 2 < paramInt2; paramInt1 += 3) {
            System.err.println("  " + paramArrayOfByte[paramInt1] + "," + paramArrayOfByte[(paramInt1 + 1)] + "," + paramArrayOfByte[(paramInt1 + 2)]);
          }
        }
      }
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AppInventorApps/MyLocationApp/dex2jar_output/MyLocationApp-dex2jar.jar!/kawa/Telnet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */