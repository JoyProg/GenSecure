package androidx.lifecycle;

import androidx.annotation.RestrictTo;

@RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
public class CompositeGeneratedAdaptersObserver
  implements GenericLifecycleObserver
{
  private final GeneratedAdapter[] mGeneratedAdapters;
  
  CompositeGeneratedAdaptersObserver(GeneratedAdapter[] paramArrayOfGeneratedAdapter)
  {
    this.mGeneratedAdapters = paramArrayOfGeneratedAdapter;
  }
  
  public void onStateChanged(LifecycleOwner paramLifecycleOwner, Lifecycle.Event paramEvent)
  {
    int i = 0;
    MethodCallsLogger localMethodCallsLogger = new MethodCallsLogger();
    GeneratedAdapter[] arrayOfGeneratedAdapter = this.mGeneratedAdapters;
    int j = arrayOfGeneratedAdapter.length;
    for (int k = 0; k < j; k++) {
      arrayOfGeneratedAdapter[k].callMethods(paramLifecycleOwner, paramEvent, false, localMethodCallsLogger);
    }
    arrayOfGeneratedAdapter = this.mGeneratedAdapters;
    j = arrayOfGeneratedAdapter.length;
    for (k = i; k < j; k++) {
      arrayOfGeneratedAdapter[k].callMethods(paramLifecycleOwner, paramEvent, true, localMethodCallsLogger);
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AppInventorApps/MyLocationApp/dex2jar_output/MyLocationApp-dex2jar.jar!/androidx/lifecycle/CompositeGeneratedAdaptersObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */