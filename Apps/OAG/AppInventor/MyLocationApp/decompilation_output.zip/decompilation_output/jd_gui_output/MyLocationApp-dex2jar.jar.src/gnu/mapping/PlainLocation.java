package gnu.mapping;

public class PlainLocation
  extends NamedLocation
{
  public PlainLocation(Symbol paramSymbol, Object paramObject)
  {
    super(paramSymbol, paramObject);
  }
  
  public PlainLocation(Symbol paramSymbol, Object paramObject1, Object paramObject2)
  {
    super(paramSymbol, paramObject1);
    this.value = paramObject2;
  }
  
  public final Object get(Object paramObject)
  {
    if (this.base != null) {
      paramObject = this.base.get(paramObject);
    }
    for (;;)
    {
      return paramObject;
      if (this.value != Location.UNBOUND) {
        paramObject = this.value;
      }
    }
  }
  
  public boolean isBound()
  {
    boolean bool;
    if (this.base != null) {
      bool = this.base.isBound();
    }
    for (;;)
    {
      return bool;
      if (this.value != Location.UNBOUND) {
        bool = true;
      } else {
        bool = false;
      }
    }
  }
  
  public final void set(Object paramObject)
  {
    if (this.base == null) {
      this.value = paramObject;
    }
    for (;;)
    {
      return;
      if (this.value == DIRECT_ON_SET)
      {
        this.base = null;
        this.value = paramObject;
      }
      else if (this.base.isConstant())
      {
        getEnvironment().put(getKeySymbol(), getKeyProperty(), paramObject);
      }
      else
      {
        this.base.set(paramObject);
      }
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AppInventorApps/MyLocationApp/dex2jar_output/MyLocationApp-dex2jar.jar!/gnu/mapping/PlainLocation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */