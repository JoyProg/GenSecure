package androidx.lifecycle;

import androidx.annotation.RestrictTo;
import java.util.HashMap;
import java.util.Map;

@RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
public class MethodCallsLogger
{
  private Map<String, Integer> mCalledMethods = new HashMap();
  
  @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
  public boolean approveCall(String paramString, int paramInt)
  {
    boolean bool = true;
    Integer localInteger = (Integer)this.mCalledMethods.get(paramString);
    int i;
    int j;
    if (localInteger != null)
    {
      i = localInteger.intValue();
      if ((i & paramInt) == 0) {
        break label70;
      }
      j = 1;
      label39:
      this.mCalledMethods.put(paramString, Integer.valueOf(i | paramInt));
      if (j != 0) {
        break label76;
      }
    }
    for (;;)
    {
      return bool;
      i = 0;
      break;
      label70:
      j = 0;
      break label39;
      label76:
      bool = false;
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AppInventorApps/MyLocationApp/dex2jar_output/MyLocationApp-dex2jar.jar!/androidx/lifecycle/MethodCallsLogger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */