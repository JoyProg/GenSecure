package androidx.lifecycle;

import androidx.annotation.MainThread;
import androidx.annotation.NonNull;
import androidx.annotation.RestrictTo;
import androidx.annotation.VisibleForTesting;
import androidx.annotation.WorkerThread;
import androidx.arch.core.executor.ArchTaskExecutor;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;

@RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
public abstract class ComputableLiveData<T>
{
  final AtomicBoolean mComputing = new AtomicBoolean(false);
  final Executor mExecutor;
  final AtomicBoolean mInvalid = new AtomicBoolean(true);
  @VisibleForTesting
  final Runnable mInvalidationRunnable = new Runnable()
  {
    @MainThread
    public void run()
    {
      boolean bool = ComputableLiveData.this.mLiveData.hasActiveObservers();
      if ((ComputableLiveData.this.mInvalid.compareAndSet(false, true)) && (bool)) {
        ComputableLiveData.this.mExecutor.execute(ComputableLiveData.this.mRefreshRunnable);
      }
    }
  };
  final LiveData<T> mLiveData;
  @VisibleForTesting
  final Runnable mRefreshRunnable = new Runnable()
  {
    @WorkerThread
    public void run()
    {
      for (;;)
      {
        int i = 0;
        int j = 0;
        Object localObject1;
        if (ComputableLiveData.this.mComputing.compareAndSet(false, true))
        {
          localObject1 = null;
          i = j;
        }
        try
        {
          while (ComputableLiveData.this.mInvalid.compareAndSet(true, false))
          {
            i = 1;
            localObject1 = ComputableLiveData.this.compute();
          }
          if (i != 0) {
            ComputableLiveData.this.mLiveData.postValue(localObject1);
          }
          ComputableLiveData.this.mComputing.set(false);
          if ((i != 0) && (ComputableLiveData.this.mInvalid.get())) {
            continue;
          }
          return;
        }
        finally
        {
          ComputableLiveData.this.mComputing.set(false);
        }
      }
    }
  };
  
  public ComputableLiveData()
  {
    this(ArchTaskExecutor.getIOThreadExecutor());
  }
  
  public ComputableLiveData(@NonNull Executor paramExecutor)
  {
    this.mExecutor = paramExecutor;
    this.mLiveData = new LiveData()
    {
      protected void onActive()
      {
        ComputableLiveData.this.mExecutor.execute(ComputableLiveData.this.mRefreshRunnable);
      }
    };
  }
  
  @WorkerThread
  protected abstract T compute();
  
  @NonNull
  public LiveData<T> getLiveData()
  {
    return this.mLiveData;
  }
  
  public void invalidate()
  {
    ArchTaskExecutor.getInstance().executeOnMainThread(this.mInvalidationRunnable);
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AppInventorApps/MyLocationApp/dex2jar_output/MyLocationApp-dex2jar.jar!/androidx/lifecycle/ComputableLiveData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */