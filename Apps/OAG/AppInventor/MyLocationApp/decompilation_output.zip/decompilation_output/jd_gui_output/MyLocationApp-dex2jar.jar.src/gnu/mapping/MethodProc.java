package gnu.mapping;

import gnu.bytecode.ArrayType;
import gnu.bytecode.Type;

public abstract class MethodProc
  extends ProcedureN
{
  public static final int NO_MATCH = -1;
  public static final int NO_MATCH_AMBIGUOUS = -851968;
  public static final int NO_MATCH_BAD_TYPE = -786432;
  public static final int NO_MATCH_TOO_FEW_ARGS = -983040;
  public static final int NO_MATCH_TOO_MANY_ARGS = -917504;
  static final Type[] unknownArgTypes = { Type.pointer_type };
  protected Object argTypes;
  
  public static RuntimeException matchFailAsException(int paramInt, Procedure paramProcedure, Object[] paramArrayOfObject)
  {
    int i = (short)paramInt;
    if ((paramInt & 0xFFFF0000) != -786432)
    {
      paramProcedure = new WrongArguments(paramProcedure, paramArrayOfObject.length);
      return paramProcedure;
    }
    if (i > 0) {}
    for (paramArrayOfObject = paramArrayOfObject[(i - 1)];; paramArrayOfObject = null)
    {
      paramProcedure = new WrongType(paramProcedure, i, paramArrayOfObject);
      break;
    }
  }
  
  public static int mostSpecific(MethodProc[] paramArrayOfMethodProc, int paramInt)
  {
    if (paramInt <= 1)
    {
      i = paramInt - 1;
      return i;
    }
    Object localObject1 = paramArrayOfMethodProc[0];
    Object localObject2 = null;
    int j = 1;
    int i = 0;
    label23:
    MethodProc localMethodProc1;
    Object localObject3;
    if (j < paramInt)
    {
      localMethodProc1 = paramArrayOfMethodProc[j];
      if (localObject1 != null)
      {
        localObject3 = mostSpecific((MethodProc)localObject1, localMethodProc1);
        if (localObject3 == null)
        {
          localObject3 = localObject2;
          if (localObject2 == null) {
            localObject3 = new MethodProc[paramInt];
          }
          localObject3[0] = localObject1;
          localObject3[1] = localMethodProc1;
          i = 2;
          localObject1 = null;
          localObject2 = localObject3;
          localObject3 = localObject1;
        }
      }
    }
    for (;;)
    {
      j++;
      localObject1 = localObject3;
      break label23;
      if (localObject3 == localMethodProc1)
      {
        localObject3 = localMethodProc1;
        i = j;
        continue;
        for (int k = 0;; k++)
        {
          if (k >= i) {
            break label184;
          }
          MethodProc localMethodProc2 = localObject2[k];
          localObject3 = mostSpecific(localMethodProc2, localMethodProc1);
          if (localObject3 == localMethodProc2)
          {
            localObject3 = localObject1;
            break;
          }
          if (localObject3 == null)
          {
            k = i + 1;
            localObject2[i] = localMethodProc1;
            localObject3 = localObject1;
            i = k;
            break;
          }
        }
        label184:
        localObject3 = localMethodProc1;
        i = j;
        continue;
        if (localObject1 != null) {
          break;
        }
        i = -1;
        break;
      }
      localObject3 = localObject1;
    }
  }
  
  public static MethodProc mostSpecific(MethodProc paramMethodProc1, MethodProc paramMethodProc2)
  {
    int i = 0;
    int j = 0;
    int k = 0;
    int m = paramMethodProc1.minArgs();
    int n = paramMethodProc2.minArgs();
    int i1 = paramMethodProc1.maxArgs();
    int i2 = paramMethodProc2.maxArgs();
    if (((i1 >= 0) && (i1 < n)) || ((i2 >= 0) && (i2 < m))) {
      paramMethodProc1 = null;
    }
    for (;;)
    {
      return paramMethodProc1;
      int i3 = paramMethodProc1.numParameters();
      int i4 = paramMethodProc2.numParameters();
      if (i3 > i4)
      {
        i4 = i3;
        label82:
        i3 = k;
        if (i1 != i2)
        {
          if (i1 < 0) {
            j = 1;
          }
          i = j;
          i3 = k;
          if (i2 < 0)
          {
            i3 = 1;
            i = j;
          }
        }
        if (m >= n) {
          break label169;
        }
        j = 1;
      }
      label125:
      for (i = 0;; i++)
      {
        if (i >= i4) {
          break label210;
        }
        k = paramMethodProc1.getParameterType(i).compare(paramMethodProc2.getParameterType(i));
        if (k == -1)
        {
          i3 = 1;
          if (j != 0)
          {
            paramMethodProc1 = null;
            break;
            break label82;
            label169:
            j = i;
            if (m <= n) {
              break label125;
            }
            i3 = 1;
            j = i;
            break label125;
          }
        }
        if (k == 1)
        {
          j = 1;
          if (i3 != 0)
          {
            paramMethodProc1 = null;
            break;
          }
        }
      }
      label210:
      if (i3 == 0) {
        if (j != 0) {
          paramMethodProc1 = paramMethodProc2;
        } else {
          paramMethodProc1 = null;
        }
      }
    }
  }
  
  public Object applyN(Object[] paramArrayOfObject)
    throws Throwable
  {
    checkArgCount(this, paramArrayOfObject.length);
    CallContext localCallContext = CallContext.getInstance();
    checkN(paramArrayOfObject, localCallContext);
    return localCallContext.runUntilValue();
  }
  
  public Type getParameterType(int paramInt)
  {
    if (!(this.argTypes instanceof Type[])) {
      resolveParameterTypes();
    }
    Object localObject = (Type[])this.argTypes;
    if ((paramInt < localObject.length) && ((paramInt < localObject.length - 1) || (maxArgs() >= 0))) {
      localObject = localObject[paramInt];
    }
    for (;;)
    {
      return (Type)localObject;
      if (maxArgs() < 0)
      {
        localObject = localObject[(localObject.length - 1)];
        if ((localObject instanceof ArrayType))
        {
          localObject = ((ArrayType)localObject).getComponentType();
          continue;
        }
      }
      localObject = Type.objectType;
    }
  }
  
  public int isApplicable(Type[] paramArrayOfType)
  {
    int i = paramArrayOfType.length;
    int j = numArgs();
    if ((i < (j & 0xFFF)) || ((j >= 0) && (i > j >> 12)))
    {
      i = -1;
      return i;
    }
    j = 1;
    for (;;)
    {
      int k = i - 1;
      i = j;
      if (k < 0) {
        break;
      }
      int m = getParameterType(k).compare(paramArrayOfType[k]);
      if (m == -3)
      {
        i = -1;
        break;
      }
      i = k;
      if (m < 0)
      {
        j = 0;
        i = k;
      }
    }
  }
  
  public int numParameters()
  {
    int i = numArgs();
    int j = i >> 12;
    if (j >= 0) {}
    for (;;)
    {
      return j;
      j = (i & 0xFFF) + 1;
    }
  }
  
  protected void resolveParameterTypes()
  {
    this.argTypes = unknownArgTypes;
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AppInventorApps/MyLocationApp/dex2jar_output/MyLocationApp-dex2jar.jar!/gnu/mapping/MethodProc.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */