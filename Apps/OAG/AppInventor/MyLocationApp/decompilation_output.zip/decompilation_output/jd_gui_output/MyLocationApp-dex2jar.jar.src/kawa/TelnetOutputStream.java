package kawa;

import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class TelnetOutputStream
  extends FilterOutputStream
{
  public TelnetOutputStream(OutputStream paramOutputStream)
  {
    super(paramOutputStream);
  }
  
  public void write(int paramInt)
    throws IOException
  {
    if (paramInt == 255) {
      this.out.write(paramInt);
    }
    this.out.write(paramInt);
  }
  
  public void write(byte[] paramArrayOfByte)
    throws IOException
  {
    write(paramArrayOfByte, 0, paramArrayOfByte.length);
  }
  
  public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    int i = paramInt1 + paramInt2;
    paramInt2 = paramInt1;
    int j = paramInt1;
    paramInt1 = paramInt2;
    while (paramInt1 < i)
    {
      paramInt2 = j;
      if (paramArrayOfByte[paramInt1] == -1)
      {
        this.out.write(paramArrayOfByte, j, paramInt1 + 1 - j);
        paramInt2 = paramInt1;
      }
      paramInt1++;
      j = paramInt2;
    }
    this.out.write(paramArrayOfByte, j, i - j);
  }
  
  public void writeCommand(int paramInt)
    throws IOException
  {
    this.out.write(255);
    this.out.write(paramInt);
  }
  
  public final void writeCommand(int paramInt1, int paramInt2)
    throws IOException
  {
    this.out.write(255);
    this.out.write(paramInt1);
    this.out.write(paramInt2);
  }
  
  public final void writeDo(int paramInt)
    throws IOException
  {
    writeCommand(253, paramInt);
  }
  
  public final void writeDont(int paramInt)
    throws IOException
  {
    writeCommand(254, paramInt);
  }
  
  public final void writeSubCommand(int paramInt, byte[] paramArrayOfByte)
    throws IOException
  {
    writeCommand(250, paramInt);
    write(paramArrayOfByte);
    writeCommand(240);
  }
  
  public final void writeWill(int paramInt)
    throws IOException
  {
    writeCommand(251, paramInt);
  }
  
  public final void writeWont(int paramInt)
    throws IOException
  {
    writeCommand(252, paramInt);
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AppInventorApps/MyLocationApp/dex2jar_output/MyLocationApp-dex2jar.jar!/kawa/TelnetOutputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */