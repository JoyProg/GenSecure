package gnu.mapping;

public class Setter
  extends ProcedureN
{
  protected Procedure getter;
  
  public Setter(Procedure paramProcedure)
  {
    this.getter = paramProcedure;
    paramProcedure = paramProcedure.getName();
    if (paramProcedure != null) {
      setName("(setter " + paramProcedure + ")");
    }
  }
  
  public Object applyN(Object[] paramArrayOfObject)
    throws Throwable
  {
    this.getter.setN(paramArrayOfObject);
    return Values.empty;
  }
  
  public int numArgs()
  {
    int i = this.getter.numArgs();
    if (i < 0) {
      i++;
    }
    for (;;)
    {
      return i;
      i += 4097;
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AppInventorApps/MyLocationApp/dex2jar_output/MyLocationApp-dex2jar.jar!/gnu/mapping/Setter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */