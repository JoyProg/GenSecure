package androidx.lifecycle;

class FullLifecycleObserverAdapter
  implements GenericLifecycleObserver
{
  private final FullLifecycleObserver mObserver;
  
  FullLifecycleObserverAdapter(FullLifecycleObserver paramFullLifecycleObserver)
  {
    this.mObserver = paramFullLifecycleObserver;
  }
  
  public void onStateChanged(LifecycleOwner paramLifecycleOwner, Lifecycle.Event paramEvent)
  {
    switch (paramEvent)
    {
    default: 
    case ???: 
    case ???: 
    case ???: 
    case ???: 
    case ???: 
    case ???: 
      for (;;)
      {
        return;
        this.mObserver.onCreate(paramLifecycleOwner);
        continue;
        this.mObserver.onStart(paramLifecycleOwner);
        continue;
        this.mObserver.onResume(paramLifecycleOwner);
        continue;
        this.mObserver.onPause(paramLifecycleOwner);
        continue;
        this.mObserver.onStop(paramLifecycleOwner);
        continue;
        this.mObserver.onDestroy(paramLifecycleOwner);
      }
    }
    throw new IllegalArgumentException("ON_ANY must not been send by anybody");
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AppInventorApps/MyLocationApp/dex2jar_output/MyLocationApp-dex2jar.jar!/androidx/lifecycle/FullLifecycleObserverAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */