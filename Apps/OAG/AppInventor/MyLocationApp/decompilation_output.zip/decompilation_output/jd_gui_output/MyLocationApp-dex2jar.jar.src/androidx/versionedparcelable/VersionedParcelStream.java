package androidx.versionedparcelable;

import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcelable;
import android.util.SparseArray;
import androidx.annotation.RestrictTo;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.Iterator;
import java.util.Set;

@RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY})
class VersionedParcelStream
  extends VersionedParcel
{
  private static final int TYPE_BOOLEAN = 5;
  private static final int TYPE_BOOLEAN_ARRAY = 6;
  private static final int TYPE_DOUBLE = 7;
  private static final int TYPE_DOUBLE_ARRAY = 8;
  private static final int TYPE_FLOAT = 13;
  private static final int TYPE_FLOAT_ARRAY = 14;
  private static final int TYPE_INT = 9;
  private static final int TYPE_INT_ARRAY = 10;
  private static final int TYPE_LONG = 11;
  private static final int TYPE_LONG_ARRAY = 12;
  private static final int TYPE_NULL = 0;
  private static final int TYPE_STRING = 3;
  private static final int TYPE_STRING_ARRAY = 4;
  private static final int TYPE_SUB_BUNDLE = 1;
  private static final int TYPE_SUB_PERSISTABLE_BUNDLE = 2;
  private static final Charset UTF_16 = Charset.forName("UTF-16");
  private final SparseArray<InputBuffer> mCachedFields = new SparseArray();
  private DataInputStream mCurrentInput;
  private DataOutputStream mCurrentOutput;
  private FieldBuffer mFieldBuffer;
  private boolean mIgnoreParcelables;
  private final DataInputStream mMasterInput;
  private final DataOutputStream mMasterOutput;
  
  public VersionedParcelStream(InputStream paramInputStream, OutputStream paramOutputStream)
  {
    if (paramInputStream != null) {}
    for (paramInputStream = new DataInputStream(paramInputStream);; paramInputStream = null)
    {
      this.mMasterInput = paramInputStream;
      paramInputStream = (InputStream)localObject;
      if (paramOutputStream != null) {
        paramInputStream = new DataOutputStream(paramOutputStream);
      }
      this.mMasterOutput = paramInputStream;
      this.mCurrentInput = this.mMasterInput;
      this.mCurrentOutput = this.mMasterOutput;
      return;
    }
  }
  
  private void readObject(int paramInt, String paramString, Bundle paramBundle)
  {
    switch (paramInt)
    {
    default: 
      throw new RuntimeException("Unknown type " + paramInt);
    case 0: 
      paramBundle.putParcelable(paramString, null);
    }
    for (;;)
    {
      return;
      paramBundle.putBundle(paramString, readBundle());
      continue;
      paramBundle.putBundle(paramString, readBundle());
      continue;
      paramBundle.putString(paramString, readString());
      continue;
      paramBundle.putStringArray(paramString, (String[])readArray(new String[0]));
      continue;
      paramBundle.putBoolean(paramString, readBoolean());
      continue;
      paramBundle.putBooleanArray(paramString, readBooleanArray());
      continue;
      paramBundle.putDouble(paramString, readDouble());
      continue;
      paramBundle.putDoubleArray(paramString, readDoubleArray());
      continue;
      paramBundle.putInt(paramString, readInt());
      continue;
      paramBundle.putIntArray(paramString, readIntArray());
      continue;
      paramBundle.putLong(paramString, readLong());
      continue;
      paramBundle.putLongArray(paramString, readLongArray());
      continue;
      paramBundle.putFloat(paramString, readFloat());
      continue;
      paramBundle.putFloatArray(paramString, readFloatArray());
    }
  }
  
  private void writeObject(Object paramObject)
  {
    if (paramObject == null) {
      writeInt(0);
    }
    for (;;)
    {
      return;
      if ((paramObject instanceof Bundle))
      {
        writeInt(1);
        writeBundle((Bundle)paramObject);
      }
      else if ((paramObject instanceof String))
      {
        writeInt(3);
        writeString((String)paramObject);
      }
      else if ((paramObject instanceof String[]))
      {
        writeInt(4);
        writeArray((String[])paramObject);
      }
      else if ((paramObject instanceof Boolean))
      {
        writeInt(5);
        writeBoolean(((Boolean)paramObject).booleanValue());
      }
      else if ((paramObject instanceof boolean[]))
      {
        writeInt(6);
        writeBooleanArray((boolean[])paramObject);
      }
      else if ((paramObject instanceof Double))
      {
        writeInt(7);
        writeDouble(((Double)paramObject).doubleValue());
      }
      else if ((paramObject instanceof double[]))
      {
        writeInt(8);
        writeDoubleArray((double[])paramObject);
      }
      else if ((paramObject instanceof Integer))
      {
        writeInt(9);
        writeInt(((Integer)paramObject).intValue());
      }
      else if ((paramObject instanceof int[]))
      {
        writeInt(10);
        writeIntArray((int[])paramObject);
      }
      else if ((paramObject instanceof Long))
      {
        writeInt(11);
        writeLong(((Long)paramObject).longValue());
      }
      else if ((paramObject instanceof long[]))
      {
        writeInt(12);
        writeLongArray((long[])paramObject);
      }
      else if ((paramObject instanceof Float))
      {
        writeInt(13);
        writeFloat(((Float)paramObject).floatValue());
      }
      else
      {
        if (!(paramObject instanceof float[])) {
          break;
        }
        writeInt(14);
        writeFloatArray((float[])paramObject);
      }
    }
    throw new IllegalArgumentException("Unsupported type " + paramObject.getClass());
  }
  
  public void closeField()
  {
    if (this.mFieldBuffer != null) {}
    try
    {
      if (this.mFieldBuffer.mOutput.size() != 0) {
        this.mFieldBuffer.flushField();
      }
      this.mFieldBuffer = null;
      return;
    }
    catch (IOException localIOException)
    {
      throw new VersionedParcel.ParcelException(localIOException);
    }
  }
  
  protected VersionedParcel createSubParcel()
  {
    return new VersionedParcelStream(this.mCurrentInput, this.mCurrentOutput);
  }
  
  public boolean isStream()
  {
    return true;
  }
  
  public boolean readBoolean()
  {
    try
    {
      boolean bool = this.mCurrentInput.readBoolean();
      return bool;
    }
    catch (IOException localIOException)
    {
      throw new VersionedParcel.ParcelException(localIOException);
    }
  }
  
  public Bundle readBundle()
  {
    int i = readInt();
    Object localObject;
    if (i < 0)
    {
      localObject = null;
      return (Bundle)localObject;
    }
    Bundle localBundle = new Bundle();
    for (int j = 0;; j++)
    {
      localObject = localBundle;
      if (j >= i) {
        break;
      }
      localObject = readString();
      readObject(readInt(), (String)localObject, localBundle);
    }
  }
  
  /* Error */
  public byte[] readByteArray()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 98	androidx/versionedparcelable/VersionedParcelStream:mCurrentInput	Ljava/io/DataInputStream;
    //   4: invokevirtual 372	java/io/DataInputStream:readInt	()I
    //   7: istore_1
    //   8: iload_1
    //   9: ifle +17 -> 26
    //   12: iload_1
    //   13: newarray <illegal type>
    //   15: astore_2
    //   16: aload_0
    //   17: getfield 98	androidx/versionedparcelable/VersionedParcelStream:mCurrentInput	Ljava/io/DataInputStream;
    //   20: aload_2
    //   21: invokevirtual 376	java/io/DataInputStream:readFully	([B)V
    //   24: aload_2
    //   25: areturn
    //   26: aconst_null
    //   27: astore_2
    //   28: goto -4 -> 24
    //   31: astore_2
    //   32: new 357	androidx/versionedparcelable/VersionedParcel$ParcelException
    //   35: dup
    //   36: aload_2
    //   37: invokespecial 360	androidx/versionedparcelable/VersionedParcel$ParcelException:<init>	(Ljava/lang/Throwable;)V
    //   40: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	41	0	this	VersionedParcelStream
    //   7	6	1	i	int
    //   15	13	2	arrayOfByte	byte[]
    //   31	6	2	localIOException	IOException
    // Exception table:
    //   from	to	target	type
    //   0	8	31	java/io/IOException
    //   12	24	31	java/io/IOException
  }
  
  public double readDouble()
  {
    try
    {
      double d = this.mCurrentInput.readDouble();
      return d;
    }
    catch (IOException localIOException)
    {
      throw new VersionedParcel.ParcelException(localIOException);
    }
  }
  
  public boolean readField(int paramInt)
  {
    boolean bool = true;
    InputBuffer localInputBuffer = (InputBuffer)this.mCachedFields.get(paramInt);
    if (localInputBuffer != null)
    {
      this.mCachedFields.remove(paramInt);
      this.mCurrentInput = localInputBuffer.mInputStream;
      return bool;
    }
    for (;;)
    {
      try
      {
        this.mCachedFields.put(localInputBuffer.mFieldId, localInputBuffer);
      }
      catch (IOException localIOException1)
      {
        try
        {
          int i = this.mMasterInput.readInt();
          int j = i & 0xFFFF;
          int k = j;
          if (j == 65535) {
            k = this.mMasterInput.readInt();
          }
          localInputBuffer = new androidx/versionedparcelable/VersionedParcelStream$InputBuffer;
          localInputBuffer.<init>(i >> 16 & 0xFFFF, k, this.mMasterInput);
          if (localInputBuffer.mFieldId != paramInt) {
            continue;
          }
          this.mCurrentInput = localInputBuffer.mInputStream;
        }
        catch (IOException localIOException2)
        {
          continue;
        }
        localIOException1 = localIOException1;
        bool = false;
      }
      break;
    }
  }
  
  public float readFloat()
  {
    try
    {
      float f = this.mCurrentInput.readFloat();
      return f;
    }
    catch (IOException localIOException)
    {
      throw new VersionedParcel.ParcelException(localIOException);
    }
  }
  
  public int readInt()
  {
    try
    {
      int i = this.mCurrentInput.readInt();
      return i;
    }
    catch (IOException localIOException)
    {
      throw new VersionedParcel.ParcelException(localIOException);
    }
  }
  
  public long readLong()
  {
    try
    {
      long l = this.mCurrentInput.readLong();
      return l;
    }
    catch (IOException localIOException)
    {
      throw new VersionedParcel.ParcelException(localIOException);
    }
  }
  
  public <T extends Parcelable> T readParcelable()
  {
    return null;
  }
  
  /* Error */
  public String readString()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 98	androidx/versionedparcelable/VersionedParcelStream:mCurrentInput	Ljava/io/DataInputStream;
    //   4: invokevirtual 372	java/io/DataInputStream:readInt	()I
    //   7: istore_1
    //   8: iload_1
    //   9: ifle +29 -> 38
    //   12: iload_1
    //   13: newarray <illegal type>
    //   15: astore_2
    //   16: aload_0
    //   17: getfield 98	androidx/versionedparcelable/VersionedParcelStream:mCurrentInput	Ljava/io/DataInputStream;
    //   20: aload_2
    //   21: invokevirtual 376	java/io/DataInputStream:readFully	([B)V
    //   24: new 146	java/lang/String
    //   27: dup
    //   28: aload_2
    //   29: getstatic 72	androidx/versionedparcelable/VersionedParcelStream:UTF_16	Ljava/nio/charset/Charset;
    //   32: invokespecial 409	java/lang/String:<init>	([BLjava/nio/charset/Charset;)V
    //   35: astore_2
    //   36: aload_2
    //   37: areturn
    //   38: aconst_null
    //   39: astore_2
    //   40: goto -4 -> 36
    //   43: astore_2
    //   44: new 357	androidx/versionedparcelable/VersionedParcel$ParcelException
    //   47: dup
    //   48: aload_2
    //   49: invokespecial 360	androidx/versionedparcelable/VersionedParcel$ParcelException:<init>	(Ljava/lang/Throwable;)V
    //   52: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	53	0	this	VersionedParcelStream
    //   7	6	1	i	int
    //   15	25	2	localObject	Object
    //   43	6	2	localIOException	IOException
    // Exception table:
    //   from	to	target	type
    //   0	8	43	java/io/IOException
    //   12	36	43	java/io/IOException
  }
  
  public IBinder readStrongBinder()
  {
    return null;
  }
  
  public void setOutputField(int paramInt)
  {
    closeField();
    this.mFieldBuffer = new FieldBuffer(paramInt, this.mMasterOutput);
    this.mCurrentOutput = this.mFieldBuffer.mDataStream;
  }
  
  public void setSerializationFlags(boolean paramBoolean1, boolean paramBoolean2)
  {
    if (!paramBoolean1) {
      throw new RuntimeException("Serialization of this object is not allowed");
    }
    this.mIgnoreParcelables = paramBoolean2;
  }
  
  public void writeBoolean(boolean paramBoolean)
  {
    try
    {
      this.mCurrentOutput.writeBoolean(paramBoolean);
      return;
    }
    catch (IOException localIOException)
    {
      throw new VersionedParcel.ParcelException(localIOException);
    }
  }
  
  public void writeBundle(Bundle paramBundle)
  {
    if (paramBundle != null) {
      try
      {
        Object localObject = paramBundle.keySet();
        this.mCurrentOutput.writeInt(((Set)localObject).size());
        localObject = ((Set)localObject).iterator();
        while (((Iterator)localObject).hasNext())
        {
          String str = (String)((Iterator)localObject).next();
          writeString(str);
          writeObject(paramBundle.get(str));
          continue;
          this.mCurrentOutput.writeInt(-1);
        }
      }
      catch (IOException paramBundle)
      {
        throw new VersionedParcel.ParcelException(paramBundle);
      }
    }
  }
  
  public void writeByteArray(byte[] paramArrayOfByte)
  {
    if (paramArrayOfByte != null) {}
    for (;;)
    {
      try
      {
        this.mCurrentOutput.writeInt(paramArrayOfByte.length);
        this.mCurrentOutput.write(paramArrayOfByte);
        return;
      }
      catch (IOException paramArrayOfByte)
      {
        throw new VersionedParcel.ParcelException(paramArrayOfByte);
      }
      this.mCurrentOutput.writeInt(-1);
    }
  }
  
  public void writeByteArray(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    if (paramArrayOfByte != null) {}
    for (;;)
    {
      try
      {
        this.mCurrentOutput.writeInt(paramInt2);
        this.mCurrentOutput.write(paramArrayOfByte, paramInt1, paramInt2);
        return;
      }
      catch (IOException paramArrayOfByte)
      {
        throw new VersionedParcel.ParcelException(paramArrayOfByte);
      }
      this.mCurrentOutput.writeInt(-1);
    }
  }
  
  public void writeDouble(double paramDouble)
  {
    try
    {
      this.mCurrentOutput.writeDouble(paramDouble);
      return;
    }
    catch (IOException localIOException)
    {
      throw new VersionedParcel.ParcelException(localIOException);
    }
  }
  
  public void writeFloat(float paramFloat)
  {
    try
    {
      this.mCurrentOutput.writeFloat(paramFloat);
      return;
    }
    catch (IOException localIOException)
    {
      throw new VersionedParcel.ParcelException(localIOException);
    }
  }
  
  public void writeInt(int paramInt)
  {
    try
    {
      this.mCurrentOutput.writeInt(paramInt);
      return;
    }
    catch (IOException localIOException)
    {
      throw new VersionedParcel.ParcelException(localIOException);
    }
  }
  
  public void writeLong(long paramLong)
  {
    try
    {
      this.mCurrentOutput.writeLong(paramLong);
      return;
    }
    catch (IOException localIOException)
    {
      throw new VersionedParcel.ParcelException(localIOException);
    }
  }
  
  public void writeParcelable(Parcelable paramParcelable)
  {
    if (!this.mIgnoreParcelables) {
      throw new RuntimeException("Parcelables cannot be written to an OutputStream");
    }
  }
  
  public void writeString(String paramString)
  {
    if (paramString != null) {}
    for (;;)
    {
      try
      {
        paramString = paramString.getBytes(UTF_16);
        this.mCurrentOutput.writeInt(paramString.length);
        this.mCurrentOutput.write(paramString);
        return;
      }
      catch (IOException paramString)
      {
        throw new VersionedParcel.ParcelException(paramString);
      }
      this.mCurrentOutput.writeInt(-1);
    }
  }
  
  public void writeStrongBinder(IBinder paramIBinder)
  {
    if (!this.mIgnoreParcelables) {
      throw new RuntimeException("Binders cannot be written to an OutputStream");
    }
  }
  
  public void writeStrongInterface(IInterface paramIInterface)
  {
    if (!this.mIgnoreParcelables) {
      throw new RuntimeException("Binders cannot be written to an OutputStream");
    }
  }
  
  private static class FieldBuffer
  {
    final DataOutputStream mDataStream = new DataOutputStream(this.mOutput);
    private final int mFieldId;
    final ByteArrayOutputStream mOutput = new ByteArrayOutputStream();
    private final DataOutputStream mTarget;
    
    FieldBuffer(int paramInt, DataOutputStream paramDataOutputStream)
    {
      this.mFieldId = paramInt;
      this.mTarget = paramDataOutputStream;
    }
    
    void flushField()
      throws IOException
    {
      this.mDataStream.flush();
      int i = this.mOutput.size();
      int j = this.mFieldId;
      if (i >= 65535) {}
      for (int k = 65535;; k = i)
      {
        this.mTarget.writeInt(j << 16 | k);
        if (i >= 65535) {
          this.mTarget.writeInt(i);
        }
        this.mOutput.writeTo(this.mTarget);
        return;
      }
    }
  }
  
  private static class InputBuffer
  {
    final int mFieldId;
    final DataInputStream mInputStream;
    private final int mSize;
    
    InputBuffer(int paramInt1, int paramInt2, DataInputStream paramDataInputStream)
      throws IOException
    {
      this.mSize = paramInt2;
      this.mFieldId = paramInt1;
      byte[] arrayOfByte = new byte[this.mSize];
      paramDataInputStream.readFully(arrayOfByte);
      this.mInputStream = new DataInputStream(new ByteArrayInputStream(arrayOfByte));
    }
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AppInventorApps/MyLocationApp/dex2jar_output/MyLocationApp-dex2jar.jar!/androidx/versionedparcelable/VersionedParcelStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */