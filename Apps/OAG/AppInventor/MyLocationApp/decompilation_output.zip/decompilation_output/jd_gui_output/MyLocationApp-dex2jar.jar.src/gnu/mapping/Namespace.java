package gnu.mapping;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.io.ObjectStreamException;
import java.util.Hashtable;

public class Namespace
  implements Externalizable, HasNamedParts
{
  public static final Namespace EmptyNamespace = valueOf("");
  protected static final Hashtable nsTable = new Hashtable(50);
  int log2Size;
  private int mask;
  String name;
  int num_bindings;
  protected String prefix = "";
  protected SymbolRef[] table;
  
  protected Namespace()
  {
    this(64);
  }
  
  protected Namespace(int paramInt)
  {
    for (this.log2Size = 4; paramInt > 1 << this.log2Size; this.log2Size += 1) {}
    paramInt = 1 << this.log2Size;
    this.table = new SymbolRef[paramInt];
    this.mask = (paramInt - 1);
  }
  
  public static Namespace create()
  {
    return new Namespace(64);
  }
  
  public static Namespace create(int paramInt)
  {
    return new Namespace(paramInt);
  }
  
  public static Namespace getDefault()
  {
    return EmptyNamespace;
  }
  
  public static Symbol getDefaultSymbol(String paramString)
  {
    return EmptyNamespace.getSymbol(paramString);
  }
  
  public static Namespace makeUnknownNamespace(String paramString)
  {
    if ((paramString == null) || (paramString == "")) {}
    for (String str = "";; str = "http://kawa.gnu.org/unknown-namespace/" + paramString) {
      return valueOf(str, paramString);
    }
  }
  
  public static Namespace valueOf()
  {
    return EmptyNamespace;
  }
  
  public static Namespace valueOf(String paramString)
  {
    String str = paramString;
    if (paramString == null) {
      str = "";
    }
    synchronized (nsTable)
    {
      paramString = (Namespace)nsTable.get(str);
      if (paramString != null) {
        return paramString;
      }
      paramString = new gnu/mapping/Namespace;
      paramString.<init>();
      paramString.setName(str.intern());
      nsTable.put(str, paramString);
    }
  }
  
  public static Namespace valueOf(String paramString, SimpleSymbol paramSimpleSymbol)
  {
    if (paramSimpleSymbol == null) {}
    for (paramSimpleSymbol = null;; paramSimpleSymbol = paramSimpleSymbol.getName()) {
      return valueOf(paramString, paramSimpleSymbol);
    }
  }
  
  public static Namespace valueOf(String paramString1, String paramString2)
  {
    if ((paramString2 == null) || (paramString2.length() == 0)) {}
    Object localObject;
    for (paramString1 = valueOf(paramString1);; paramString1 = (String)localObject)
    {
      String str;
      for (;;)
      {
        return paramString1;
        str = paramString2 + " -> " + paramString1;
        synchronized (nsTable)
        {
          localObject = nsTable.get(str);
          if ((localObject instanceof Namespace)) {
            paramString1 = (Namespace)localObject;
          }
        }
      }
      localObject = new gnu/mapping/Namespace;
      ((Namespace)localObject).<init>();
      ((Namespace)localObject).setName(paramString1.intern());
      ((Namespace)localObject).prefix = paramString2.intern();
      nsTable.put(str, localObject);
    }
  }
  
  public Symbol add(Symbol paramSymbol, int paramInt)
  {
    paramInt &= this.mask;
    SymbolRef localSymbolRef = new SymbolRef(paramSymbol, this);
    paramSymbol.namespace = this;
    localSymbolRef.next = this.table[paramInt];
    this.table[paramInt] = localSymbolRef;
    this.num_bindings += 1;
    if (this.num_bindings >= this.table.length) {
      rehash();
    }
    return paramSymbol;
  }
  
  public Object get(String paramString)
  {
    return Environment.getCurrent().get(getSymbol(paramString));
  }
  
  public final String getName()
  {
    return this.name;
  }
  
  public final String getPrefix()
  {
    return this.prefix;
  }
  
  public Symbol getSymbol(String paramString)
  {
    return lookup(paramString, paramString.hashCode(), true);
  }
  
  public boolean isConstant(String paramString)
  {
    return false;
  }
  
  public Symbol lookup(String paramString)
  {
    return lookup(paramString, paramString.hashCode(), false);
  }
  
  public Symbol lookup(String paramString, int paramInt, boolean paramBoolean)
  {
    for (;;)
    {
      try
      {
        Object localObject = lookupInternal(paramString, paramInt);
        if (localObject != null)
        {
          paramString = (String)localObject;
          return paramString;
        }
        if (!paramBoolean) {
          break label77;
        }
        if (this == EmptyNamespace)
        {
          localObject = new gnu/mapping/SimpleSymbol;
          ((SimpleSymbol)localObject).<init>(paramString);
          paramString = (String)localObject;
          paramString = add(paramString, paramInt);
          continue;
        }
        paramString = new Symbol(this, paramString);
      }
      finally {}
      continue;
      label77:
      paramString = null;
    }
  }
  
  protected final Symbol lookupInternal(String paramString, int paramInt)
  {
    paramInt &= this.mask;
    Object localObject1 = null;
    Object localObject2 = this.table[paramInt];
    Symbol localSymbol;
    if (localObject2 != null)
    {
      SymbolRef localSymbolRef = ((SymbolRef)localObject2).next;
      localSymbol = ((SymbolRef)localObject2).getSymbol();
      if (localSymbol == null)
      {
        if (localObject1 == null) {
          this.table[paramInt] = localSymbolRef;
        }
        for (;;)
        {
          this.num_bindings -= 1;
          localObject2 = localSymbolRef;
          break;
          ((SymbolRef)localObject1).next = localSymbolRef;
        }
      }
      if (!localSymbol.getLocalPart().equals(paramString)) {}
    }
    for (paramString = localSymbol;; paramString = null)
    {
      return paramString;
      localObject1 = localObject2;
      break;
    }
  }
  
  public void readExternal(ObjectInput paramObjectInput)
    throws IOException, ClassNotFoundException
  {
    this.name = ((String)paramObjectInput.readObject()).intern();
    this.prefix = ((String)paramObjectInput.readObject());
  }
  
  public Object readResolve()
    throws ObjectStreamException
  {
    Object localObject = getName();
    Namespace localNamespace;
    if (localObject != null) {
      if ((this.prefix == null) || (this.prefix.length() == 0))
      {
        localNamespace = (Namespace)nsTable.get(localObject);
        if (localNamespace == null) {
          break label75;
        }
      }
    }
    for (localObject = localNamespace;; localObject = this)
    {
      return localObject;
      localObject = this.prefix + " -> " + (String)localObject;
      break;
      label75:
      nsTable.put(localObject, this);
    }
  }
  
  protected void rehash()
  {
    int i = this.table.length;
    int j = i * 2;
    int k = j - 1;
    int m = 0;
    SymbolRef[] arrayOfSymbolRef1 = this.table;
    SymbolRef[] arrayOfSymbolRef2 = new SymbolRef[j];
    int n = i - 1;
    if (n >= 0)
    {
      Object localObject = arrayOfSymbolRef1[n];
      for (j = m;; j = i)
      {
        m = j;
        i = n;
        if (localObject == null) {
          break;
        }
        SymbolRef localSymbolRef = ((SymbolRef)localObject).next;
        Symbol localSymbol = ((SymbolRef)localObject).getSymbol();
        i = j;
        if (localSymbol != null)
        {
          m = localSymbol.getName().hashCode() & k;
          i = j + 1;
          ((SymbolRef)localObject).next = arrayOfSymbolRef2[m];
          arrayOfSymbolRef2[m] = localObject;
        }
        localObject = localSymbolRef;
      }
    }
    this.table = arrayOfSymbolRef2;
    this.log2Size += 1;
    this.mask = k;
    this.num_bindings = m;
  }
  
  public boolean remove(Symbol paramSymbol)
  {
    for (;;)
    {
      SymbolRef localSymbolRef;
      try
      {
        int i = paramSymbol.getLocalPart().hashCode() & this.mask;
        Object localObject1 = null;
        localObject2 = this.table[i];
        if (localObject2 == null) {
          break label114;
        }
        localSymbolRef = ((SymbolRef)localObject2).next;
        Symbol localSymbol = ((SymbolRef)localObject2).getSymbol();
        if ((localSymbol == null) || (localSymbol == paramSymbol))
        {
          if (localObject1 == null)
          {
            this.table[i] = localSymbolRef;
            this.num_bindings -= 1;
            if (localSymbol != null)
            {
              bool = true;
              return bool;
            }
          }
          else
          {
            ((SymbolRef)localObject1).next = localSymbolRef;
            continue;
          }
        }
        else {
          localObject1 = localObject2;
        }
      }
      finally {}
      Object localObject2 = localSymbolRef;
      continue;
      label114:
      boolean bool = false;
    }
  }
  
  public final void setName(String paramString)
  {
    this.name = paramString;
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder("#,(namespace \"");
    localStringBuilder.append(this.name);
    localStringBuilder.append('"');
    if ((this.prefix != null) && (this.prefix != ""))
    {
      localStringBuilder.append(' ');
      localStringBuilder.append(this.prefix);
    }
    localStringBuilder.append(')');
    return localStringBuilder.toString();
  }
  
  public void writeExternal(ObjectOutput paramObjectOutput)
    throws IOException
  {
    paramObjectOutput.writeObject(getName());
    paramObjectOutput.writeObject(this.prefix);
  }
}


/* Location:              /Users/joyidialu/Documents/MMath/CS 858/cs858_project/apps/OAG_Apps/AppInventorApps/MyLocationApp/dex2jar_output/MyLocationApp-dex2jar.jar!/gnu/mapping/Namespace.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */