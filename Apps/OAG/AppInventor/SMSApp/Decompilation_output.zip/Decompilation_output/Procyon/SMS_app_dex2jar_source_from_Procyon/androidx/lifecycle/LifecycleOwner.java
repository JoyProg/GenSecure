// 
// Decompiled by Procyon v0.5.36
// 

package androidx.lifecycle;

import androidx.annotation.NonNull;

public interface LifecycleOwner
{
    @NonNull
    Lifecycle getLifecycle();
}
