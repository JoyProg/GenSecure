// 
// Decompiled by Procyon v0.5.36
// 

package kawa;

import java.io.IOException;
import java.io.InputStream;
import java.io.FilterInputStream;

public class TelnetInputStream extends FilterInputStream
{
    static final int SB_IAC = 400;
    protected byte[] buf;
    Telnet connection;
    int count;
    int pos;
    int state;
    int subCommandLength;
    
    public TelnetInputStream(final InputStream in, final Telnet connection) throws IOException {
        super(in);
        this.state = 0;
        this.subCommandLength = 0;
        this.buf = new byte[512];
        this.connection = connection;
    }
    
    @Override
    public int read() throws IOException {
        Block_7: {
            int n;
            while (true) {
                if (this.pos >= this.count) {
                    final int available = this.in.available();
                    int len;
                    if (available <= 0) {
                        len = 1;
                    }
                    else if ((len = available) > this.buf.length - this.subCommandLength) {
                        len = this.buf.length - this.subCommandLength;
                    }
                    final int read = this.in.read(this.buf, this.subCommandLength, len);
                    this.pos = this.subCommandLength;
                    if ((this.count = read) <= 0) {
                        n = -1;
                        break;
                    }
                }
                final int state = this.buf[this.pos++] & 0xFF;
                if (this.state == 0) {
                    if ((n = state) != 255) {
                        break;
                    }
                    this.state = 255;
                }
                else if (this.state == 255) {
                    if (state == 255) {
                        break Block_7;
                    }
                    if (state == 251 || state == 252 || state == 253 || state == 254 || state == 250) {
                        this.state = state;
                    }
                    else if (state == 244) {
                        System.err.println("Interrupt Process");
                        this.state = 0;
                    }
                    else {
                        if (state == 236) {
                            return -1;
                        }
                        this.state = 0;
                    }
                }
                else if (this.state == 251 || this.state == 252 || this.state == 253 || this.state == 254) {
                    this.connection.handle(this.state, state);
                    this.state = 0;
                }
                else if (this.state == 250) {
                    if (state == 255) {
                        this.state = 400;
                    }
                    else {
                        this.buf[this.subCommandLength++] = (byte)state;
                    }
                }
                else if (this.state == 400) {
                    if (state == 255) {
                        this.buf[this.subCommandLength++] = (byte)state;
                        this.state = 250;
                    }
                    else if (state == 240) {
                        this.connection.subCommand(this.buf, 0, this.subCommandLength);
                        this.state = 0;
                        this.subCommandLength = 0;
                    }
                    else {
                        this.state = 0;
                        this.subCommandLength = 0;
                    }
                }
                else {
                    System.err.println("Bad state " + this.state);
                }
            }
            return n;
        }
        this.state = 0;
        return 255;
        n = -1;
        return n;
    }
    
    @Override
    public int read(final byte[] array, int n, final int n2) throws IOException {
        int n3;
        if (n2 <= 0) {
            n3 = 0;
        }
        else {
            int n4 = 0;
            int n5 = 0;
            Label_0066: {
                if (this.state == 0) {
                    n5 = n;
                    if (this.pos < this.count) {
                        break Label_0066;
                    }
                }
                final int read = this.read();
                if ((n3 = read) < 0) {
                    return n3;
                }
                array[n] = (byte)read;
                n4 = 0 + 1;
                n5 = n + 1;
            }
            n = n4;
            if (this.state == 0) {
                while (true) {
                    n = n4;
                    if (this.pos >= this.count || (n = n4) >= n2) {
                        break;
                    }
                    n = this.buf[this.pos];
                    if (n == -1) {
                        n = n4;
                        break;
                    }
                    array[n5] = (byte)n;
                    ++n4;
                    ++this.pos;
                    ++n5;
                }
            }
            n3 = n;
        }
        return n3;
    }
}
