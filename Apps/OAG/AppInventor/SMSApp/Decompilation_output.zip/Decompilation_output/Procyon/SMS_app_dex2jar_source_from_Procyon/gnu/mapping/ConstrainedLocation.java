// 
// Decompiled by Procyon v0.5.36
// 

package gnu.mapping;

public class ConstrainedLocation extends Location
{
    protected Location base;
    protected Procedure converter;
    
    public static ConstrainedLocation make(final Location base, final Procedure converter) {
        final ConstrainedLocation constrainedLocation = new ConstrainedLocation();
        constrainedLocation.base = base;
        constrainedLocation.converter = converter;
        return constrainedLocation;
    }
    
    protected Object coerce(Object apply1) {
        try {
            apply1 = this.converter.apply1(apply1);
            return apply1;
        }
        catch (Throwable t) {
            throw WrappedException.wrapIfNeeded(t);
        }
    }
    
    @Override
    public final Object get(final Object o) {
        return this.base.get(o);
    }
    
    @Override
    public Object getKeyProperty() {
        return this.base.getKeyProperty();
    }
    
    @Override
    public Symbol getKeySymbol() {
        return this.base.getKeySymbol();
    }
    
    @Override
    public boolean isBound() {
        return this.base.isBound();
    }
    
    @Override
    public boolean isConstant() {
        return this.base.isConstant();
    }
    
    @Override
    public final void set(final Object o) {
        this.base.set(this.coerce(o));
    }
    
    @Override
    public void setRestore(final Object restore) {
        this.base.setRestore(restore);
    }
    
    @Override
    public Object setWithSave(final Object o) {
        return this.base.setWithSave(this.coerce(o));
    }
}
