// 
// Decompiled by Procyon v0.5.36
// 

package kawa;

import javax.swing.text.StyleConstants;
import gnu.kawa.models.Viewable;
import javax.swing.text.MutableAttributeSet;
import javax.swing.text.SimpleAttributeSet;
import gnu.kawa.models.Paintable;
import java.awt.Component;
import java.io.Writer;
import gnu.text.Path;
import javax.swing.text.AttributeSet;
import gnu.mapping.OutPort;

public class ReplPaneOutPort extends OutPort
{
    ReplDocument document;
    String str;
    AttributeSet style;
    TextPaneWriter tout;
    
    public ReplPaneOutPort(final ReplDocument replDocument, final String s, final AttributeSet set) {
        this(new TextPaneWriter(replDocument, set), replDocument, s, set);
    }
    
    ReplPaneOutPort(final TextPaneWriter tout, final ReplDocument document, final String s, final AttributeSet style) {
        super(tout, true, true, Path.valueOf(s));
        this.str = "";
        this.tout = tout;
        this.document = document;
        this.style = style;
    }
    
    @Override
    public void print(final Object o) {
        if (o instanceof Component) {
            this.write((Component)o);
        }
        else if (o instanceof Paintable) {
            final SimpleAttributeSet set = new SimpleAttributeSet();
            set.addAttribute("$ename", "Paintable");
            set.addAttribute(ReplPane.PaintableAttribute, o);
            this.write(" ", set);
        }
        else if (o instanceof Viewable) {
            final SimpleAttributeSet set2 = new SimpleAttributeSet();
            set2.addAttribute("$ename", "Viewable");
            set2.addAttribute(ReplPane.ViewableAttribute, o);
            this.write(" ", set2);
        }
        else {
            super.print(o);
        }
    }
    
    public void write(final Component c) {
        synchronized (this) {
            final SimpleAttributeSet a = new SimpleAttributeSet();
            StyleConstants.setComponent(a, c);
            this.write(" ", a);
        }
    }
    
    public void write(final String s, final MutableAttributeSet set) {
        this.flush();
        this.document.write(s, set);
        this.setColumnNumber(1);
    }
}
