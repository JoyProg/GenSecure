// 
// Decompiled by Procyon v0.5.36
// 

package androidx.lifecycle;

import java.util.HashMap;
import java.util.Map;
import androidx.annotation.RestrictTo;

@RestrictTo({ RestrictTo.Scope.LIBRARY_GROUP })
public class MethodCallsLogger
{
    private Map<String, Integer> mCalledMethods;
    
    public MethodCallsLogger() {
        this.mCalledMethods = new HashMap<String, Integer>();
    }
    
    @RestrictTo({ RestrictTo.Scope.LIBRARY_GROUP })
    public boolean approveCall(final String s, final int n) {
        boolean b = true;
        final Integer n2 = this.mCalledMethods.get(s);
        int intValue;
        if (n2 != null) {
            intValue = n2;
        }
        else {
            intValue = 0;
        }
        int n3;
        if ((intValue & n) != 0x0) {
            n3 = 1;
        }
        else {
            n3 = 0;
        }
        this.mCalledMethods.put(s, intValue | n);
        if (n3 != 0) {
            b = false;
        }
        return b;
    }
}
