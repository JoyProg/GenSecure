// 
// Decompiled by Procyon v0.5.36
// 

package kawa;

import gnu.mapping.Values;
import gnu.expr.ApplicationMainSupport;
import java.util.ArrayList;
import java.io.PrintStream;
import gnu.expr.ModuleBody;
import gnu.mapping.OutPort;
import gnu.expr.Compilation;
import gnu.mapping.Environment;
import java.io.File;
import gnu.lists.FString;
import gnu.text.WriterManager;
import gnu.expr.Language;
import gnu.mapping.Procedure0or1;

public class repl extends Procedure0or1
{
    public static String compilationTopname;
    static int defaultParseOptions;
    public static String homeDirectory;
    public static boolean noConsole;
    static Language previousLanguage;
    static boolean shutdownRegistered;
    Language language;
    
    static {
        repl.compilationTopname = null;
        repl.defaultParseOptions = 72;
        repl.shutdownRegistered = WriterManager.instance.registerShutdownHook();
    }
    
    public repl(final Language language) {
        this.language = language;
    }
    
    static void bad_option(final String str) {
        System.err.println("kawa: bad option '" + str + "'");
        printOptions(System.err);
        System.exit(-1);
    }
    
    static void checkInitFile() {
        if (repl.homeDirectory == null) {
            File file = null;
            repl.homeDirectory = System.getProperty("user.home");
            Comparable false;
            if (repl.homeDirectory != null) {
                false = new FString(repl.homeDirectory);
                String child;
                if ("/".equals(System.getProperty("file.separator"))) {
                    child = ".kawarc.scm";
                }
                else {
                    child = "kawarc.scm";
                }
                file = new File(repl.homeDirectory, child);
            }
            else {
                false = Boolean.FALSE;
            }
            Environment.getCurrent().put("home-directory", false);
            if (file != null && file.exists() && !Shell.runFileOrClass(file.getPath(), true, 0)) {
                System.exit(-1);
            }
        }
    }
    
    public static void compileFiles(final String[] p0, final int p1, final int p2) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_3       
        //     4: iload_2        
        //     5: iload_1        
        //     6: isub           
        //     7: anewarray       Lgnu/expr/Compilation;
        //    10: astore          4
        //    12: iload_2        
        //    13: iload_1        
        //    14: isub           
        //    15: anewarray       Lgnu/expr/ModuleInfo;
        //    18: astore          5
        //    20: new             Lgnu/text/SourceMessages;
        //    23: dup            
        //    24: invokespecial   gnu/text/SourceMessages.<init>:()V
        //    27: astore          6
        //    29: iload_1        
        //    30: istore          7
        //    32: iload           7
        //    34: iload_2        
        //    35: if_icmpge       283
        //    38: aload_0        
        //    39: iload           7
        //    41: aaload         
        //    42: astore          8
        //    44: aload           8
        //    46: invokestatic    kawa/repl.getLanguageFromFilenameExtension:(Ljava/lang/String;)V
        //    49: invokestatic    gnu/expr/Language.getDefaultLanguage:()Lgnu/expr/Language;
        //    52: astore          9
        //    54: aconst_null    
        //    55: astore          10
        //    57: aload           10
        //    59: astore          11
        //    61: aload           8
        //    63: invokestatic    gnu/mapping/InPort.openFile:(Ljava/lang/Object;)Lgnu/mapping/InPort;
        //    66: astore          12
        //    68: aload           10
        //    70: astore          11
        //    72: aload           9
        //    74: aload           12
        //    76: aload           6
        //    78: getstatic       kawa/repl.defaultParseOptions:I
        //    81: invokevirtual   gnu/expr/Language.parse:(Lgnu/mapping/InPort;Lgnu/text/SourceMessages;I)Lgnu/expr/Compilation;
        //    84: astore          10
        //    86: aload           10
        //    88: astore          11
        //    90: getstatic       kawa/repl.compilationTopname:Ljava/lang/String;
        //    93: ifnull          173
        //    96: aload           10
        //    98: astore          11
        //   100: getstatic       kawa/repl.compilationTopname:Ljava/lang/String;
        //   103: invokestatic    gnu/expr/Compilation.mangleNameIfNeeded:(Ljava/lang/String;)Ljava/lang/String;
        //   106: astore          9
        //   108: aload           10
        //   110: astore          11
        //   112: new             Lgnu/bytecode/ClassType;
        //   115: astore          12
        //   117: aload           10
        //   119: astore          11
        //   121: aload           12
        //   123: aload           9
        //   125: invokespecial   gnu/bytecode/ClassType.<init>:(Ljava/lang/String;)V
        //   128: aload           10
        //   130: astore          11
        //   132: aload           10
        //   134: invokevirtual   gnu/expr/Compilation.getModule:()Lgnu/expr/ModuleExp;
        //   137: astore          9
        //   139: aload           10
        //   141: astore          11
        //   143: aload           9
        //   145: aload           12
        //   147: invokevirtual   gnu/expr/ModuleExp.setType:(Lgnu/bytecode/ClassType;)V
        //   150: aload           10
        //   152: astore          11
        //   154: aload           9
        //   156: getstatic       kawa/repl.compilationTopname:Ljava/lang/String;
        //   159: invokevirtual   gnu/expr/ModuleExp.setName:(Ljava/lang/String;)V
        //   162: aload           10
        //   164: astore          11
        //   166: aload           10
        //   168: aload           12
        //   170: putfield        gnu/expr/Compilation.mainClass:Lgnu/bytecode/ClassType;
        //   173: aload           10
        //   175: astore          11
        //   177: aload           5
        //   179: iload           7
        //   181: iload_1        
        //   182: isub           
        //   183: aload_3        
        //   184: aload           10
        //   186: invokevirtual   gnu/expr/ModuleManager.find:(Lgnu/expr/Compilation;)Lgnu/expr/ModuleInfo;
        //   189: aastore        
        //   190: aload           4
        //   192: iload           7
        //   194: iload_1        
        //   195: isub           
        //   196: aload           10
        //   198: aastore        
        //   199: aload           6
        //   201: invokevirtual   gnu/text/SourceMessages.seenErrorsOrWarnings:()Z
        //   204: ifeq            255
        //   207: getstatic       java/lang/System.err:Ljava/io/PrintStream;
        //   210: new             Ljava/lang/StringBuilder;
        //   213: dup            
        //   214: invokespecial   java/lang/StringBuilder.<init>:()V
        //   217: ldc             "(compiling "
        //   219: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   222: aload           8
        //   224: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   227: bipush          41
        //   229: invokevirtual   java/lang/StringBuilder.append:(C)Ljava/lang/StringBuilder;
        //   232: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   235: invokevirtual   java/io/PrintStream.println:(Ljava/lang/String;)V
        //   238: aload           6
        //   240: getstatic       java/lang/System.err:Ljava/io/PrintStream;
        //   243: bipush          20
        //   245: invokevirtual   gnu/text/SourceMessages.checkErrors:(Ljava/io/PrintStream;I)Z
        //   248: ifeq            255
        //   251: iconst_1       
        //   252: invokestatic    java/lang/System.exit:(I)V
        //   255: iinc            7, 1
        //   258: goto            32
        //   261: astore          12
        //   263: aload           10
        //   265: astore          11
        //   267: getstatic       java/lang/System.err:Ljava/io/PrintStream;
        //   270: aload           12
        //   272: invokevirtual   java/io/PrintStream.println:(Ljava/lang/Object;)V
        //   275: aload           10
        //   277: astore          11
        //   279: iconst_m1      
        //   280: invokestatic    java/lang/System.exit:(I)V
        //   283: iload_1        
        //   284: istore          7
        //   286: iload           7
        //   288: iload_2        
        //   289: if_icmpge       490
        //   292: aload_0        
        //   293: iload           7
        //   295: aaload         
        //   296: astore          11
        //   298: aload           4
        //   300: iload           7
        //   302: iload_1        
        //   303: isub           
        //   304: aaload         
        //   305: astore          10
        //   307: getstatic       java/lang/System.err:Ljava/io/PrintStream;
        //   310: astore          8
        //   312: new             Ljava/lang/StringBuilder;
        //   315: astore_3       
        //   316: aload_3        
        //   317: invokespecial   java/lang/StringBuilder.<init>:()V
        //   320: aload           8
        //   322: aload_3        
        //   323: ldc             "(compiling "
        //   325: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   328: aload           11
        //   330: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   333: ldc             " to "
        //   335: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   338: aload           10
        //   340: getfield        gnu/expr/Compilation.mainClass:Lgnu/bytecode/ClassType;
        //   343: invokevirtual   gnu/bytecode/ClassType.getName:()Ljava/lang/String;
        //   346: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   349: bipush          41
        //   351: invokevirtual   java/lang/StringBuilder.append:(C)Ljava/lang/StringBuilder;
        //   354: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   357: invokevirtual   java/io/PrintStream.println:(Ljava/lang/String;)V
        //   360: aload           5
        //   362: iload           7
        //   364: iload_1        
        //   365: isub           
        //   366: aaload         
        //   367: bipush          14
        //   369: invokevirtual   gnu/expr/ModuleInfo.loadByStages:(I)V
        //   372: aload           6
        //   374: invokevirtual   gnu/text/SourceMessages.seenErrors:()Z
        //   377: istore          13
        //   379: aload           6
        //   381: getstatic       java/lang/System.err:Ljava/io/PrintStream;
        //   384: bipush          50
        //   386: invokevirtual   gnu/text/SourceMessages.checkErrors:(Ljava/io/PrintStream;I)Z
        //   389: pop            
        //   390: iload           13
        //   392: ifeq            399
        //   395: iconst_m1      
        //   396: invokestatic    java/lang/System.exit:(I)V
        //   399: aload           4
        //   401: iload           7
        //   403: iload_1        
        //   404: isub           
        //   405: aload           10
        //   407: aastore        
        //   408: aload           6
        //   410: invokevirtual   gnu/text/SourceMessages.seenErrors:()Z
        //   413: istore          13
        //   415: aload           6
        //   417: getstatic       java/lang/System.err:Ljava/io/PrintStream;
        //   420: bipush          50
        //   422: invokevirtual   gnu/text/SourceMessages.checkErrors:(Ljava/io/PrintStream;I)Z
        //   425: pop            
        //   426: iload           13
        //   428: ifeq            435
        //   431: iconst_m1      
        //   432: invokestatic    java/lang/System.exit:(I)V
        //   435: iinc            7, 1
        //   438: goto            286
        //   441: astore          10
        //   443: aload           10
        //   445: instanceof      Lgnu/text/SyntaxException;
        //   448: ifeq            464
        //   451: aload           10
        //   453: checkcast       Lgnu/text/SyntaxException;
        //   456: invokevirtual   gnu/text/SyntaxException.getMessages:()Lgnu/text/SourceMessages;
        //   459: aload           6
        //   461: if_acmpeq       199
        //   464: aload           10
        //   466: aload           11
        //   468: aload           8
        //   470: invokestatic    kawa/repl.internalError:(Ljava/lang/Throwable;Lgnu/expr/Compilation;Ljava/lang/Object;)V
        //   473: goto            199
        //   476: astore          8
        //   478: aload           8
        //   480: aload           10
        //   482: aload           11
        //   484: invokestatic    kawa/repl.internalError:(Ljava/lang/Throwable;Lgnu/expr/Compilation;Ljava/lang/Object;)V
        //   487: goto            435
        //   490: return         
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                           
        //  -----  -----  -----  -----  -------------------------------
        //  61     68     261    283    Ljava/io/FileNotFoundException;
        //  61     68     441    476    Ljava/lang/Throwable;
        //  72     86     441    476    Ljava/lang/Throwable;
        //  90     96     441    476    Ljava/lang/Throwable;
        //  100    108    441    476    Ljava/lang/Throwable;
        //  112    117    441    476    Ljava/lang/Throwable;
        //  121    128    441    476    Ljava/lang/Throwable;
        //  132    139    441    476    Ljava/lang/Throwable;
        //  143    150    441    476    Ljava/lang/Throwable;
        //  154    162    441    476    Ljava/lang/Throwable;
        //  166    173    441    476    Ljava/lang/Throwable;
        //  177    190    441    476    Ljava/lang/Throwable;
        //  267    275    441    476    Ljava/lang/Throwable;
        //  279    283    441    476    Ljava/lang/Throwable;
        //  307    390    476    490    Ljava/lang/Throwable;
        //  395    399    476    490    Ljava/lang/Throwable;
        //  408    426    476    490    Ljava/lang/Throwable;
        //  431    435    476    490    Ljava/lang/Throwable;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0399:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static void getLanguage() {
        if (repl.previousLanguage == null) {
            Language.setDefaults(repl.previousLanguage = Language.getInstance(null));
        }
    }
    
    public static void getLanguageFromFilenameExtension(final String s) {
        Label_0026: {
            if (repl.previousLanguage != null) {
                break Label_0026;
            }
            repl.previousLanguage = Language.getInstanceFromFilenameExtension(s);
            if (repl.previousLanguage == null) {
                break Label_0026;
            }
            Language.setDefaults(repl.previousLanguage);
            return;
        }
        getLanguage();
    }
    
    static void internalError(final Throwable t, final Compilation compilation, final Object obj) {
        final StringBuffer sb = new StringBuffer();
        if (compilation != null) {
            final String fileName = compilation.getFileName();
            final int lineNumber = compilation.getLineNumber();
            if (fileName != null && lineNumber > 0) {
                sb.append(fileName);
                sb.append(':');
                sb.append(lineNumber);
                sb.append(": ");
            }
        }
        sb.append("internal error while compiling ");
        sb.append(obj);
        System.err.println(sb.toString());
        t.printStackTrace(System.err);
        System.exit(-1);
    }
    
    public static void main(final String[] array) {
        while (true) {
            while (true) {
                Label_0109: {
                    try {
                        final int processArgs = processArgs(array, 0, array.length);
                        if (processArgs >= 0) {
                            if (processArgs < array.length) {
                                final String s = array[processArgs];
                                getLanguageFromFilenameExtension(s);
                                setArgs(array, processArgs + 1);
                                checkInitFile();
                                Shell.runFileOrClass(s, false, 0);
                            }
                            else {
                                getLanguage();
                                setArgs(array, processArgs);
                                checkInitFile();
                                if (!shouldUseGuiConsole()) {
                                    break Label_0109;
                                }
                                startGuiConsole();
                            }
                            if (!repl.shutdownRegistered) {
                                OutPort.runCleanups();
                            }
                            ModuleBody.exitDecrement();
                        }
                        return;
                    }
                    finally {
                        if (!repl.shutdownRegistered) {
                            OutPort.runCleanups();
                        }
                        ModuleBody.exitDecrement();
                    }
                }
                if (!Shell.run(Language.getDefaultLanguage(), Environment.getCurrent())) {
                    System.exit(-1);
                    continue;
                }
                continue;
            }
        }
    }
    
    public static void printOption(final PrintStream printStream, final String s, final String x) {
        printStream.print(" ");
        printStream.print(s);
        for (int length = s.length(), i = 0; i < 30 - (length + 1); ++i) {
            printStream.print(" ");
        }
        printStream.print(" ");
        printStream.println(x);
    }
    
    public static void printOptions(final PrintStream printStream) {
        printStream.println("Usage: [java kawa.repl | kawa] [options ...]");
        printStream.println();
        printStream.println(" Generic options:");
        printOption(printStream, "--help", "Show help about options");
        printOption(printStream, "--author", "Show author information");
        printOption(printStream, "--version", "Show version information");
        printStream.println();
        printStream.println(" Options");
        printOption(printStream, "-e <expr>", "Evaluate expression <expr>");
        printOption(printStream, "-c <expr>", "Same as -e, but make sure ~/.kawarc.scm is run first");
        printOption(printStream, "-f <filename>", "File to interpret");
        printOption(printStream, "-s| --", "Start reading commands interactively from console");
        printOption(printStream, "-w", "Launch the interpreter in a GUI window");
        printOption(printStream, "--server <port>", "Start a server accepting telnet connections on <port>");
        printOption(printStream, "--debug-dump-zip", "Compiled interactive expressions to a zip archive");
        printOption(printStream, "--debug-print-expr", "Print generated internal expressions");
        printOption(printStream, "--debug-print-final-expr", "Print expression after any optimizations");
        printOption(printStream, "--debug-error-prints-stack-trace", "Print stack trace with errors");
        printOption(printStream, "--debug-warning-prints-stack-trace", "Print stack trace with warnings");
        printOption(printStream, "--[no-]full-tailcalls", "(Don't) use full tail-calls");
        printOption(printStream, "-C <filename> ...", "Compile named files to Java class files");
        printOption(printStream, "--output-format <format>", "Use <format> when printing top-level output");
        printOption(printStream, "--<language>", "Select source language, one of:");
        final String[][] languages = Language.getLanguages();
        for (int i = 0; i < languages.length; ++i) {
            printStream.print("   ");
            final String[] array = languages[i];
            for (int length = array.length, j = 0; j < length - 1; ++j) {
                printStream.print(array[j] + " ");
            }
            if (i == 0) {
                printStream.print("[default]");
            }
            printStream.println();
        }
        printStream.println(" Compilation options, must be specified before -C");
        printOption(printStream, "-d <dirname>", "Directory to place .class files in");
        printOption(printStream, "-P <prefix>", "Prefix to prepand to class names");
        printOption(printStream, "-T <topname>", "name to give to top-level class");
        printOption(printStream, "--main", "Generate an application, with a main method");
        printOption(printStream, "--applet", "Generate an applet");
        printOption(printStream, "--servlet", "Generate a servlet");
        printOption(printStream, "--module-static", "Top-level definitions are by default static");
        final ArrayList<String> keys = Compilation.options.keys();
        for (int k = 0; k < keys.size(); ++k) {
            final String str = keys.get(k);
            printOption(printStream, "--" + str, Compilation.options.getDoc(str));
        }
        printStream.println();
        printStream.println("For more information go to:  http://www.gnu.org/software/kawa/");
    }
    
    public static int processArgs(final String[] p0, final int p1, final int p2) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: istore_3       
        //     2: iload_1        
        //     3: istore          4
        //     5: iload           4
        //     7: iload_2        
        //     8: if_icmpge       2812
        //    11: aload_0        
        //    12: iload           4
        //    14: aaload         
        //    15: astore          5
        //    17: aload           5
        //    19: ldc_w           "-c"
        //    22: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //    25: ifne            39
        //    28: aload           5
        //    30: ldc_w           "-e"
        //    33: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //    36: ifeq            151
        //    39: iload           4
        //    41: iconst_1       
        //    42: iadd           
        //    43: istore_1       
        //    44: iload_1        
        //    45: iload_2        
        //    46: if_icmpne       54
        //    49: aload           5
        //    51: invokestatic    kawa/repl.bad_option:(Ljava/lang/String;)V
        //    54: invokestatic    kawa/repl.getLanguage:()V
        //    57: aload_0        
        //    58: iload_1        
        //    59: iconst_1       
        //    60: iadd           
        //    61: invokestatic    kawa/repl.setArgs:([Ljava/lang/String;I)V
        //    64: aload           5
        //    66: ldc_w           "-c"
        //    69: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //    72: ifeq            78
        //    75: invokestatic    kawa/repl.checkInitFile:()V
        //    78: invokestatic    gnu/expr/Language.getDefaultLanguage:()Lgnu/expr/Language;
        //    81: astore          6
        //    83: new             Lgnu/text/SourceMessages;
        //    86: dup            
        //    87: invokespecial   gnu/text/SourceMessages.<init>:()V
        //    90: astore          7
        //    92: aload           6
        //    94: invokestatic    gnu/mapping/Environment.getCurrent:()Lgnu/mapping/Environment;
        //    97: new             Lgnu/mapping/CharArrayInPort;
        //   100: dup            
        //   101: aload_0        
        //   102: iload_1        
        //   103: aaload         
        //   104: invokespecial   gnu/mapping/CharArrayInPort.<init>:(Ljava/lang/String;)V
        //   107: invokestatic    gnu/mapping/OutPort.outDefault:()Lgnu/mapping/OutPort;
        //   110: aconst_null    
        //   111: aload           7
        //   113: invokestatic    kawa/Shell.run:(Lgnu/expr/Language;Lgnu/mapping/Environment;Lgnu/mapping/InPort;Lgnu/mapping/OutPort;Lgnu/mapping/OutPort;Lgnu/text/SourceMessages;)Ljava/lang/Throwable;
        //   116: astore          6
        //   118: aload           6
        //   120: ifnull          137
        //   123: aload           6
        //   125: aload           7
        //   127: invokestatic    gnu/mapping/OutPort.errDefault:()Lgnu/mapping/OutPort;
        //   130: invokestatic    kawa/Shell.printError:(Ljava/lang/Throwable;Lgnu/text/SourceMessages;Lgnu/mapping/OutPort;)V
        //   133: iconst_m1      
        //   134: invokestatic    java/lang/System.exit:(I)V
        //   137: iconst_1       
        //   138: istore          8
        //   140: iload_1        
        //   141: iconst_1       
        //   142: iadd           
        //   143: istore          4
        //   145: iload           8
        //   147: istore_3       
        //   148: goto            5
        //   151: aload           5
        //   153: ldc_w           "-f"
        //   156: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //   159: ifeq            217
        //   162: iload           4
        //   164: iconst_1       
        //   165: iadd           
        //   166: istore_1       
        //   167: iload_1        
        //   168: iload_2        
        //   169: if_icmpne       177
        //   172: aload           5
        //   174: invokestatic    kawa/repl.bad_option:(Ljava/lang/String;)V
        //   177: aload_0        
        //   178: iload_1        
        //   179: aaload         
        //   180: astore          7
        //   182: aload           7
        //   184: invokestatic    kawa/repl.getLanguageFromFilenameExtension:(Ljava/lang/String;)V
        //   187: aload_0        
        //   188: iload_1        
        //   189: iconst_1       
        //   190: iadd           
        //   191: invokestatic    kawa/repl.setArgs:([Ljava/lang/String;I)V
        //   194: invokestatic    kawa/repl.checkInitFile:()V
        //   197: aload           7
        //   199: iconst_1       
        //   200: iconst_0       
        //   201: invokestatic    kawa/Shell.runFileOrClass:(Ljava/lang/String;ZI)Z
        //   204: ifne            211
        //   207: iconst_m1      
        //   208: invokestatic    java/lang/System.exit:(I)V
        //   211: iconst_1       
        //   212: istore          8
        //   214: goto            140
        //   217: aload           5
        //   219: ldc_w           "--script"
        //   222: invokevirtual   java/lang/String.startsWith:(Ljava/lang/String;)Z
        //   225: ifeq            327
        //   228: aload           5
        //   230: bipush          8
        //   232: invokevirtual   java/lang/String.substring:(I)Ljava/lang/String;
        //   235: astore          7
        //   237: iinc            4, 1
        //   240: iconst_0       
        //   241: istore_3       
        //   242: iload_3        
        //   243: istore_1       
        //   244: iload           4
        //   246: istore          8
        //   248: aload           7
        //   250: invokevirtual   java/lang/String.length:()I
        //   253: ifle            266
        //   256: aload           7
        //   258: invokestatic    java/lang/Integer.parseInt:(Ljava/lang/String;)I
        //   261: istore_1       
        //   262: iload           4
        //   264: istore          8
        //   266: iload           8
        //   268: iload_2        
        //   269: if_icmpne       277
        //   272: aload           5
        //   274: invokestatic    kawa/repl.bad_option:(Ljava/lang/String;)V
        //   277: aload_0        
        //   278: iload           8
        //   280: aaload         
        //   281: astore          7
        //   283: aload           7
        //   285: invokestatic    kawa/repl.getLanguageFromFilenameExtension:(Ljava/lang/String;)V
        //   288: aload_0        
        //   289: iload           8
        //   291: iconst_1       
        //   292: iadd           
        //   293: invokestatic    kawa/repl.setArgs:([Ljava/lang/String;I)V
        //   296: invokestatic    kawa/repl.checkInitFile:()V
        //   299: aload           7
        //   301: iconst_1       
        //   302: iload_1        
        //   303: invokestatic    kawa/Shell.runFileOrClass:(Ljava/lang/String;ZI)Z
        //   306: ifne            313
        //   309: iconst_m1      
        //   310: invokestatic    java/lang/System.exit:(I)V
        //   313: iconst_m1      
        //   314: istore_1       
        //   315: iload_1        
        //   316: ireturn        
        //   317: astore          7
        //   319: iload_2        
        //   320: istore          8
        //   322: iload_3        
        //   323: istore_1       
        //   324: goto            266
        //   327: aload           5
        //   329: ldc_w           "\\"
        //   332: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //   335: ifeq            853
        //   338: iinc            4, 1
        //   341: iload           4
        //   343: iload_2        
        //   344: if_icmpne       352
        //   347: aload           5
        //   349: invokestatic    kawa/repl.bad_option:(Ljava/lang/String;)V
        //   352: aload_0        
        //   353: iload           4
        //   355: aaload         
        //   356: astore          6
        //   358: new             Lgnu/text/SourceMessages;
        //   361: dup            
        //   362: invokespecial   gnu/text/SourceMessages.<init>:()V
        //   365: astore          7
        //   367: new             Ljava/io/BufferedInputStream;
        //   370: astore          9
        //   372: new             Ljava/io/FileInputStream;
        //   375: astore          10
        //   377: aload           10
        //   379: aload           6
        //   381: invokespecial   java/io/FileInputStream.<init>:(Ljava/lang/String;)V
        //   384: aload           9
        //   386: aload           10
        //   388: invokespecial   java/io/BufferedInputStream.<init>:(Ljava/io/InputStream;)V
        //   391: aload           9
        //   393: invokevirtual   java/io/InputStream.read:()I
        //   396: istore_2       
        //   397: iload_2        
        //   398: bipush          35
        //   400: if_icmpne       667
        //   403: new             Ljava/lang/StringBuffer;
        //   406: astore          5
        //   408: aload           5
        //   410: bipush          100
        //   412: invokespecial   java/lang/StringBuffer.<init>:(I)V
        //   415: new             Ljava/util/Vector;
        //   418: astore          10
        //   420: aload           10
        //   422: bipush          10
        //   424: invokespecial   java/util/Vector.<init>:(I)V
        //   427: iconst_0       
        //   428: istore          8
        //   430: iload           8
        //   432: istore_1       
        //   433: iload_2        
        //   434: bipush          10
        //   436: if_icmpeq       464
        //   439: iload           8
        //   441: istore_1       
        //   442: iload_2        
        //   443: bipush          13
        //   445: if_icmpeq       464
        //   448: iload           8
        //   450: istore_1       
        //   451: iload_2        
        //   452: iflt            464
        //   455: aload           9
        //   457: invokevirtual   java/io/InputStream.read:()I
        //   460: istore_2       
        //   461: goto            430
        //   464: aload           9
        //   466: invokevirtual   java/io/InputStream.read:()I
        //   469: istore          8
        //   471: iload           8
        //   473: ifge            521
        //   476: getstatic       java/lang/System.err:Ljava/io/PrintStream;
        //   479: astore          11
        //   481: new             Ljava/lang/StringBuilder;
        //   484: astore          12
        //   486: aload           12
        //   488: invokespecial   java/lang/StringBuilder.<init>:()V
        //   491: aload           11
        //   493: aload           12
        //   495: ldc_w           "unexpected end-of-file processing argument line for: '"
        //   498: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   501: aload           6
        //   503: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   506: bipush          39
        //   508: invokevirtual   java/lang/StringBuilder.append:(C)Ljava/lang/StringBuilder;
        //   511: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   514: invokevirtual   java/io/PrintStream.println:(Ljava/lang/String;)V
        //   517: iconst_m1      
        //   518: invokestatic    java/lang/System.exit:(I)V
        //   521: iload_1        
        //   522: ifne            818
        //   525: iload           8
        //   527: bipush          92
        //   529: if_icmpeq       546
        //   532: iload           8
        //   534: bipush          39
        //   536: if_icmpeq       546
        //   539: iload           8
        //   541: bipush          34
        //   543: if_icmpne       552
        //   546: iload           8
        //   548: istore_1       
        //   549: goto            464
        //   552: iload           8
        //   554: bipush          10
        //   556: if_icmpeq       566
        //   559: iload           8
        //   561: bipush          13
        //   563: if_icmpne       775
        //   566: aload           5
        //   568: invokevirtual   java/lang/StringBuffer.length:()I
        //   571: ifle            584
        //   574: aload           10
        //   576: aload           5
        //   578: invokevirtual   java/lang/StringBuffer.toString:()Ljava/lang/String;
        //   581: invokevirtual   java/util/Vector.addElement:(Ljava/lang/Object;)V
        //   584: aload           10
        //   586: invokevirtual   java/util/Vector.size:()I
        //   589: istore_1       
        //   590: iload_1        
        //   591: ifle            667
        //   594: iload_1        
        //   595: anewarray       Ljava/lang/String;
        //   598: astore          5
        //   600: aload           10
        //   602: aload           5
        //   604: invokevirtual   java/util/Vector.copyInto:([Ljava/lang/Object;)V
        //   607: aload           5
        //   609: iconst_0       
        //   610: iload_1        
        //   611: invokestatic    kawa/repl.processArgs:([Ljava/lang/String;II)I
        //   614: istore_2       
        //   615: iload_2        
        //   616: iflt            667
        //   619: iload_2        
        //   620: iload_1        
        //   621: if_icmpge       667
        //   624: getstatic       java/lang/System.err:Ljava/io/PrintStream;
        //   627: astore          5
        //   629: new             Ljava/lang/StringBuilder;
        //   632: astore          10
        //   634: aload           10
        //   636: invokespecial   java/lang/StringBuilder.<init>:()V
        //   639: aload           5
        //   641: aload           10
        //   643: ldc_w           ""
        //   646: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   649: iload_1        
        //   650: iload_2        
        //   651: isub           
        //   652: invokevirtual   java/lang/StringBuilder.append:(I)Ljava/lang/StringBuilder;
        //   655: ldc_w           " unused meta args"
        //   658: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   661: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   664: invokevirtual   java/io/PrintStream.println:(Ljava/lang/String;)V
        //   667: aload           6
        //   669: invokestatic    kawa/repl.getLanguageFromFilenameExtension:(Ljava/lang/String;)V
        //   672: aload           9
        //   674: aload           6
        //   676: invokestatic    gnu/mapping/InPort.openFile:(Ljava/io/InputStream;Ljava/lang/Object;)Lgnu/mapping/InPort;
        //   679: astore          6
        //   681: aload_0        
        //   682: iload           4
        //   684: iconst_1       
        //   685: iadd           
        //   686: invokestatic    kawa/repl.setArgs:([Ljava/lang/String;I)V
        //   689: invokestatic    kawa/repl.checkInitFile:()V
        //   692: invokestatic    gnu/mapping/OutPort.errDefault:()Lgnu/mapping/OutPort;
        //   695: astore_0       
        //   696: invokestatic    gnu/expr/Language.getDefaultLanguage:()Lgnu/expr/Language;
        //   699: invokestatic    gnu/mapping/Environment.getCurrent:()Lgnu/mapping/Environment;
        //   702: aload           6
        //   704: invokestatic    gnu/mapping/OutPort.outDefault:()Lgnu/mapping/OutPort;
        //   707: aconst_null    
        //   708: aload           7
        //   710: invokestatic    kawa/Shell.run:(Lgnu/expr/Language;Lgnu/mapping/Environment;Lgnu/mapping/InPort;Lgnu/mapping/OutPort;Lgnu/mapping/OutPort;Lgnu/text/SourceMessages;)Ljava/lang/Throwable;
        //   713: astore          6
        //   715: aload           7
        //   717: aload_0        
        //   718: bipush          20
        //   720: invokevirtual   gnu/text/SourceMessages.printAll:(Ljava/io/PrintWriter;I)V
        //   723: aload           6
        //   725: ifnull          770
        //   728: aload           6
        //   730: instanceof      Lgnu/text/SyntaxException;
        //   733: ifeq            753
        //   736: aload           6
        //   738: checkcast       Lgnu/text/SyntaxException;
        //   741: invokevirtual   gnu/text/SyntaxException.getMessages:()Lgnu/text/SourceMessages;
        //   744: aload           7
        //   746: if_acmpne       753
        //   749: iconst_1       
        //   750: invokestatic    java/lang/System.exit:(I)V
        //   753: aload           6
        //   755: athrow         
        //   756: astore_0       
        //   757: aload_0        
        //   758: aload           7
        //   760: invokestatic    gnu/mapping/OutPort.errDefault:()Lgnu/mapping/OutPort;
        //   763: invokestatic    kawa/Shell.printError:(Ljava/lang/Throwable;Lgnu/text/SourceMessages;Lgnu/mapping/OutPort;)V
        //   766: iconst_1       
        //   767: invokestatic    java/lang/System.exit:(I)V
        //   770: iconst_m1      
        //   771: istore_1       
        //   772: goto            315
        //   775: iload           8
        //   777: bipush          32
        //   779: if_icmpeq       791
        //   782: iload_1        
        //   783: istore_2       
        //   784: iload           8
        //   786: bipush          9
        //   788: if_icmpne       826
        //   791: aload           5
        //   793: invokevirtual   java/lang/StringBuffer.length:()I
        //   796: ifle            464
        //   799: aload           10
        //   801: aload           5
        //   803: invokevirtual   java/lang/StringBuffer.toString:()Ljava/lang/String;
        //   806: invokevirtual   java/util/Vector.addElement:(Ljava/lang/Object;)V
        //   809: aload           5
        //   811: iconst_0       
        //   812: invokevirtual   java/lang/StringBuffer.setLength:(I)V
        //   815: goto            464
        //   818: iload_1        
        //   819: bipush          92
        //   821: if_icmpne       840
        //   824: iconst_0       
        //   825: istore_2       
        //   826: aload           5
        //   828: iload           8
        //   830: i2c            
        //   831: invokevirtual   java/lang/StringBuffer.append:(C)Ljava/lang/StringBuffer;
        //   834: pop            
        //   835: iload_2        
        //   836: istore_1       
        //   837: goto            464
        //   840: iload_1        
        //   841: istore_2       
        //   842: iload           8
        //   844: iload_1        
        //   845: if_icmpne       826
        //   848: iconst_0       
        //   849: istore_1       
        //   850: goto            464
        //   853: aload           5
        //   855: ldc_w           "-s"
        //   858: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //   861: ifne            875
        //   864: aload           5
        //   866: ldc_w           "--"
        //   869: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //   872: ifeq            904
        //   875: invokestatic    kawa/repl.getLanguage:()V
        //   878: aload_0        
        //   879: iload           4
        //   881: iconst_1       
        //   882: iadd           
        //   883: invokestatic    kawa/repl.setArgs:([Ljava/lang/String;I)V
        //   886: invokestatic    kawa/repl.checkInitFile:()V
        //   889: invokestatic    gnu/expr/Language.getDefaultLanguage:()Lgnu/expr/Language;
        //   892: invokestatic    gnu/mapping/Environment.getCurrent:()Lgnu/mapping/Environment;
        //   895: invokestatic    kawa/Shell.run:(Lgnu/expr/Language;Lgnu/mapping/Environment;)Z
        //   898: pop            
        //   899: iconst_m1      
        //   900: istore_1       
        //   901: goto            315
        //   904: aload           5
        //   906: ldc_w           "-w"
        //   909: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //   912: ifeq            940
        //   915: iload           4
        //   917: iconst_1       
        //   918: iadd           
        //   919: istore_1       
        //   920: invokestatic    kawa/repl.getLanguage:()V
        //   923: aload_0        
        //   924: iload_1        
        //   925: invokestatic    kawa/repl.setArgs:([Ljava/lang/String;I)V
        //   928: invokestatic    kawa/repl.checkInitFile:()V
        //   931: invokestatic    kawa/repl.startGuiConsole:()V
        //   934: iconst_1       
        //   935: istore          8
        //   937: goto            140
        //   940: aload           5
        //   942: ldc_w           "-d"
        //   945: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //   948: ifeq            981
        //   951: iload           4
        //   953: iconst_1       
        //   954: iadd           
        //   955: istore_1       
        //   956: iload_1        
        //   957: iload_2        
        //   958: if_icmpne       966
        //   961: aload           5
        //   963: invokestatic    kawa/repl.bad_option:(Ljava/lang/String;)V
        //   966: invokestatic    gnu/expr/ModuleManager.getInstance:()Lgnu/expr/ModuleManager;
        //   969: aload_0        
        //   970: iload_1        
        //   971: aaload         
        //   972: invokevirtual   gnu/expr/ModuleManager.setCompilationDirectory:(Ljava/lang/String;)V
        //   975: iload_3        
        //   976: istore          8
        //   978: goto            140
        //   981: aload           5
        //   983: ldc_w           "--target"
        //   986: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //   989: ifne            1003
        //   992: aload           5
        //   994: ldc_w           "target"
        //   997: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //  1000: ifeq            1211
        //  1003: iload           4
        //  1005: iconst_1       
        //  1006: iadd           
        //  1007: istore_1       
        //  1008: iload_1        
        //  1009: iload_2        
        //  1010: if_icmpne       1018
        //  1013: aload           5
        //  1015: invokestatic    kawa/repl.bad_option:(Ljava/lang/String;)V
        //  1018: aload_0        
        //  1019: iload_1        
        //  1020: aaload         
        //  1021: astore          7
        //  1023: aload           7
        //  1025: ldc_w           "7"
        //  1028: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //  1031: ifeq            1040
        //  1034: ldc_w           3342336
        //  1037: putstatic       gnu/expr/Compilation.defaultClassFileVersion:I
        //  1040: aload           7
        //  1042: ldc_w           "6"
        //  1045: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //  1048: ifne            1062
        //  1051: aload           7
        //  1053: ldc_w           "1.6"
        //  1056: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //  1059: ifeq            1074
        //  1062: ldc_w           3276800
        //  1065: putstatic       gnu/expr/Compilation.defaultClassFileVersion:I
        //  1068: iload_3        
        //  1069: istore          8
        //  1071: goto            140
        //  1074: aload           7
        //  1076: ldc_w           "5"
        //  1079: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //  1082: ifne            1096
        //  1085: aload           7
        //  1087: ldc_w           "1.5"
        //  1090: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //  1093: ifeq            1108
        //  1096: ldc_w           3211264
        //  1099: putstatic       gnu/expr/Compilation.defaultClassFileVersion:I
        //  1102: iload_3        
        //  1103: istore          8
        //  1105: goto            140
        //  1108: aload           7
        //  1110: ldc_w           "1.4"
        //  1113: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //  1116: ifeq            1131
        //  1119: ldc_w           3145728
        //  1122: putstatic       gnu/expr/Compilation.defaultClassFileVersion:I
        //  1125: iload_3        
        //  1126: istore          8
        //  1128: goto            140
        //  1131: aload           7
        //  1133: ldc_w           "1.3"
        //  1136: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //  1139: ifeq            1154
        //  1142: ldc_w           3080192
        //  1145: putstatic       gnu/expr/Compilation.defaultClassFileVersion:I
        //  1148: iload_3        
        //  1149: istore          8
        //  1151: goto            140
        //  1154: aload           7
        //  1156: ldc_w           "1.2"
        //  1159: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //  1162: ifeq            1177
        //  1165: ldc_w           3014656
        //  1168: putstatic       gnu/expr/Compilation.defaultClassFileVersion:I
        //  1171: iload_3        
        //  1172: istore          8
        //  1174: goto            140
        //  1177: aload           7
        //  1179: ldc_w           "1.1"
        //  1182: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //  1185: ifeq            1200
        //  1188: ldc_w           2949123
        //  1191: putstatic       gnu/expr/Compilation.defaultClassFileVersion:I
        //  1194: iload_3        
        //  1195: istore          8
        //  1197: goto            140
        //  1200: aload           7
        //  1202: invokestatic    kawa/repl.bad_option:(Ljava/lang/String;)V
        //  1205: iload_3        
        //  1206: istore          8
        //  1208: goto            140
        //  1211: aload           5
        //  1213: ldc_w           "-P"
        //  1216: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //  1219: ifeq            1249
        //  1222: iload           4
        //  1224: iconst_1       
        //  1225: iadd           
        //  1226: istore_1       
        //  1227: iload_1        
        //  1228: iload_2        
        //  1229: if_icmpne       1237
        //  1232: aload           5
        //  1234: invokestatic    kawa/repl.bad_option:(Ljava/lang/String;)V
        //  1237: aload_0        
        //  1238: iload_1        
        //  1239: aaload         
        //  1240: putstatic       gnu/expr/Compilation.classPrefixDefault:Ljava/lang/String;
        //  1243: iload_3        
        //  1244: istore          8
        //  1246: goto            140
        //  1249: aload           5
        //  1251: ldc_w           "-T"
        //  1254: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //  1257: ifeq            1287
        //  1260: iload           4
        //  1262: iconst_1       
        //  1263: iadd           
        //  1264: istore_1       
        //  1265: iload_1        
        //  1266: iload_2        
        //  1267: if_icmpne       1275
        //  1270: aload           5
        //  1272: invokestatic    kawa/repl.bad_option:(Ljava/lang/String;)V
        //  1275: aload_0        
        //  1276: iload_1        
        //  1277: aaload         
        //  1278: putstatic       kawa/repl.compilationTopname:Ljava/lang/String;
        //  1281: iload_3        
        //  1282: istore          8
        //  1284: goto            140
        //  1287: aload           5
        //  1289: ldc_w           "-C"
        //  1292: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //  1295: ifeq            1324
        //  1298: iload           4
        //  1300: iconst_1       
        //  1301: iadd           
        //  1302: istore_1       
        //  1303: iload_1        
        //  1304: iload_2        
        //  1305: if_icmpne       1313
        //  1308: aload           5
        //  1310: invokestatic    kawa/repl.bad_option:(Ljava/lang/String;)V
        //  1313: aload_0        
        //  1314: iload_1        
        //  1315: iload_2        
        //  1316: invokestatic    kawa/repl.compileFiles:([Ljava/lang/String;II)V
        //  1319: iconst_m1      
        //  1320: istore_1       
        //  1321: goto            315
        //  1324: aload           5
        //  1326: ldc_w           "--output-format"
        //  1329: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //  1332: ifne            1346
        //  1335: aload           5
        //  1337: ldc_w           "--format"
        //  1340: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //  1343: ifeq            1373
        //  1346: iload           4
        //  1348: iconst_1       
        //  1349: iadd           
        //  1350: istore_1       
        //  1351: iload_1        
        //  1352: iload_2        
        //  1353: if_icmpne       1361
        //  1356: aload           5
        //  1358: invokestatic    kawa/repl.bad_option:(Ljava/lang/String;)V
        //  1361: aload_0        
        //  1362: iload_1        
        //  1363: aaload         
        //  1364: invokestatic    kawa/Shell.setDefaultFormat:(Ljava/lang/String;)V
        //  1367: iload_3        
        //  1368: istore          8
        //  1370: goto            140
        //  1373: aload           5
        //  1375: ldc_w           "--connect"
        //  1378: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //  1381: ifeq            1536
        //  1384: iinc            4, 1
        //  1387: iload           4
        //  1389: iload_2        
        //  1390: if_icmpne       1398
        //  1393: aload           5
        //  1395: invokestatic    kawa/repl.bad_option:(Ljava/lang/String;)V
        //  1398: aload_0        
        //  1399: iload           4
        //  1401: aaload         
        //  1402: ldc_w           "-"
        //  1405: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //  1408: ifeq            1512
        //  1411: iconst_0       
        //  1412: istore_1       
        //  1413: new             Ljava/net/Socket;
        //  1416: astore          7
        //  1418: aload           7
        //  1420: aconst_null    
        //  1421: invokestatic    java/net/InetAddress.getByName:(Ljava/lang/String;)Ljava/net/InetAddress;
        //  1424: iload_1        
        //  1425: invokespecial   java/net/Socket.<init>:(Ljava/net/InetAddress;I)V
        //  1428: new             Lkawa/Telnet;
        //  1431: astore          6
        //  1433: aload           6
        //  1435: aload           7
        //  1437: iconst_1       
        //  1438: invokespecial   kawa/Telnet.<init>:(Ljava/net/Socket;Z)V
        //  1441: aload           6
        //  1443: invokevirtual   kawa/Telnet.getInputStream:()Lkawa/TelnetInputStream;
        //  1446: astore          7
        //  1448: aload           6
        //  1450: invokevirtual   kawa/Telnet.getOutputStream:()Lkawa/TelnetOutputStream;
        //  1453: astore          9
        //  1455: new             Ljava/io/PrintStream;
        //  1458: astore          6
        //  1460: aload           6
        //  1462: aload           9
        //  1464: iconst_1       
        //  1465: invokespecial   java/io/PrintStream.<init>:(Ljava/io/OutputStream;Z)V
        //  1468: aload           7
        //  1470: invokestatic    java/lang/System.setIn:(Ljava/io/InputStream;)V
        //  1473: aload           6
        //  1475: invokestatic    java/lang/System.setOut:(Ljava/io/PrintStream;)V
        //  1478: aload           6
        //  1480: invokestatic    java/lang/System.setErr:(Ljava/io/PrintStream;)V
        //  1483: iload_3        
        //  1484: istore          8
        //  1486: iload           4
        //  1488: istore_1       
        //  1489: goto            140
        //  1492: astore_0       
        //  1493: aload_0        
        //  1494: getstatic       java/lang/System.err:Ljava/io/PrintStream;
        //  1497: invokevirtual   java/io/IOException.printStackTrace:(Ljava/io/PrintStream;)V
        //  1500: new             Ljava/lang/Error;
        //  1503: dup            
        //  1504: aload_0        
        //  1505: invokevirtual   java/io/IOException.toString:()Ljava/lang/String;
        //  1508: invokespecial   java/lang/Error.<init>:(Ljava/lang/String;)V
        //  1511: athrow         
        //  1512: aload_0        
        //  1513: iload           4
        //  1515: aaload         
        //  1516: invokestatic    java/lang/Integer.parseInt:(Ljava/lang/String;)I
        //  1519: istore_1       
        //  1520: goto            1413
        //  1523: astore          7
        //  1525: ldc_w           "--connect port#"
        //  1528: invokestatic    kawa/repl.bad_option:(Ljava/lang/String;)V
        //  1531: iconst_m1      
        //  1532: istore_1       
        //  1533: goto            1413
        //  1536: aload           5
        //  1538: ldc_w           "--server"
        //  1541: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //  1544: ifeq            1748
        //  1547: invokestatic    kawa/repl.getLanguage:()V
        //  1550: iload           4
        //  1552: iconst_1       
        //  1553: iadd           
        //  1554: istore_1       
        //  1555: iload_1        
        //  1556: iload_2        
        //  1557: if_icmpne       1565
        //  1560: aload           5
        //  1562: invokestatic    kawa/repl.bad_option:(Ljava/lang/String;)V
        //  1565: aload_0        
        //  1566: iload_1        
        //  1567: aaload         
        //  1568: ldc_w           "-"
        //  1571: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //  1574: ifeq            1726
        //  1577: iconst_0       
        //  1578: istore_1       
        //  1579: new             Ljava/net/ServerSocket;
        //  1582: astore_0       
        //  1583: aload_0        
        //  1584: iload_1        
        //  1585: invokespecial   java/net/ServerSocket.<init>:(I)V
        //  1588: aload_0        
        //  1589: invokevirtual   java/net/ServerSocket.getLocalPort:()I
        //  1592: istore_1       
        //  1593: getstatic       java/lang/System.err:Ljava/io/PrintStream;
        //  1596: astore          7
        //  1598: new             Ljava/lang/StringBuilder;
        //  1601: astore          6
        //  1603: aload           6
        //  1605: invokespecial   java/lang/StringBuilder.<init>:()V
        //  1608: aload           7
        //  1610: aload           6
        //  1612: ldc_w           "Listening on port "
        //  1615: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1618: iload_1        
        //  1619: invokevirtual   java/lang/StringBuilder.append:(I)Ljava/lang/StringBuilder;
        //  1622: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //  1625: invokevirtual   java/io/PrintStream.println:(Ljava/lang/String;)V
        //  1628: getstatic       java/lang/System.err:Ljava/io/PrintStream;
        //  1631: ldc_w           "waiting ... "
        //  1634: invokevirtual   java/io/PrintStream.print:(Ljava/lang/String;)V
        //  1637: getstatic       java/lang/System.err:Ljava/io/PrintStream;
        //  1640: invokevirtual   java/io/PrintStream.flush:()V
        //  1643: aload_0        
        //  1644: invokevirtual   java/net/ServerSocket.accept:()Ljava/net/Socket;
        //  1647: astore          7
        //  1649: getstatic       java/lang/System.err:Ljava/io/PrintStream;
        //  1652: astore          9
        //  1654: new             Ljava/lang/StringBuilder;
        //  1657: astore          6
        //  1659: aload           6
        //  1661: invokespecial   java/lang/StringBuilder.<init>:()V
        //  1664: aload           9
        //  1666: aload           6
        //  1668: ldc_w           "got connection from "
        //  1671: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1674: aload           7
        //  1676: invokevirtual   java/net/Socket.getInetAddress:()Ljava/net/InetAddress;
        //  1679: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //  1682: ldc_w           " port:"
        //  1685: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1688: aload           7
        //  1690: invokevirtual   java/net/Socket.getPort:()I
        //  1693: invokevirtual   java/lang/StringBuilder.append:(I)Ljava/lang/StringBuilder;
        //  1696: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //  1699: invokevirtual   java/io/PrintStream.println:(Ljava/lang/String;)V
        //  1702: invokestatic    gnu/expr/Language.getDefaultLanguage:()Lgnu/expr/Language;
        //  1705: aload           7
        //  1707: invokestatic    kawa/TelnetRepl.serve:(Lgnu/expr/Language;Ljava/net/Socket;)V
        //  1710: goto            1628
        //  1713: astore_0       
        //  1714: new             Ljava/lang/Error;
        //  1717: dup            
        //  1718: aload_0        
        //  1719: invokevirtual   java/io/IOException.toString:()Ljava/lang/String;
        //  1722: invokespecial   java/lang/Error.<init>:(Ljava/lang/String;)V
        //  1725: athrow         
        //  1726: aload_0        
        //  1727: iload_1        
        //  1728: aaload         
        //  1729: invokestatic    java/lang/Integer.parseInt:(Ljava/lang/String;)I
        //  1732: istore_1       
        //  1733: goto            1579
        //  1736: astore_0       
        //  1737: ldc_w           "--server port#"
        //  1740: invokestatic    kawa/repl.bad_option:(Ljava/lang/String;)V
        //  1743: iconst_m1      
        //  1744: istore_1       
        //  1745: goto            1579
        //  1748: aload           5
        //  1750: ldc_w           "--http-auto-handler"
        //  1753: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //  1756: ifeq            1793
        //  1759: iload           4
        //  1761: iconst_2       
        //  1762: iadd           
        //  1763: istore_1       
        //  1764: iload_1        
        //  1765: iload_2        
        //  1766: if_icmplt       1774
        //  1769: aload           5
        //  1771: invokestatic    kawa/repl.bad_option:(Ljava/lang/String;)V
        //  1774: getstatic       java/lang/System.err:Ljava/io/PrintStream;
        //  1777: ldc_w           "kawa: HttpServer classes not found"
        //  1780: invokevirtual   java/io/PrintStream.println:(Ljava/lang/String;)V
        //  1783: iconst_m1      
        //  1784: invokestatic    java/lang/System.exit:(I)V
        //  1787: iload_3        
        //  1788: istore          8
        //  1790: goto            140
        //  1793: aload           5
        //  1795: ldc_w           "--http-start"
        //  1798: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //  1801: ifeq            1839
        //  1804: iload           4
        //  1806: iconst_1       
        //  1807: iadd           
        //  1808: istore_1       
        //  1809: iload_1        
        //  1810: iload_2        
        //  1811: if_icmplt       1820
        //  1814: ldc_w           "missing httpd port argument"
        //  1817: invokestatic    kawa/repl.bad_option:(Ljava/lang/String;)V
        //  1820: getstatic       java/lang/System.err:Ljava/io/PrintStream;
        //  1823: ldc_w           "kawa: HttpServer classes not found"
        //  1826: invokevirtual   java/io/PrintStream.println:(Ljava/lang/String;)V
        //  1829: iconst_m1      
        //  1830: invokestatic    java/lang/System.exit:(I)V
        //  1833: iload_3        
        //  1834: istore          8
        //  1836: goto            140
        //  1839: aload           5
        //  1841: ldc_w           "--main"
        //  1844: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //  1847: ifeq            1863
        //  1850: iconst_1       
        //  1851: putstatic       gnu/expr/Compilation.generateMainDefault:Z
        //  1854: iload_3        
        //  1855: istore          8
        //  1857: iload           4
        //  1859: istore_1       
        //  1860: goto            140
        //  1863: aload           5
        //  1865: ldc_w           "--applet"
        //  1868: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //  1871: ifeq            1892
        //  1874: getstatic       kawa/repl.defaultParseOptions:I
        //  1877: bipush          16
        //  1879: ior            
        //  1880: putstatic       kawa/repl.defaultParseOptions:I
        //  1883: iload_3        
        //  1884: istore          8
        //  1886: iload           4
        //  1888: istore_1       
        //  1889: goto            140
        //  1892: aload           5
        //  1894: ldc_w           "--servlet"
        //  1897: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //  1900: ifeq            1925
        //  1903: getstatic       kawa/repl.defaultParseOptions:I
        //  1906: bipush          32
        //  1908: ior            
        //  1909: putstatic       kawa/repl.defaultParseOptions:I
        //  1912: iconst_2       
        //  1913: putstatic       gnu/kawa/servlet/HttpRequestContext.importServletDefinitions:I
        //  1916: iload_3        
        //  1917: istore          8
        //  1919: iload           4
        //  1921: istore_1       
        //  1922: goto            140
        //  1925: aload           5
        //  1927: ldc_w           "--debug-dump-zip"
        //  1930: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //  1933: ifeq            1951
        //  1936: ldc_w           "kawa-zip-dump-"
        //  1939: putstatic       gnu/expr/ModuleExp.dumpZipPrefix:Ljava/lang/String;
        //  1942: iload_3        
        //  1943: istore          8
        //  1945: iload           4
        //  1947: istore_1       
        //  1948: goto            140
        //  1951: aload           5
        //  1953: ldc_w           "--debug-print-expr"
        //  1956: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //  1959: ifeq            1975
        //  1962: iconst_1       
        //  1963: putstatic       gnu/expr/Compilation.debugPrintExpr:Z
        //  1966: iload_3        
        //  1967: istore          8
        //  1969: iload           4
        //  1971: istore_1       
        //  1972: goto            140
        //  1975: aload           5
        //  1977: ldc_w           "--debug-print-final-expr"
        //  1980: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //  1983: ifeq            1999
        //  1986: iconst_1       
        //  1987: putstatic       gnu/expr/Compilation.debugPrintFinalExpr:Z
        //  1990: iload_3        
        //  1991: istore          8
        //  1993: iload           4
        //  1995: istore_1       
        //  1996: goto            140
        //  1999: aload           5
        //  2001: ldc_w           "--debug-error-prints-stack-trace"
        //  2004: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //  2007: ifeq            2023
        //  2010: iconst_1       
        //  2011: putstatic       gnu/text/SourceMessages.debugStackTraceOnError:Z
        //  2014: iload_3        
        //  2015: istore          8
        //  2017: iload           4
        //  2019: istore_1       
        //  2020: goto            140
        //  2023: aload           5
        //  2025: ldc_w           "--debug-warning-prints-stack-trace"
        //  2028: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //  2031: ifeq            2047
        //  2034: iconst_1       
        //  2035: putstatic       gnu/text/SourceMessages.debugStackTraceOnWarning:Z
        //  2038: iload_3        
        //  2039: istore          8
        //  2041: iload           4
        //  2043: istore_1       
        //  2044: goto            140
        //  2047: aload           5
        //  2049: ldc_w           "--module-nonstatic"
        //  2052: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //  2055: ifne            2069
        //  2058: aload           5
        //  2060: ldc_w           "--no-module-static"
        //  2063: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //  2066: ifeq            2082
        //  2069: iconst_m1      
        //  2070: putstatic       gnu/expr/Compilation.moduleStatic:I
        //  2073: iload_3        
        //  2074: istore          8
        //  2076: iload           4
        //  2078: istore_1       
        //  2079: goto            140
        //  2082: aload           5
        //  2084: ldc_w           "--module-static"
        //  2087: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //  2090: ifeq            2106
        //  2093: iconst_1       
        //  2094: putstatic       gnu/expr/Compilation.moduleStatic:I
        //  2097: iload_3        
        //  2098: istore          8
        //  2100: iload           4
        //  2102: istore_1       
        //  2103: goto            140
        //  2106: aload           5
        //  2108: ldc_w           "--module-static-run"
        //  2111: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //  2114: ifeq            2130
        //  2117: iconst_2       
        //  2118: putstatic       gnu/expr/Compilation.moduleStatic:I
        //  2121: iload_3        
        //  2122: istore          8
        //  2124: iload           4
        //  2126: istore_1       
        //  2127: goto            140
        //  2130: aload           5
        //  2132: ldc_w           "--no-inline"
        //  2135: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //  2138: ifne            2152
        //  2141: aload           5
        //  2143: ldc_w           "--inline=none"
        //  2146: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //  2149: ifeq            2165
        //  2152: iconst_0       
        //  2153: putstatic       gnu/expr/Compilation.inlineOk:Z
        //  2156: iload_3        
        //  2157: istore          8
        //  2159: iload           4
        //  2161: istore_1       
        //  2162: goto            140
        //  2165: aload           5
        //  2167: ldc_w           "--no-console"
        //  2170: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //  2173: ifeq            2189
        //  2176: iconst_1       
        //  2177: putstatic       kawa/repl.noConsole:Z
        //  2180: iload_3        
        //  2181: istore          8
        //  2183: iload           4
        //  2185: istore_1       
        //  2186: goto            140
        //  2189: aload           5
        //  2191: ldc_w           "--inline"
        //  2194: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //  2197: ifeq            2213
        //  2200: iconst_1       
        //  2201: putstatic       gnu/expr/Compilation.inlineOk:Z
        //  2204: iload_3        
        //  2205: istore          8
        //  2207: iload           4
        //  2209: istore_1       
        //  2210: goto            140
        //  2213: aload           5
        //  2215: ldc_w           "--cps"
        //  2218: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //  2221: ifeq            2237
        //  2224: iconst_4       
        //  2225: putstatic       gnu/expr/Compilation.defaultCallConvention:I
        //  2228: iload_3        
        //  2229: istore          8
        //  2231: iload           4
        //  2233: istore_1       
        //  2234: goto            140
        //  2237: aload           5
        //  2239: ldc_w           "--full-tailcalls"
        //  2242: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //  2245: ifeq            2261
        //  2248: iconst_3       
        //  2249: putstatic       gnu/expr/Compilation.defaultCallConvention:I
        //  2252: iload_3        
        //  2253: istore          8
        //  2255: iload           4
        //  2257: istore_1       
        //  2258: goto            140
        //  2261: aload           5
        //  2263: ldc_w           "--no-full-tailcalls"
        //  2266: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //  2269: ifeq            2285
        //  2272: iconst_1       
        //  2273: putstatic       gnu/expr/Compilation.defaultCallConvention:I
        //  2276: iload_3        
        //  2277: istore          8
        //  2279: iload           4
        //  2281: istore_1       
        //  2282: goto            140
        //  2285: aload           5
        //  2287: ldc_w           "--pedantic"
        //  2290: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //  2293: ifeq            2309
        //  2296: iconst_1       
        //  2297: putstatic       gnu/expr/Language.requirePedantic:Z
        //  2300: iload_3        
        //  2301: istore          8
        //  2303: iload           4
        //  2305: istore_1       
        //  2306: goto            140
        //  2309: aload           5
        //  2311: ldc_w           "--help"
        //  2314: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //  2317: ifeq            2339
        //  2320: getstatic       java/lang/System.out:Ljava/io/PrintStream;
        //  2323: invokestatic    kawa/repl.printOptions:(Ljava/io/PrintStream;)V
        //  2326: iconst_0       
        //  2327: invokestatic    java/lang/System.exit:(I)V
        //  2330: iload_3        
        //  2331: istore          8
        //  2333: iload           4
        //  2335: istore_1       
        //  2336: goto            140
        //  2339: aload           5
        //  2341: ldc_w           "--author"
        //  2344: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //  2347: ifeq            2372
        //  2350: getstatic       java/lang/System.out:Ljava/io/PrintStream;
        //  2353: ldc_w           "Per Bothner <per@bothner.com>"
        //  2356: invokevirtual   java/io/PrintStream.println:(Ljava/lang/String;)V
        //  2359: iconst_0       
        //  2360: invokestatic    java/lang/System.exit:(I)V
        //  2363: iload_3        
        //  2364: istore          8
        //  2366: iload           4
        //  2368: istore_1       
        //  2369: goto            140
        //  2372: aload           5
        //  2374: ldc_w           "--version"
        //  2377: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //  2380: ifeq            2425
        //  2383: getstatic       java/lang/System.out:Ljava/io/PrintStream;
        //  2386: ldc_w           "Kawa "
        //  2389: invokevirtual   java/io/PrintStream.print:(Ljava/lang/String;)V
        //  2392: getstatic       java/lang/System.out:Ljava/io/PrintStream;
        //  2395: invokestatic    kawa/Version.getVersion:()Ljava/lang/String;
        //  2398: invokevirtual   java/io/PrintStream.print:(Ljava/lang/String;)V
        //  2401: getstatic       java/lang/System.out:Ljava/io/PrintStream;
        //  2404: invokevirtual   java/io/PrintStream.println:()V
        //  2407: getstatic       java/lang/System.out:Ljava/io/PrintStream;
        //  2410: ldc_w           "Copyright (C) 2009 Per Bothner"
        //  2413: invokevirtual   java/io/PrintStream.println:(Ljava/lang/String;)V
        //  2416: iconst_1       
        //  2417: istore          8
        //  2419: iload           4
        //  2421: istore_1       
        //  2422: goto            140
        //  2425: aload           5
        //  2427: invokevirtual   java/lang/String.length:()I
        //  2430: ifle            2798
        //  2433: aload           5
        //  2435: iconst_0       
        //  2436: invokevirtual   java/lang/String.charAt:(I)C
        //  2439: bipush          45
        //  2441: if_icmpne       2798
        //  2444: aload           5
        //  2446: astore          6
        //  2448: aload           6
        //  2450: astore          7
        //  2452: aload           6
        //  2454: invokevirtual   java/lang/String.length:()I
        //  2457: iconst_2       
        //  2458: if_icmple       2497
        //  2461: aload           6
        //  2463: astore          7
        //  2465: aload           6
        //  2467: iconst_0       
        //  2468: invokevirtual   java/lang/String.charAt:(I)C
        //  2471: bipush          45
        //  2473: if_icmpne       2497
        //  2476: aload           6
        //  2478: iconst_1       
        //  2479: invokevirtual   java/lang/String.charAt:(I)C
        //  2482: bipush          45
        //  2484: if_icmpne       2534
        //  2487: iconst_2       
        //  2488: istore_1       
        //  2489: aload           6
        //  2491: iload_1        
        //  2492: invokevirtual   java/lang/String.substring:(I)Ljava/lang/String;
        //  2495: astore          7
        //  2497: aload           7
        //  2499: invokestatic    gnu/expr/Language.getInstance:(Ljava/lang/String;)Lgnu/expr/Language;
        //  2502: astore          6
        //  2504: aload           6
        //  2506: ifnull          2547
        //  2509: getstatic       kawa/repl.previousLanguage:Lgnu/expr/Language;
        //  2512: ifnonnull       2539
        //  2515: aload           6
        //  2517: invokestatic    gnu/expr/Language.setDefaults:(Lgnu/expr/Language;)V
        //  2520: aload           6
        //  2522: putstatic       kawa/repl.previousLanguage:Lgnu/expr/Language;
        //  2525: iload_3        
        //  2526: istore          8
        //  2528: iload           4
        //  2530: istore_1       
        //  2531: goto            140
        //  2534: iconst_1       
        //  2535: istore_1       
        //  2536: goto            2489
        //  2539: aload           6
        //  2541: invokestatic    gnu/expr/Language.setCurrentLanguage:(Lgnu/expr/Language;)V
        //  2544: goto            2520
        //  2547: aload           7
        //  2549: ldc_w           "="
        //  2552: invokevirtual   java/lang/String.indexOf:(Ljava/lang/String;)I
        //  2555: istore_1       
        //  2556: iload_1        
        //  2557: ifge            2720
        //  2560: aconst_null    
        //  2561: astore          6
        //  2563: aload           7
        //  2565: ldc_w           "no-"
        //  2568: invokevirtual   java/lang/String.startsWith:(Ljava/lang/String;)Z
        //  2571: ifeq            2742
        //  2574: aload           7
        //  2576: invokevirtual   java/lang/String.length:()I
        //  2579: iconst_3       
        //  2580: if_icmple       2742
        //  2583: iconst_1       
        //  2584: istore          13
        //  2586: aload           7
        //  2588: astore          10
        //  2590: aload           6
        //  2592: astore          9
        //  2594: aload           6
        //  2596: ifnonnull       2625
        //  2599: aload           7
        //  2601: astore          10
        //  2603: aload           6
        //  2605: astore          9
        //  2607: iload           13
        //  2609: ifeq            2625
        //  2612: ldc_w           "no"
        //  2615: astore          9
        //  2617: aload           7
        //  2619: iconst_3       
        //  2620: invokevirtual   java/lang/String.substring:(I)Ljava/lang/String;
        //  2623: astore          10
        //  2625: getstatic       gnu/expr/Compilation.options:Lgnu/text/Options;
        //  2628: aload           10
        //  2630: aload           9
        //  2632: invokevirtual   gnu/text/Options.set:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
        //  2635: astore          6
        //  2637: iload_3        
        //  2638: istore          8
        //  2640: iload           4
        //  2642: istore_1       
        //  2643: aload           6
        //  2645: ifnull          140
        //  2648: aload           6
        //  2650: astore          7
        //  2652: iload           13
        //  2654: ifeq            2698
        //  2657: aload           6
        //  2659: astore          7
        //  2661: aload           6
        //  2663: ldc_w           "unknown option name"
        //  2666: if_acmpne       2698
        //  2669: new             Ljava/lang/StringBuilder;
        //  2672: dup            
        //  2673: invokespecial   java/lang/StringBuilder.<init>:()V
        //  2676: ldc_w           "both '--no-' prefix and '="
        //  2679: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  2682: aload           9
        //  2684: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  2687: ldc_w           "' specified"
        //  2690: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  2693: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //  2696: astore          7
        //  2698: aload           7
        //  2700: ldc_w           "unknown option name"
        //  2703: if_acmpne       2748
        //  2706: aload           5
        //  2708: invokestatic    kawa/repl.bad_option:(Ljava/lang/String;)V
        //  2711: iload_3        
        //  2712: istore          8
        //  2714: iload           4
        //  2716: istore_1       
        //  2717: goto            140
        //  2720: aload           7
        //  2722: iload_1        
        //  2723: iconst_1       
        //  2724: iadd           
        //  2725: invokevirtual   java/lang/String.substring:(I)Ljava/lang/String;
        //  2728: astore          6
        //  2730: aload           7
        //  2732: iconst_0       
        //  2733: iload_1        
        //  2734: invokevirtual   java/lang/String.substring:(II)Ljava/lang/String;
        //  2737: astore          7
        //  2739: goto            2563
        //  2742: iconst_0       
        //  2743: istore          13
        //  2745: goto            2586
        //  2748: getstatic       java/lang/System.err:Ljava/io/PrintStream;
        //  2751: new             Ljava/lang/StringBuilder;
        //  2754: dup            
        //  2755: invokespecial   java/lang/StringBuilder.<init>:()V
        //  2758: ldc             "kawa: bad option '"
        //  2760: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  2763: aload           5
        //  2765: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  2768: ldc_w           "': "
        //  2771: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  2774: aload           7
        //  2776: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  2779: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //  2782: invokevirtual   java/io/PrintStream.println:(Ljava/lang/String;)V
        //  2785: iconst_m1      
        //  2786: invokestatic    java/lang/System.exit:(I)V
        //  2789: iload_3        
        //  2790: istore          8
        //  2792: iload           4
        //  2794: istore_1       
        //  2795: goto            140
        //  2798: iload_3        
        //  2799: istore          8
        //  2801: iload           4
        //  2803: istore_1       
        //  2804: aload           5
        //  2806: invokestatic    gnu/expr/ApplicationMainSupport.processSetProperty:(Ljava/lang/String;)Z
        //  2809: ifne            140
        //  2812: iload_3        
        //  2813: ifeq            2821
        //  2816: iconst_m1      
        //  2817: istore_1       
        //  2818: goto            315
        //  2821: iload           4
        //  2823: istore_1       
        //  2824: goto            315
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                             
        //  -----  -----  -----  -----  ---------------------------------
        //  256    262    317    327    Ljava/lang/Throwable;
        //  367    397    756    770    Ljava/lang/Throwable;
        //  403    427    756    770    Ljava/lang/Throwable;
        //  455    461    756    770    Ljava/lang/Throwable;
        //  464    471    756    770    Ljava/lang/Throwable;
        //  476    521    756    770    Ljava/lang/Throwable;
        //  566    584    756    770    Ljava/lang/Throwable;
        //  584    590    756    770    Ljava/lang/Throwable;
        //  594    615    756    770    Ljava/lang/Throwable;
        //  624    667    756    770    Ljava/lang/Throwable;
        //  667    723    756    770    Ljava/lang/Throwable;
        //  728    753    756    770    Ljava/lang/Throwable;
        //  753    756    756    770    Ljava/lang/Throwable;
        //  791    815    756    770    Ljava/lang/Throwable;
        //  826    835    756    770    Ljava/lang/Throwable;
        //  1413   1483   1492   1512   Ljava/io/IOException;
        //  1512   1520   1523   1536   Ljava/lang/NumberFormatException;
        //  1579   1628   1713   1726   Ljava/io/IOException;
        //  1628   1710   1713   1726   Ljava/io/IOException;
        //  1726   1733   1736   1748   Ljava/lang/NumberFormatException;
        // 
        // The error that occurred was:
        // 
        // java.lang.NullPointerException
        //     at com.strobel.assembler.ir.StackMappingVisitor.push(StackMappingVisitor.java:290)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:833)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static void setArgs(final String[] array, final int n) {
        ApplicationMainSupport.setArgs(array, n);
    }
    
    public static boolean shouldUseGuiConsole() {
        boolean b = true;
        if (!repl.noConsole) {
            while (true) {
                try {
                    if (Class.forName("java.lang.System").getMethod("console", (Class<?>[])new Class[0]).invoke(new Object[0], new Object[0]) != null) {
                        b = false;
                    }
                }
                catch (Throwable t) {
                    continue;
                }
                break;
            }
        }
        return b;
    }
    
    private static void startGuiConsole() {
        try {
            Class.forName("kawa.GuiConsole").newInstance();
        }
        catch (Exception obj) {
            System.err.println("failed to create Kawa window: " + obj);
            System.exit(-1);
        }
    }
    
    @Override
    public Object apply0() {
        Shell.run(this.language, Environment.getCurrent());
        return Values.empty;
    }
    
    @Override
    public Object apply1(final Object o) {
        Shell.run(this.language, (Environment)o);
        return Values.empty;
    }
}
