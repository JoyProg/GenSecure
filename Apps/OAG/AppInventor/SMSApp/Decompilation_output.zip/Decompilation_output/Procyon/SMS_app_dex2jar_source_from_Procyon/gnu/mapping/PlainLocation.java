// 
// Decompiled by Procyon v0.5.36
// 

package gnu.mapping;

public class PlainLocation extends NamedLocation
{
    public PlainLocation(final Symbol symbol, final Object o) {
        super(symbol, o);
    }
    
    public PlainLocation(final Symbol symbol, final Object o, final Object value) {
        super(symbol, o);
        this.value = value;
    }
    
    @Override
    public final Object get(Object o) {
        if (this.base != null) {
            o = this.base.get(o);
        }
        else if (this.value != Location.UNBOUND) {
            o = this.value;
        }
        return o;
    }
    
    @Override
    public boolean isBound() {
        boolean bound;
        if (this.base != null) {
            bound = this.base.isBound();
        }
        else {
            bound = (this.value != Location.UNBOUND);
        }
        return bound;
    }
    
    @Override
    public final void set(final Object o) {
        if (this.base == null) {
            this.value = o;
        }
        else if (this.value == PlainLocation.DIRECT_ON_SET) {
            this.base = null;
            this.value = o;
        }
        else if (this.base.isConstant()) {
            this.getEnvironment().put(this.getKeySymbol(), this.getKeyProperty(), o);
        }
        else {
            this.base.set(o);
        }
    }
}
