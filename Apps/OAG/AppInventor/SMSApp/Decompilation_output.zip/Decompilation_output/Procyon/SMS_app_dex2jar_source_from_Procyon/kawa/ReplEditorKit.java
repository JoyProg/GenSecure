// 
// Decompiled by Procyon v0.5.36
// 

package kawa;

import gnu.kawa.models.Paintable;
import javax.swing.text.AttributeSet;
import gnu.kawa.swingviews.SwingDisplay;
import gnu.kawa.models.Viewable;
import javax.swing.JPanel;
import java.awt.Component;
import javax.swing.text.ComponentView;
import javax.swing.text.View;
import javax.swing.text.Element;
import javax.swing.text.ViewFactory;
import javax.swing.text.StyledEditorKit;

class ReplEditorKit extends StyledEditorKit
{
    ViewFactory factory;
    final ReplPane pane;
    ViewFactory styledFactory;
    
    public ReplEditorKit(final ReplPane pane) {
        this.pane = pane;
        this.styledFactory = super.getViewFactory();
        this.factory = new ViewFactory() {
            @Override
            public View create(final Element element) {
                final String name = element.getName();
                View create;
                if (name == "Viewable") {
                    create = new ComponentView(element) {
                        @Override
                        protected Component createComponent() {
                            final AttributeSet attributes = this.getElement().getAttributes();
                            JPanel panel = new JPanel();
                            ((Viewable)attributes.getAttribute(ReplPane.ViewableAttribute)).makeView(SwingDisplay.getInstance(), panel);
                            if (panel.getComponentCount() == 1) {
                                final Component component = panel.getComponent(0);
                                panel.removeAll();
                                panel = (JPanel)component;
                            }
                            else {
                                panel.setBackground(pane.getBackground());
                            }
                            return panel;
                        }
                    };
                }
                else if (name == "Paintable") {
                    create = new PaintableView(element, (Paintable)element.getAttributes().getAttribute(ReplPane.PaintableAttribute));
                }
                else {
                    create = ReplEditorKit.this.styledFactory.create(element);
                }
                return create;
            }
        };
    }
    
    @Override
    public ViewFactory getViewFactory() {
        return this.factory;
    }
}
