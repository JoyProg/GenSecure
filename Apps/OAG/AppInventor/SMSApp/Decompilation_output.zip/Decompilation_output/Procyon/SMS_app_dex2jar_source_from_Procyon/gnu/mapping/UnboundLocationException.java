// 
// Decompiled by Procyon v0.5.36
// 

package gnu.mapping;

import gnu.text.SourceLocator;

public class UnboundLocationException extends RuntimeException
{
    int column;
    String filename;
    int line;
    Location location;
    public Object symbol;
    
    public UnboundLocationException() {
    }
    
    public UnboundLocationException(final Location location) {
        this.location = location;
    }
    
    public UnboundLocationException(final Object symbol) {
        this.symbol = symbol;
    }
    
    public UnboundLocationException(final Object symbol, final SourceLocator sourceLocator) {
        this.symbol = symbol;
        if (sourceLocator != null) {
            this.filename = sourceLocator.getFileName();
            this.line = sourceLocator.getLineNumber();
            this.column = sourceLocator.getColumnNumber();
        }
    }
    
    public UnboundLocationException(final Object symbol, final String message) {
        super(message);
        this.symbol = symbol;
    }
    
    public UnboundLocationException(final Object symbol, final String filename, final int line, final int column) {
        this.symbol = symbol;
        this.filename = filename;
        this.line = line;
        this.column = column;
    }
    
    @Override
    public String getMessage() {
        String s = super.getMessage();
        if (s == null) {
            final StringBuffer sb = new StringBuffer();
            if (this.filename != null || this.line > 0) {
                if (this.filename != null) {
                    sb.append(this.filename);
                }
                if (this.line >= 0) {
                    sb.append(':');
                    sb.append(this.line);
                    if (this.column > 0) {
                        sb.append(':');
                        sb.append(this.column);
                    }
                }
                sb.append(": ");
            }
            Object keySymbol;
            if (this.location == null) {
                keySymbol = null;
            }
            else {
                keySymbol = this.location.getKeySymbol();
            }
            if (keySymbol != null) {
                sb.append("unbound location ");
                sb.append(keySymbol);
                final Object keyProperty = this.location.getKeyProperty();
                if (keyProperty != null) {
                    sb.append(" (property ");
                    sb.append(keyProperty);
                    sb.append(')');
                }
            }
            else if (this.symbol != null) {
                sb.append("unbound location ");
                sb.append(this.symbol);
            }
            else {
                sb.append("unbound location");
            }
            s = sb.toString();
        }
        return s;
    }
    
    public void setLine(final String filename, final int line, final int column) {
        this.filename = filename;
        this.line = line;
        this.column = column;
    }
    
    @Override
    public String toString() {
        return this.getMessage();
    }
}
