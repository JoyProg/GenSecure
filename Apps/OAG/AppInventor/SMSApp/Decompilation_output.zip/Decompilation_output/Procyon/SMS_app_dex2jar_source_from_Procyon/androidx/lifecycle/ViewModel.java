// 
// Decompiled by Procyon v0.5.36
// 

package androidx.lifecycle;

public abstract class ViewModel
{
    protected void onCleared() {
    }
}
