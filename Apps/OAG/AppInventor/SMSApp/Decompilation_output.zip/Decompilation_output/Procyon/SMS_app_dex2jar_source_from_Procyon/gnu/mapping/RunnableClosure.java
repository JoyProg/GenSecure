// 
// Decompiled by Procyon v0.5.36
// 

package gnu.mapping;

import java.util.concurrent.Callable;

public class RunnableClosure implements Callable<Object>, Runnable
{
    static int nrunnables;
    Procedure action;
    CallContext context;
    private OutPort err;
    Throwable exception;
    private InPort in;
    String name;
    private OutPort out;
    Object result;
    
    static {
        RunnableClosure.nrunnables = 0;
    }
    
    public RunnableClosure(final Procedure procedure) {
        this(procedure, CallContext.getInstance());
    }
    
    public RunnableClosure(final Procedure action, final CallContext callContext) {
        final StringBuilder append = new StringBuilder().append("r");
        final int nrunnables = RunnableClosure.nrunnables;
        RunnableClosure.nrunnables = nrunnables + 1;
        this.setName(append.append(nrunnables).toString());
        this.action = action;
    }
    
    public RunnableClosure(final Procedure procedure, final InPort in, final OutPort out, final OutPort err) {
        this(procedure, CallContext.getInstance());
        this.in = in;
        this.out = out;
        this.err = err;
    }
    
    @Override
    public Object call() throws Exception {
        this.run();
        final Throwable exception = this.exception;
        if (exception == null) {
            return this.result;
        }
        if (exception instanceof Exception) {
            throw (Exception)exception;
        }
        if (exception instanceof Error) {
            throw (Error)exception;
        }
        throw new RuntimeException(exception);
    }
    
    public final CallContext getCallContext() {
        return this.context;
    }
    
    public String getName() {
        return this.name;
    }
    
    Object getResult() throws Throwable {
        final Throwable exception = this.exception;
        if (exception != null) {
            throw exception;
        }
        return this.result;
    }
    
    @Override
    public void run() {
        try {
            final Environment current = Environment.getCurrent();
            final String name = this.getName();
            if (current != null && current.getSymbol() == null && name != null) {
                current.setName(name);
            }
            if (this.context == null) {
                this.context = CallContext.getInstance();
            }
            else {
                CallContext.setInstance(this.context);
            }
            if (this.in != null) {
                InPort.setInDefault(this.in);
            }
            if (this.out != null) {
                OutPort.setOutDefault(this.out);
            }
            if (this.err != null) {
                OutPort.setErrDefault(this.err);
            }
            this.result = this.action.apply0();
        }
        catch (Throwable exception) {
            this.exception = exception;
        }
    }
    
    public void setName(final String name) {
        this.name = name;
    }
    
    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer();
        sb.append("#<runnable ");
        sb.append(this.getName());
        sb.append(">");
        return sb.toString();
    }
}
