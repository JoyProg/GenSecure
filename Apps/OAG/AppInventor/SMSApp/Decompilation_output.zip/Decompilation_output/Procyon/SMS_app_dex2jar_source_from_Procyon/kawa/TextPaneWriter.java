// 
// Decompiled by Procyon v0.5.36
// 

package kawa;

import javax.swing.text.AttributeSet;
import java.io.Writer;

class TextPaneWriter extends Writer
{
    ReplDocument document;
    String str;
    AttributeSet style;
    
    public TextPaneWriter(final ReplDocument document, final AttributeSet style) {
        this.str = "";
        this.document = document;
        this.style = style;
    }
    
    @Override
    public void close() {
        this.flush();
    }
    
    @Override
    public void flush() {
        synchronized (this) {
            final String str = this.str;
            if (!str.equals("")) {
                this.str = "";
                this.write(str);
            }
        }
    }
    
    @Override
    public void write(final int n) {
        synchronized (this) {
            this.str += (char)n;
            if (n == 10) {
                this.flush();
            }
        }
    }
    
    @Override
    public void write(final String s) {
        this.document.write(s, this.style);
    }
    
    @Override
    public void write(final char[] value, final int offset, final int count) {
        synchronized (this) {
            this.flush();
            if (count != 0) {
                this.write(new String(value, offset, count));
            }
        }
    }
}
