// 
// Decompiled by Procyon v0.5.36
// 

package gnu.mapping;

public class Future extends Thread
{
    public RunnableClosure closure;
    
    public Future(final Procedure procedure) {
        this.closure = new RunnableClosure(procedure);
    }
    
    public Future(final Procedure procedure, final CallContext callContext) {
        this.closure = new RunnableClosure(procedure, callContext);
    }
    
    public Future(final Procedure procedure, final InPort inPort, final OutPort outPort, final OutPort outPort2) {
        this.closure = new RunnableClosure(procedure, inPort, outPort, outPort2);
    }
    
    public static Future make(final Procedure procedure, Environment setSaveCurrent, final InPort inPort, final OutPort outPort, final OutPort outPort2) {
        setSaveCurrent = Environment.setSaveCurrent(setSaveCurrent);
        try {
            return new Future(procedure, inPort, outPort, outPort2);
        }
        finally {
            Environment.restoreCurrent(setSaveCurrent);
        }
    }
    
    public final CallContext getCallContext() {
        return this.closure.getCallContext();
    }
    
    @Override
    public void run() {
        this.closure.run();
    }
    
    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer();
        sb.append("#<future ");
        sb.append(this.getName());
        sb.append(">");
        return sb.toString();
    }
    
    public Object waitForResult() throws Throwable {
        try {
            this.join();
            final Throwable exception = this.closure.exception;
            if (exception != null) {
                throw exception;
            }
        }
        catch (InterruptedException ex) {
            throw new RuntimeException("thread join [force] was interrupted");
        }
        return this.closure.result;
    }
}
