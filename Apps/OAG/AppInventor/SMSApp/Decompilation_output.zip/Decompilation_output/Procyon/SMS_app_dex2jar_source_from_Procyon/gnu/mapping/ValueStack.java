// 
// Decompiled by Procyon v0.5.36
// 

package gnu.mapping;

import gnu.lists.Sequence;

public class ValueStack extends Values implements Sequence
{
    @Override
    public void clear() {
        this.oindex = 0;
        super.clear();
    }
}
