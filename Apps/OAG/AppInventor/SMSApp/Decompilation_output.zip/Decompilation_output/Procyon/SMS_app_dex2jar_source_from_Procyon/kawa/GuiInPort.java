// 
// Decompiled by Procyon v0.5.36
// 

package kawa;

import java.io.IOException;
import javax.swing.text.AttributeSet;
import gnu.mapping.OutPort;
import gnu.text.Path;
import java.io.Reader;
import gnu.mapping.TtyInPort;

class GuiInPort extends TtyInPort
{
    ReplDocument document;
    
    public GuiInPort(final Reader reader, final Path path, final OutPort outPort, final ReplDocument document) {
        super(reader, path, outPort);
        this.document = document;
    }
    
    @Override
    public void emitPrompt(final String s) throws IOException {
        this.document.write(s, ReplDocument.promptStyle);
    }
}
