// 
// Decompiled by Procyon v0.5.36
// 

package gnu.mapping;

import java.io.ObjectOutput;
import java.io.ObjectStreamException;
import java.io.IOException;
import java.io.ObjectInput;

public class SimpleSymbol extends Symbol
{
    public SimpleSymbol() {
    }
    
    public SimpleSymbol(final String s) {
        super(Namespace.EmptyNamespace, s);
    }
    
    @Override
    public void readExternal(final ObjectInput objectInput) throws IOException, ClassNotFoundException {
        this.name = ((String)objectInput.readObject()).intern();
    }
    
    @Override
    public Object readResolve() throws ObjectStreamException {
        return Namespace.EmptyNamespace.getSymbol(this.getName().intern());
    }
    
    @Override
    public void writeExternal(final ObjectOutput objectOutput) throws IOException {
        objectOutput.writeObject(this.getName());
    }
}
