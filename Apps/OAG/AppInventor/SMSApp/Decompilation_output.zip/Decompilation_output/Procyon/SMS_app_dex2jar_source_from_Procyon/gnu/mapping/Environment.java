// 
// Decompiled by Procyon v0.5.36
// 

package gnu.mapping;

import java.util.Hashtable;

public abstract class Environment extends PropertySet
{
    static final int CAN_DEFINE = 1;
    static final int CAN_IMPLICITLY_DEFINE = 4;
    static final int CAN_REDEFINE = 2;
    static final int DIRECT_INHERITED_ON_SET = 16;
    public static final int INDIRECT_DEFINES = 32;
    static final int THREAD_SAFE = 8;
    protected static final InheritedLocal curEnvironment;
    static final Hashtable envTable;
    static Environment global;
    int flags;
    
    static {
        envTable = new Hashtable(50);
        curEnvironment = new InheritedLocal();
    }
    
    public Environment() {
        this.flags = 23;
    }
    
    public static Environment current() {
        return getCurrent();
    }
    
    public static Environment getCurrent() {
        Environment make;
        if ((make = Environment.curEnvironment.get()) == null) {
            make = make(Thread.currentThread().getName(), Environment.global);
            make.flags |= 0x8;
            Environment.curEnvironment.set(make);
        }
        return make;
    }
    
    public static Environment getGlobal() {
        return Environment.global;
    }
    
    public static Environment getInstance(final String s) {
        String key = s;
        if (s == null) {
            key = "";
        }
        synchronized (Environment.envTable) {
            Environment value = Environment.envTable.get(key);
            if (value == null) {
                value = new SimpleEnvironment();
                value.setName(key);
                Environment.envTable.put(key, value);
            }
            // monitorexit(Environment.envTable)
            return value;
        }
    }
    
    public static InheritingEnvironment make(final String s, final Environment environment) {
        return new InheritingEnvironment(s, environment);
    }
    
    public static SimpleEnvironment make() {
        return new SimpleEnvironment();
    }
    
    public static SimpleEnvironment make(final String s) {
        return new SimpleEnvironment(s);
    }
    
    public static void restoreCurrent(final Environment value) {
        Environment.curEnvironment.set(value);
    }
    
    public static void setCurrent(final Environment value) {
        Environment.curEnvironment.set(value);
    }
    
    public static void setGlobal(final Environment global) {
        Environment.global = global;
    }
    
    public static Environment setSaveCurrent(final Environment value) {
        final Environment environment = Environment.curEnvironment.get();
        Environment.curEnvironment.set(value);
        return environment;
    }
    
    public static Environment user() {
        return getCurrent();
    }
    
    public abstract NamedLocation addLocation(final Symbol p0, final Object p1, final Location p2);
    
    public final void addLocation(final EnvironmentKey environmentKey, final Location location) {
        this.addLocation(environmentKey.getKeySymbol(), environmentKey.getKeyProperty(), location);
    }
    
    public final void addLocation(final NamedLocation namedLocation) {
        this.addLocation(namedLocation.getKeySymbol(), namedLocation.getKeyProperty(), namedLocation);
    }
    
    SimpleEnvironment cloneForThread() {
        final InheritingEnvironment inheritingEnvironment = new InheritingEnvironment(null, this);
        if (this instanceof InheritingEnvironment) {
            final InheritingEnvironment inheritingEnvironment2 = (InheritingEnvironment)this;
            final int numInherited = inheritingEnvironment2.numInherited;
            inheritingEnvironment.numInherited = numInherited;
            inheritingEnvironment.inherited = new Environment[numInherited];
            for (int i = 0; i < numInherited; ++i) {
                inheritingEnvironment.inherited[i] = inheritingEnvironment2.inherited[i];
            }
        }
        final LocationEnumeration enumerateLocations = this.enumerateLocations();
        while (enumerateLocations.hasMoreElements()) {
            final Location nextLocation = enumerateLocations.nextLocation();
            final Symbol keySymbol = nextLocation.getKeySymbol();
            final Object keyProperty = nextLocation.getKeyProperty();
            if (keySymbol != null && nextLocation instanceof NamedLocation) {
                NamedLocation namedLocation2;
                final NamedLocation namedLocation = namedLocation2 = (NamedLocation)nextLocation;
                if (namedLocation.base == null) {
                    namedLocation2 = new SharedLocation(keySymbol, keyProperty, 0);
                    ((SharedLocation)namedLocation2).value = namedLocation.value;
                    namedLocation.base = namedLocation2;
                    namedLocation.value = null;
                }
                inheritingEnvironment.addUnboundLocation(keySymbol, keyProperty, keySymbol.hashCode() ^ System.identityHashCode(keyProperty)).base = namedLocation2;
            }
        }
        return inheritingEnvironment;
    }
    
    public final boolean containsKey(final Object o) {
        Object keyProperty = null;
        Object keySymbol = o;
        if (o instanceof EnvironmentKey) {
            final EnvironmentKey environmentKey = (EnvironmentKey)o;
            keySymbol = environmentKey.getKeySymbol();
            keyProperty = environmentKey.getKeyProperty();
        }
        Symbol symbol;
        if (keySymbol instanceof Symbol) {
            symbol = (Symbol)keySymbol;
        }
        else {
            symbol = this.getSymbol((String)keySymbol);
        }
        return this.isBound(symbol, keyProperty);
    }
    
    public Namespace defaultNamespace() {
        return Namespace.getDefault();
    }
    
    public abstract void define(final Symbol p0, final Object p1, final Object p2);
    
    public abstract LocationEnumeration enumerateAllLocations();
    
    public abstract LocationEnumeration enumerateLocations();
    
    public final Object get(final EnvironmentKey environmentKey, final Object o) {
        return this.get(environmentKey.getKeySymbol(), environmentKey.getKeyProperty(), o);
    }
    
    public Object get(final Symbol symbol) {
        final String unbound = Location.UNBOUND;
        final Object value = this.get(symbol, null, unbound);
        if (value == unbound) {
            throw new UnboundLocationException(symbol);
        }
        return value;
    }
    
    public Object get(final Symbol symbol, final Object o, Object value) {
        final Location lookup = this.lookup(symbol, o);
        if (lookup != null) {
            value = lookup.get(value);
        }
        return value;
    }
    
    public final Object get(final Object o) {
        Object keyProperty = null;
        Object keySymbol = o;
        if (o instanceof EnvironmentKey) {
            final EnvironmentKey environmentKey = (EnvironmentKey)o;
            keySymbol = environmentKey.getKeySymbol();
            keyProperty = environmentKey.getKeyProperty();
        }
        Symbol symbol;
        if (keySymbol instanceof Symbol) {
            symbol = (Symbol)keySymbol;
        }
        else {
            symbol = this.getSymbol((String)keySymbol);
        }
        return this.get(symbol, keyProperty, null);
    }
    
    public final Object get(final String s, final Object o) {
        return this.get(this.getSymbol(s), null, o);
    }
    
    public boolean getCanDefine() {
        return (this.flags & 0x1) != 0x0;
    }
    
    public boolean getCanRedefine() {
        return (this.flags & 0x2) != 0x0;
    }
    
    public final Object getChecked(final String str) {
        final Object value = this.get(str, Location.UNBOUND);
        if (value == Location.UNBOUND) {
            throw new UnboundLocationException((Object)(str + " in " + this));
        }
        return value;
    }
    
    public int getFlags() {
        return this.flags;
    }
    
    public final Object getFunction(final Symbol symbol) {
        final String unbound = Location.UNBOUND;
        final Object value = this.get(symbol, EnvironmentKey.FUNCTION, unbound);
        if (value == unbound) {
            throw new UnboundLocationException(symbol);
        }
        return value;
    }
    
    public final Object getFunction(final Symbol symbol, final Object o) {
        return this.get(symbol, EnvironmentKey.FUNCTION, o);
    }
    
    public final Location getLocation(final Symbol symbol) {
        return this.getLocation(symbol, null, true);
    }
    
    public final Location getLocation(final Symbol symbol, final Object o) {
        return this.getLocation(symbol, o, true);
    }
    
    public final Location getLocation(final Object o, final boolean b) {
        Object keyProperty = null;
        Object keySymbol = o;
        if (o instanceof EnvironmentKey) {
            final EnvironmentKey environmentKey = (EnvironmentKey)o;
            keySymbol = environmentKey.getKeySymbol();
            keyProperty = environmentKey.getKeyProperty();
        }
        Symbol symbol;
        if (keySymbol instanceof Symbol) {
            symbol = (Symbol)keySymbol;
        }
        else {
            symbol = this.getSymbol((String)keySymbol);
        }
        return this.getLocation(symbol, keyProperty, b);
    }
    
    public abstract NamedLocation getLocation(final Symbol p0, final Object p1, final int p2, final boolean p3);
    
    public final NamedLocation getLocation(final Symbol symbol, final Object o, final boolean b) {
        return this.getLocation(symbol, o, symbol.hashCode() ^ System.identityHashCode(o), b);
    }
    
    public Symbol getSymbol(final String s) {
        return this.defaultNamespace().getSymbol(s);
    }
    
    protected abstract boolean hasMoreElements(final LocationEnumeration p0);
    
    public final boolean isBound(final Symbol symbol) {
        return this.isBound(symbol, null);
    }
    
    public boolean isBound(final Symbol symbol, final Object o) {
        final Location lookup = this.lookup(symbol, o);
        return lookup != null && lookup.isBound();
    }
    
    public final boolean isLocked() {
        return (this.flags & 0x3) == 0x0;
    }
    
    public final Location lookup(final Symbol symbol) {
        return this.getLocation(symbol, null, false);
    }
    
    public final Location lookup(final Symbol symbol, final Object o) {
        return this.getLocation(symbol, o, false);
    }
    
    public abstract NamedLocation lookup(final Symbol p0, final Object p1, final int p2);
    
    public final Object put(final Object o, final Object o2) {
        final Location location = this.getLocation(o, true);
        final Object value = location.get(null);
        location.set(o2);
        return value;
    }
    
    public final Object put(final String s, final Object o) {
        return this.put((Object)s, o);
    }
    
    public final void put(final Symbol symbol, final Object o) {
        this.put(symbol, null, o);
    }
    
    public void put(final Symbol symbol, final Object o, final Object o2) {
        final Location location = this.getLocation(symbol, o);
        if (location.isConstant()) {
            this.define(symbol, o, o2);
        }
        else {
            location.set(o2);
        }
    }
    
    public final void putFunction(final Symbol symbol, final Object o) {
        this.put(symbol, EnvironmentKey.FUNCTION, o);
    }
    
    public final Object remove(final EnvironmentKey environmentKey) {
        final Symbol keySymbol = environmentKey.getKeySymbol();
        final Object keyProperty = environmentKey.getKeyProperty();
        return this.remove(keySymbol, keyProperty, keySymbol.hashCode() ^ System.identityHashCode(keyProperty));
    }
    
    public final Object remove(final Symbol symbol, final Object o) {
        return this.remove(symbol, o, symbol.hashCode() ^ System.identityHashCode(o));
    }
    
    public Object remove(final Symbol symbol, final Object o, final int n) {
        final Object o2 = null;
        final Location unlink = this.unlink(symbol, o, n);
        Object value;
        if (unlink == null) {
            value = o2;
        }
        else {
            value = unlink.get(null);
            unlink.undefine();
        }
        return value;
    }
    
    public final Object remove(Object o) {
        if (o instanceof EnvironmentKey) {
            final EnvironmentKey environmentKey = (EnvironmentKey)o;
            o = this.remove(environmentKey.getKeySymbol(), environmentKey.getKeyProperty());
        }
        else {
            Symbol symbol;
            if (o instanceof Symbol) {
                symbol = (Symbol)o;
            }
            else {
                symbol = this.getSymbol((String)o);
            }
            o = this.remove(symbol, null, symbol.hashCode() ^ System.identityHashCode(null));
        }
        return o;
    }
    
    public final void remove(final Symbol symbol) {
        this.remove(symbol, null, symbol.hashCode());
    }
    
    public final void removeFunction(final Symbol symbol) {
        this.remove(symbol, EnvironmentKey.FUNCTION);
    }
    
    public void setCanDefine(final boolean b) {
        if (b) {
            this.flags |= 0x1;
        }
        else {
            this.flags &= 0xFFFFFFFE;
        }
    }
    
    public void setCanRedefine(final boolean b) {
        if (b) {
            this.flags |= 0x2;
        }
        else {
            this.flags &= 0xFFFFFFFD;
        }
    }
    
    public void setFlag(final boolean b, final int n) {
        if (b) {
            this.flags |= n;
        }
        else {
            this.flags &= ~n;
        }
    }
    
    public final void setIndirectDefines() {
        this.flags |= 0x20;
        ((InheritingEnvironment)this).baseTimestamp = Integer.MAX_VALUE;
    }
    
    public void setLocked() {
        this.flags &= 0xFFFFFFF8;
    }
    
    @Override
    public String toString() {
        return "#<environment " + this.getName() + '>';
    }
    
    public String toStringVerbose() {
        return this.toString();
    }
    
    public Location unlink(final Symbol symbol, final Object o, final int n) {
        throw new RuntimeException("unsupported operation: unlink (aka undefine)");
    }
    
    static class InheritedLocal extends InheritableThreadLocal<Environment>
    {
        @Override
        protected Environment childValue(final Environment environment) {
            Environment current = environment;
            if (environment == null) {
                current = Environment.getCurrent();
            }
            final SimpleEnvironment cloneForThread = current.cloneForThread();
            cloneForThread.flags |= 0x8;
            cloneForThread.flags &= 0xFFFFFFEF;
            return cloneForThread;
        }
    }
}
