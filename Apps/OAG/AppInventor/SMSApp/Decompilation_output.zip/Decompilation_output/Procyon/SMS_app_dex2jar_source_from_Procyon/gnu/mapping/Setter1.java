// 
// Decompiled by Procyon v0.5.36
// 

package gnu.mapping;

public class Setter1 extends Setter
{
    public Setter1(final Procedure procedure) {
        super(procedure);
    }
    
    @Override
    public Object apply2(final Object o, final Object o2) throws Throwable {
        this.getter.set1(o, o2);
        return Values.empty;
    }
    
    @Override
    public Object applyN(final Object[] array) throws Throwable {
        final int length = array.length;
        if (length != 2) {
            throw new WrongArguments(this, length);
        }
        this.getter.set1(array[0], array[1]);
        return Values.empty;
    }
    
    @Override
    public int numArgs() {
        return 8194;
    }
}
