// 
// Decompiled by Procyon v0.5.36
// 

package gnu.mapping;

public class PropertyKey<T>
{
    String name;
    
    public PropertyKey(final String name) {
        this.name = name;
    }
    
    public final T get(final PropertySet set) {
        return this.get(set, null);
    }
    
    public T get(final PropertySet set, final T t) {
        return (T)set.getProperty(this, t);
    }
    
    public void set(final PropertySet set, final T t) {
        set.setProperty(this, t);
    }
}
