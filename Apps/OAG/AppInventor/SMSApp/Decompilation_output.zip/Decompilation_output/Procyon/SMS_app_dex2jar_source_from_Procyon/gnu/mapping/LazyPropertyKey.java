// 
// Decompiled by Procyon v0.5.36
// 

package gnu.mapping;

public class LazyPropertyKey<T> extends PropertyKey<T>
{
    public LazyPropertyKey(final String s) {
        super(s);
    }
    
    @Override
    public T get(final PropertySet set, final T t) {
        final Object property = set.getProperty(this, t);
        if (!(property instanceof String)) {
            return (T)property;
        }
        final String str = (String)property;
        int beginIndex;
        if (str.charAt(0) == '*') {
            beginIndex = 1;
        }
        else {
            beginIndex = 0;
        }
        final int index = str.indexOf(58);
        if (index <= beginIndex || index >= str.length() - 1) {
            throw new RuntimeException("lazy property " + this + " must have the form \"ClassName:fieldName\" or \"ClassName:staticMethodName\"");
        }
        final String substring = str.substring(beginIndex, index);
        final String substring2 = str.substring(index + 1);
        try {
            final Class<?> forName = Class.forName(substring, true, set.getClass().getClassLoader());
            Object o;
            if (beginIndex == 0) {
                o = forName.getField(substring2).get(null);
            }
            else {
                o = forName.getDeclaredMethod(substring2, Object.class).invoke(null, set);
            }
            set.setProperty(this, o);
            final Object o2 = o;
            return (T)o2;
        }
        catch (Throwable cause) {
            final StringBuilder append = new StringBuilder().append("lazy property ").append(this).append(" has specifier \"").append(str).append("\" but there is no such ");
            String str2;
            if (beginIndex == 0) {
                str2 = "field";
            }
            else {
                str2 = "method";
            }
            throw new RuntimeException(append.append(str2).toString(), cause);
        }
        final Object o2 = property;
        return (T)o2;
    }
    
    public void set(final PropertySet set, final String s) {
        set.setProperty(this, s);
    }
}
