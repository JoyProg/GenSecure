// 
// Decompiled by Procyon v0.5.36
// 

package kawa;

import java.io.IOException;
import java.io.OutputStream;
import java.io.FilterOutputStream;

public class TelnetOutputStream extends FilterOutputStream
{
    public TelnetOutputStream(final OutputStream out) {
        super(out);
    }
    
    @Override
    public void write(final int n) throws IOException {
        if (n == 255) {
            this.out.write(n);
        }
        this.out.write(n);
    }
    
    @Override
    public void write(final byte[] array) throws IOException {
        this.write(array, 0, array.length);
    }
    
    @Override
    public void write(final byte[] array, int i, int n) throws IOException {
        final int n2 = i + n;
        final int n3 = i;
        n = i;
        int n4;
        for (i = n3; i < n2; ++i, n = n4) {
            n4 = n;
            if (array[i] == -1) {
                this.out.write(array, n, i + 1 - n);
                n4 = i;
            }
        }
        this.out.write(array, n, n2 - n);
    }
    
    public void writeCommand(final int n) throws IOException {
        this.out.write(255);
        this.out.write(n);
    }
    
    public final void writeCommand(final int n, final int n2) throws IOException {
        this.out.write(255);
        this.out.write(n);
        this.out.write(n2);
    }
    
    public final void writeDo(final int n) throws IOException {
        this.writeCommand(253, n);
    }
    
    public final void writeDont(final int n) throws IOException {
        this.writeCommand(254, n);
    }
    
    public final void writeSubCommand(final int n, final byte[] array) throws IOException {
        this.writeCommand(250, n);
        this.write(array);
        this.writeCommand(240);
    }
    
    public final void writeWill(final int n) throws IOException {
        this.writeCommand(251, n);
    }
    
    public final void writeWont(final int n) throws IOException {
        this.writeCommand(252, n);
    }
}
