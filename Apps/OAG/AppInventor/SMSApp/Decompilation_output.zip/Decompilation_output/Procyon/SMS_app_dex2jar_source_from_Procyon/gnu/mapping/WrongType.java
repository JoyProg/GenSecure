// 
// Decompiled by Procyon v0.5.36
// 

package gnu.mapping;

import java.io.Serializable;
import gnu.bytecode.ClassType;
import gnu.bytecode.Type;

public class WrongType extends WrappedException
{
    public static final int ARG_CAST = -4;
    public static final int ARG_DESCRIPTION = -3;
    public static final int ARG_UNKNOWN = -1;
    public static final int ARG_VARNAME = -2;
    public Object argValue;
    public Object expectedType;
    public int number;
    public Procedure proc;
    public String procname;
    
    public WrongType(final int number, final Object argValue, final Type expectedType) {
        this.number = number;
        this.argValue = argValue;
        this.expectedType = expectedType;
    }
    
    public WrongType(final Procedure proc, final int number, final ClassCastException ex) {
        super(ex);
        this.proc = proc;
        this.procname = proc.getName();
        this.number = number;
    }
    
    public WrongType(final Procedure proc, final int number, final Object argValue) {
        this.proc = proc;
        this.procname = proc.getName();
        this.number = number;
        this.argValue = argValue;
    }
    
    public WrongType(final Procedure proc, final int number, final Object argValue, final Type expectedType) {
        this.proc = proc;
        this.procname = proc.getName();
        this.number = number;
        this.argValue = argValue;
        this.expectedType = expectedType;
    }
    
    public WrongType(final Procedure proc, final int n, final Object o, final String s) {
        this(proc.getName(), n, o, s);
        this.proc = proc;
    }
    
    public WrongType(final ClassCastException ex, final Procedure procedure, final int n, final Object argValue) {
        this(procedure, n, ex);
        this.argValue = argValue;
    }
    
    public WrongType(final ClassCastException ex, final String s, final int n, final Object argValue) {
        this(s, n, ex);
        this.argValue = argValue;
    }
    
    public WrongType(final String procname, final int number, final ClassCastException ex) {
        super(ex);
        this.procname = procname;
        this.number = number;
    }
    
    public WrongType(final String procname, final int number, final Object argValue, final String expectedType) {
        this.procname = procname;
        this.number = number;
        this.argValue = argValue;
        this.expectedType = expectedType;
    }
    
    public WrongType(final String procname, final int number, final String expectedType) {
        super(null, null);
        this.procname = procname;
        this.number = number;
        this.expectedType = expectedType;
    }
    
    public static WrongType make(final ClassCastException ex, final Procedure procedure, final int n) {
        return new WrongType(procedure, n, ex);
    }
    
    public static WrongType make(final ClassCastException ex, final Procedure procedure, final int n, final Object argValue) {
        final WrongType wrongType = new WrongType(procedure, n, ex);
        wrongType.argValue = argValue;
        return wrongType;
    }
    
    public static WrongType make(final ClassCastException ex, final String s, final int n) {
        return new WrongType(s, n, ex);
    }
    
    public static WrongType make(final ClassCastException ex, final String s, final int n, final Object argValue) {
        final WrongType wrongType = new WrongType(s, n, ex);
        wrongType.argValue = argValue;
        return wrongType;
    }
    
    @Override
    public String getMessage() {
        final StringBuffer sb = new StringBuffer(100);
        if (this.number == -3) {
            sb.append(this.procname);
        }
        else if (this.number == -4 || this.number == -2) {
            sb.append("Value");
        }
        else {
            sb.append("Argument ");
            if (this.number > 0) {
                sb.append('#');
                sb.append(this.number);
            }
        }
        if (this.argValue != null) {
            sb.append(" (");
            final String string = this.argValue.toString();
            if (string.length() > 50) {
                sb.append(string.substring(0, 47));
                sb.append("...");
            }
            else {
                sb.append(string);
            }
            sb.append(")");
        }
        if (this.procname != null && this.number != -3) {
            String str;
            if (this.number == -2) {
                str = " for variable '";
            }
            else {
                str = " to '";
            }
            sb.append(str);
            sb.append(this.procname);
            sb.append("'");
        }
        sb.append(" has wrong type");
        if (this.argValue != null) {
            sb.append(" (");
            sb.append(this.argValue.getClass().getName());
            sb.append(")");
        }
        final Object expectedType = this.expectedType;
        java.lang.reflect.Type parameterType;
        if ((parameterType = (java.lang.reflect.Type)expectedType) == null) {
            parameterType = (java.lang.reflect.Type)expectedType;
            if (this.number > 0) {
                parameterType = (java.lang.reflect.Type)expectedType;
                if (this.proc instanceof MethodProc) {
                    parameterType = ((MethodProc)this.proc).getParameterType(this.number - 1);
                }
            }
        }
        if (parameterType != null && parameterType != Type.pointer_type) {
            sb.append(" (expected: ");
            Serializable obj;
            if (parameterType instanceof Type) {
                obj = ((ClassType)parameterType).getName();
            }
            else {
                obj = (Serializable)parameterType;
                if (parameterType instanceof Class) {
                    obj = ((Class)parameterType).getName();
                }
            }
            sb.append(obj);
            sb.append(")");
        }
        final Throwable cause = this.getCause();
        if (cause != null) {
            final String message = cause.getMessage();
            if (message != null) {
                sb.append(" (");
                sb.append(message);
                sb.append(')');
            }
        }
        return sb.toString();
    }
}
