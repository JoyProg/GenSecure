// 
// Decompiled by Procyon v0.5.36
// 

package gnu.mapping;

import java.io.ObjectOutput;
import java.io.ObjectStreamException;
import java.io.IOException;
import java.io.ObjectInput;
import java.util.Set;

public class SimpleEnvironment extends Environment
{
    int currentTimestamp;
    int log2Size;
    private int mask;
    int num_bindings;
    NamedLocation sharedTail;
    NamedLocation[] table;
    
    public SimpleEnvironment() {
        this(64);
    }
    
    public SimpleEnvironment(int i) {
        this.log2Size = 4;
        while (i > 1 << this.log2Size) {
            ++this.log2Size;
        }
        i = 1 << this.log2Size;
        this.table = new NamedLocation[i];
        this.mask = i - 1;
        this.sharedTail = new PlainLocation(null, null, this);
    }
    
    public SimpleEnvironment(final String name) {
        this();
        this.setName(name);
    }
    
    public static Location getCurrentLocation(final String s) {
        return Environment.getCurrent().getLocation(s, true);
    }
    
    public static Object lookup_global(final Symbol symbol) throws UnboundLocationException {
        final Location lookup = Environment.getCurrent().lookup(symbol);
        if (lookup == null) {
            throw new UnboundLocationException(symbol);
        }
        return lookup.get();
    }
    
    NamedLocation addLocation(final Symbol symbol, final Object o, final int n, final Location location) {
        Location location2 = location;
        if (location instanceof ThreadLocation) {
            location2 = location;
            if (((ThreadLocation)location).property == o) {
                location2 = ((ThreadLocation)location).getLocation();
            }
        }
        NamedLocation namedLocation = this.lookupDirect(symbol, o, n);
        if (location2 != namedLocation) {
            boolean b;
            if (namedLocation != null) {
                b = true;
            }
            else {
                b = false;
            }
            if ((b ? 1 : 0) == 0) {
                namedLocation = this.addUnboundLocation(symbol, o, n);
            }
            Label_0127: {
                if ((this.flags & 0x3) != 0x3) {
                    int bound;
                    if ((bound = (b ? 1 : 0)) != 0) {
                        bound = (namedLocation.isBound() ? 1 : 0);
                    }
                    if (bound != 0) {
                        if ((this.flags & 0x2) != 0x0) {
                            break Label_0127;
                        }
                    }
                    else if ((this.flags & 0x1) != 0x0 || !location2.isBound()) {
                        break Label_0127;
                    }
                    this.redefineError(symbol, o, namedLocation);
                }
            }
            if ((this.flags & 0x20) != 0x0) {
                namedLocation.base = ((SimpleEnvironment)((InheritingEnvironment)this).getParent(0)).addLocation(symbol, o, n, location2);
            }
            else {
                namedLocation.base = location2;
            }
            namedLocation.value = IndirectableLocation.INDIRECT_FLUIDS;
        }
        return namedLocation;
    }
    
    @Override
    public NamedLocation addLocation(final Symbol symbol, final Object o, final Location location) {
        return this.addLocation(symbol, o, symbol.hashCode() ^ System.identityHashCode(o), location);
    }
    
    protected NamedLocation addUnboundLocation(final Symbol symbol, final Object o, final int n) {
        final NamedLocation entry = this.newEntry(symbol, o, n & this.mask);
        entry.base = null;
        entry.value = Location.UNBOUND;
        return entry;
    }
    
    public NamedLocation define(final Symbol symbol, final Object o, int n, final Object value) {
        n &= this.mask;
        for (NamedLocation next = this.table[n]; next != null; next = next.next) {
            if (next.matches(symbol, o)) {
                while (true) {
                    Label_0087: {
                        if (next.isBound()) {
                            if (!this.getCanDefine()) {
                                break Label_0087;
                            }
                        }
                        else if (!this.getCanRedefine()) {
                            break Label_0087;
                        }
                        next.base = null;
                        next.value = value;
                        return next;
                    }
                    this.redefineError(symbol, o, next);
                    continue;
                }
            }
        }
        final NamedLocation entry = this.newEntry(symbol, o, n);
        entry.set(value);
        return entry;
    }
    
    @Override
    public void define(final Symbol symbol, final Object o, final Object o2) {
        this.define(symbol, o, symbol.hashCode() ^ System.identityHashCode(o), o2);
    }
    
    public Set entrySet() {
        return new EnvironmentMappings(this);
    }
    
    @Override
    public LocationEnumeration enumerateAllLocations() {
        return this.enumerateLocations();
    }
    
    @Override
    public LocationEnumeration enumerateLocations() {
        final LocationEnumeration locationEnumeration = new LocationEnumeration(this.table, 1 << this.log2Size);
        locationEnumeration.env = this;
        return locationEnumeration;
    }
    
    @Override
    public NamedLocation getLocation(final Symbol symbol, final Object o, final int n, final boolean b) {
        synchronized (this) {
            final NamedLocation lookup = this.lookup(symbol, o, n);
            NamedLocation addUnboundLocation;
            if (lookup != null) {
                addUnboundLocation = lookup;
            }
            else if (!b) {
                addUnboundLocation = null;
            }
            else {
                addUnboundLocation = this.addUnboundLocation(symbol, o, n);
            }
            return addUnboundLocation;
        }
    }
    
    @Override
    protected boolean hasMoreElements(final LocationEnumeration locationEnumeration) {
        boolean b;
        while (true) {
            if (locationEnumeration.nextLoc == null) {
                locationEnumeration.prevLoc = null;
                if (--locationEnumeration.index < 0) {
                    b = false;
                    break;
                }
                locationEnumeration.nextLoc = locationEnumeration.bindings[locationEnumeration.index];
                if (locationEnumeration.nextLoc == null) {
                    continue;
                }
            }
            if (locationEnumeration.nextLoc.name != null) {
                b = true;
                break;
            }
            locationEnumeration.nextLoc = locationEnumeration.nextLoc.next;
        }
        return b;
    }
    
    @Override
    public NamedLocation lookup(final Symbol symbol, final Object o, final int n) {
        return this.lookupDirect(symbol, o, n);
    }
    
    public NamedLocation lookupDirect(final Symbol symbol, final Object o, final int n) {
        for (NamedLocation next = this.table[n & this.mask]; next != null; next = next.next) {
            if (next.matches(symbol, o)) {
                return next;
            }
        }
        return null;
    }
    
    NamedLocation newEntry(final Symbol symbol, final Object o, final int n) {
        final NamedLocation location = this.newLocation(symbol, o);
        NamedLocation sharedTail;
        if ((sharedTail = this.table[n]) == null) {
            sharedTail = this.sharedTail;
        }
        location.next = sharedTail;
        this.table[n] = location;
        ++this.num_bindings;
        if (this.num_bindings >= this.table.length) {
            this.rehash();
        }
        return location;
    }
    
    NamedLocation newLocation(final Symbol symbol, final Object o) {
        NamedLocation namedLocation;
        if ((this.flags & 0x8) != 0x0) {
            namedLocation = new SharedLocation(symbol, o, this.currentTimestamp);
        }
        else {
            namedLocation = new PlainLocation(symbol, o);
        }
        return namedLocation;
    }
    
    @Override
    public void put(final Symbol obj, final Object o, final Object o2) {
        final NamedLocation location = this.getLocation(obj, o, (this.flags & 0x4) != 0x0);
        if (location == null) {
            throw new UnboundLocationException(obj);
        }
        if (location.isConstant()) {
            throw new IllegalStateException("attempt to modify read-only location: " + obj + " in " + this + " loc:" + location);
        }
        location.set(o2);
    }
    
    public void readExternal(final ObjectInput objectInput) throws IOException, ClassNotFoundException {
        this.setSymbol(objectInput.readObject());
    }
    
    public Object readResolve() throws ObjectStreamException {
        final String name = this.getName();
        Environment environment = SimpleEnvironment.envTable.get(name);
        if (environment == null) {
            SimpleEnvironment.envTable.put(name, this);
            environment = this;
        }
        return environment;
    }
    
    protected void redefineError(final Symbol obj, final Object o, final Location location) {
        throw new IllegalStateException("prohibited define/redefine of " + obj + " in " + this);
    }
    
    void rehash() {
        final NamedLocation[] table = this.table;
        int length = table.length;
        final int n = length * 2;
        final NamedLocation[] table2 = new NamedLocation[n];
        final int mask = n - 1;
        while (true) {
            final int n2 = length - 1;
            if (n2 < 0) {
                break;
            }
            NamedLocation namedLocation = table[n2];
            while (true) {
                length = n2;
                if (namedLocation == null) {
                    break;
                }
                length = n2;
                if (namedLocation == this.sharedTail) {
                    break;
                }
                final NamedLocation next = namedLocation.next;
                final int n3 = (namedLocation.name.hashCode() ^ System.identityHashCode(namedLocation.property)) & mask;
                NamedLocation sharedTail;
                if ((sharedTail = table2[n3]) == null) {
                    sharedTail = this.sharedTail;
                }
                namedLocation.next = sharedTail;
                table2[n3] = namedLocation;
                namedLocation = next;
            }
        }
        this.table = table2;
        ++this.log2Size;
        this.mask = mask;
    }
    
    public int size() {
        return this.num_bindings;
    }
    
    protected void toStringBase(final StringBuffer sb) {
    }
    
    @Override
    public String toStringVerbose() {
        final StringBuffer obj = new StringBuffer();
        this.toStringBase(obj);
        return "#<environment " + this.getName() + " num:" + this.num_bindings + " ts:" + this.currentTimestamp + (Object)obj + '>';
    }
    
    @Override
    public Location unlink(final Symbol symbol, final Object o, int n) {
        n &= this.mask;
        NamedLocation namedLocation = null;
        NamedLocation next2;
        for (NamedLocation next = this.table[n]; next != null; next = next2) {
            next2 = next.next;
            if (next.matches(symbol, o)) {
                if (!this.getCanRedefine()) {
                    this.redefineError(symbol, o, next);
                }
                if (namedLocation == null) {
                    this.table[n] = next2;
                }
                else {
                    namedLocation.next = next;
                }
                --this.num_bindings;
                return next;
            }
            namedLocation = next;
        }
        return null;
    }
    
    public void writeExternal(final ObjectOutput objectOutput) throws IOException {
        objectOutput.writeObject(this.getSymbol());
    }
}
