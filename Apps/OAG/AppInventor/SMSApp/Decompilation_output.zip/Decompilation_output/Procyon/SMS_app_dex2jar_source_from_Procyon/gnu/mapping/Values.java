// 
// Decompiled by Procyon v0.5.36
// 

package gnu.mapping;

import java.io.ObjectOutput;
import java.io.ObjectStreamException;
import java.io.IOException;
import java.io.ObjectInput;
import java.util.Iterator;
import java.util.List;
import gnu.lists.Consumer;
import java.io.Externalizable;
import gnu.text.Printable;
import gnu.lists.TreeList;

public class Values extends TreeList implements Printable, Externalizable
{
    public static final Values empty;
    public static final Object[] noArgs;
    
    static {
        noArgs = new Object[0];
        empty = new Values(Values.noArgs);
    }
    
    public Values() {
    }
    
    public Values(final Object[] array) {
        for (int i = 0; i < array.length; ++i) {
            this.writeObject(array[i]);
        }
    }
    
    public static int countValues(final Object o) {
        int size;
        if (o instanceof Values) {
            size = ((Values)o).size();
        }
        else {
            size = 1;
        }
        return size;
    }
    
    public static Values make() {
        return new Values();
    }
    
    public static Object make(final TreeList list) {
        return make(list, 0, list.data.length);
    }
    
    public static Object make(final TreeList list, final int n, final int n2) {
        if (n != n2) {
            final int nextDataIndex = list.nextDataIndex(n);
            if (nextDataIndex > 0) {
                if (nextDataIndex == n2 || list.nextDataIndex(nextDataIndex) < 0) {
                    return list.getPosNext(n << 1);
                }
                final Values values = new Values();
                list.consumeIRange(n, n2, values);
                return values;
            }
        }
        return Values.empty;
    }
    
    public static Object make(final List list) {
        int size;
        if (list == null) {
            size = 0;
        }
        else {
            size = list.size();
        }
        Object o;
        if (size == 0) {
            o = Values.empty;
        }
        else if (size == 1) {
            o = list.get(0);
        }
        else {
            final Values values = new Values();
            final Iterator<Object> iterator = list.iterator();
            while (true) {
                o = values;
                if (!iterator.hasNext()) {
                    break;
                }
                values.writeObject(iterator.next());
            }
        }
        return o;
    }
    
    public static Object make(final Object[] array) {
        Object empty;
        if (array.length == 1) {
            empty = array[0];
        }
        else if (array.length == 0) {
            empty = Values.empty;
        }
        else {
            empty = new Values(array);
        }
        return empty;
    }
    
    public static int nextIndex(final Object o, int nextDataIndex) {
        if (o instanceof Values) {
            nextDataIndex = ((Values)o).nextDataIndex(nextDataIndex);
        }
        else if (nextDataIndex == 0) {
            nextDataIndex = 1;
        }
        else {
            nextDataIndex = -1;
        }
        return nextDataIndex;
    }
    
    public static Object nextValue(final Object o, final int n) {
        Object posNext = o;
        if (o instanceof Values) {
            final Values values = (Values)o;
            int n2;
            if ((n2 = n) >= values.gapEnd) {
                n2 = n - (values.gapEnd - values.gapStart);
            }
            posNext = ((Values)o).getPosNext(n2 << 1);
        }
        return posNext;
    }
    
    public static Object values(final Object... array) {
        return make(array);
    }
    
    public static void writeValues(final Object o, final Consumer consumer) {
        if (o instanceof Values) {
            ((Values)o).consume(consumer);
        }
        else {
            consumer.writeObject(o);
        }
    }
    
    public Object call_with(final Procedure procedure) throws Throwable {
        return procedure.applyN(this.toArray());
    }
    
    public final Object canonicalize() {
        Object o = this;
        if (this.gapEnd == this.data.length) {
            if (this.gapStart == 0) {
                o = Values.empty;
            }
            else {
                o = this;
                if (this.nextDataIndex(0) == this.gapStart) {
                    o = this.getPosNext(0);
                }
            }
        }
        return o;
    }
    
    public Object[] getValues() {
        Object[] array;
        if (this.isEmpty()) {
            array = Values.noArgs;
        }
        else {
            array = this.toArray();
        }
        return array;
    }
    
    @Override
    public void print(final Consumer consumer) {
        if (this == Values.empty) {
            consumer.write("#!void");
        }
        else {
            final int length = this.toArray().length;
            if (true) {
                consumer.write("#<values");
            }
            int n = 0;
            while (true) {
                final int nextDataIndex = this.nextDataIndex(n);
                if (nextDataIndex < 0) {
                    break;
                }
                consumer.write(32);
                int n2;
                if ((n2 = n) >= this.gapEnd) {
                    n2 = n - (this.gapEnd - this.gapStart);
                }
                final Object posNext = this.getPosNext(n2 << 1);
                if (posNext instanceof Printable) {
                    ((Printable)posNext).print(consumer);
                }
                else {
                    consumer.writeObject(posNext);
                }
                n = nextDataIndex;
            }
            if (true) {
                consumer.write(62);
            }
        }
    }
    
    @Override
    public void readExternal(final ObjectInput objectInput) throws IOException, ClassNotFoundException {
        for (int int1 = objectInput.readInt(), i = 0; i < int1; ++i) {
            this.writeObject(objectInput.readObject());
        }
    }
    
    public Object readResolve() throws ObjectStreamException {
        Values empty = this;
        if (this.isEmpty()) {
            empty = Values.empty;
        }
        return empty;
    }
    
    @Override
    public void writeExternal(final ObjectOutput objectOutput) throws IOException {
        final Object[] array = this.toArray();
        final int length = array.length;
        objectOutput.writeInt(length);
        for (int i = 0; i < length; ++i) {
            objectOutput.writeObject(array[i]);
        }
    }
}
