// 
// Decompiled by Procyon v0.5.36
// 

package gnu.mapping;

public class ReadOnlyLocation extends ConstrainedLocation
{
    public static ReadOnlyLocation make(final Location base) {
        final ReadOnlyLocation readOnlyLocation = new ReadOnlyLocation();
        readOnlyLocation.base = base;
        return readOnlyLocation;
    }
    
    @Override
    protected Object coerce(final Object o) {
        final StringBuffer sb = new StringBuffer("attempt to modify read-only location");
        final Symbol keySymbol = this.getKeySymbol();
        if (keySymbol != null) {
            sb.append(": ");
            sb.append(keySymbol);
        }
        throw new IllegalStateException(sb.toString());
    }
    
    @Override
    public boolean isConstant() {
        return true;
    }
}
