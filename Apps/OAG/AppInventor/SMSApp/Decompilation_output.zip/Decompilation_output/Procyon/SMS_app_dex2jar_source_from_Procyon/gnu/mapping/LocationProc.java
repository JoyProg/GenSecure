// 
// Decompiled by Procyon v0.5.36
// 

package gnu.mapping;

public class LocationProc extends Procedure0or1 implements HasSetter
{
    Location loc;
    
    public LocationProc(final Location loc) {
        this.loc = loc;
    }
    
    public LocationProc(final Location loc, final Procedure procedure) {
        this.loc = loc;
        if (procedure != null) {
            this.pushConverter(procedure);
        }
    }
    
    public static LocationProc makeNamed(final Symbol symbol, final Location location) {
        final LocationProc locationProc = new LocationProc(location);
        locationProc.setSymbol(symbol);
        return locationProc;
    }
    
    @Override
    public Object apply0() throws Throwable {
        return this.loc.get();
    }
    
    @Override
    public Object apply1(final Object o) throws Throwable {
        this.set0(o);
        return Values.empty;
    }
    
    public final Location getLocation() {
        return this.loc;
    }
    
    @Override
    public Procedure getSetter() {
        return new Setter0(this);
    }
    
    public void pushConverter(final Procedure procedure) {
        this.loc = ConstrainedLocation.make(this.loc, procedure);
    }
    
    @Override
    public void set0(final Object o) throws Throwable {
        this.loc.set(o);
    }
    
    @Override
    public String toString() {
        String s;
        if (this.getSymbol() != null) {
            s = super.toString();
        }
        else {
            s = "#<location-proc " + this.loc + ">";
        }
        return s;
    }
}
