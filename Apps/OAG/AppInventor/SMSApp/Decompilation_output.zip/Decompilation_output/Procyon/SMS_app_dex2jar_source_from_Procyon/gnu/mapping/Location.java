// 
// Decompiled by Procyon v0.5.36
// 

package gnu.mapping;

import java.io.PrintWriter;

public abstract class Location
{
    public static final String UNBOUND;
    
    static {
        UNBOUND = new String("(unbound)");
    }
    
    public static IndirectableLocation make(final Symbol symbol) {
        final PlainLocation plainLocation = new PlainLocation(symbol, null);
        plainLocation.base = null;
        plainLocation.value = Location.UNBOUND;
        return plainLocation;
    }
    
    public static IndirectableLocation make(final String s) {
        final PlainLocation plainLocation = new PlainLocation(Namespace.EmptyNamespace.getSymbol(s.intern()), null);
        plainLocation.base = null;
        plainLocation.value = Location.UNBOUND;
        return plainLocation;
    }
    
    public static Location make(final Object global, final String s) {
        final ThreadLocation threadLocation = new ThreadLocation(s);
        threadLocation.setGlobal(global);
        return threadLocation;
    }
    
    public boolean entered() {
        return false;
    }
    
    public final Object get() {
        final String unbound = Location.UNBOUND;
        final Object value = this.get(unbound);
        if (value == unbound) {
            throw new UnboundLocationException(this);
        }
        return value;
    }
    
    public abstract Object get(final Object p0);
    
    public Location getBase() {
        return this;
    }
    
    public Object getKeyProperty() {
        return null;
    }
    
    public Symbol getKeySymbol() {
        return null;
    }
    
    public final Object getValue() {
        return this.get(null);
    }
    
    public boolean isBound() {
        final String unbound = Location.UNBOUND;
        return this.get(unbound) != unbound;
    }
    
    public boolean isConstant() {
        return false;
    }
    
    public void print(final PrintWriter printWriter) {
        printWriter.print("#<location ");
        final Symbol keySymbol = this.getKeySymbol();
        if (keySymbol != null) {
            printWriter.print(keySymbol);
        }
        final String unbound = Location.UNBOUND;
        final Object value = this.get(unbound);
        if (value != unbound) {
            printWriter.print(" -> ");
            printWriter.print(value);
        }
        else {
            printWriter.print("(unbound)");
        }
        printWriter.print('>');
    }
    
    public abstract void set(final Object p0);
    
    public void setRestore(final Object o) {
        this.set(o);
    }
    
    public final Object setValue(final Object o) {
        final Object value = this.get(null);
        this.set(o);
        return value;
    }
    
    public Object setWithSave(final Object o) {
        final Object value = this.get(Location.UNBOUND);
        this.set(o);
        return value;
    }
    
    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer();
        sb.append(this.getClass().getName());
        final Symbol keySymbol = this.getKeySymbol();
        sb.append('[');
        if (keySymbol != null) {
            sb.append(keySymbol);
            final Object keyProperty = this.getKeyProperty();
            if (keyProperty != null && keyProperty != this) {
                sb.append('/');
                sb.append(keyProperty);
            }
        }
        sb.append("]");
        return sb.toString();
    }
    
    public void undefine() {
        this.set(Location.UNBOUND);
    }
}
