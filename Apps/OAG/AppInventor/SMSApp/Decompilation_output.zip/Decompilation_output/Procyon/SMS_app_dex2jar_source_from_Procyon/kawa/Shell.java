// 
// Decompiled by Procyon v0.5.36
// 

package kawa;

import gnu.mapping.PropertySet;
import java.io.Serializable;
import java.io.Closeable;
import gnu.expr.ModuleBody;
import java.io.BufferedInputStream;
import gnu.mapping.Procedure;
import gnu.mapping.TtyInPort;
import gnu.text.Lexer;
import gnu.expr.ModuleInfo;
import gnu.bytecode.ArrayClassLoader;
import java.io.PrintWriter;
import gnu.mapping.WrongArguments;
import gnu.lists.AbstractFormat;
import java.io.Writer;
import gnu.lists.VoidConsumer;
import gnu.lists.Consumer;
import gnu.text.SyntaxException;
import gnu.expr.Compilation;
import gnu.expr.ModuleExp;
import gnu.mapping.Values;
import gnu.mapping.CallContext;
import gnu.expr.ModuleManager;
import gnu.text.SourceMessages;
import java.net.URL;
import gnu.mapping.InPort;
import java.io.File;
import gnu.bytecode.ZipLoader;
import gnu.mapping.WrappedException;
import gnu.text.FilePath;
import java.io.IOException;
import gnu.expr.CompiledModule;
import gnu.expr.Language;
import gnu.mapping.Environment;
import gnu.text.Path;
import java.io.InputStream;
import gnu.mapping.OutPort;
import java.lang.reflect.Method;

public class Shell
{
    private static Class[] boolClasses;
    public static ThreadLocal currentLoadPath;
    public static Object[] defaultFormatInfo;
    public static Method defaultFormatMethod;
    public static String defaultFormatName;
    static Object[][] formats;
    private static Class[] httpPrinterClasses;
    private static Class[] noClasses;
    private static Object portArg;
    private static Class[] xmlPrinterClasses;
    
    static {
        Shell.currentLoadPath = new ThreadLocal();
        Shell.noClasses = new Class[0];
        Shell.boolClasses = new Class[] { Boolean.TYPE };
        Shell.xmlPrinterClasses = new Class[] { OutPort.class, Object.class };
        Shell.httpPrinterClasses = new Class[] { OutPort.class };
        Shell.portArg = "(port)";
        Shell.formats = new Object[][] { { "scheme", "gnu.kawa.functions.DisplayFormat", "getSchemeFormat", Shell.boolClasses, Boolean.FALSE }, { "readable-scheme", "gnu.kawa.functions.DisplayFormat", "getSchemeFormat", Shell.boolClasses, Boolean.TRUE }, { "elisp", "gnu.kawa.functions.DisplayFormat", "getEmacsLispFormat", Shell.boolClasses, Boolean.FALSE }, { "readable-elisp", "gnu.kawa.functions.DisplayFormat", "getEmacsLispFormat", Shell.boolClasses, Boolean.TRUE }, { "clisp", "gnu.kawa.functions.DisplayFormat", "getCommonLispFormat", Shell.boolClasses, Boolean.FALSE }, { "readable-clisp", "gnu.kawa.functions.DisplayFormat", "getCommonLispFormat", Shell.boolClasses, Boolean.TRUE }, { "commonlisp", "gnu.kawa.functions.DisplayFormat", "getCommonLispFormat", Shell.boolClasses, Boolean.FALSE }, { "readable-commonlisp", "gnu.kawa.functions.DisplayFormat", "getCommonLispFormat", Shell.boolClasses, Boolean.TRUE }, { "xml", "gnu.xml.XMLPrinter", "make", Shell.xmlPrinterClasses, Shell.portArg, null }, { "html", "gnu.xml.XMLPrinter", "make", Shell.xmlPrinterClasses, Shell.portArg, "html" }, { "xhtml", "gnu.xml.XMLPrinter", "make", Shell.xmlPrinterClasses, Shell.portArg, "xhtml" }, { "cgi", "gnu.kawa.xml.HttpPrinter", "make", Shell.httpPrinterClasses, Shell.portArg }, { "ignore", "gnu.lists.VoidConsumer", "getInstance", Shell.noClasses }, { null } };
    }
    
    public static final CompiledModule checkCompiledZip(InputStream string, Path path, final Environment current, Language ex) throws IOException {
        while (true) {
            Environment current2 = null;
            try {
                string.mark(5);
                int n;
                if (string.read() == 80 && string.read() == 75 && string.read() == 3 && string.read() == 4) {
                    n = 1;
                }
                else {
                    n = 0;
                }
                string.reset();
                if (n == 0) {
                    final Object make = current2;
                    return (CompiledModule)make;
                }
            }
            catch (IOException ex2) {
                final Object make = current2;
                return (CompiledModule)make;
            }
            string.close();
            current2 = Environment.getCurrent();
            string = (InputStream)path.toString();
            Label_0096: {
                if (current == current2) {
                    break Label_0096;
                }
                try {
                    Environment.setCurrent(current);
                    if (!(path instanceof FilePath)) {
                        path = (Path)new StringBuilder();
                        ex = (IOException)new RuntimeException(((StringBuilder)path).append("load: ").append((String)string).append(" - not a file path").toString());
                        throw ex;
                    }
                }
                catch (IOException ex) {
                    try {
                        path = (Path)new StringBuilder();
                        throw new WrappedException(((StringBuilder)path).append("load: ").append((String)string).append(" - ").append(ex.toString()).toString(), ex);
                    }
                    finally {
                        if (current != current2) {
                            Environment.setCurrent(current2);
                        }
                    }
                }
            }
            final File file = ((FilePath)path).toFile();
            final String s;
            if (!file.exists()) {
                throw new RuntimeException("load: " + s + " - not found");
            }
            if (!file.canRead()) {
                throw new RuntimeException("load: " + s + " - not readable");
            }
            Object make;
            final CompiledModule compiledModule = (CompiledModule)(make = CompiledModule.make(new ZipLoader(s).loadAllClasses(), (Language)ex));
            if (current != current2) {
                Environment.setCurrent(current2);
                make = compiledModule;
                return (CompiledModule)make;
            }
            return (CompiledModule)make;
        }
    }
    
    static CompiledModule compileSource(final InPort inPort, final Environment environment, final URL url, final Language language, final SourceMessages sourceMessages) throws SyntaxException, IOException {
        final CompiledModule compiledModule = null;
        final Compilation parse = language.parse(inPort, sourceMessages, 1, ModuleManager.getInstance().findWithSourcePath(inPort.getName()));
        CallContext.getInstance().values = Values.noArgs;
        final Object evalModule1 = ModuleExp.evalModule1(environment, parse, url, null);
        CompiledModule compiledModule2 = compiledModule;
        if (evalModule1 != null) {
            if (sourceMessages.seenErrors()) {
                compiledModule2 = compiledModule;
            }
            else {
                compiledModule2 = new CompiledModule(parse.getModule(), evalModule1, language);
            }
        }
        return compiledModule2;
    }
    
    public static Consumer getOutputConsumer(OutPort outPort) {
        final Object[] defaultFormatInfo = Shell.defaultFormatInfo;
        if (outPort == null) {
            outPort = (OutPort)VoidConsumer.getInstance();
        }
        else if (defaultFormatInfo == null) {
            outPort = (OutPort)Language.getDefaultLanguage().getOutputConsumer(outPort);
        }
        else {
            Object[] args;
            try {
                args = new Object[defaultFormatInfo.length - 4];
                System.arraycopy(defaultFormatInfo, 4, args, 0, args.length);
                int length = args.length;
                while (true) {
                    final int n = length - 1;
                    if (n < 0) {
                        break;
                    }
                    length = n;
                    if (args[n] != Shell.portArg) {
                        continue;
                    }
                    args[n] = outPort;
                    length = n;
                }
            }
            catch (Throwable obj) {
                throw new RuntimeException("cannot get output-format '" + Shell.defaultFormatName + "' - caught " + obj);
            }
            final Object invoke = Shell.defaultFormatMethod.invoke(null, args);
            if (invoke instanceof AbstractFormat) {
                outPort.objectFormat = (AbstractFormat)invoke;
            }
            else {
                outPort = (OutPort)invoke;
            }
        }
        return outPort;
    }
    
    public static void printError(final Throwable t, final SourceMessages sourceMessages, final OutPort s) {
        if (t instanceof WrongArguments) {
            final WrongArguments wrongArguments = (WrongArguments)t;
            sourceMessages.printAll(s, 20);
            if (wrongArguments.usage != null) {
                s.println("usage: " + wrongArguments.usage);
            }
            wrongArguments.printStackTrace(s);
        }
        else if (t instanceof ClassCastException) {
            sourceMessages.printAll(s, 20);
            s.println("Invalid parameter, was: " + t.getMessage());
            t.printStackTrace(s);
        }
        else {
            if (t instanceof SyntaxException) {
                final SyntaxException ex = (SyntaxException)t;
                if (ex.getMessages() == sourceMessages) {
                    ex.printAll(s, 20);
                    ex.clear();
                    return;
                }
            }
            sourceMessages.printAll(s, 20);
            t.printStackTrace(s);
        }
    }
    
    public static Throwable run(final Language saveCurrent, final Environment environment, final InPort inPort, final Consumer consumer, final OutPort outPort, final URL url, final SourceMessages sourceMessages) {
        final Language setSaveCurrent = Language.setSaveCurrent(saveCurrent);
        final Lexer lexer = saveCurrent.getLexer(inPort, sourceMessages);
        while (true) {
            boolean interactive = false;
            Label_0023: {
                if (outPort != null) {
                    interactive = true;
                    break Label_0023;
                }
                Label_0148: {
                    break Label_0148;
                    while (true) {
                        while (true) {
                            try {
                                final Thread currentThread = Thread.currentThread();
                                Object o = currentThread.getContextClassLoader();
                                Object module = null;
                                if (!(o instanceof ArrayClassLoader)) {
                                    module = new ArrayClassLoader((ClassLoader)o);
                                    currentThread.setContextClassLoader((ClassLoader)module);
                                }
                                while (true) {
                                Label_0126_Outer:
                                    while (true) {
                                        boolean checkErrors;
                                        final CallContext instance;
                                        final Consumer consumer2;
                                        int read;
                                        Block_19_Outer:Block_15_Outer:
                                        while (true) {
                                            Label_0203: {
                                                try {
                                                    o = saveCurrent.parse(lexer, 7, null);
                                                    if (interactive) {
                                                        checkErrors = sourceMessages.checkErrors(outPort, 20);
                                                        if (o == null) {
                                                            if (consumer != null) {
                                                                instance.consumer = consumer2;
                                                            }
                                                            Language.restoreCurrent(setSaveCurrent);
                                                            module = null;
                                                            return (Throwable)module;
                                                        }
                                                        break Label_0203;
                                                    }
                                                    else {
                                                        if (sourceMessages.seenErrors()) {
                                                            module = new SyntaxException(sourceMessages);
                                                            throw module;
                                                        }
                                                        break Label_0203;
                                                    }
                                                    interactive = false;
                                                    break Label_0023;
                                                }
                                                catch (Throwable module) {
                                                    if (!interactive) {
                                                        if (consumer != null) {
                                                            instance.consumer = consumer2;
                                                        }
                                                        Language.restoreCurrent(setSaveCurrent);
                                                        return (Throwable)module;
                                                    }
                                                    break Label_0126_Outer;
                                                    // iftrue(Label_0322:, !consumer instanceof Writer)
                                                    // iftrue(Label_0094:, checkErrors)
                                                    // iftrue(Label_0094:, read >= 0)
                                                    // iftrue(Label_0268:, read == 32 || read == 9)
                                                    // iftrue(Label_0330:, read >= 0 && read != 13 && read != 10)
                                                    while (true) {
                                                        Label_0293: {
                                                            Block_17: {
                                                                Block_12: {
                                                                    while (true) {
                                                                    Block_16:
                                                                        while (true) {
                                                                            inPort.unread();
                                                                            break Label_0293;
                                                                            break Block_16;
                                                                            break Block_12;
                                                                            break Block_17;
                                                                            checkErrors = false;
                                                                            continue Label_0126_Outer;
                                                                            Label_0330: {
                                                                                continue Block_15_Outer;
                                                                            }
                                                                        }
                                                                        ((Writer)consumer).flush();
                                                                        continue;
                                                                    }
                                                                }
                                                                module = ((Compilation)o).getModule();
                                                                ((PropertySet)module).setName("atInteractiveLevel$" + ++ModuleExp.interactiveCounter);
                                                                Label_0268: {
                                                                    read = inPort.read();
                                                                }
                                                                break Label_0293;
                                                            }
                                                            continue Block_19_Outer;
                                                        }
                                                        continue;
                                                    }
                                                }
                                                // iftrue(Label_0094:, !ModuleExp.evalModule(environment, instance, (Compilation)o, url, outPort))
                                                finally {
                                                    if (consumer != null) {
                                                        instance.consumer = consumer2;
                                                    }
                                                    Language.restoreCurrent(setSaveCurrent);
                                                }
                                            }
                                            break;
                                        }
                                        break;
                                    }
                                    printError((Throwable)module, sourceMessages, outPort);
                                }
                            }
                            catch (SecurityException module) {
                                continue;
                            }
                            continue;
                        }
                    }
                }
            }
            lexer.setInteractive(interactive);
            final CallContext instance = CallContext.getInstance();
            Consumer consumer2 = null;
            if (consumer != null) {
                consumer2 = instance.consumer;
                instance.consumer = consumer;
            }
            continue;
        }
    }
    
    public static Throwable run(final Language language, final Environment environment, final InPort inPort, final OutPort outPort, final OutPort outPort2, final SourceMessages sourceMessages) {
        AbstractFormat objectFormat = null;
        if (outPort != null) {
            objectFormat = outPort.objectFormat;
        }
        final Consumer outputConsumer = getOutputConsumer(outPort);
        try {
            return run(language, environment, inPort, outputConsumer, outPort2, null, sourceMessages);
        }
        finally {
            if (outPort != null) {
                outPort.objectFormat = objectFormat;
            }
        }
    }
    
    public static boolean run(final Language language, final Environment environment) {
        final InPort inDefault = InPort.inDefault();
        final SourceMessages sourceMessages = new SourceMessages();
        OutPort errDefault;
        if (inDefault instanceof TtyInPort) {
            final Procedure prompter = language.getPrompter();
            if (prompter != null) {
                ((TtyInPort)inDefault).setPrompter(prompter);
            }
            errDefault = OutPort.errDefault();
        }
        else {
            errDefault = null;
        }
        final Throwable run = run(language, environment, inDefault, OutPort.outDefault(), errDefault, sourceMessages);
        boolean b;
        if (run == null) {
            b = true;
        }
        else {
            printError(run, sourceMessages, OutPort.errDefault());
            b = false;
        }
        return b;
    }
    
    public static boolean run(final Language language, final Environment environment, final InPort inPort, final Consumer consumer, final OutPort outPort, final URL url) {
        final SourceMessages sourceMessages = new SourceMessages();
        final Throwable run = run(language, environment, inPort, consumer, outPort, url, sourceMessages);
        if (run != null) {
            printError(run, sourceMessages, outPort);
        }
        return run == null;
    }
    
    public static final boolean runFile(final InputStream in, final Path value, final Environment environment, final boolean b, int n) throws Throwable {
        Closeable openFile = in;
        if (!(in instanceof BufferedInputStream)) {
            openFile = new BufferedInputStream(in);
        }
        final Language defaultLanguage = Language.getDefaultLanguage();
        final Path value2 = Shell.currentLoadPath.get();
        Object checkCompiledZip = null;
        Label_0222: {
            try {
                Shell.currentLoadPath.set(value);
                if ((checkCompiledZip = checkCompiledZip((InputStream)openFile, value, environment, defaultLanguage)) != null) {
                    break Label_0222;
                }
                openFile = InPort.openFile((InputStream)openFile, value);
                while (--n >= 0) {
                    ((InPort)openFile).skipRestOfLine();
                }
            }
            finally {
                Shell.currentLoadPath.set(value2);
            }
            SourceMessages sourceMessages;
            while (true) {
                URL url = null;
                Label_0168: {
                    while (true) {
                        try {
                            checkCompiledZip = new SourceMessages();
                            url = value.toURL();
                            if (!b) {
                                break Label_0168;
                            }
                            if (ModuleBody.getMainPrintValues()) {
                                final Consumer outputConsumer = getOutputConsumer(OutPort.outDefault());
                                final Throwable run = run(defaultLanguage, environment, (InPort)openFile, outputConsumer, null, url, (SourceMessages)checkCompiledZip);
                                if (run != null) {
                                    throw run;
                                }
                                break;
                            }
                        }
                        finally {
                            ((InPort)openFile).close();
                        }
                        final Consumer outputConsumer = new VoidConsumer();
                        continue;
                    }
                }
                final CompiledModule compileSource = compileSource((InPort)openFile, environment, url, defaultLanguage, (SourceMessages)checkCompiledZip);
                ((SourceMessages)checkCompiledZip).printAll(OutPort.errDefault(), 20);
                if ((sourceMessages = (SourceMessages)compileSource) == null) {
                    final boolean b2 = false;
                    ((InPort)openFile).close();
                    Shell.currentLoadPath.set(value2);
                    return b2;
                }
                break;
            }
            ((InPort)openFile).close();
            checkCompiledZip = sourceMessages;
        }
        if (checkCompiledZip != null) {
            ((CompiledModule)checkCompiledZip).evalModule(environment, OutPort.outDefault());
        }
        Shell.currentLoadPath.set(value2);
        return true;
    }
    
    public static boolean runFileOrClass(String className, final boolean b, final int n) {
        final boolean b2 = false;
        final Language defaultLanguage = Language.getDefaultLanguage();
        try {
            Label_0045: {
                if (!((String)className).equals("-")) {
                    break Label_0045;
                }
                Path path = Path.valueOf("/dev/stdin");
                InputStream inputStream = System.in;
                try {
                    return runFile(inputStream, path, Environment.getCurrent(), b, n);
                    path = Path.valueOf(className);
                    inputStream = path.openInputStream();
                }
                catch (Throwable t) {
                    t.printStackTrace(System.err);
                    final boolean runFile = b2;
                }
            }
        }
        catch (Throwable t2) {
            try {
                final Serializable forName;
                className = (Throwable)(forName = Class.forName((String)className));
                final Language language = defaultLanguage;
                final CompiledModule compiledModule = CompiledModule.make((Class)forName, language);
                final Environment environment = Environment.getCurrent();
                final OutPort outPort = OutPort.outDefault();
                compiledModule.evalModule(environment, outPort);
                return true;
            }
            catch (Throwable className) {
                System.err.println("Cannot read file " + t2.getMessage());
                return b2;
            }
            boolean runFile;
            try {
                final Serializable forName = className;
                final Language language = defaultLanguage;
                final CompiledModule compiledModule = CompiledModule.make((Class)forName, language);
                final Environment environment = Environment.getCurrent();
                final OutPort outPort = OutPort.outDefault();
                compiledModule.evalModule(environment, outPort);
                runFile = true;
                return runFile;
            }
            catch (Throwable className) {
                className.printStackTrace();
                runFile = b2;
                return runFile;
            }
            return runFile;
        }
    }
    
    public static void setDefaultFormat(String s) {
        s = (Shell.defaultFormatName = s.intern());
        int n = 0;
        Object[] defaultFormatInfo;
        while (true) {
            defaultFormatInfo = Shell.formats[n];
            final Object o = defaultFormatInfo[0];
            if (o == null) {
                System.err.println("kawa: unknown output format '" + s + "'");
                System.exit(-1);
            }
            else if (o == s) {
                break;
            }
            ++n;
        }
        Shell.defaultFormatInfo = defaultFormatInfo;
        while (true) {
            try {
                Shell.defaultFormatMethod = Class.forName((String)defaultFormatInfo[1]).getMethod((String)defaultFormatInfo[2], (Class<?>[])defaultFormatInfo[3]);
                if (!Shell.defaultFormatInfo[1].equals("gnu.lists.VoidConsumer")) {
                    ModuleBody.setMainPrintValues(true);
                }
            }
            catch (Throwable obj) {
                System.err.println("kawa:  caught " + obj + " while looking for format '" + s + "'");
                System.exit(-1);
                continue;
            }
            break;
        }
    }
}
