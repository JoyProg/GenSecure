// 
// Decompiled by Procyon v0.5.36
// 

package gnu.mapping;

public class SharedLocation extends NamedLocation
{
    int timestamp;
    
    public SharedLocation(final Symbol symbol, final Object o, final int timestamp) {
        super(symbol, o);
        this.timestamp = timestamp;
    }
    
    @Override
    public final Object get(Object o) {
        synchronized (this) {
            if (this.base != null) {
                o = this.base.get(o);
            }
            else if (this.value != Location.UNBOUND) {
                o = this.value;
            }
            return o;
        }
    }
    
    @Override
    public boolean isBound() {
        synchronized (this) {
            boolean bound;
            if (this.base != null) {
                bound = this.base.isBound();
            }
            else {
                bound = (this.value != Location.UNBOUND);
            }
            return bound;
        }
    }
    
    @Override
    public final void set(final Object o) {
        while (true) {
            Label_0045: {
                synchronized (this) {
                    if (this.base == null) {
                        this.value = o;
                    }
                    else {
                        if (this.value != SharedLocation.DIRECT_ON_SET) {
                            break Label_0045;
                        }
                        this.base = null;
                        this.value = o;
                    }
                    return;
                }
            }
            final Throwable t;
            if (this.base.isConstant()) {
                this.getEnvironment().put(this.getKeySymbol(), this.getKeyProperty(), t);
                return;
            }
            this.base.set(t);
        }
    }
}
