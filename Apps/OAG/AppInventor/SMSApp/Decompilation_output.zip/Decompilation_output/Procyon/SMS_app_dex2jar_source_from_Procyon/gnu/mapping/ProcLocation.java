// 
// Decompiled by Procyon v0.5.36
// 

package gnu.mapping;

public class ProcLocation extends Location
{
    Object[] args;
    Procedure proc;
    
    public ProcLocation(final Procedure proc, final Object[] args) {
        this.proc = proc;
        this.args = args;
    }
    
    @Override
    public Object get(Object applyN) {
        try {
            applyN = this.proc.applyN(this.args);
            return applyN;
        }
        catch (RuntimeException ex) {
            throw ex;
        }
        catch (Error error) {
            throw error;
        }
        catch (Throwable t) {
            throw new WrappedException(t);
        }
    }
    
    @Override
    public boolean isBound() {
        return true;
    }
    
    @Override
    public void set(final Object o) {
        final int length = this.args.length;
        final Object[] n = new Object[length + 1];
        n[length] = o;
        System.arraycopy(this.args, 0, n, 0, length);
        try {
            this.proc.setN(n);
        }
        catch (RuntimeException ex) {
            throw ex;
        }
        catch (Error error) {
            throw error;
        }
        catch (Throwable t) {
            throw new WrappedException(t);
        }
    }
}
