// 
// Decompiled by Procyon v0.5.36
// 

package androidx.lifecycle;

import androidx.annotation.MainThread;
import android.util.Log;
import androidx.annotation.Nullable;
import androidx.arch.core.internal.SafeIterableMap;
import java.util.Iterator;
import java.util.Map;
import androidx.annotation.NonNull;
import java.util.ArrayList;
import androidx.arch.core.internal.FastSafeIterableMap;
import java.lang.ref.WeakReference;

public class LifecycleRegistry extends Lifecycle
{
    private static final String LOG_TAG = "LifecycleRegistry";
    private int mAddingObserverCounter;
    private boolean mHandlingEvent;
    private final WeakReference<LifecycleOwner> mLifecycleOwner;
    private boolean mNewEventOccurred;
    private FastSafeIterableMap<LifecycleObserver, ObserverWithState> mObserverMap;
    private ArrayList<State> mParentStates;
    private State mState;
    
    public LifecycleRegistry(@NonNull final LifecycleOwner referent) {
        this.mObserverMap = new FastSafeIterableMap<LifecycleObserver, ObserverWithState>();
        this.mAddingObserverCounter = 0;
        this.mHandlingEvent = false;
        this.mNewEventOccurred = false;
        this.mParentStates = new ArrayList<State>();
        this.mLifecycleOwner = new WeakReference<LifecycleOwner>(referent);
        this.mState = State.INITIALIZED;
    }
    
    private void backwardPass(final LifecycleOwner lifecycleOwner) {
        final Iterator<Map.Entry<LifecycleObserver, ObserverWithState>> descendingIterator = (Iterator<Map.Entry<LifecycleObserver, ObserverWithState>>)this.mObserverMap.descendingIterator();
        while (descendingIterator.hasNext() && !this.mNewEventOccurred) {
            final Map.Entry<LifecycleObserver, ObserverWithState> entry = descendingIterator.next();
            final ObserverWithState observerWithState = entry.getValue();
            while (observerWithState.mState.compareTo(this.mState) > 0 && !this.mNewEventOccurred && this.mObserverMap.contains(entry.getKey())) {
                final Event downEvent = downEvent(observerWithState.mState);
                this.pushParentState(getStateAfter(downEvent));
                observerWithState.dispatchEvent(lifecycleOwner, downEvent);
                this.popParentState();
            }
        }
    }
    
    private State calculateTargetState(final LifecycleObserver lifecycleObserver) {
        final Map.Entry<LifecycleObserver, ObserverWithState> ceil = this.mObserverMap.ceil(lifecycleObserver);
        State mState;
        if (ceil != null) {
            mState = ceil.getValue().mState;
        }
        else {
            mState = null;
        }
        State state;
        if (!this.mParentStates.isEmpty()) {
            state = this.mParentStates.get(this.mParentStates.size() - 1);
        }
        else {
            state = null;
        }
        return min(min(this.mState, mState), state);
    }
    
    private static Event downEvent(final State obj) {
        Event event = null;
        switch (obj) {
            default: {
                throw new IllegalArgumentException("Unexpected state value " + obj);
            }
            case INITIALIZED: {
                throw new IllegalArgumentException();
            }
            case CREATED: {
                event = Event.ON_DESTROY;
                break;
            }
            case STARTED: {
                event = Event.ON_STOP;
                break;
            }
            case RESUMED: {
                event = Event.ON_PAUSE;
                break;
            }
            case DESTROYED: {
                throw new IllegalArgumentException();
            }
        }
        return event;
    }
    
    private void forwardPass(final LifecycleOwner lifecycleOwner) {
        final SafeIterableMap.IteratorWithAdditions iteratorWithAdditions = this.mObserverMap.iteratorWithAdditions();
        while (iteratorWithAdditions.hasNext() && !this.mNewEventOccurred) {
            final Map.Entry<K, ObserverWithState> entry = ((Iterator<Map.Entry<K, ObserverWithState>>)iteratorWithAdditions).next();
            final ObserverWithState observerWithState = entry.getValue();
            while (observerWithState.mState.compareTo(this.mState) < 0 && !this.mNewEventOccurred && this.mObserverMap.contains((LifecycleObserver)entry.getKey())) {
                this.pushParentState(observerWithState.mState);
                observerWithState.dispatchEvent(lifecycleOwner, upEvent(observerWithState.mState));
                this.popParentState();
            }
        }
    }
    
    static State getStateAfter(final Event obj) {
        State state = null;
        switch (obj) {
            default: {
                throw new IllegalArgumentException("Unexpected event value " + obj);
            }
            case ON_CREATE:
            case ON_STOP: {
                state = State.CREATED;
                break;
            }
            case ON_START:
            case ON_PAUSE: {
                state = State.STARTED;
                break;
            }
            case ON_RESUME: {
                state = State.RESUMED;
                break;
            }
            case ON_DESTROY: {
                state = State.DESTROYED;
                break;
            }
        }
        return state;
    }
    
    private boolean isSynced() {
        boolean b = true;
        if (this.mObserverMap.size() != 0) {
            final State mState = this.mObserverMap.eldest().getValue().mState;
            final State mState2 = this.mObserverMap.newest().getValue().mState;
            b = (mState == mState2 && this.mState == mState2);
        }
        return b;
    }
    
    static State min(@NonNull State o, @Nullable final State state) {
        if (state != null && state.compareTo(o) < 0) {
            o = state;
        }
        return o;
    }
    
    private void moveToState(final State mState) {
        if (this.mState != mState) {
            this.mState = mState;
            if (this.mHandlingEvent || this.mAddingObserverCounter != 0) {
                this.mNewEventOccurred = true;
            }
            else {
                this.mHandlingEvent = true;
                this.sync();
                this.mHandlingEvent = false;
            }
        }
    }
    
    private void popParentState() {
        this.mParentStates.remove(this.mParentStates.size() - 1);
    }
    
    private void pushParentState(final State e) {
        this.mParentStates.add(e);
    }
    
    private void sync() {
        final LifecycleOwner lifecycleOwner = this.mLifecycleOwner.get();
        if (lifecycleOwner == null) {
            Log.w("LifecycleRegistry", "LifecycleOwner is garbage collected, you shouldn't try dispatch new events from it.");
        }
        else {
            while (!this.isSynced()) {
                this.mNewEventOccurred = false;
                if (this.mState.compareTo(this.mObserverMap.eldest().getValue().mState) < 0) {
                    this.backwardPass(lifecycleOwner);
                }
                final Map.Entry<LifecycleObserver, ObserverWithState> newest = this.mObserverMap.newest();
                if (!this.mNewEventOccurred && newest != null && this.mState.compareTo(newest.getValue().mState) > 0) {
                    this.forwardPass(lifecycleOwner);
                }
            }
            this.mNewEventOccurred = false;
        }
    }
    
    private static Event upEvent(final State obj) {
        Event event = null;
        switch (obj) {
            default: {
                throw new IllegalArgumentException("Unexpected state value " + obj);
            }
            case INITIALIZED:
            case DESTROYED: {
                event = Event.ON_CREATE;
                break;
            }
            case CREATED: {
                event = Event.ON_START;
                break;
            }
            case STARTED: {
                event = Event.ON_RESUME;
                break;
            }
            case RESUMED: {
                throw new IllegalArgumentException();
            }
        }
        return event;
    }
    
    @Override
    public void addObserver(@NonNull final LifecycleObserver lifecycleObserver) {
        State state;
        if (this.mState == State.DESTROYED) {
            state = State.DESTROYED;
        }
        else {
            state = State.INITIALIZED;
        }
        final ObserverWithState observerWithState = new ObserverWithState(lifecycleObserver, state);
        if (this.mObserverMap.putIfAbsent(lifecycleObserver, observerWithState) == null) {
            final LifecycleOwner lifecycleOwner = this.mLifecycleOwner.get();
            if (lifecycleOwner != null) {
                final boolean b = this.mAddingObserverCounter != 0 || this.mHandlingEvent;
                State o = this.calculateTargetState(lifecycleObserver);
                ++this.mAddingObserverCounter;
                while (observerWithState.mState.compareTo(o) < 0 && this.mObserverMap.contains(lifecycleObserver)) {
                    this.pushParentState(observerWithState.mState);
                    observerWithState.dispatchEvent(lifecycleOwner, upEvent(observerWithState.mState));
                    this.popParentState();
                    o = this.calculateTargetState(lifecycleObserver);
                }
                if (!b) {
                    this.sync();
                }
                --this.mAddingObserverCounter;
            }
        }
    }
    
    @NonNull
    @Override
    public State getCurrentState() {
        return this.mState;
    }
    
    public int getObserverCount() {
        return this.mObserverMap.size();
    }
    
    public void handleLifecycleEvent(@NonNull final Event event) {
        this.moveToState(getStateAfter(event));
    }
    
    @MainThread
    public void markState(@NonNull final State state) {
        this.moveToState(state);
    }
    
    @Override
    public void removeObserver(@NonNull final LifecycleObserver lifecycleObserver) {
        this.mObserverMap.remove(lifecycleObserver);
    }
    
    static class ObserverWithState
    {
        GenericLifecycleObserver mLifecycleObserver;
        State mState;
        
        ObserverWithState(final LifecycleObserver lifecycleObserver, final State mState) {
            this.mLifecycleObserver = Lifecycling.getCallback(lifecycleObserver);
            this.mState = mState;
        }
        
        void dispatchEvent(final LifecycleOwner lifecycleOwner, final Event event) {
            final State stateAfter = LifecycleRegistry.getStateAfter(event);
            this.mState = LifecycleRegistry.min(this.mState, stateAfter);
            this.mLifecycleObserver.onStateChanged(lifecycleOwner, event);
            this.mState = stateAfter;
        }
    }
}
