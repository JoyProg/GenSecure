// 
// Decompiled by Procyon v0.5.36
// 

package gnu.mapping;

public abstract class ProcedureN extends Procedure
{
    public static final Object[] noArgs;
    
    static {
        noArgs = new Object[0];
    }
    
    public ProcedureN() {
    }
    
    public ProcedureN(final String s) {
        super(s);
    }
    
    @Override
    public Object apply0() throws Throwable {
        return this.applyN(ProcedureN.noArgs);
    }
    
    @Override
    public Object apply1(final Object o) throws Throwable {
        return this.applyN(new Object[] { o });
    }
    
    @Override
    public Object apply2(final Object o, final Object o2) throws Throwable {
        return this.applyN(new Object[] { o, o2 });
    }
    
    @Override
    public Object apply3(final Object o, final Object o2, final Object o3) throws Throwable {
        return this.applyN(new Object[] { o, o2, o3 });
    }
    
    @Override
    public Object apply4(final Object o, final Object o2, final Object o3, final Object o4) throws Throwable {
        return this.applyN(new Object[] { o, o2, o3, o4 });
    }
    
    @Override
    public abstract Object applyN(final Object[] p0) throws Throwable;
}
