// 
// Decompiled by Procyon v0.5.36
// 

package androidx.versionedparcelable;

import android.os.IInterface;
import android.util.SparseBooleanArray;
import android.util.SizeF;
import androidx.annotation.RequiresApi;
import android.util.Size;
import androidx.collection.ArraySet;
import java.util.Set;
import java.io.ObjectStreamClass;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ByteArrayInputStream;
import java.util.List;
import android.os.Bundle;
import java.util.ArrayList;
import java.io.IOException;
import java.io.OutputStream;
import java.io.ObjectOutputStream;
import java.io.ByteArrayOutputStream;
import java.util.Iterator;
import java.lang.reflect.InvocationTargetException;
import java.util.Collection;
import android.os.IBinder;
import java.io.Serializable;
import android.os.Parcelable;
import androidx.annotation.NonNull;
import android.os.NetworkOnMainThreadException;
import android.os.BadParcelableException;
import androidx.annotation.RestrictTo;

@RestrictTo({ RestrictTo.Scope.LIBRARY_GROUP })
public abstract class VersionedParcel
{
    private static final int EX_BAD_PARCELABLE = -2;
    private static final int EX_ILLEGAL_ARGUMENT = -3;
    private static final int EX_ILLEGAL_STATE = -5;
    private static final int EX_NETWORK_MAIN_THREAD = -6;
    private static final int EX_NULL_POINTER = -4;
    private static final int EX_PARCELABLE = -9;
    private static final int EX_SECURITY = -1;
    private static final int EX_UNSUPPORTED_OPERATION = -7;
    private static final String TAG = "VersionedParcel";
    private static final int TYPE_BINDER = 5;
    private static final int TYPE_PARCELABLE = 2;
    private static final int TYPE_SERIALIZABLE = 3;
    private static final int TYPE_STRING = 4;
    private static final int TYPE_VERSIONED_PARCELABLE = 1;
    
    private Exception createException(final int i, final String s) {
        Object o = null;
        switch (i) {
            default: {
                o = new RuntimeException("Unknown exception code: " + i + " msg " + s);
                break;
            }
            case -9: {
                o = this.readParcelable();
                break;
            }
            case -1: {
                o = new SecurityException(s);
                break;
            }
            case -2: {
                o = new BadParcelableException(s);
                break;
            }
            case -3: {
                o = new IllegalArgumentException(s);
                break;
            }
            case -4: {
                o = new NullPointerException(s);
                break;
            }
            case -5: {
                o = new IllegalStateException(s);
                break;
            }
            case -6: {
                o = new NetworkOnMainThreadException();
                break;
            }
            case -7: {
                o = new UnsupportedOperationException(s);
                break;
            }
        }
        return (Exception)o;
    }
    
    private static <T extends VersionedParcelable> Class findParcelClass(final T t) throws ClassNotFoundException {
        return findParcelClass(t.getClass());
    }
    
    private static Class findParcelClass(final Class<? extends VersionedParcelable> clazz) throws ClassNotFoundException {
        return Class.forName(String.format("%s.%sParcelizer", clazz.getPackage().getName(), clazz.getSimpleName()), false, clazz.getClassLoader());
    }
    
    @NonNull
    protected static Throwable getRootCause(@NonNull Throwable cause) {
        while (cause.getCause() != null) {
            cause = cause.getCause();
        }
        return cause;
    }
    
    private <T> int getType(final T t) {
        int n;
        if (t instanceof String) {
            n = 4;
        }
        else if (t instanceof Parcelable) {
            n = 2;
        }
        else if (t instanceof VersionedParcelable) {
            n = 1;
        }
        else if (t instanceof Serializable) {
            n = 3;
        }
        else {
            if (!(t instanceof IBinder)) {
                throw new IllegalArgumentException(t.getClass().getName() + " cannot be VersionedParcelled");
            }
            n = 5;
        }
        return n;
    }
    
    private <T, S extends Collection<T>> S readCollection(int int1, final S n) {
        int1 = this.readInt();
        Collection<T> collection = null;
        Label_0011: {
            if (int1 < 0) {
                collection = null;
            }
            else {
                collection = n;
                if (int1 != 0) {
                    final int int2 = this.readInt();
                    if (int1 < 0) {
                        collection = null;
                    }
                    else {
                        int n2 = int1;
                        int n3 = int1;
                        int n4 = int1;
                        int n5 = int1;
                        switch (int2) {
                            default: {
                                collection = n;
                                break;
                            }
                            case 1: {
                                while (true) {
                                    collection = n;
                                    if (n2 <= 0) {
                                        break Label_0011;
                                    }
                                    n.add(this.readVersionedParcelable());
                                    --n2;
                                }
                                break;
                            }
                            case 4: {
                                while (true) {
                                    collection = n;
                                    if (n3 <= 0) {
                                        break Label_0011;
                                    }
                                    n.add((T)this.readString());
                                    --n3;
                                }
                                break;
                            }
                            case 2: {
                                while (true) {
                                    collection = n;
                                    if (n4 <= 0) {
                                        break Label_0011;
                                    }
                                    n.add(this.readParcelable());
                                    --n4;
                                }
                                break;
                            }
                            case 3: {
                                while (true) {
                                    collection = n;
                                    if (n5 <= 0) {
                                        break Label_0011;
                                    }
                                    n.add((T)this.readSerializable());
                                    --n5;
                                }
                                break;
                            }
                            case 5: {
                                while (true) {
                                    collection = n;
                                    if (int1 <= 0) {
                                        break Label_0011;
                                    }
                                    n.add((T)this.readStrongBinder());
                                    --int1;
                                }
                                break;
                            }
                        }
                    }
                }
            }
        }
        return (S)collection;
    }
    
    private Exception readException(final int n, final String s) {
        return this.createException(n, s);
    }
    
    private int readExceptionCode() {
        return this.readInt();
    }
    
    protected static <T extends VersionedParcelable> T readFromParcel(final String name, final VersionedParcel versionedParcel) {
        try {
            return (T)Class.forName(name, true, VersionedParcel.class.getClassLoader()).getDeclaredMethod("read", VersionedParcel.class).invoke(null, versionedParcel);
        }
        catch (IllegalAccessException cause) {
            throw new RuntimeException("VersionedParcel encountered IllegalAccessException", cause);
        }
        catch (InvocationTargetException cause2) {
            if (cause2.getCause() instanceof RuntimeException) {
                throw (RuntimeException)cause2.getCause();
            }
            throw new RuntimeException("VersionedParcel encountered InvocationTargetException", cause2);
        }
        catch (NoSuchMethodException cause3) {
            throw new RuntimeException("VersionedParcel encountered NoSuchMethodException", cause3);
        }
        catch (ClassNotFoundException cause4) {
            throw new RuntimeException("VersionedParcel encountered ClassNotFoundException", cause4);
        }
    }
    
    private <T> void writeCollection(final Collection<T> collection, int outputField) {
        this.setOutputField(outputField);
        if (collection == null) {
            this.writeInt(-1);
        }
        else {
            outputField = collection.size();
            this.writeInt(outputField);
            if (outputField > 0) {
                outputField = this.getType(collection.iterator().next());
                this.writeInt(outputField);
                switch (outputField) {
                    case 1: {
                        final Iterator<T> iterator = collection.iterator();
                        while (iterator.hasNext()) {
                            this.writeVersionedParcelable((VersionedParcelable)iterator.next());
                        }
                        break;
                    }
                    case 4: {
                        final Iterator<T> iterator2 = collection.iterator();
                        while (iterator2.hasNext()) {
                            this.writeString((String)iterator2.next());
                        }
                        break;
                    }
                    case 2: {
                        final Iterator<T> iterator3 = collection.iterator();
                        while (iterator3.hasNext()) {
                            this.writeParcelable((Parcelable)iterator3.next());
                        }
                        break;
                    }
                    case 3: {
                        final Iterator<T> iterator4 = collection.iterator();
                        while (iterator4.hasNext()) {
                            this.writeSerializable((Serializable)iterator4.next());
                        }
                        break;
                    }
                    case 5: {
                        final Iterator<T> iterator5 = collection.iterator();
                        while (iterator5.hasNext()) {
                            this.writeStrongBinder((IBinder)iterator5.next());
                        }
                        break;
                    }
                }
            }
        }
    }
    
    private void writeSerializable(final Serializable obj) {
        if (obj == null) {
            this.writeString(null);
        }
        else {
            final String name = obj.getClass().getName();
            this.writeString(name);
            final ByteArrayOutputStream out = new ByteArrayOutputStream();
            try {
                final ObjectOutputStream objectOutputStream = new ObjectOutputStream(out);
                objectOutputStream.writeObject(obj);
                objectOutputStream.close();
                this.writeByteArray(out.toByteArray());
            }
            catch (IOException cause) {
                throw new RuntimeException("VersionedParcelable encountered IOException writing serializable object (name = " + name + ")", cause);
            }
        }
    }
    
    protected static <T extends VersionedParcelable> void writeToParcel(final T t, final VersionedParcel versionedParcel) {
        try {
            findParcelClass(t).getDeclaredMethod("write", t.getClass(), VersionedParcel.class).invoke(null, t, versionedParcel);
        }
        catch (IllegalAccessException cause) {
            throw new RuntimeException("VersionedParcel encountered IllegalAccessException", cause);
        }
        catch (InvocationTargetException cause2) {
            if (cause2.getCause() instanceof RuntimeException) {
                throw (RuntimeException)cause2.getCause();
            }
            throw new RuntimeException("VersionedParcel encountered InvocationTargetException", cause2);
        }
        catch (NoSuchMethodException cause3) {
            throw new RuntimeException("VersionedParcel encountered NoSuchMethodException", cause3);
        }
        catch (ClassNotFoundException cause4) {
            throw new RuntimeException("VersionedParcel encountered ClassNotFoundException", cause4);
        }
    }
    
    private void writeVersionedParcelableCreator(final VersionedParcelable versionedParcelable) {
        try {
            this.writeString(findParcelClass(versionedParcelable.getClass()).getName());
        }
        catch (ClassNotFoundException cause) {
            throw new RuntimeException(versionedParcelable.getClass().getSimpleName() + " does not have a Parcelizer", cause);
        }
    }
    
    protected abstract void closeField();
    
    protected abstract VersionedParcel createSubParcel();
    
    public boolean isStream() {
        return false;
    }
    
    protected <T> T[] readArray(final T[] a) {
        T[] array = null;
        int i = this.readInt();
        if (i >= 0) {
            final ArrayList list = new ArrayList<IBinder>(i);
            if (i != 0) {
                final int int1 = this.readInt();
                if (i < 0) {
                    return array;
                }
                int j = i;
                int k = i;
                int l = i;
                int n = i;
                switch (int1) {
                    case 4: {
                        while (j > 0) {
                            list.add((IBinder)this.readString());
                            --j;
                        }
                        break;
                    }
                    case 2: {
                        while (k > 0) {
                            list.add(this.readParcelable());
                            --k;
                        }
                        break;
                    }
                    case 1: {
                        while (l > 0) {
                            list.add(this.readVersionedParcelable());
                            --l;
                        }
                        break;
                    }
                    case 3: {
                        while (n > 0) {
                            list.add((IBinder)this.readSerializable());
                            --n;
                        }
                        break;
                    }
                    case 5: {
                        while (i > 0) {
                            list.add(this.readStrongBinder());
                            --i;
                        }
                        break;
                    }
                }
            }
            array = list.toArray(a);
        }
        return array;
    }
    
    public <T> T[] readArray(T[] array, final int n) {
        if (this.readField(n)) {
            array = this.readArray(array);
        }
        return array;
    }
    
    protected abstract boolean readBoolean();
    
    public boolean readBoolean(boolean boolean1, final int n) {
        if (this.readField(n)) {
            boolean1 = this.readBoolean();
        }
        return boolean1;
    }
    
    protected boolean[] readBooleanArray() {
        final int int1 = this.readInt();
        boolean[] array;
        if (int1 < 0) {
            array = null;
        }
        else {
            final boolean[] array2 = new boolean[int1];
            int n = 0;
            while (true) {
                array = array2;
                if (n >= int1) {
                    break;
                }
                array2[n] = (this.readInt() != 0);
                ++n;
            }
        }
        return array;
    }
    
    public boolean[] readBooleanArray(boolean[] booleanArray, final int n) {
        if (this.readField(n)) {
            booleanArray = this.readBooleanArray();
        }
        return booleanArray;
    }
    
    protected abstract Bundle readBundle();
    
    public Bundle readBundle(Bundle bundle, final int n) {
        if (this.readField(n)) {
            bundle = this.readBundle();
        }
        return bundle;
    }
    
    public byte readByte(final byte b, final int n) {
        byte b2;
        if (!this.readField(n)) {
            b2 = b;
        }
        else {
            b2 = (byte)(this.readInt() & 0xFF);
        }
        return b2;
    }
    
    protected abstract byte[] readByteArray();
    
    public byte[] readByteArray(byte[] byteArray, final int n) {
        if (this.readField(n)) {
            byteArray = this.readByteArray();
        }
        return byteArray;
    }
    
    public char[] readCharArray(char[] array, int i) {
        if (this.readField(i)) {
            final int int1 = this.readInt();
            if (int1 < 0) {
                array = null;
            }
            else {
                array = new char[int1];
                for (i = 0; i < int1; ++i) {
                    array[i] = (char)this.readInt();
                }
            }
        }
        return array;
    }
    
    protected abstract double readDouble();
    
    public double readDouble(double double1, final int n) {
        if (this.readField(n)) {
            double1 = this.readDouble();
        }
        return double1;
    }
    
    protected double[] readDoubleArray() {
        final int int1 = this.readInt();
        double[] array;
        if (int1 < 0) {
            array = null;
        }
        else {
            final double[] array2 = new double[int1];
            int n = 0;
            while (true) {
                array = array2;
                if (n >= int1) {
                    break;
                }
                array2[n] = this.readDouble();
                ++n;
            }
        }
        return array;
    }
    
    public double[] readDoubleArray(double[] doubleArray, final int n) {
        if (this.readField(n)) {
            doubleArray = this.readDoubleArray();
        }
        return doubleArray;
    }
    
    public Exception readException(Exception exception, int exceptionCode) {
        if (this.readField(exceptionCode)) {
            exceptionCode = this.readExceptionCode();
            if (exceptionCode != 0) {
                exception = this.readException(exceptionCode, this.readString());
            }
        }
        return exception;
    }
    
    protected abstract boolean readField(final int p0);
    
    protected abstract float readFloat();
    
    public float readFloat(float float1, final int n) {
        if (this.readField(n)) {
            float1 = this.readFloat();
        }
        return float1;
    }
    
    protected float[] readFloatArray() {
        final int int1 = this.readInt();
        float[] array;
        if (int1 < 0) {
            array = null;
        }
        else {
            final float[] array2 = new float[int1];
            int n = 0;
            while (true) {
                array = array2;
                if (n >= int1) {
                    break;
                }
                array2[n] = this.readFloat();
                ++n;
            }
        }
        return array;
    }
    
    public float[] readFloatArray(float[] floatArray, final int n) {
        if (this.readField(n)) {
            floatArray = this.readFloatArray();
        }
        return floatArray;
    }
    
    protected abstract int readInt();
    
    public int readInt(int int1, final int n) {
        if (this.readField(n)) {
            int1 = this.readInt();
        }
        return int1;
    }
    
    protected int[] readIntArray() {
        final int int1 = this.readInt();
        int[] array;
        if (int1 < 0) {
            array = null;
        }
        else {
            final int[] array2 = new int[int1];
            int n = 0;
            while (true) {
                array = array2;
                if (n >= int1) {
                    break;
                }
                array2[n] = this.readInt();
                ++n;
            }
        }
        return array;
    }
    
    public int[] readIntArray(int[] intArray, final int n) {
        if (this.readField(n)) {
            intArray = this.readIntArray();
        }
        return intArray;
    }
    
    public <T> List<T> readList(List<T> list, final int n) {
        if (this.readField(n)) {
            list = this.readCollection(n, new ArrayList<T>());
        }
        return list;
    }
    
    protected abstract long readLong();
    
    public long readLong(long long1, final int n) {
        if (this.readField(n)) {
            long1 = this.readLong();
        }
        return long1;
    }
    
    protected long[] readLongArray() {
        final int int1 = this.readInt();
        long[] array;
        if (int1 < 0) {
            array = null;
        }
        else {
            final long[] array2 = new long[int1];
            int n = 0;
            while (true) {
                array = array2;
                if (n >= int1) {
                    break;
                }
                array2[n] = this.readLong();
                ++n;
            }
        }
        return array;
    }
    
    public long[] readLongArray(long[] longArray, final int n) {
        if (this.readField(n)) {
            longArray = this.readLongArray();
        }
        return longArray;
    }
    
    protected abstract <T extends Parcelable> T readParcelable();
    
    public <T extends Parcelable> T readParcelable(T parcelable, final int n) {
        if (this.readField(n)) {
            parcelable = this.readParcelable();
        }
        return parcelable;
    }
    
    protected Serializable readSerializable() {
        final String string = this.readString();
        Serializable s;
        if (string == null) {
            s = null;
        }
        else {
            final ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(this.readByteArray());
            try {
                s = (Serializable)new ObjectInputStream(byteArrayInputStream) {
                    @Override
                    protected Class<?> resolveClass(final ObjectStreamClass desc) throws IOException, ClassNotFoundException {
                        final Class<?> forName = Class.forName(desc.getName(), false, this.getClass().getClassLoader());
                        Class<?> resolveClass;
                        if (forName != null) {
                            resolveClass = forName;
                        }
                        else {
                            resolveClass = super.resolveClass(desc);
                        }
                        return resolveClass;
                    }
                }.readObject();
            }
            catch (IOException cause) {
                throw new RuntimeException("VersionedParcelable encountered IOException reading a Serializable object (name = " + string + ")", cause);
            }
            catch (ClassNotFoundException cause2) {
                throw new RuntimeException("VersionedParcelable encountered ClassNotFoundException reading a Serializable object (name = " + string + ")", cause2);
            }
        }
        return s;
    }
    
    public <T> Set<T> readSet(Set<T> set, final int n) {
        if (this.readField(n)) {
            set = this.readCollection(n, new ArraySet<T>());
        }
        return set;
    }
    
    @RequiresApi(api = 21)
    public Size readSize(Size size, final int n) {
        if (this.readField(n)) {
            if (this.readBoolean()) {
                size = new Size(this.readInt(), this.readInt());
            }
            else {
                size = null;
            }
        }
        return size;
    }
    
    @RequiresApi(api = 21)
    public SizeF readSizeF(SizeF sizeF, final int n) {
        if (this.readField(n)) {
            if (this.readBoolean()) {
                sizeF = new SizeF(this.readFloat(), this.readFloat());
            }
            else {
                sizeF = null;
            }
        }
        return sizeF;
    }
    
    public SparseBooleanArray readSparseBooleanArray(SparseBooleanArray sparseBooleanArray, int i) {
        if (this.readField(i)) {
            final int int1 = this.readInt();
            if (int1 < 0) {
                sparseBooleanArray = null;
            }
            else {
                sparseBooleanArray = new SparseBooleanArray(int1);
                for (i = 0; i < int1; ++i) {
                    sparseBooleanArray.put(this.readInt(), this.readBoolean());
                }
            }
        }
        return sparseBooleanArray;
    }
    
    protected abstract String readString();
    
    public String readString(String string, final int n) {
        if (this.readField(n)) {
            string = this.readString();
        }
        return string;
    }
    
    protected abstract IBinder readStrongBinder();
    
    public IBinder readStrongBinder(IBinder strongBinder, final int n) {
        if (this.readField(n)) {
            strongBinder = this.readStrongBinder();
        }
        return strongBinder;
    }
    
    protected <T extends VersionedParcelable> T readVersionedParcelable() {
        final String string = this.readString();
        VersionedParcelable fromParcel;
        if (string == null) {
            fromParcel = null;
        }
        else {
            fromParcel = readFromParcel(string, this.createSubParcel());
        }
        return (T)fromParcel;
    }
    
    public <T extends VersionedParcelable> T readVersionedParcelable(T versionedParcelable, final int n) {
        if (this.readField(n)) {
            versionedParcelable = this.readVersionedParcelable();
        }
        return versionedParcelable;
    }
    
    protected abstract void setOutputField(final int p0);
    
    public void setSerializationFlags(final boolean b, final boolean b2) {
    }
    
    protected <T> void writeArray(final T[] array) {
        if (array == null) {
            this.writeInt(-1);
        }
        else {
            final int length = array.length;
            int i = 0;
            int j = 0;
            int k = 0;
            int l = 0;
            int n = 0;
            this.writeInt(length);
            if (length > 0) {
                final int type = this.getType(array[0]);
                this.writeInt(type);
                switch (type) {
                    case 1: {
                        while (n < length) {
                            this.writeVersionedParcelable((VersionedParcelable)array[n]);
                            ++n;
                        }
                        break;
                    }
                    case 4: {
                        while (i < length) {
                            this.writeString((String)array[i]);
                            ++i;
                        }
                        break;
                    }
                    case 2: {
                        while (j < length) {
                            this.writeParcelable((Parcelable)array[j]);
                            ++j;
                        }
                        break;
                    }
                    case 3: {
                        while (k < length) {
                            this.writeSerializable((Serializable)array[k]);
                            ++k;
                        }
                        break;
                    }
                    case 5: {
                        while (l < length) {
                            this.writeStrongBinder((IBinder)array[l]);
                            ++l;
                        }
                        break;
                    }
                }
            }
        }
    }
    
    public <T> void writeArray(final T[] array, final int outputField) {
        this.setOutputField(outputField);
        this.writeArray(array);
    }
    
    protected abstract void writeBoolean(final boolean p0);
    
    public void writeBoolean(final boolean b, final int outputField) {
        this.setOutputField(outputField);
        this.writeBoolean(b);
    }
    
    protected void writeBooleanArray(final boolean[] array) {
        if (array != null) {
            final int length = array.length;
            this.writeInt(length);
            for (int i = 0; i < length; ++i) {
                int n;
                if (array[i]) {
                    n = 1;
                }
                else {
                    n = 0;
                }
                this.writeInt(n);
            }
        }
        else {
            this.writeInt(-1);
        }
    }
    
    public void writeBooleanArray(final boolean[] array, final int outputField) {
        this.setOutputField(outputField);
        this.writeBooleanArray(array);
    }
    
    protected abstract void writeBundle(final Bundle p0);
    
    public void writeBundle(final Bundle bundle, final int outputField) {
        this.setOutputField(outputField);
        this.writeBundle(bundle);
    }
    
    public void writeByte(final byte b, final int outputField) {
        this.setOutputField(outputField);
        this.writeInt(b);
    }
    
    protected abstract void writeByteArray(final byte[] p0);
    
    public void writeByteArray(final byte[] array, final int outputField) {
        this.setOutputField(outputField);
        this.writeByteArray(array);
    }
    
    protected abstract void writeByteArray(final byte[] p0, final int p1, final int p2);
    
    public void writeByteArray(final byte[] array, final int n, final int n2, final int outputField) {
        this.setOutputField(outputField);
        this.writeByteArray(array, n, n2);
    }
    
    public void writeCharArray(final char[] array, int i) {
        this.setOutputField(i);
        if (array != null) {
            final int length = array.length;
            this.writeInt(length);
            for (i = 0; i < length; ++i) {
                this.writeInt(array[i]);
            }
        }
        else {
            this.writeInt(-1);
        }
    }
    
    protected abstract void writeDouble(final double p0);
    
    public void writeDouble(final double n, final int outputField) {
        this.setOutputField(outputField);
        this.writeDouble(n);
    }
    
    protected void writeDoubleArray(final double[] array) {
        if (array != null) {
            final int length = array.length;
            this.writeInt(length);
            for (int i = 0; i < length; ++i) {
                this.writeDouble(array[i]);
            }
        }
        else {
            this.writeInt(-1);
        }
    }
    
    public void writeDoubleArray(final double[] array, final int outputField) {
        this.setOutputField(outputField);
        this.writeDoubleArray(array);
    }
    
    public void writeException(final Exception cause, int outputField) {
        this.setOutputField(outputField);
        if (cause == null) {
            this.writeNoException();
        }
        else {
            outputField = 0;
            if (cause instanceof Parcelable && cause.getClass().getClassLoader() == Parcelable.class.getClassLoader()) {
                outputField = -9;
            }
            else if (cause instanceof SecurityException) {
                outputField = -1;
            }
            else if (cause instanceof BadParcelableException) {
                outputField = -2;
            }
            else if (cause instanceof IllegalArgumentException) {
                outputField = -3;
            }
            else if (cause instanceof NullPointerException) {
                outputField = -4;
            }
            else if (cause instanceof IllegalStateException) {
                outputField = -5;
            }
            else if (cause instanceof NetworkOnMainThreadException) {
                outputField = -6;
            }
            else if (cause instanceof UnsupportedOperationException) {
                outputField = -7;
            }
            this.writeInt(outputField);
            if (outputField == 0) {
                if (cause instanceof RuntimeException) {
                    throw (RuntimeException)cause;
                }
                throw new RuntimeException(cause);
            }
            else {
                this.writeString(cause.getMessage());
                switch (outputField) {
                    case -9: {
                        this.writeParcelable((Parcelable)cause);
                        break;
                    }
                }
            }
        }
    }
    
    protected abstract void writeFloat(final float p0);
    
    public void writeFloat(final float n, final int outputField) {
        this.setOutputField(outputField);
        this.writeFloat(n);
    }
    
    protected void writeFloatArray(final float[] array) {
        if (array != null) {
            final int length = array.length;
            this.writeInt(length);
            for (int i = 0; i < length; ++i) {
                this.writeFloat(array[i]);
            }
        }
        else {
            this.writeInt(-1);
        }
    }
    
    public void writeFloatArray(final float[] array, final int outputField) {
        this.setOutputField(outputField);
        this.writeFloatArray(array);
    }
    
    protected abstract void writeInt(final int p0);
    
    public void writeInt(final int n, final int outputField) {
        this.setOutputField(outputField);
        this.writeInt(n);
    }
    
    protected void writeIntArray(final int[] array) {
        if (array != null) {
            final int length = array.length;
            this.writeInt(length);
            for (int i = 0; i < length; ++i) {
                this.writeInt(array[i]);
            }
        }
        else {
            this.writeInt(-1);
        }
    }
    
    public void writeIntArray(final int[] array, final int outputField) {
        this.setOutputField(outputField);
        this.writeIntArray(array);
    }
    
    public <T> void writeList(final List<T> list, final int n) {
        this.writeCollection(list, n);
    }
    
    protected abstract void writeLong(final long p0);
    
    public void writeLong(final long n, final int outputField) {
        this.setOutputField(outputField);
        this.writeLong(n);
    }
    
    protected void writeLongArray(final long[] array) {
        if (array != null) {
            final int length = array.length;
            this.writeInt(length);
            for (int i = 0; i < length; ++i) {
                this.writeLong(array[i]);
            }
        }
        else {
            this.writeInt(-1);
        }
    }
    
    public void writeLongArray(final long[] array, final int outputField) {
        this.setOutputField(outputField);
        this.writeLongArray(array);
    }
    
    protected void writeNoException() {
        this.writeInt(0);
    }
    
    protected abstract void writeParcelable(final Parcelable p0);
    
    public void writeParcelable(final Parcelable parcelable, final int outputField) {
        this.setOutputField(outputField);
        this.writeParcelable(parcelable);
    }
    
    public void writeSerializable(final Serializable s, final int outputField) {
        this.setOutputField(outputField);
        this.writeSerializable(s);
    }
    
    public <T> void writeSet(final Set<T> set, final int n) {
        this.writeCollection(set, n);
    }
    
    @RequiresApi(api = 21)
    public void writeSize(final Size size, final int outputField) {
        this.setOutputField(outputField);
        this.writeBoolean(size != null);
        if (size != null) {
            this.writeInt(size.getWidth());
            this.writeInt(size.getHeight());
        }
    }
    
    @RequiresApi(api = 21)
    public void writeSizeF(final SizeF sizeF, final int outputField) {
        this.setOutputField(outputField);
        this.writeBoolean(sizeF != null);
        if (sizeF != null) {
            this.writeFloat(sizeF.getWidth());
            this.writeFloat(sizeF.getHeight());
        }
    }
    
    public void writeSparseBooleanArray(final SparseBooleanArray sparseBooleanArray, int i) {
        this.setOutputField(i);
        if (sparseBooleanArray == null) {
            this.writeInt(-1);
        }
        else {
            final int size = sparseBooleanArray.size();
            this.writeInt(size);
            for (i = 0; i < size; ++i) {
                this.writeInt(sparseBooleanArray.keyAt(i));
                this.writeBoolean(sparseBooleanArray.valueAt(i));
            }
        }
    }
    
    protected abstract void writeString(final String p0);
    
    public void writeString(final String s, final int outputField) {
        this.setOutputField(outputField);
        this.writeString(s);
    }
    
    protected abstract void writeStrongBinder(final IBinder p0);
    
    public void writeStrongBinder(final IBinder binder, final int outputField) {
        this.setOutputField(outputField);
        this.writeStrongBinder(binder);
    }
    
    protected abstract void writeStrongInterface(final IInterface p0);
    
    public void writeStrongInterface(final IInterface interface1, final int outputField) {
        this.setOutputField(outputField);
        this.writeStrongInterface(interface1);
    }
    
    protected void writeVersionedParcelable(final VersionedParcelable versionedParcelable) {
        if (versionedParcelable == null) {
            this.writeString(null);
        }
        else {
            this.writeVersionedParcelableCreator(versionedParcelable);
            final VersionedParcel subParcel = this.createSubParcel();
            writeToParcel(versionedParcelable, subParcel);
            subParcel.closeField();
        }
    }
    
    public void writeVersionedParcelable(final VersionedParcelable versionedParcelable, final int outputField) {
        this.setOutputField(outputField);
        this.writeVersionedParcelable(versionedParcelable);
    }
    
    public static class ParcelException extends RuntimeException
    {
        public ParcelException(final Throwable cause) {
            super(cause);
        }
    }
}
