// 
// Decompiled by Procyon v0.5.36
// 

package gnu.mapping;

public abstract class Procedure0or1 extends Procedure
{
    public Procedure0or1() {
    }
    
    public Procedure0or1(final String s) {
        super(s);
    }
    
    @Override
    public abstract Object apply0() throws Throwable;
    
    @Override
    public abstract Object apply1(final Object p0) throws Throwable;
    
    @Override
    public Object apply2(final Object o, final Object o2) {
        throw new WrongArguments(this, 2);
    }
    
    @Override
    public Object apply3(final Object o, final Object o2, final Object o3) {
        throw new WrongArguments(this, 3);
    }
    
    @Override
    public Object apply4(final Object o, final Object o2, final Object o3, final Object o4) {
        throw new WrongArguments(this, 4);
    }
    
    @Override
    public Object applyN(final Object[] array) throws Throwable {
        Object o;
        if (array.length == 0) {
            o = this.apply0();
        }
        else {
            if (array.length != 1) {
                throw new WrongArguments(this, array.length);
            }
            o = this.apply1(array[0]);
        }
        return o;
    }
    
    @Override
    public int numArgs() {
        return 4096;
    }
}
