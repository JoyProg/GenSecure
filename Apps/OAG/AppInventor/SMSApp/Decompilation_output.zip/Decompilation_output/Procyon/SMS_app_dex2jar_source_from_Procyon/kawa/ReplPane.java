// 
// Decompiled by Procyon v0.5.36
// 

package kawa;

import gnu.lists.CharBuffer;
import java.awt.event.KeyEvent;
import gnu.mapping.OutPort;
import javax.swing.text.MutableAttributeSet;
import javax.swing.text.Element;
import java.io.Serializable;
import javax.swing.text.AttributeSet;
import javax.swing.text.EditorKit;
import java.awt.event.FocusListener;
import javax.swing.text.StyledDocument;
import java.awt.event.KeyListener;
import javax.swing.JTextPane;

public class ReplPane extends JTextPane implements KeyListener
{
    public static final Object PaintableAttribute;
    public static final String PaintableElementName = "Paintable";
    public static final Object ViewableAttribute;
    public static final String ViewableElementName = "Viewable";
    ReplDocument document;
    
    static {
        ViewableAttribute = new String("Viewable");
        PaintableAttribute = new String("Paintable");
    }
    
    public ReplPane(final ReplDocument l) {
        super(l);
        this.document = l;
        l.pane = this;
        ++l.paneCount;
        this.addKeyListener(this);
        this.addFocusListener(l);
        this.getEditorKit();
        this.setCaretPosition(l.outputMark);
    }
    
    @Override
    protected EditorKit createDefaultEditorKit() {
        return new ReplEditorKit(this);
    }
    
    void enter() {
        final int caretPosition = this.getCaretPosition();
        Serializable s = this.document.content.buffer;
        final int n = ((CharBuffer)s).length() - 1;
        this.document.endMark = -1;
        Label_0161: {
            if (caretPosition < this.document.outputMark) {
                break Label_0161;
            }
            final int index = ((CharBuffer)s).indexOf(10, caretPosition);
            Label_0136: {
                int endOffset;
                if ((endOffset = index) == n) {
                    if (n <= this.document.outputMark || ((CharBuffer)s).charAt(n - 1) != '\n') {
                        break Label_0136;
                    }
                    endOffset = index - 1;
                }
                while (true) {
                    this.document.endMark = endOffset;
                    synchronized (this.document.in_r) {
                        this.document.in_r.notifyAll();
                        // monitorexit(this.document.in_r)
                        if (caretPosition <= endOffset) {
                            this.setCaretPosition(endOffset + 1);
                        }
                        return;
                        this.document.insertString(n, "\n", null);
                        endOffset = index;
                        continue;
                    }
                    break;
                }
            }
        }
        int endOffset;
        if (caretPosition == 0) {
            endOffset = 0;
        }
        else {
            endOffset = ((CharBuffer)s).lastIndexOf(10, caretPosition - 1) + 1;
        }
        final Element characterElement = this.document.getCharacterElement(endOffset);
        final int index2 = ((CharBuffer)s).indexOf(10, caretPosition);
        if (characterElement.getAttributes().isEqual(ReplDocument.promptStyle)) {
            endOffset = characterElement.getEndOffset();
        }
        if (index2 < 0) {
            s = ((CharBuffer)s).substring(endOffset, n) + '\n';
        }
        else {
            s = ((CharBuffer)s).substring(endOffset, index2 + 1);
        }
        this.setCaretPosition(this.document.outputMark);
        this.document.write((String)s, ReplDocument.inputStyle);
        if (this.document.in_r != null) {
            this.document.in_r.append((CharSequence)s, 0, ((String)s).length());
        }
    }
    
    @Override
    public MutableAttributeSet getInputAttributes() {
        return ReplDocument.inputStyle;
    }
    
    public OutPort getStderr() {
        return this.document.err_stream;
    }
    
    public OutPort getStdout() {
        return this.document.out_stream;
    }
    
    @Override
    public void keyPressed(final KeyEvent keyEvent) {
        if (keyEvent.getKeyCode() == 10) {
            this.enter();
            keyEvent.consume();
        }
    }
    
    @Override
    public void keyReleased(final KeyEvent keyEvent) {
    }
    
    @Override
    public void keyTyped(final KeyEvent keyEvent) {
    }
    
    @Override
    public void removeNotify() {
        super.removeNotify();
        final ReplDocument document = this.document;
        final int paneCount = document.paneCount - 1;
        document.paneCount = paneCount;
        if (paneCount == 0) {
            this.document.close();
        }
    }
}
