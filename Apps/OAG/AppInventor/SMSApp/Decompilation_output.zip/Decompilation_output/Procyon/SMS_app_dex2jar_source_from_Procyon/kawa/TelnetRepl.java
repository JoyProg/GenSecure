// 
// Decompiled by Procyon v0.5.36
// 

package kawa;

import java.io.IOException;
import gnu.mapping.InPort;
import gnu.mapping.Procedure;
import gnu.mapping.Future;
import java.io.InputStream;
import gnu.mapping.TtyInPort;
import gnu.text.Path;
import java.io.OutputStream;
import gnu.mapping.OutPort;
import gnu.text.FilePath;
import java.net.Socket;
import gnu.expr.Language;
import gnu.mapping.Procedure0;

public class TelnetRepl extends Procedure0
{
    Language language;
    Socket socket;
    
    public TelnetRepl(final Language language, final Socket socket) {
        this.language = language;
        this.socket = socket;
    }
    
    public static void serve(final Language language, final Socket socket) throws IOException {
        final Telnet telnet = new Telnet(socket, true);
        final TelnetOutputStream outputStream = telnet.getOutputStream();
        final TelnetInputStream inputStream = telnet.getInputStream();
        final OutPort outPort = new OutPort(outputStream, FilePath.valueOf("/dev/stdout"));
        new Future(new TelnetRepl(language, socket), new TtyInPort(inputStream, FilePath.valueOf("/dev/stdin"), outPort), outPort, outPort).start();
    }
    
    @Override
    public Object apply0() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: getfield        kawa/TelnetRepl.language:Lgnu/expr/Language;
        //     4: invokestatic    gnu/mapping/Environment.getCurrent:()Lgnu/mapping/Environment;
        //     7: invokestatic    kawa/Shell.run:(Lgnu/expr/Language;Lgnu/mapping/Environment;)Z
        //    10: pop            
        //    11: getstatic       gnu/mapping/Values.empty:Lgnu/mapping/Values;
        //    14: astore_1       
        //    15: aload_0        
        //    16: getfield        kawa/TelnetRepl.socket:Ljava/net/Socket;
        //    19: invokevirtual   java/net/Socket.close:()V
        //    22: aload_1        
        //    23: areturn        
        //    24: astore_2       
        //    25: aload_0        
        //    26: getfield        kawa/TelnetRepl.socket:Ljava/net/Socket;
        //    29: invokevirtual   java/net/Socket.close:()V
        //    32: aload_2        
        //    33: athrow         
        //    34: astore_1       
        //    35: goto            32
        //    38: astore_2       
        //    39: goto            22
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  0      15     24     38     Any
        //  15     22     38     42     Ljava/io/IOException;
        //  25     32     34     38     Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0022:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
}
