// 
// Decompiled by Procyon v0.5.36
// 

package gnu.mapping;

import gnu.bytecode.ArrayType;
import gnu.bytecode.Type;

public abstract class MethodProc extends ProcedureN
{
    public static final int NO_MATCH = -1;
    public static final int NO_MATCH_AMBIGUOUS = -851968;
    public static final int NO_MATCH_BAD_TYPE = -786432;
    public static final int NO_MATCH_TOO_FEW_ARGS = -983040;
    public static final int NO_MATCH_TOO_MANY_ARGS = -917504;
    static final Type[] unknownArgTypes;
    protected Object argTypes;
    
    static {
        unknownArgTypes = new Type[] { Type.pointer_type };
    }
    
    public static RuntimeException matchFailAsException(final int n, final Procedure procedure, final Object[] array) {
        final short n2 = (short)n;
        RuntimeException ex;
        if ((n & 0xFFFF0000) != 0xFFF40000) {
            ex = new WrongArguments(procedure, array.length);
        }
        else {
            Object o;
            if (n2 > 0) {
                o = array[n2 - 1];
            }
            else {
                o = null;
            }
            ex = new WrongType(procedure, n2, o);
        }
        return ex;
    }
    
    public static int mostSpecific(final MethodProc[] array, final int n) {
        int n2;
        if (n <= 1) {
            n2 = n - 1;
        }
        else {
            MethodProc methodProc = array[0];
            MethodProc[] array2 = null;
            int i = 1;
            n2 = 0;
            while (i < n) {
                final MethodProc methodProc2 = array[i];
                MethodProc methodProc4 = null;
                Label_0089: {
                    if (methodProc != null) {
                        final MethodProc mostSpecific = mostSpecific(methodProc, methodProc2);
                        if (mostSpecific == null) {
                            MethodProc[] array3;
                            if ((array3 = array2) == null) {
                                array3 = new MethodProc[n];
                            }
                            array3[0] = methodProc;
                            array3[1] = methodProc2;
                            n2 = 2;
                            final MethodProc methodProc3 = null;
                            array2 = array3;
                            methodProc4 = methodProc3;
                        }
                        else if (mostSpecific == methodProc2) {
                            methodProc4 = methodProc2;
                            n2 = i;
                        }
                        else {
                            methodProc4 = methodProc;
                        }
                    }
                    else {
                        for (final MethodProc methodProc5 : array2) {
                            final MethodProc mostSpecific2 = mostSpecific(methodProc5, methodProc2);
                            if (mostSpecific2 == methodProc5) {
                                methodProc4 = methodProc;
                                break Label_0089;
                            }
                            if (mostSpecific2 == null) {
                                final int n3 = n2 + 1;
                                array2[n2] = methodProc2;
                                methodProc4 = methodProc;
                                n2 = n3;
                                break Label_0089;
                            }
                        }
                        methodProc4 = methodProc2;
                        n2 = i;
                    }
                }
                ++i;
                methodProc = methodProc4;
            }
            if (methodProc == null) {
                n2 = -1;
            }
        }
        return n2;
    }
    
    public static MethodProc mostSpecific(MethodProc methodProc, final MethodProc methodProc2) {
        int n = 0;
        boolean b = false;
        final int n2 = 0;
        final int minArgs = methodProc.minArgs();
        final int minArgs2 = methodProc2.minArgs();
        final int maxArgs = methodProc.maxArgs();
        final int maxArgs2 = methodProc2.maxArgs();
        if ((maxArgs >= 0 && maxArgs < minArgs2) || (maxArgs2 >= 0 && maxArgs2 < minArgs)) {
            methodProc = null;
        }
        else {
            int numParameters = methodProc.numParameters();
            final int numParameters2 = methodProc2.numParameters();
            if (numParameters <= numParameters2) {
                numParameters = numParameters2;
            }
            int n3 = n2;
            if (maxArgs != maxArgs2) {
                if (maxArgs < 0) {
                    b = true;
                }
                n = (b ? 1 : 0);
                n3 = n2;
                if (maxArgs2 < 0) {
                    n3 = 1;
                    n = (b ? 1 : 0);
                }
            }
            int n4;
            if (minArgs < minArgs2) {
                n4 = 1;
            }
            else {
                n4 = n;
                if (minArgs > minArgs2) {
                    n3 = 1;
                    n4 = n;
                }
            }
            for (int i = 0; i < numParameters; ++i) {
                final int compare = methodProc.getParameterType(i).compare(methodProc2.getParameterType(i));
                if (compare == -1) {
                    n3 = 1;
                    if (n4 != 0) {
                        methodProc = null;
                        return methodProc;
                    }
                }
                if (compare == 1) {
                    n4 = 1;
                    if (n3 != 0) {
                        methodProc = null;
                        return methodProc;
                    }
                }
            }
            if (n3 == 0) {
                if (n4 != 0) {
                    methodProc = methodProc2;
                }
                else {
                    methodProc = null;
                }
            }
        }
        return methodProc;
    }
    
    @Override
    public Object applyN(final Object[] array) throws Throwable {
        Procedure.checkArgCount(this, array.length);
        final CallContext instance = CallContext.getInstance();
        this.checkN(array, instance);
        return instance.runUntilValue();
    }
    
    public Type getParameterType(final int n) {
        if (!(this.argTypes instanceof Type[])) {
            this.resolveParameterTypes();
        }
        final Type[] array = (Type[])this.argTypes;
        Type type;
        if (n < array.length && (n < array.length - 1 || this.maxArgs() >= 0)) {
            type = array[n];
        }
        else {
            if (this.maxArgs() < 0) {
                final Type type2 = array[array.length - 1];
                if (type2 instanceof ArrayType) {
                    type = ((ArrayType)type2).getComponentType();
                    return type;
                }
            }
            type = Type.objectType;
        }
        return type;
    }
    
    public int isApplicable(final Type[] array) {
        int length = array.length;
        final int numArgs = this.numArgs();
        int n;
        if (length < (numArgs & 0xFFF) || (numArgs >= 0 && length > numArgs >> 12)) {
            n = -1;
        }
        else {
            int n2 = 1;
            while (true) {
                final int n3 = length - 1;
                n = n2;
                if (n3 < 0) {
                    return n;
                }
                final int compare = this.getParameterType(n3).compare(array[n3]);
                if (compare == -3) {
                    break;
                }
                length = n3;
                if (compare >= 0) {
                    continue;
                }
                n2 = 0;
                length = n3;
            }
            n = -1;
        }
        return n;
    }
    
    public int numParameters() {
        final int numArgs = this.numArgs();
        int n = numArgs >> 12;
        if (n < 0) {
            n = (numArgs & 0xFFF) + 1;
        }
        return n;
    }
    
    protected void resolveParameterTypes() {
        this.argTypes = MethodProc.unknownArgTypes;
    }
}
