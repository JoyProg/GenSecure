// 
// Decompiled by Procyon v0.5.36
// 

package kawa;

import java.awt.event.FocusEvent;
import javax.swing.text.BadLocationException;
import gnu.lists.CharBuffer;
import javax.swing.event.DocumentEvent;
import java.util.ArrayList;
import gnu.mapping.InPort;
import gnu.mapping.Procedure;
import gnu.mapping.Values;
import javax.swing.SwingUtilities;
import gnu.mapping.OutPort;
import java.io.Reader;
import gnu.text.Path;
import javax.swing.text.AttributeSet;
import gnu.expr.ModuleBody;
import javax.swing.text.AbstractDocument;
import javax.swing.text.MutableAttributeSet;
import javax.swing.text.StyleConstants;
import java.awt.Color;
import gnu.mapping.Future;
import javax.swing.JTextPane;
import gnu.expr.Language;
import gnu.text.QueueReader;
import gnu.mapping.Environment;
import gnu.kawa.swingviews.SwingContent;
import javax.swing.text.StyleContext;
import javax.swing.text.Style;
import java.awt.event.FocusListener;
import javax.swing.event.DocumentListener;
import javax.swing.text.DefaultStyledDocument;

public class ReplDocument extends DefaultStyledDocument implements DocumentListener, FocusListener
{
    static Style blueStyle;
    public static Style defaultStyle;
    public static Style inputStyle;
    static Style promptStyle;
    public static Style redStyle;
    public static StyleContext styles;
    Object closeListeners;
    SwingContent content;
    public int endMark;
    Environment environment;
    final ReplPaneOutPort err_stream;
    final GuiInPort in_p;
    final QueueReader in_r;
    Language language;
    int length;
    final ReplPaneOutPort out_stream;
    public int outputMark;
    JTextPane pane;
    int paneCount;
    Future thread;
    
    static {
        ReplDocument.styles = new StyleContext();
        ReplDocument.defaultStyle = ReplDocument.styles.addStyle("default", null);
        ReplDocument.inputStyle = ReplDocument.styles.addStyle("input", null);
        ReplDocument.redStyle = ReplDocument.styles.addStyle("red", null);
        ReplDocument.blueStyle = ReplDocument.styles.addStyle("blue", null);
        ReplDocument.promptStyle = ReplDocument.styles.addStyle("prompt", null);
        StyleConstants.setForeground(ReplDocument.redStyle, Color.red);
        StyleConstants.setForeground(ReplDocument.blueStyle, Color.blue);
        StyleConstants.setForeground(ReplDocument.promptStyle, Color.green);
        StyleConstants.setBold(ReplDocument.inputStyle, true);
    }
    
    public ReplDocument(final Language language, final Environment environment, final boolean b) {
        this(new SwingContent(), language, environment, b);
    }
    
    private ReplDocument(final SwingContent swingContent, final Language language, final Environment environment, final boolean b) {
        super((Content)swingContent, ReplDocument.styles);
        this.outputMark = 0;
        this.endMark = -1;
        this.length = 0;
        this.content = swingContent;
        ModuleBody.exitIncrement();
        this.addDocumentListener(this);
        this.language = language;
        this.in_r = new QueueReader() {
            @Override
            public void checkAvailable() {
                ReplDocument.this.checkingPendingInput();
            }
        };
        this.out_stream = new ReplPaneOutPort(this, "/dev/stdout", ReplDocument.defaultStyle);
        this.err_stream = new ReplPaneOutPort(this, "/dev/stderr", ReplDocument.redStyle);
        this.in_p = new GuiInPort(this.in_r, Path.valueOf("/dev/stdin"), this.out_stream, this);
        (this.thread = Future.make(new repl(language) {
            @Override
            public Object apply0() {
                final Environment current = Environment.getCurrent();
                if (b) {
                    current.setIndirectDefines();
                }
                ReplDocument.this.environment = current;
                Shell.run(this.language, current);
                SwingUtilities.invokeLater(new Runnable() {
                    @Override
                    public void run() {
                        ReplDocument.this.fireDocumentClosed();
                    }
                });
                return Values.empty;
            }
        }, environment, this.in_p, this.out_stream, this.err_stream)).start();
    }
    
    public void addDocumentCloseListener(final DocumentCloseListener documentCloseListener) {
        if (this.closeListeners == null) {
            this.closeListeners = documentCloseListener;
        }
        else {
            ArrayList<DocumentCloseListener> closeListeners;
            if (this.closeListeners instanceof ArrayList) {
                closeListeners = (ArrayList<DocumentCloseListener>)this.closeListeners;
            }
            else {
                closeListeners = new ArrayList<DocumentCloseListener>(10);
                closeListeners.add((DocumentCloseListener)this.closeListeners);
                this.closeListeners = closeListeners;
            }
            closeListeners.add(documentCloseListener);
        }
    }
    
    @Override
    public void changedUpdate(final DocumentEvent documentEvent) {
        this.textValueChanged(documentEvent);
    }
    
    public void checkingPendingInput() {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                final int outputMark = ReplDocument.this.outputMark;
                if (outputMark > ReplDocument.this.endMark) {
                    return;
                }
                final CharBuffer buffer = ReplDocument.this.content.buffer;
                final int index = buffer.indexOf(10, outputMark);
                if (index == ReplDocument.this.endMark) {
                    ReplDocument.this.endMark = -1;
                }
                if (outputMark == ReplDocument.this.outputMark) {
                    ReplDocument.this.outputMark = index + 1;
                }
                if (ReplDocument.this.in_r == null) {
                    return;
                }
                synchronized (ReplDocument.this.in_r) {
                    ReplDocument.this.in_r.append(buffer, outputMark, index + 1);
                    ReplDocument.this.in_r.notifyAll();
                }
            }
        });
    }
    
    void close() {
        this.in_r.appendEOF();
        while (true) {
            try {
                Thread.sleep(100L);
                this.thread.stop();
                this.fireDocumentClosed();
                ModuleBody.exitDecrement();
            }
            catch (InterruptedException ex) {
                continue;
            }
            break;
        }
    }
    
    public void deleteOldText() {
        int lastIndex = 0;
        synchronized (this) {
            try {
                final String text = this.getText(0, this.outputMark);
                if (this.outputMark > 0) {
                    lastIndex = text.lastIndexOf(10, this.outputMark - 1);
                    ++lastIndex;
                }
                this.remove(0, lastIndex);
            }
            catch (BadLocationException cause) {
                throw new Error(cause);
            }
        }
    }
    
    void fireDocumentClosed() {
        if (this.closeListeners instanceof DocumentCloseListener) {
            ((DocumentCloseListener)this.closeListeners).closed(this);
        }
        else if (this.closeListeners != null) {
            final ArrayList list = (ArrayList)this.closeListeners;
            int size = list.size();
            while (--size >= 0) {
                list.get(size).closed(this);
            }
        }
    }
    
    @Override
    public void focusGained(final FocusEvent focusEvent) {
        final Object source = focusEvent.getSource();
        if (source instanceof ReplPane) {
            this.pane = (ReplPane)source;
        }
        else {
            this.pane = null;
        }
        ReplPane pane;
        if (source instanceof ReplPane) {
            pane = (ReplPane)source;
        }
        else {
            pane = null;
        }
        this.pane = pane;
    }
    
    @Override
    public void focusLost(final FocusEvent focusEvent) {
        this.pane = null;
    }
    
    @Override
    public void insertString(final int offs, final String str, final AttributeSet a) {
        try {
            super.insertString(offs, str, a);
        }
        catch (BadLocationException cause) {
            throw new Error(cause);
        }
    }
    
    @Override
    public void insertUpdate(final DocumentEvent documentEvent) {
        this.textValueChanged(documentEvent);
    }
    
    public void removeDocumentCloseListener(final DocumentCloseListener documentCloseListener) {
        if (this.closeListeners instanceof DocumentCloseListener) {
            if (this.closeListeners == documentCloseListener) {
                this.closeListeners = null;
            }
        }
        else if (this.closeListeners != null) {
            final ArrayList list = (ArrayList)this.closeListeners;
            int size = list.size();
            while (true) {
                final int n = size - 1;
                if (n < 0) {
                    break;
                }
                size = n;
                if (list.get(n) != documentCloseListener) {
                    continue;
                }
                list.remove(n);
                size = n;
            }
            if (list.size() == 0) {
                this.closeListeners = null;
            }
        }
    }
    
    @Override
    public void removeUpdate(final DocumentEvent documentEvent) {
        this.textValueChanged(documentEvent);
    }
    
    public void textValueChanged(final DocumentEvent documentEvent) {
        while (true) {
            final int offset;
            final int n;
            Label_0098: {
                synchronized (this) {
                    offset = documentEvent.getOffset();
                    n = this.getLength() - this.length;
                    this.length += n;
                    if (offset < this.outputMark) {
                        this.outputMark += n;
                    }
                    else if (offset - n < this.outputMark) {
                        this.outputMark = offset;
                    }
                    if (this.endMark >= 0) {
                        if (offset >= this.endMark) {
                            break Label_0098;
                        }
                        this.endMark += n;
                    }
                    return;
                }
            }
            if (offset - n < this.endMark) {
                this.endMark = offset;
            }
        }
    }
    
    public void write(final String s, final AttributeSet set) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                int n;
                if (ReplDocument.this.pane != null && ReplDocument.this.pane.getCaretPosition() == ReplDocument.this.outputMark) {
                    n = 1;
                }
                else {
                    n = 0;
                }
                ReplDocument.this.insertString(ReplDocument.this.outputMark, s, set);
                final int length = s.length();
                final ReplDocument this$0 = ReplDocument.this;
                this$0.outputMark += length;
                if (n != 0) {
                    ReplDocument.this.pane.setCaretPosition(ReplDocument.this.outputMark);
                }
            }
        });
    }
    
    public interface DocumentCloseListener
    {
        void closed(final ReplDocument p0);
    }
}
