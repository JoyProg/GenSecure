// 
// Decompiled by Procyon v0.5.36
// 

package kawa;

import java.awt.geom.AffineTransform;
import java.awt.Paint;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Graphics;
import java.awt.Rectangle;
import javax.swing.text.BadLocationException;
import javax.swing.text.Position;
import java.awt.Shape;
import javax.swing.text.Element;
import gnu.kawa.models.Paintable;
import java.awt.geom.Rectangle2D;
import javax.swing.text.View;

class PaintableView extends View
{
    Rectangle2D bounds;
    Paintable p;
    
    public PaintableView(final Element elem, final Paintable p2) {
        super(elem);
        this.p = p2;
        this.bounds = p2.getBounds2D();
    }
    
    @Override
    public float getAlignment(final int axis) {
        float alignment = 0.0f;
        switch (axis) {
            default: {
                alignment = super.getAlignment(axis);
                break;
            }
            case 1: {
                alignment = 1.0f;
                break;
            }
        }
        return alignment;
    }
    
    @Override
    public float getPreferredSpan(final int i) {
        float n = 0.0f;
        switch (i) {
            default: {
                throw new IllegalArgumentException("Invalid axis: " + i);
            }
            case 0: {
                n = (float)this.bounds.getWidth();
                break;
            }
            case 1: {
                n = (float)this.bounds.getHeight();
                break;
            }
        }
        return n;
    }
    
    @Override
    public Shape modelToView(final int n, final Shape shape, final Position.Bias bias) throws BadLocationException {
        final int startOffset = this.getStartOffset();
        final int endOffset = this.getEndOffset();
        if (n >= startOffset && n <= endOffset) {
            final Rectangle bounds = shape.getBounds();
            if (n == endOffset) {
                bounds.x += bounds.width;
            }
            bounds.width = 0;
            return bounds;
        }
        throw new BadLocationException(n + " not in range " + startOffset + "," + endOffset, n);
    }
    
    @Override
    public void paint(Graphics graphics, Shape paint) {
        graphics = graphics;
        final Rectangle bounds = paint.getBounds();
        final AffineTransform transform = ((Graphics2D)graphics).getTransform();
        paint = (Shape)((Graphics2D)graphics).getPaint();
        try {
            ((Graphics2D)graphics).translate(bounds.x, bounds.y);
            ((Graphics2D)graphics).setPaint(Color.BLACK);
            this.p.paint((Graphics2D)graphics);
        }
        finally {
            ((Graphics2D)graphics).setTransform(transform);
            ((Graphics2D)graphics).setPaint((Paint)paint);
        }
    }
    
    @Override
    public int viewToModel(final float n, final float n2, final Shape shape, final Position.Bias[] array) {
        final Rectangle rectangle = (Rectangle)shape;
        int n3;
        if (n < rectangle.x + rectangle.width / 2) {
            array[0] = Position.Bias.Forward;
            n3 = this.getStartOffset();
        }
        else {
            array[0] = Position.Bias.Backward;
            n3 = this.getEndOffset();
        }
        return n3;
    }
}
