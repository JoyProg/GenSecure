// 
// Decompiled by Procyon v0.5.36
// 

package gnu.mapping;

import gnu.lists.Consumer;
import java.io.BufferedInputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.io.IOException;
import java.io.InputStream;
import gnu.text.Path;
import gnu.text.Printable;
import gnu.text.LineBufferedReader;

public class InPort extends LineBufferedReader implements Printable
{
    public static final ThreadLocation inLocation;
    private static InPort systemInPort;
    
    static {
        InPort.systemInPort = new TtyInPort(System.in, Path.valueOf("/dev/stdin"), OutPort.outInitial);
        (inLocation = new ThreadLocation("in-default")).setGlobal(InPort.systemInPort);
    }
    
    public InPort(final InputStream inputStream) {
        super(inputStream);
    }
    
    public InPort(final InputStream inputStream, final Path path) {
        this(inputStream);
        this.setPath(path);
    }
    
    public InPort(final InputStream inputStream, final Path path, final Object o) throws UnsupportedEncodingException {
        this(convertToReader(inputStream, o), path);
        Label_0027: {
            if (o != Boolean.FALSE) {
                break Label_0027;
            }
            while (true) {
                try {
                    this.setBuffer(new char[2048]);
                    return;
                    this.setConvertCR(true);
                }
                catch (IOException ex) {}
            }
        }
    }
    
    public InPort(final Reader reader) {
        super(reader);
    }
    
    public InPort(final Reader reader, final Path path) {
        this(reader);
        this.setPath(path);
    }
    
    public static Reader convertToReader(final InputStream inputStream, Object string) {
        if (string == null || string == Boolean.TRUE) {
            return new InputStreamReader(inputStream);
        }
        Label_0033: {
            if (string != Boolean.FALSE) {
                break Label_0033;
            }
            string = "8859_1";
            try {
                return new InputStreamReader(inputStream, (String)string);
                string = string.toString();
                return new InputStreamReader(inputStream, (String)string);
            }
            catch (UnsupportedEncodingException ex) {
                throw new RuntimeException("unknown character encoding: " + (String)string);
            }
        }
        return new InputStreamReader(inputStream);
    }
    
    public static InPort inDefault() {
        return (InPort)InPort.inLocation.get();
    }
    
    public static InPort openFile(final InputStream inputStream, final Object o) throws UnsupportedEncodingException {
        return new InPort(inputStream, Path.valueOf(o), Environment.user().get("port-char-encoding"));
    }
    
    public static InPort openFile(final Object o) throws IOException {
        final Path value = Path.valueOf(o);
        return openFile(new BufferedInputStream(value.openInputStream()), value);
    }
    
    public static void setInDefault(final InPort inPort) {
        InPort.inLocation.set(inPort);
    }
    
    @Override
    public void print(final Consumer consumer) {
        consumer.write("#<input-port");
        final String name = this.getName();
        if (name != null) {
            consumer.write(32);
            consumer.write(name);
        }
        consumer.write(62);
    }
}
