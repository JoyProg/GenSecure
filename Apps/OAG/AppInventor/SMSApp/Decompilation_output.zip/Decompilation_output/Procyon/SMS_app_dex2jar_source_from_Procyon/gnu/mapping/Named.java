// 
// Decompiled by Procyon v0.5.36
// 

package gnu.mapping;

public interface Named
{
    String getName();
    
    Object getSymbol();
    
    void setName(final String p0);
}
