// 
// Decompiled by Procyon v0.5.36
// 

package gnu.mapping;

import gnu.lists.Pair;
import gnu.lists.LList;
import gnu.lists.TreeList;
import gnu.math.IntNum;
import gnu.lists.Consumer;

public class CallContext
{
    public static final int ARG_IN_IVALUE1 = 5;
    public static final int ARG_IN_IVALUE2 = 6;
    public static final int ARG_IN_VALUE1 = 1;
    public static final int ARG_IN_VALUE2 = 2;
    public static final int ARG_IN_VALUE3 = 3;
    public static final int ARG_IN_VALUE4 = 4;
    public static final int ARG_IN_VALUES_ARRAY = 0;
    static ThreadLocal currentContext;
    public Consumer consumer;
    public int count;
    public Object[][] evalFrames;
    public int ivalue1;
    public int ivalue2;
    public int next;
    public int pc;
    public Procedure proc;
    public Object value1;
    public Object value2;
    public Object value3;
    public Object value4;
    public Object[] values;
    public ValueStack vstack;
    public int where;
    
    static {
        CallContext.currentContext = new ThreadLocal();
    }
    
    public CallContext() {
        this.vstack = new ValueStack();
        this.consumer = this.vstack;
    }
    
    public static CallContext getInstance() {
        CallContext onlyInstance;
        if ((onlyInstance = getOnlyInstance()) == null) {
            onlyInstance = new CallContext();
            setInstance(onlyInstance);
        }
        return onlyInstance;
    }
    
    public static CallContext getOnlyInstance() {
        return CallContext.currentContext.get();
    }
    
    public static void setInstance(final CallContext value) {
        Thread.currentThread();
        CallContext.currentContext.set(value);
    }
    
    public final void cleanupFromContext(final int n) {
        final ValueStack vstack = this.vstack;
        final char[] data = vstack.data;
        final int oindex = data[n - 2] << 16 | (data[n - 1] & '\uffff');
        this.consumer = (Consumer)vstack.objects[oindex];
        vstack.objects[oindex] = null;
        vstack.oindex = oindex;
        vstack.gapStart = n - 3;
    }
    
    Object getArgAsObject(final int n) {
        if (n < 8) {
            switch (this.where >> n * 4 & 0xF) {
                case 1: {
                    return this.value1;
                }
                case 2: {
                    return this.value2;
                }
                case 3: {
                    return this.value3;
                }
                case 4: {
                    return this.value4;
                }
                case 5: {
                    return IntNum.make(this.ivalue1);
                }
                case 6: {
                    return IntNum.make(this.ivalue2);
                }
            }
        }
        return this.values[n];
    }
    
    public int getArgCount() {
        return this.count;
    }
    
    public Object[] getArgs() {
        Object[] values;
        if (this.where == 0) {
            values = this.values;
        }
        else {
            final int count = this.count;
            this.next = 0;
            final Object[] array = new Object[count];
            int n = 0;
            while (true) {
                values = array;
                if (n >= count) {
                    break;
                }
                array[n] = this.getNextArg();
                ++n;
            }
        }
        return values;
    }
    
    public final Object getFromContext(final int n) throws Throwable {
        this.runUntilDone();
        final ValueStack vstack = this.vstack;
        final Object make = Values.make(vstack, n, vstack.gapStart);
        this.cleanupFromContext(n);
        return make;
    }
    
    public Object getNextArg() {
        if (this.next >= this.count) {
            throw new WrongArguments(null, this.count);
        }
        return this.getArgAsObject(this.next++);
    }
    
    public Object getNextArg(Object argAsObject) {
        if (this.next < this.count) {
            argAsObject = this.getArgAsObject(this.next++);
        }
        return argAsObject;
    }
    
    public int getNextIntArg() {
        if (this.next >= this.count) {
            throw new WrongArguments(null, this.count);
        }
        return ((Number)this.getArgAsObject(this.next++)).intValue();
    }
    
    public int getNextIntArg(int intValue) {
        if (this.next < this.count) {
            intValue = this.next++;
            intValue = ((Number)this.getArgAsObject(intValue)).intValue();
        }
        return intValue;
    }
    
    public final Object[] getRestArgsArray(int i) {
        final Object[] array = new Object[this.count - i];
        int n = 0;
        while (i < this.count) {
            array[n] = this.getArgAsObject(i);
            ++n;
            ++i;
        }
        return array;
    }
    
    public final LList getRestArgsList(int i) {
        LList empty = LList.Empty;
        Pair pair = null;
        while (i < this.count) {
            final Pair cdr = new Pair(this.getArgAsObject(i), empty);
            if (pair == null) {
                empty = cdr;
            }
            else {
                pair.setCdr(cdr);
            }
            ++i;
            pair = cdr;
        }
        return empty;
    }
    
    public void lastArg() {
        if (this.next < this.count) {
            throw new WrongArguments(null, this.count);
        }
        this.values = null;
    }
    
    public void runUntilDone() throws Throwable {
        while (true) {
            final Procedure proc = this.proc;
            if (proc == null) {
                break;
            }
            this.proc = null;
            proc.apply(this);
        }
    }
    
    public final Object runUntilValue() throws Throwable {
        final Consumer consumer = this.consumer;
        final ValueStack vstack = this.vstack;
        this.consumer = vstack;
        final int gapStart = vstack.gapStart;
        final int oindex = vstack.oindex;
        try {
            this.runUntilDone();
            return Values.make(vstack, gapStart, vstack.gapStart);
        }
        finally {
            this.consumer = consumer;
            vstack.gapStart = gapStart;
            vstack.oindex = oindex;
        }
    }
    
    public final void runUntilValue(final Consumer consumer) throws Throwable {
        final Consumer consumer2 = this.consumer;
        this.consumer = consumer;
        try {
            this.runUntilDone();
        }
        finally {
            this.consumer = consumer2;
        }
    }
    
    public final int startFromContext() {
        final ValueStack vstack = this.vstack;
        final int find = vstack.find(this.consumer);
        vstack.ensureSpace(3);
        final int gapStart = vstack.gapStart;
        final char[] data = vstack.data;
        final int n = gapStart + 1;
        data[gapStart] = 61698;
        vstack.setIntN(n, find);
        final int gapStart2 = n + 2;
        this.consumer = vstack;
        return vstack.gapStart = gapStart2;
    }
    
    public void writeValue(final Object o) {
        Values.writeValues(o, this.consumer);
    }
}
