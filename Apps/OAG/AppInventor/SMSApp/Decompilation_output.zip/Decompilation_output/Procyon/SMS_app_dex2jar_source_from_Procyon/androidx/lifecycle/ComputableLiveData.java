// 
// Decompiled by Procyon v0.5.36
// 

package androidx.lifecycle;

import androidx.annotation.MainThread;
import androidx.annotation.WorkerThread;
import androidx.annotation.NonNull;
import androidx.arch.core.executor.ArchTaskExecutor;
import androidx.annotation.VisibleForTesting;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;
import androidx.annotation.RestrictTo;

@RestrictTo({ RestrictTo.Scope.LIBRARY_GROUP })
public abstract class ComputableLiveData<T>
{
    final AtomicBoolean mComputing;
    final Executor mExecutor;
    final AtomicBoolean mInvalid;
    @VisibleForTesting
    final Runnable mInvalidationRunnable;
    final LiveData<T> mLiveData;
    @VisibleForTesting
    final Runnable mRefreshRunnable;
    
    public ComputableLiveData() {
        this(ArchTaskExecutor.getIOThreadExecutor());
    }
    
    public ComputableLiveData(@NonNull final Executor mExecutor) {
        this.mInvalid = new AtomicBoolean(true);
        this.mComputing = new AtomicBoolean(false);
        this.mRefreshRunnable = new Runnable() {
            @WorkerThread
            @Override
            public void run() {
                while (true) {
                    int n = 0;
                    final int n2 = 0;
                    Label_0077: {
                        if (!ComputableLiveData.this.mComputing.compareAndSet(false, true)) {
                            break Label_0077;
                        }
                        T compute = null;
                        n = n2;
                        try {
                            while (ComputableLiveData.this.mInvalid.compareAndSet(true, false)) {
                                n = 1;
                                compute = ComputableLiveData.this.compute();
                            }
                            if (n != 0) {
                                ComputableLiveData.this.mLiveData.postValue(compute);
                            }
                            ComputableLiveData.this.mComputing.set(false);
                            if (n == 0 || !ComputableLiveData.this.mInvalid.get()) {
                                return;
                            }
                            continue;
                        }
                        finally {
                            ComputableLiveData.this.mComputing.set(false);
                        }
                    }
                }
            }
        };
        this.mInvalidationRunnable = new Runnable() {
            @MainThread
            @Override
            public void run() {
                final boolean hasActiveObservers = ComputableLiveData.this.mLiveData.hasActiveObservers();
                if (ComputableLiveData.this.mInvalid.compareAndSet(false, true) && hasActiveObservers) {
                    ComputableLiveData.this.mExecutor.execute(ComputableLiveData.this.mRefreshRunnable);
                }
            }
        };
        this.mExecutor = mExecutor;
        this.mLiveData = new LiveData<T>() {
            @Override
            protected void onActive() {
                ComputableLiveData.this.mExecutor.execute(ComputableLiveData.this.mRefreshRunnable);
            }
        };
    }
    
    @WorkerThread
    protected abstract T compute();
    
    @NonNull
    public LiveData<T> getLiveData() {
        return this.mLiveData;
    }
    
    public void invalidate() {
        ArchTaskExecutor.getInstance().executeOnMainThread(this.mInvalidationRunnable);
    }
}
