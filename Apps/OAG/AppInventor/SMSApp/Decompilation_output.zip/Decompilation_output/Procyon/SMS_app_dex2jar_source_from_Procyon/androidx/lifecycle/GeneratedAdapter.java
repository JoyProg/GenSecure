// 
// Decompiled by Procyon v0.5.36
// 

package androidx.lifecycle;

import androidx.annotation.RestrictTo;

@RestrictTo({ RestrictTo.Scope.LIBRARY_GROUP })
public interface GeneratedAdapter
{
    void callMethods(final LifecycleOwner p0, final Lifecycle.Event p1, final boolean p2, final MethodCallsLogger p3);
}
