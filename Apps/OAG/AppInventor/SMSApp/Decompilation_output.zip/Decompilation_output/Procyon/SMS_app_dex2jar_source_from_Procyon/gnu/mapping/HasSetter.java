// 
// Decompiled by Procyon v0.5.36
// 

package gnu.mapping;

public interface HasSetter
{
    Procedure getSetter();
}
