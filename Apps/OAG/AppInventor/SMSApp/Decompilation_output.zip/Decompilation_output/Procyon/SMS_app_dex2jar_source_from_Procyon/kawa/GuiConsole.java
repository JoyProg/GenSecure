// 
// Decompiled by Procyon v0.5.36
// 

package kawa;

import java.awt.Component;
import javax.swing.JScrollPane;
import java.awt.LayoutManager;
import java.awt.BorderLayout;
import gnu.mapping.OutPort;
import java.awt.event.ActionEvent;
import java.awt.event.WindowListener;
import java.awt.MenuItem;
import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;
import gnu.mapping.Environment;
import gnu.expr.Language;
import java.awt.event.ActionListener;
import javax.swing.JFrame;

public class GuiConsole extends JFrame implements ActionListener, DocumentCloseListener
{
    private static String CLOSE;
    private static String EXIT;
    private static String NEW;
    private static String NEW_SHARED;
    private static String PURGE_MESSAGE;
    static int window_number;
    ReplDocument document;
    ReplPane pane;
    
    static {
        GuiConsole.CLOSE = "Close";
        GuiConsole.EXIT = "Exit";
        GuiConsole.NEW = "New";
        GuiConsole.NEW_SHARED = "New (Shared)";
        GuiConsole.PURGE_MESSAGE = "Purge Buffer";
        GuiConsole.window_number = 0;
    }
    
    public GuiConsole() {
        this(Language.getDefaultLanguage(), Environment.getCurrent(), false);
    }
    
    public GuiConsole(final Language language, final Environment environment, final boolean b) {
        super("Kawa");
        repl.getLanguage();
        this.init(new ReplDocument(language, environment, b));
    }
    
    public GuiConsole(final ReplDocument replDocument) {
        super("Kawa");
        this.init(replDocument);
    }
    
    public static void main(final String[] array) {
        repl.noConsole = false;
        final int processArgs = repl.processArgs(array, 0, array.length);
        repl.getLanguage();
        repl.setArgs(array, processArgs);
        repl.checkInitFile();
        new GuiConsole();
    }
    
    private void setupMenus() {
        final WindowAdapter l = new WindowAdapter() {
            @Override
            public void windowClosing(final WindowEvent windowEvent) {
                GuiConsole.this.close();
            }
        };
        final MenuBar menuBar = new MenuBar();
        final Menu m = new Menu("File");
        final Menu i = new Menu("Utilities");
        menuBar.add(m);
        menuBar.add(i);
        final MenuItem mi = new MenuItem(GuiConsole.NEW);
        mi.addActionListener(this);
        m.add(mi);
        final MenuItem mi2 = new MenuItem(GuiConsole.NEW_SHARED);
        mi2.addActionListener(this);
        m.add(mi2);
        final MenuItem mi3 = new MenuItem(GuiConsole.CLOSE);
        mi3.addActionListener(this);
        m.add(mi3);
        final MenuItem mi4 = new MenuItem(GuiConsole.EXIT);
        mi4.addActionListener(this);
        this.addWindowListener(l);
        m.add(mi4);
        final MenuItem mi5 = new MenuItem(GuiConsole.PURGE_MESSAGE);
        mi5.addActionListener(this);
        i.add(mi5);
        this.setMenuBar(menuBar);
    }
    
    @Override
    public void actionPerformed(final ActionEvent actionEvent) {
        final String actionCommand = actionEvent.getActionCommand();
        if (actionCommand.equals(GuiConsole.NEW)) {
            new GuiConsole(this.document.language, Environment.getGlobal(), false);
        }
        else if (actionCommand.equals(GuiConsole.NEW_SHARED)) {
            new GuiConsole(this.document.language, this.document.environment, true);
        }
        else if (actionCommand.equals(GuiConsole.EXIT)) {
            System.exit(0);
        }
        else if (actionCommand.equals(GuiConsole.CLOSE)) {
            this.close();
        }
        else if (actionCommand.equals(GuiConsole.PURGE_MESSAGE)) {
            this.pane.document.deleteOldText();
        }
        else {
            OutPort.outDefault().println("Unknown menu action: " + actionCommand);
        }
    }
    
    void close() {
        this.document.removeDocumentCloseListener((ReplDocument.DocumentCloseListener)this);
        this.dispose();
    }
    
    @Override
    public void closed(final ReplDocument replDocument) {
        this.close();
    }
    
    void init(final ReplDocument document) {
        (this.document = document).addDocumentCloseListener((ReplDocument.DocumentCloseListener)this);
        this.pane = new ReplPane(this.document);
        ++GuiConsole.window_number;
        this.setLayout(new BorderLayout(0, 0));
        this.add("Center", new JScrollPane(this.pane));
        this.setupMenus();
        this.setLocation(GuiConsole.window_number * 100, GuiConsole.window_number * 50);
        this.setSize(700, 500);
        this.setVisible(true);
    }
}
