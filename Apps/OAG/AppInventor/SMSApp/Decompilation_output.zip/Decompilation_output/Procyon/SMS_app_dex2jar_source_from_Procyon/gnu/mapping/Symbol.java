// 
// Decompiled by Procyon v0.5.36
// 

package gnu.mapping;

import java.io.ObjectOutput;
import java.io.ObjectStreamException;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.Externalizable;

public class Symbol implements EnvironmentKey, Comparable, Externalizable
{
    public static final Symbol FUNCTION;
    public static final Symbol PLIST;
    protected String name;
    Namespace namespace;
    
    static {
        FUNCTION = makeUninterned("(function)");
        PLIST = makeUninterned("(property-list)");
    }
    
    public Symbol() {
    }
    
    public Symbol(final Namespace namespace, final String name) {
        this.name = name;
        this.namespace = namespace;
    }
    
    public static boolean equals(final Symbol symbol, final Symbol symbol2) {
        boolean b = true;
        if (symbol != symbol2) {
            if (symbol == null || symbol2 == null) {
                b = false;
            }
            else {
                if (symbol.name == symbol2.name) {
                    final Namespace namespace = symbol.namespace;
                    final Namespace namespace2 = symbol2.namespace;
                    if (namespace != null && namespace2 != null) {
                        if (namespace.name != namespace2.name) {
                            b = false;
                            return b;
                        }
                        return b;
                    }
                }
                b = false;
            }
        }
        return b;
    }
    
    public static Symbol make(final Object o, final String s) {
        Namespace value;
        if (o instanceof String) {
            value = Namespace.valueOf((String)o);
        }
        else {
            value = (Namespace)o;
        }
        Symbol symbol;
        if (value == null || s == null) {
            symbol = makeUninterned(s);
        }
        else {
            symbol = value.getSymbol(s.intern());
        }
        return symbol;
    }
    
    public static Symbol make(final String s, final String s2, final String s3) {
        return Namespace.valueOf(s, s3).getSymbol(s2.intern());
    }
    
    public static Symbol makeUninterned(final String s) {
        return new Symbol(null, s);
    }
    
    public static Symbol makeWithUnknownNamespace(final String s, final String s2) {
        return Namespace.makeUnknownNamespace(s2).getSymbol(s.intern());
    }
    
    public static Symbol parse(final String s) {
        final int length = s.length();
        int n = -1;
        final int n2 = -1;
        int n3 = 0;
        final int n4 = 0;
        int n5 = 0;
        int index = 0;
        while (true) {
            int n8 = 0;
            int n10 = 0;
            Block_13: {
                Block_10: {
                    int n6;
                    int n7;
                    int endIndex;
                    while (true) {
                        n6 = n;
                        n7 = n4;
                        n8 = n5;
                        endIndex = n2;
                        if (index >= length) {
                            break;
                        }
                        final char char1 = s.charAt(index);
                        if (char1 == ':' && n3 == 0) {
                            n8 = index;
                            n7 = index + 1;
                            endIndex = n2;
                            n6 = n;
                            break;
                        }
                        int n9 = n3;
                        n10 = n;
                        n8 = n5;
                        if (char1 == '{') {
                            n10 = n;
                            n8 = n5;
                            if (n < 0) {
                                n8 = index;
                                n10 = index;
                            }
                            n9 = n3 + 1;
                        }
                        n3 = n9;
                        if (char1 == '}') {
                            final int n11 = n9 - 1;
                            if (n11 == 0) {
                                break Block_10;
                            }
                            if ((n3 = n11) < 0) {
                                break Block_13;
                            }
                        }
                        ++index;
                        n = n10;
                        n5 = n8;
                    }
                    Symbol symbol;
                    if (n6 >= 0 && endIndex > 0) {
                        final String substring = s.substring(n6 + 1, endIndex);
                        String substring2;
                        if (n8 > 0) {
                            substring2 = s.substring(0, n8);
                        }
                        else {
                            substring2 = null;
                        }
                        symbol = valueOf(s.substring(n7), substring, substring2);
                    }
                    else if (n8 > 0) {
                        symbol = makeWithUnknownNamespace(s.substring(n7), s.substring(0, n8));
                    }
                    else {
                        symbol = valueOf(s);
                    }
                    return symbol;
                }
                int endIndex = index;
                if (index < length && s.charAt(index + 1) == ':') {
                    index += 2;
                }
                else {
                    ++index;
                }
                int n6 = n10;
                int n7 = index;
                continue;
            }
            final int n12 = n8;
            int n6 = n10;
            int n7 = n12;
            int endIndex = n2;
            continue;
        }
    }
    
    public static SimpleSymbol valueOf(final String s) {
        return (SimpleSymbol)Namespace.EmptyNamespace.getSymbol(s.intern());
    }
    
    public static Symbol valueOf(final String s, final Object o) {
        Symbol symbol;
        if (o == null || o == Boolean.FALSE) {
            symbol = makeUninterned(s);
        }
        else {
            Namespace namespace;
            if (o instanceof Namespace) {
                namespace = (Namespace)o;
            }
            else if (o == Boolean.TRUE) {
                namespace = Namespace.EmptyNamespace;
            }
            else {
                namespace = Namespace.valueOf(((CharSequence)o).toString());
            }
            symbol = namespace.getSymbol(s.intern());
        }
        return symbol;
    }
    
    public static Symbol valueOf(final String s, final String s2, final String s3) {
        return Namespace.valueOf(s2, s3).getSymbol(s.intern());
    }
    
    @Override
    public int compareTo(final Object o) {
        final Symbol symbol = (Symbol)o;
        if (this.getNamespaceURI() != symbol.getNamespaceURI()) {
            throw new IllegalArgumentException("comparing Symbols in different namespaces");
        }
        return this.getLocalName().compareTo(symbol.getLocalName());
    }
    
    @Override
    public final boolean equals(final Object o) {
        return o instanceof Symbol && equals(this, (Symbol)o);
    }
    
    @Override
    public final Object getKeyProperty() {
        return null;
    }
    
    @Override
    public final Symbol getKeySymbol() {
        return this;
    }
    
    public final String getLocalName() {
        return this.name;
    }
    
    public final String getLocalPart() {
        return this.name;
    }
    
    public final String getName() {
        return this.name;
    }
    
    public final Namespace getNamespace() {
        return this.namespace;
    }
    
    public final String getNamespaceURI() {
        final Namespace namespace = this.getNamespace();
        String name;
        if (namespace == null) {
            name = null;
        }
        else {
            name = namespace.getName();
        }
        return name;
    }
    
    public final String getPrefix() {
        final Namespace namespace = this.namespace;
        String prefix;
        if (namespace == null) {
            prefix = "";
        }
        else {
            prefix = namespace.prefix;
        }
        return prefix;
    }
    
    public final boolean hasEmptyNamespace() {
        final Namespace namespace = this.getNamespace();
        if (namespace != null) {
            final String name = namespace.getName();
            if (name != null && name.length() != 0) {
                return false;
            }
        }
        return true;
    }
    
    @Override
    public int hashCode() {
        int hashCode;
        if (this.name == null) {
            hashCode = 0;
        }
        else {
            hashCode = this.name.hashCode();
        }
        return hashCode;
    }
    
    @Override
    public boolean matches(final EnvironmentKey environmentKey) {
        return equals(environmentKey.getKeySymbol(), this) && environmentKey.getKeyProperty() == null;
    }
    
    @Override
    public boolean matches(final Symbol symbol, final Object o) {
        return equals(symbol, this) && o == null;
    }
    
    @Override
    public void readExternal(final ObjectInput objectInput) throws IOException, ClassNotFoundException {
        this.namespace = (Namespace)objectInput.readObject();
        this.name = (String)objectInput.readObject();
    }
    
    public Object readResolve() throws ObjectStreamException {
        Symbol make;
        if (this.namespace == null) {
            make = this;
        }
        else {
            make = make(this.namespace, this.getName());
        }
        return make;
    }
    
    public final void setNamespace(final Namespace namespace) {
        this.namespace = namespace;
    }
    
    @Override
    public String toString() {
        return this.toString('P');
    }
    
    public String toString(final char c) {
        boolean b = true;
        final String namespaceURI = this.getNamespaceURI();
        final String prefix = this.getPrefix();
        boolean b2;
        if (namespaceURI != null && namespaceURI.length() > 0) {
            b2 = true;
        }
        else {
            b2 = false;
        }
        if (prefix == null || prefix.length() <= 0) {
            b = false;
        }
        final String name = this.getName();
        if (!b2) {
            final String string = name;
            if (!b) {
                return string;
            }
        }
        final StringBuilder sb = new StringBuilder();
        if (b && (c != 'U' || !b2)) {
            sb.append(prefix);
        }
        if (b2 && (c != 'P' || !b)) {
            sb.append('{');
            sb.append(this.getNamespaceURI());
            sb.append('}');
        }
        sb.append(':');
        sb.append(name);
        return sb.toString();
    }
    
    @Override
    public void writeExternal(final ObjectOutput objectOutput) throws IOException {
        objectOutput.writeObject(this.getNamespace());
        objectOutput.writeObject(this.getName());
    }
}
