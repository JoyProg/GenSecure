// 
// Decompiled by Procyon v0.5.36
// 

package gnu.mapping;

import java.util.Map;

public abstract class NamedLocation extends IndirectableLocation implements Entry, EnvironmentKey
{
    final Symbol name;
    NamedLocation next;
    final Object property;
    
    public NamedLocation(final NamedLocation namedLocation) {
        this.name = namedLocation.name;
        this.property = namedLocation.property;
    }
    
    public NamedLocation(final Symbol name, final Object property) {
        this.name = name;
        this.property = property;
    }
    
    @Override
    public boolean entered() {
        return this.next != null;
    }
    
    @Override
    public boolean equals(Object value) {
        final boolean b = false;
        boolean equals;
        if (!(value instanceof NamedLocation)) {
            equals = b;
        }
        else {
            final NamedLocation namedLocation = (NamedLocation)value;
            if (this.name == null) {
                equals = b;
                if (namedLocation.name != null) {
                    return equals;
                }
            }
            else if (!this.name.equals(namedLocation.name)) {
                equals = b;
                return equals;
            }
            equals = b;
            if (this.property == namedLocation.property) {
                value = this.getValue();
                final Object value2 = namedLocation.getValue();
                if (value == value2) {
                    equals = true;
                }
                else {
                    equals = b;
                    if (value != null) {
                        equals = b;
                        if (value2 != null) {
                            equals = value.equals(value2);
                        }
                    }
                }
            }
        }
        return equals;
    }
    
    @Override
    public Environment getEnvironment() {
        for (NamedLocation next = this; next != null; next = next.next) {
            if (next.name == null) {
                final Environment environment = (Environment)next.value;
                if (environment != null) {
                    return environment;
                }
            }
        }
        return super.getEnvironment();
    }
    
    @Override
    public final Object getKey() {
        EnvironmentKey name = this;
        if (this.property == null) {
            name = this.name;
        }
        return name;
    }
    
    @Override
    public final Object getKeyProperty() {
        return this.property;
    }
    
    @Override
    public final Symbol getKeySymbol() {
        return this.name;
    }
    
    @Override
    public int hashCode() {
        final int n = this.name.hashCode() ^ System.identityHashCode(this.property);
        final Object value = this.getValue();
        int n2 = n;
        if (value != null) {
            n2 = (n ^ value.hashCode());
        }
        return n2;
    }
    
    @Override
    public final boolean matches(final EnvironmentKey environmentKey) {
        return Symbol.equals(environmentKey.getKeySymbol(), this.name) && environmentKey.getKeyProperty() == this.property;
    }
    
    @Override
    public final boolean matches(final Symbol symbol, final Object o) {
        return Symbol.equals(symbol, this.name) && o == this.property;
    }
    
    @Override
    public void setRestore(final Object restore) {
        while (true) {
            Label_0051: {
                synchronized (this) {
                    if (this.value == NamedLocation.INDIRECT_FLUIDS) {
                        this.base.setRestore(restore);
                    }
                    else {
                        if (!(restore instanceof Location)) {
                            break Label_0051;
                        }
                        this.value = null;
                        this.base = (Location)restore;
                    }
                    return;
                }
            }
            final Throwable value;
            this.value = value;
            this.base = null;
        }
    }
    
    @Override
    public Object setWithSave(Object o) {
        synchronized (this) {
            if (this.value == NamedLocation.INDIRECT_FLUIDS) {
                o = this.base.setWithSave(o);
            }
            else {
                final ThreadLocation anonymous = ThreadLocation.makeAnonymous(this.name);
                anonymous.global.base = this.base;
                anonymous.global.value = this.value;
                this.setAlias(anonymous);
                final NamedLocation location = anonymous.getLocation();
                location.value = o;
                location.base = null;
                o = anonymous.global;
            }
            return o;
        }
    }
}
