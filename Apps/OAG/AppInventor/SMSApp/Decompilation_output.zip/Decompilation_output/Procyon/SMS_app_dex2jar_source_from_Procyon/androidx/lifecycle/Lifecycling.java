// 
// Decompiled by Procyon v0.5.36
// 

package androidx.lifecycle;

import java.util.Collection;
import java.util.ArrayList;
import java.util.Collections;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.lang.reflect.Constructor;
import java.util.List;
import java.util.Map;
import androidx.annotation.RestrictTo;

@RestrictTo({ RestrictTo.Scope.LIBRARY_GROUP })
public class Lifecycling
{
    private static final int GENERATED_CALLBACK = 2;
    private static final int REFLECTIVE_CALLBACK = 1;
    private static Map<Class, Integer> sCallbackCache;
    private static Map<Class, List<Constructor<? extends GeneratedAdapter>>> sClassToAdapters;
    
    static {
        Lifecycling.sCallbackCache = new HashMap<Class, Integer>();
        Lifecycling.sClassToAdapters = new HashMap<Class, List<Constructor<? extends GeneratedAdapter>>>();
    }
    
    private Lifecycling() {
    }
    
    private static GeneratedAdapter createGeneratedAdapter(final Constructor<? extends GeneratedAdapter> constructor, final Object o) {
        try {
            return (GeneratedAdapter)constructor.newInstance(o);
        }
        catch (IllegalAccessException cause) {
            throw new RuntimeException(cause);
        }
        catch (InstantiationException cause2) {
            throw new RuntimeException(cause2);
        }
        catch (InvocationTargetException cause3) {
            throw new RuntimeException(cause3);
        }
    }
    
    @Nullable
    private static Constructor<? extends GeneratedAdapter> generatedConstructor(final Class<?> clazz) {
        try {
            final Package package1 = clazz.getPackage();
            String s = clazz.getCanonicalName();
            String name;
            if (package1 != null) {
                name = package1.getName();
            }
            else {
                name = "";
            }
            if (!name.isEmpty()) {
                s = s.substring(name.length() + 1);
            }
            final String adapterName = getAdapterName(s);
            String string;
            if (name.isEmpty()) {
                string = adapterName;
            }
            else {
                string = name + "." + adapterName;
            }
            Constructor<?> declaredConstructor;
            final Constructor<?> constructor = declaredConstructor = Class.forName(string).getDeclaredConstructor(clazz);
            if (!constructor.isAccessible()) {
                constructor.setAccessible(true);
                declaredConstructor = constructor;
            }
            return (Constructor<? extends GeneratedAdapter>)declaredConstructor;
        }
        catch (ClassNotFoundException ex) {
            final Constructor<?> declaredConstructor = null;
            return (Constructor<? extends GeneratedAdapter>)declaredConstructor;
        }
        catch (NoSuchMethodException cause) {
            throw new RuntimeException(cause);
        }
    }
    
    public static String getAdapterName(final String s) {
        return s.replace(".", "_") + "_LifecycleAdapter";
    }
    
    @NonNull
    static GenericLifecycleObserver getCallback(final Object o) {
        GenericLifecycleObserver genericLifecycleObserver;
        if (o instanceof FullLifecycleObserver) {
            genericLifecycleObserver = new FullLifecycleObserverAdapter((FullLifecycleObserver)o);
        }
        else if (o instanceof GenericLifecycleObserver) {
            genericLifecycleObserver = (GenericLifecycleObserver)o;
        }
        else {
            final Class<?> class1 = o.getClass();
            if (getObserverConstructorType(class1) == 2) {
                final List<Constructor<? extends GeneratedAdapter>> list = Lifecycling.sClassToAdapters.get(class1);
                if (list.size() == 1) {
                    genericLifecycleObserver = new SingleGeneratedAdapterObserver(createGeneratedAdapter(list.get(0), o));
                }
                else {
                    final GeneratedAdapter[] array = new GeneratedAdapter[list.size()];
                    for (int i = 0; i < list.size(); ++i) {
                        array[i] = createGeneratedAdapter(list.get(i), o);
                    }
                    genericLifecycleObserver = new CompositeGeneratedAdaptersObserver(array);
                }
            }
            else {
                genericLifecycleObserver = new ReflectiveGenericLifecycleObserver(o);
            }
        }
        return genericLifecycleObserver;
    }
    
    private static int getObserverConstructorType(final Class<?> clazz) {
        int i;
        if (Lifecycling.sCallbackCache.containsKey(clazz)) {
            i = Lifecycling.sCallbackCache.get(clazz);
        }
        else {
            i = resolveObserverCallbackType(clazz);
            Lifecycling.sCallbackCache.put(clazz, i);
        }
        return i;
    }
    
    private static boolean isLifecycleParent(final Class<?> clazz) {
        return clazz != null && LifecycleObserver.class.isAssignableFrom(clazz);
    }
    
    private static int resolveObserverCallbackType(final Class<?> clazz) {
        int n;
        if (clazz.getCanonicalName() == null) {
            n = 1;
        }
        else {
            final Constructor<? extends GeneratedAdapter> generatedConstructor = generatedConstructor(clazz);
            if (generatedConstructor != null) {
                Lifecycling.sClassToAdapters.put(clazz, Collections.singletonList(generatedConstructor));
                n = 2;
            }
            else if (ClassesInfoCache.sInstance.hasLifecycleMethods(clazz)) {
                n = 1;
            }
            else {
                final Class<?> superclass = clazz.getSuperclass();
                List<Constructor<? extends GeneratedAdapter>> list = null;
                if (isLifecycleParent(superclass)) {
                    if (getObserverConstructorType(superclass) == 1) {
                        n = 1;
                        return n;
                    }
                    list = new ArrayList<Constructor<? extends GeneratedAdapter>>(Lifecycling.sClassToAdapters.get(superclass));
                }
                for (final Class<?> clazz2 : clazz.getInterfaces()) {
                    if (isLifecycleParent(clazz2)) {
                        if (getObserverConstructorType(clazz2) == 1) {
                            n = 1;
                            return n;
                        }
                        List<Constructor<? extends GeneratedAdapter>> list2;
                        if ((list2 = list) == null) {
                            list2 = new ArrayList<Constructor<? extends GeneratedAdapter>>();
                        }
                        list2.addAll(Lifecycling.sClassToAdapters.get(clazz2));
                        list = list2;
                    }
                }
                if (list != null) {
                    Lifecycling.sClassToAdapters.put(clazz, list);
                    n = 2;
                }
                else {
                    n = 1;
                }
            }
        }
        return n;
    }
}
