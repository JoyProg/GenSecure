// 
// Decompiled by Procyon v0.5.36
// 

package gnu.mapping;

import java.io.ObjectOutput;
import java.io.ObjectStreamException;
import java.io.IOException;
import java.io.ObjectInput;
import java.util.Hashtable;
import java.io.Externalizable;

public class Namespace implements Externalizable, HasNamedParts
{
    public static final Namespace EmptyNamespace;
    protected static final Hashtable nsTable;
    int log2Size;
    private int mask;
    String name;
    int num_bindings;
    protected String prefix;
    protected SymbolRef[] table;
    
    static {
        nsTable = new Hashtable(50);
        EmptyNamespace = valueOf("");
    }
    
    protected Namespace() {
        this(64);
    }
    
    protected Namespace(int i) {
        this.prefix = "";
        this.log2Size = 4;
        while (i > 1 << this.log2Size) {
            ++this.log2Size;
        }
        i = 1 << this.log2Size;
        this.table = new SymbolRef[i];
        this.mask = i - 1;
    }
    
    public static Namespace create() {
        return new Namespace(64);
    }
    
    public static Namespace create(final int n) {
        return new Namespace(n);
    }
    
    public static Namespace getDefault() {
        return Namespace.EmptyNamespace;
    }
    
    public static Symbol getDefaultSymbol(final String s) {
        return Namespace.EmptyNamespace.getSymbol(s);
    }
    
    public static Namespace makeUnknownNamespace(final String str) {
        String string;
        if (str == null || str == "") {
            string = "";
        }
        else {
            string = "http://kawa.gnu.org/unknown-namespace/" + str;
        }
        return valueOf(string, str);
    }
    
    public static Namespace valueOf() {
        return Namespace.EmptyNamespace;
    }
    
    public static Namespace valueOf(final String s) {
        String s2 = s;
        if (s == null) {
            s2 = "";
        }
        synchronized (Namespace.nsTable) {
            Namespace value = Namespace.nsTable.get(s2);
            if (value == null) {
                value = new Namespace();
                value.setName(s2.intern());
                Namespace.nsTable.put(s2, value);
            }
            // monitorexit(Namespace.nsTable)
            return value;
        }
    }
    
    public static Namespace valueOf(final String s, final SimpleSymbol simpleSymbol) {
        String name;
        if (simpleSymbol == null) {
            name = null;
        }
        else {
            name = simpleSymbol.getName();
        }
        return valueOf(s, name);
    }
    
    public static Namespace valueOf(final String str, final String str2) {
        Object value = null;
        if (str2 == null || str2.length() == 0) {
            value = valueOf(str);
        }
        else {
            final String string = str2 + " -> " + str;
            synchronized (Namespace.nsTable) {
                final Object value2 = Namespace.nsTable.get(string);
                if (value2 instanceof Namespace) {
                    final Namespace namespace = (Namespace)value2;
                    return (Namespace)value;
                }
            }
            final Namespace value3 = new Namespace();
            value3.setName(((String)value).intern());
            value3.prefix = str2.intern();
            Namespace.nsTable.put(string, value3);
            // monitorexit(hashtable)
            value = value3;
        }
        return (Namespace)value;
    }
    
    public Symbol add(final Symbol symbol, int n) {
        n &= this.mask;
        final SymbolRef symbolRef = new SymbolRef(symbol, this);
        symbol.namespace = this;
        symbolRef.next = this.table[n];
        this.table[n] = symbolRef;
        ++this.num_bindings;
        if (this.num_bindings >= this.table.length) {
            this.rehash();
        }
        return symbol;
    }
    
    @Override
    public Object get(final String s) {
        return Environment.getCurrent().get(this.getSymbol(s));
    }
    
    public final String getName() {
        return this.name;
    }
    
    public final String getPrefix() {
        return this.prefix;
    }
    
    public Symbol getSymbol(final String s) {
        return this.lookup(s, s.hashCode(), true);
    }
    
    @Override
    public boolean isConstant(final String s) {
        return false;
    }
    
    public Symbol lookup(final String s) {
        return this.lookup(s, s.hashCode(), false);
    }
    
    public Symbol lookup(final String s, final int n, final boolean b) {
        while (true) {
            Label_0077: {
                while (true) {
                    Label_0064: {
                        synchronized (this) {
                            final Symbol lookupInternal = this.lookupInternal(s, n);
                            Symbol add;
                            if (lookupInternal != null) {
                                // monitorexit(this)
                                add = lookupInternal;
                            }
                            else {
                                if (!b) {
                                    break Label_0077;
                                }
                                if (this != Namespace.EmptyNamespace) {
                                    break Label_0064;
                                }
                                final Symbol symbol = new SimpleSymbol(s);
                                add = this.add(symbol, n);
                            }
                            return add;
                        }
                    }
                    final String s2;
                    final Symbol symbol = new Symbol(this, s2);
                    continue;
                }
            }
            // monitorexit(this)
            return null;
        }
    }
    
    protected final Symbol lookupInternal(final String anObject, int n) {
        n &= this.mask;
        SymbolRef symbolRef = null;
        SymbolRef next;
        for (SymbolRef symbolRef2 = this.table[n]; symbolRef2 != null; symbolRef2 = next) {
            next = symbolRef2.next;
            final Symbol symbol = symbolRef2.getSymbol();
            if (symbol == null) {
                if (symbolRef == null) {
                    this.table[n] = next;
                }
                else {
                    symbolRef.next = next;
                }
                --this.num_bindings;
            }
            else {
                if (symbol.getLocalPart().equals(anObject)) {
                    return symbol;
                }
                symbolRef = symbolRef2;
            }
        }
        return null;
    }
    
    @Override
    public void readExternal(final ObjectInput objectInput) throws IOException, ClassNotFoundException {
        this.name = ((String)objectInput.readObject()).intern();
        this.prefix = (String)objectInput.readObject();
    }
    
    public Object readResolve() throws ObjectStreamException {
        String key = this.getName();
        if (key == null) {
            return this;
        }
        if (this.prefix != null && this.prefix.length() != 0) {
            key = this.prefix + " -> " + key;
        }
        final Namespace namespace = Namespace.nsTable.get(key);
        if (namespace == null) {
            Namespace.nsTable.put(key, this);
            return this;
        }
        return namespace;
        namespace2 = this;
        return namespace2;
    }
    
    protected void rehash() {
        int length = this.table.length;
        final int n = length * 2;
        final int mask = n - 1;
        int num_bindings = 0;
        final SymbolRef[] table = this.table;
        final SymbolRef[] table2 = new SymbolRef[n];
        while (true) {
            final int n2 = length - 1;
            if (n2 < 0) {
                break;
            }
            SymbolRef symbolRef = table[n2];
            int n3 = num_bindings;
            while (true) {
                num_bindings = n3;
                length = n2;
                if (symbolRef == null) {
                    break;
                }
                final SymbolRef next = symbolRef.next;
                final Symbol symbol = symbolRef.getSymbol();
                int n4 = n3;
                if (symbol != null) {
                    final int n5 = symbol.getName().hashCode() & mask;
                    n4 = n3 + 1;
                    symbolRef.next = table2[n5];
                    table2[n5] = symbolRef;
                }
                symbolRef = next;
                n3 = n4;
            }
        }
        this.table = table2;
        ++this.log2Size;
        this.mask = mask;
        this.num_bindings = num_bindings;
    }
    
    public boolean remove(final Symbol symbol) {
        while (true) {
        Label_0114:
            while (true) {
                final SymbolRef next;
                Label_0107: {
                    final SymbolRef symbolRef2;
                    synchronized (this) {
                        final int n = symbol.getLocalPart().hashCode() & this.mask;
                        final SymbolRef symbolRef = null;
                        symbolRef2 = this.table[n];
                        if (symbolRef2 == null) {
                            break Label_0114;
                        }
                        next = symbolRef2.next;
                        final Symbol symbol2 = symbolRef2.getSymbol();
                        if (symbol2 == null || symbol2 == symbol) {
                            if (symbolRef == null) {
                                this.table[n] = next;
                            }
                            else {
                                symbolRef.next = next;
                            }
                            --this.num_bindings;
                            if (symbol2 != null) {
                                return true;
                            }
                            break Label_0107;
                        }
                    }
                    final SymbolRef symbolRef = symbolRef2;
                }
                SymbolRef symbolRef2 = next;
                continue;
            }
            // monitorexit(this)
            return false;
        }
    }
    
    public final void setName(final String name) {
        this.name = name;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("#,(namespace \"");
        sb.append(this.name);
        sb.append('\"');
        if (this.prefix != null && this.prefix != "") {
            sb.append(' ');
            sb.append(this.prefix);
        }
        sb.append(')');
        return sb.toString();
    }
    
    @Override
    public void writeExternal(final ObjectOutput objectOutput) throws IOException {
        objectOutput.writeObject(this.getName());
        objectOutput.writeObject(this.prefix);
    }
}
