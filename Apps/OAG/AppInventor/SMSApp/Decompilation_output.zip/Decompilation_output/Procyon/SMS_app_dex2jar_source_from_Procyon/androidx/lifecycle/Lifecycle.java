// 
// Decompiled by Procyon v0.5.36
// 

package androidx.lifecycle;

import androidx.annotation.MainThread;
import androidx.annotation.NonNull;

public abstract class Lifecycle
{
    @MainThread
    public abstract void addObserver(@NonNull final LifecycleObserver p0);
    
    @MainThread
    @NonNull
    public abstract State getCurrentState();
    
    @MainThread
    public abstract void removeObserver(@NonNull final LifecycleObserver p0);
    
    public enum Event
    {
        ON_ANY, 
        ON_CREATE, 
        ON_DESTROY, 
        ON_PAUSE, 
        ON_RESUME, 
        ON_START, 
        ON_STOP;
    }
    
    public enum State
    {
        CREATED, 
        DESTROYED, 
        INITIALIZED, 
        RESUMED, 
        STARTED;
        
        public boolean isAtLeast(@NonNull final State o) {
            return this.compareTo(o) >= 0;
        }
    }
}
