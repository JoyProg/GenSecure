// 
// Decompiled by Procyon v0.5.36
// 

package gnu.mapping;

import gnu.lists.LList;
import gnu.lists.Pair;

public class PropertyLocation extends Location
{
    Pair pair;
    
    public static Object getProperty(final Object o, final Object o2, final Object o3) {
        return getProperty(o, o2, o3, Environment.getCurrent());
    }
    
    public static Object getProperty(Object o, final Object o2, final Object o3, final Environment environment) {
        Object defaultSymbol = o;
        if (!(o instanceof Symbol)) {
            if (!(o instanceof String)) {
                o = plistGet(environment.get(Symbol.PLIST, o, LList.Empty), o2, o3);
                return o;
            }
            defaultSymbol = Namespace.getDefaultSymbol((String)o);
        }
        o = environment.get((Symbol)defaultSymbol, o2, o3);
        return o;
    }
    
    public static Object getPropertyList(final Object o) {
        return Environment.getCurrent().get(Symbol.PLIST, o, LList.Empty);
    }
    
    public static Object getPropertyList(final Object o, final Environment environment) {
        return environment.get(Symbol.PLIST, o, LList.Empty);
    }
    
    public static Object plistGet(final Object o, final Object o2, final Object o3) {
        Pair pair;
        do {
            final Object car = o3;
            if (!(o instanceof Pair)) {
                return car;
            }
            pair = (Pair)o;
        } while (pair.getCar() != o2);
        return ((Pair)pair.getCdr()).getCar();
    }
    
    public static Object plistPut(Object o, final Object o2, final Object car) {
        Pair pair2;
        for (Object cdr = o; cdr instanceof Pair; cdr = pair2.getCdr()) {
            final Pair pair = (Pair)cdr;
            pair2 = (Pair)pair.getCdr();
            if (pair.getCar() == o2) {
                pair2.setCar(car);
                return o;
            }
        }
        o = new Pair(o2, new Pair(car, o));
        return o;
    }
    
    public static Object plistRemove(final Object o, final Object o2) {
        Pair pair = null;
        Object cdr = o;
        Label_0055: {
            Object o3;
            while (true) {
                o3 = o;
                if (!(cdr instanceof Pair)) {
                    break;
                }
                final Pair pair2 = (Pair)cdr;
                final Pair pair3 = (Pair)pair2.getCdr();
                cdr = pair3.getCdr();
                if (pair2.getCar() == o2) {
                    if (pair == null) {
                        o3 = cdr;
                        break;
                    }
                    break Label_0055;
                }
                else {
                    pair = pair3;
                }
            }
            return o3;
        }
        pair.setCdr(cdr);
        return o;
    }
    
    public static void putProperty(final Object o, final Object o2, final Object o3) {
        putProperty(o, o2, o3, Environment.getCurrent());
    }
    
    public static void putProperty(Object pair, final Object o, Object o2, final Environment environment) {
        Object defaultSymbol = pair;
        if (!(pair instanceof Symbol)) {
            if (!(pair instanceof String)) {
                final Location location = environment.getLocation(Symbol.PLIST, pair);
                location.set(plistPut(location.get(LList.Empty), o, o2));
                return;
            }
            defaultSymbol = Namespace.getDefaultSymbol((String)pair);
        }
        final Location lookup = environment.lookup((Symbol)defaultSymbol, o);
        if (lookup != null) {
            final Location base = lookup.getBase();
            if (base instanceof PropertyLocation) {
                ((PropertyLocation)base).set(o2);
                return;
            }
        }
        final Location location2 = environment.getLocation(Symbol.PLIST, defaultSymbol);
        pair = new Pair(o2, location2.get(LList.Empty));
        location2.set(new Pair(o, pair));
        o2 = new PropertyLocation();
        ((PropertyLocation)o2).pair = (Pair)pair;
        environment.addLocation((Symbol)defaultSymbol, o, (Location)o2);
    }
    
    public static boolean removeProperty(final Object o, final Object o2) {
        return removeProperty(o, o2, Environment.getCurrent());
    }
    
    public static boolean removeProperty(final Object o, final Object o2, final Environment environment) {
        final boolean b = false;
        final Location lookup = environment.lookup(Symbol.PLIST, o);
        boolean b2;
        if (lookup == null) {
            b2 = b;
        }
        else {
            final Object value = lookup.get(LList.Empty);
            b2 = b;
            if (value instanceof Pair) {
                Pair pair = (Pair)value;
                Pair pair2 = null;
                while (pair.getCar() != o2) {
                    final Object cdr = pair.getCdr();
                    b2 = b;
                    if (!(cdr instanceof Pair)) {
                        return b2;
                    }
                    pair2 = pair;
                    pair = (Pair)cdr;
                }
                final Object cdr2 = ((Pair)pair.getCdr()).getCdr();
                if (pair2 == null) {
                    lookup.set(cdr2);
                }
                else {
                    pair2.setCdr(cdr2);
                }
                if (o instanceof Symbol) {
                    environment.remove((Symbol)o, o2);
                }
                b2 = true;
            }
        }
        return b2;
    }
    
    public static void setPropertyList(final Object o, final Object o2) {
        setPropertyList(o, o2, Environment.getCurrent());
    }
    
    public static void setPropertyList(Object o, final Object o2, final Environment environment) {
        synchronized (environment) {
            final Location lookup = environment.lookup(Symbol.PLIST, o);
            if (o instanceof Symbol) {
                final Symbol symbol = (Symbol)o;
                Pair pair;
                for (o = lookup.get(LList.Empty); o instanceof Pair; o = ((Pair)pair.getCdr()).getCdr()) {
                    pair = (Pair)o;
                    o = pair.getCar();
                    if (plistGet(o2, o, null) != null) {
                        environment.remove(symbol, o);
                    }
                }
                o = o2;
            Label_0143_Outer:
                while (o instanceof Pair) {
                    final Pair pair2 = (Pair)o;
                    final Object car = pair2.getCar();
                    final Location lookup2 = environment.lookup(symbol, car);
                    while (true) {
                        Label_0168: {
                            if (lookup2 == null) {
                                break Label_0168;
                            }
                            final Location base = lookup2.getBase();
                            if (!(base instanceof PropertyLocation)) {
                                break Label_0168;
                            }
                            o = base;
                            final Pair pair3 = (Pair)pair2.getCdr();
                            ((PropertyLocation)o).pair = pair3;
                            o = pair3.getCdr();
                            continue Label_0143_Outer;
                        }
                        o = new PropertyLocation();
                        environment.addLocation(symbol, car, (Location)o);
                        continue;
                    }
                }
            }
            lookup.set(o2);
        }
    }
    
    @Override
    public final Object get(final Object o) {
        return this.pair.getCar();
    }
    
    @Override
    public boolean isBound() {
        return true;
    }
    
    @Override
    public final void set(final Object car) {
        this.pair.setCar(car);
    }
}
