// 
// Decompiled by Procyon v0.5.36
// 

package androidx.lifecycle;

import androidx.annotation.MainThread;
import androidx.annotation.Nullable;
import androidx.arch.core.util.Function;
import androidx.annotation.NonNull;

public class Transformations
{
    private Transformations() {
    }
    
    @MainThread
    public static <X, Y> LiveData<Y> map(@NonNull final LiveData<X> liveData, @NonNull final Function<X, Y> function) {
        final MediatorLiveData<Y> mediatorLiveData = new MediatorLiveData<Y>();
        mediatorLiveData.addSource(liveData, new Observer<X>() {
            @Override
            public void onChanged(@Nullable final X x) {
                mediatorLiveData.setValue(function.apply(x));
            }
        });
        return mediatorLiveData;
    }
    
    @MainThread
    public static <X, Y> LiveData<Y> switchMap(@NonNull final LiveData<X> liveData, @NonNull final Function<X, LiveData<Y>> function) {
        final MediatorLiveData<Y> mediatorLiveData = new MediatorLiveData<Y>();
        mediatorLiveData.addSource(liveData, new Observer<X>() {
            LiveData<Y> mSource;
            
            @Override
            public void onChanged(@Nullable final X x) {
                final LiveData<Y> mSource = function.apply(x);
                if (this.mSource != mSource) {
                    if (this.mSource != null) {
                        mediatorLiveData.removeSource(this.mSource);
                    }
                    this.mSource = mSource;
                    if (this.mSource != null) {
                        mediatorLiveData.addSource(this.mSource, new Observer<Y>() {
                            @Override
                            public void onChanged(@Nullable final Y value) {
                                mediatorLiveData.setValue(value);
                            }
                        });
                    }
                }
            }
        });
        return mediatorLiveData;
    }
}
