// 
// Decompiled by Procyon v0.5.36
// 

package gnu.mapping;

public class WrongArguments extends IllegalArgumentException
{
    public int number;
    Procedure proc;
    public String procname;
    public String usage;
    
    public WrongArguments(final Procedure proc, final int number) {
        this.proc = proc;
        this.number = number;
    }
    
    public WrongArguments(final String procname, final int number, final String usage) {
        this.procname = procname;
        this.number = number;
        this.usage = usage;
    }
    
    public static String checkArgCount(final Procedure procedure, final int n) {
        final int numArgs = procedure.numArgs();
        String s;
        if ((s = procedure.getName()) == null) {
            s = procedure.getClass().getName();
        }
        return checkArgCount(s, numArgs & 0xFFF, numArgs >> 12, n);
    }
    
    public static String checkArgCount(String string, final int n, final int i, final int j) {
        int n2;
        if (j < n) {
            n2 = 0;
        }
        else {
            if (i < 0 || j <= i) {
                string = null;
                return string;
            }
            n2 = 1;
        }
        final StringBuffer sb = new StringBuffer(100);
        sb.append("call to ");
        if (string == null) {
            sb.append("unnamed procedure");
        }
        else {
            sb.append('\'');
            sb.append(string);
            sb.append('\'');
        }
        if (n2 != 0) {
            string = " has too many";
        }
        else {
            string = " has too few";
        }
        sb.append(string);
        sb.append(" arguments (");
        sb.append(j);
        if (n == i) {
            sb.append("; must be ");
            sb.append(n);
        }
        else {
            sb.append("; min=");
            sb.append(n);
            if (i >= 0) {
                sb.append(", max=");
                sb.append(i);
            }
        }
        sb.append(')');
        string = sb.toString();
        return string;
    }
    
    @Override
    public String getMessage() {
        if (this.proc == null) {
            return super.getMessage();
        }
        String s = checkArgCount(this.proc, this.number);
        if (s == null) {
            return super.getMessage();
        }
        return s;
        s = super.getMessage();
        return s;
    }
}
