// 
// Decompiled by Procyon v0.5.36
// 

package gnu.mapping;

public abstract class Procedure1 extends Procedure
{
    public Procedure1() {
    }
    
    public Procedure1(final String s) {
        super(s);
    }
    
    @Override
    public Object apply0() throws Throwable {
        throw new WrongArguments(this, 0);
    }
    
    @Override
    public abstract Object apply1(final Object p0) throws Throwable;
    
    @Override
    public Object apply2(final Object o, final Object o2) throws Throwable {
        throw new WrongArguments(this, 2);
    }
    
    @Override
    public Object apply3(final Object o, final Object o2, final Object o3) throws Throwable {
        throw new WrongArguments(this, 3);
    }
    
    @Override
    public Object apply4(final Object o, final Object o2, final Object o3, final Object o4) throws Throwable {
        throw new WrongArguments(this, 4);
    }
    
    @Override
    public Object applyN(final Object[] array) throws Throwable {
        if (array.length != 1) {
            throw new WrongArguments(this, array.length);
        }
        return this.apply1(array[0]);
    }
    
    @Override
    public int numArgs() {
        return 4097;
    }
}
