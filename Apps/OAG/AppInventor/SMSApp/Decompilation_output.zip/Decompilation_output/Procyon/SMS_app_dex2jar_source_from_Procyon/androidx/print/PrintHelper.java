// 
// Decompiled by Procyon v0.5.36
// 

package androidx.print;

import android.os.CancellationSignal$OnCancelListener;
import android.print.PrintDocumentInfo;
import android.print.PrintDocumentInfo$Builder;
import android.os.Bundle;
import android.print.PrintDocumentAdapter$LayoutResultCallback;
import android.print.PageRange;
import android.os.AsyncTask;
import android.print.PrintAttributes$Margins;
import android.print.PrintDocumentAdapter$WriteResultCallback;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PrintDocumentAdapter;
import android.print.PrintAttributes$MediaSize;
import android.print.PrintManager;
import androidx.annotation.Nullable;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.IOException;
import android.util.Log;
import android.graphics.Rect;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.graphics.Matrix;
import android.graphics.RectF;
import androidx.annotation.RequiresApi;
import android.print.PrintAttributes$Builder;
import android.print.PrintAttributes;
import android.graphics.ColorFilter;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.ColorMatrix;
import android.graphics.Paint;
import android.graphics.Canvas;
import android.graphics.Bitmap$Config;
import android.graphics.Bitmap;
import androidx.annotation.NonNull;
import android.os.Build$VERSION;
import android.graphics.BitmapFactory$Options;
import android.content.Context;
import android.annotation.SuppressLint;

public final class PrintHelper
{
    @SuppressLint({ "InlinedApi" })
    public static final int COLOR_MODE_COLOR = 2;
    @SuppressLint({ "InlinedApi" })
    public static final int COLOR_MODE_MONOCHROME = 1;
    static final boolean IS_MIN_MARGINS_HANDLING_CORRECT;
    private static final String LOG_TAG = "PrintHelper";
    private static final int MAX_PRINT_SIZE = 3500;
    public static final int ORIENTATION_LANDSCAPE = 1;
    public static final int ORIENTATION_PORTRAIT = 2;
    static final boolean PRINT_ACTIVITY_RESPECTS_ORIENTATION;
    public static final int SCALE_MODE_FILL = 2;
    public static final int SCALE_MODE_FIT = 1;
    int mColorMode;
    final Context mContext;
    BitmapFactory$Options mDecodeOptions;
    final Object mLock;
    int mOrientation;
    int mScaleMode;
    
    static {
        final boolean b = true;
        PRINT_ACTIVITY_RESPECTS_ORIENTATION = (Build$VERSION.SDK_INT < 20 || Build$VERSION.SDK_INT > 23);
        IS_MIN_MARGINS_HANDLING_CORRECT = (Build$VERSION.SDK_INT != 23 && b);
    }
    
    public PrintHelper(@NonNull final Context mContext) {
        this.mDecodeOptions = null;
        this.mLock = new Object();
        this.mScaleMode = 2;
        this.mColorMode = 2;
        this.mOrientation = 1;
        this.mContext = mContext;
    }
    
    static Bitmap convertBitmapForColorMode(Bitmap bitmap, final int n) {
        if (n == 1) {
            final Bitmap bitmap2 = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap$Config.ARGB_8888);
            final Canvas canvas = new Canvas(bitmap2);
            final Paint paint = new Paint();
            final ColorMatrix colorMatrix = new ColorMatrix();
            colorMatrix.setSaturation(0.0f);
            paint.setColorFilter((ColorFilter)new ColorMatrixColorFilter(colorMatrix));
            canvas.drawBitmap(bitmap, 0.0f, 0.0f, paint);
            canvas.setBitmap((Bitmap)null);
            bitmap = bitmap2;
        }
        return bitmap;
    }
    
    @RequiresApi(19)
    private static PrintAttributes$Builder copyAttributes(final PrintAttributes printAttributes) {
        final PrintAttributes$Builder setMinMargins = new PrintAttributes$Builder().setMediaSize(printAttributes.getMediaSize()).setResolution(printAttributes.getResolution()).setMinMargins(printAttributes.getMinMargins());
        if (printAttributes.getColorMode() != 0) {
            setMinMargins.setColorMode(printAttributes.getColorMode());
        }
        if (Build$VERSION.SDK_INT >= 23 && printAttributes.getDuplexMode() != 0) {
            setMinMargins.setDuplexMode(printAttributes.getDuplexMode());
        }
        return setMinMargins;
    }
    
    static Matrix getMatrix(final int n, final int n2, final RectF rectF, final int n3) {
        final Matrix matrix = new Matrix();
        final float n4 = rectF.width() / n;
        float n5;
        if (n3 == 2) {
            n5 = Math.max(n4, rectF.height() / n2);
        }
        else {
            n5 = Math.min(n4, rectF.height() / n2);
        }
        matrix.postScale(n5, n5);
        matrix.postTranslate((rectF.width() - n * n5) / 2.0f, (rectF.height() - n2 * n5) / 2.0f);
        return matrix;
    }
    
    static boolean isPortrait(final Bitmap bitmap) {
        return bitmap.getWidth() <= bitmap.getHeight();
    }
    
    private Bitmap loadBitmap(final Uri uri, BitmapFactory$Options decodeStream) throws FileNotFoundException {
        if (uri == null || this.mContext == null) {
            throw new IllegalArgumentException("bad argument to loadBitmap");
        }
        InputStream openInputStream = null;
        try {
            final InputStream inputStream = openInputStream = this.mContext.getContentResolver().openInputStream(uri);
            decodeStream = (BitmapFactory$Options)BitmapFactory.decodeStream(inputStream, (Rect)null, decodeStream);
            if (inputStream == null) {
                return (Bitmap)decodeStream;
            }
            try {
                inputStream.close();
                return (Bitmap)decodeStream;
            }
            catch (IOException ex) {
                Log.w("PrintHelper", "close fail ", (Throwable)ex);
            }
        }
        finally {
            Label_0076: {
                if (openInputStream == null) {
                    break Label_0076;
                }
                try {
                    openInputStream.close();
                }
                catch (IOException ex2) {
                    Log.w("PrintHelper", "close fail ", (Throwable)ex2);
                }
            }
        }
    }
    
    public static boolean systemSupportsPrint() {
        return Build$VERSION.SDK_INT >= 19;
    }
    
    public int getColorMode() {
        return this.mColorMode;
    }
    
    public int getOrientation() {
        int mOrientation;
        if (Build$VERSION.SDK_INT >= 19 && this.mOrientation == 0) {
            mOrientation = 1;
        }
        else {
            mOrientation = this.mOrientation;
        }
        return mOrientation;
    }
    
    public int getScaleMode() {
        return this.mScaleMode;
    }
    
    Bitmap loadConstrainedBitmap(Uri uri) throws FileNotFoundException {
        final Bitmap bitmap = null;
        if (uri == null || this.mContext == null) {
            throw new IllegalArgumentException("bad argument to getScaledBitmap");
        }
        final BitmapFactory$Options bitmapFactory$Options = new BitmapFactory$Options();
        bitmapFactory$Options.inJustDecodeBounds = true;
        this.loadBitmap(uri, bitmapFactory$Options);
        final int outWidth = bitmapFactory$Options.outWidth;
        final int outHeight = bitmapFactory$Options.outHeight;
        Bitmap bitmap2 = bitmap;
        if (outWidth > 0) {
            if (outHeight <= 0) {
                bitmap2 = bitmap;
            }
            else {
                int i;
                int inSampleSize;
                for (i = Math.max(outWidth, outHeight), inSampleSize = 1; i > 3500; i >>>= 1, inSampleSize <<= 1) {}
                bitmap2 = bitmap;
                if (inSampleSize > 0) {
                    bitmap2 = bitmap;
                    if (Math.min(outWidth, outHeight) / inSampleSize > 0) {
                        final Object mLock = this.mLock;
                        final BitmapFactory$Options mDecodeOptions;
                        synchronized (mLock) {
                            this.mDecodeOptions = new BitmapFactory$Options();
                            this.mDecodeOptions.inMutable = true;
                            this.mDecodeOptions.inSampleSize = inSampleSize;
                            mDecodeOptions = this.mDecodeOptions;
                            // monitorexit(mLock)
                            final PrintHelper printHelper = this;
                            final Uri uri2 = uri;
                            final BitmapFactory$Options bitmapFactory$Options2 = mDecodeOptions;
                            printHelper.loadBitmap(uri2, bitmapFactory$Options2);
                            final PrintHelper printHelper2 = this;
                            final Object o = printHelper2.mLock;
                            final Object o2;
                            uri = (Uri)(o2 = o);
                            synchronized (o2) {
                                final PrintHelper printHelper3 = this;
                                final BitmapFactory$Options bitmapFactory$Options3 = null;
                                printHelper3.mDecodeOptions = bitmapFactory$Options3;
                            }
                        }
                        try {
                            final PrintHelper printHelper = this;
                            final Uri uri2 = uri;
                            final BitmapFactory$Options bitmapFactory$Options2 = mDecodeOptions;
                            printHelper.loadBitmap(uri2, bitmapFactory$Options2);
                            final PrintHelper printHelper2 = this;
                            final Object o = printHelper2.mLock;
                            final Object o2;
                            uri = (Uri)(o2 = o);
                            // monitorenter(o2)
                            final PrintHelper printHelper3 = this;
                            final BitmapFactory$Options bitmapFactory$Options3 = null;
                            printHelper3.mDecodeOptions = bitmapFactory$Options3;
                        }
                        finally {
                            synchronized (this.mLock) {
                                this.mDecodeOptions = null;
                            }
                            // monitorexit(this.mLock)
                        }
                    }
                }
            }
        }
        return bitmap2;
    }
    
    public void printBitmap(@NonNull final String s, @NonNull final Bitmap bitmap) {
        this.printBitmap(s, bitmap, null);
    }
    
    public void printBitmap(@NonNull final String s, @NonNull final Bitmap bitmap, @Nullable final OnPrintFinishCallback onPrintFinishCallback) {
        if (Build$VERSION.SDK_INT >= 19 && bitmap != null) {
            final PrintManager printManager = (PrintManager)this.mContext.getSystemService("print");
            PrintAttributes$MediaSize mediaSize;
            if (isPortrait(bitmap)) {
                mediaSize = PrintAttributes$MediaSize.UNKNOWN_PORTRAIT;
            }
            else {
                mediaSize = PrintAttributes$MediaSize.UNKNOWN_LANDSCAPE;
            }
            printManager.print(s, (PrintDocumentAdapter)new PrintBitmapAdapter(s, this.mScaleMode, bitmap, onPrintFinishCallback), new PrintAttributes$Builder().setMediaSize(mediaSize).setColorMode(this.mColorMode).build());
        }
    }
    
    public void printBitmap(@NonNull final String s, @NonNull final Uri uri) throws FileNotFoundException {
        this.printBitmap(s, uri, null);
    }
    
    public void printBitmap(@NonNull final String s, @NonNull final Uri uri, @Nullable final OnPrintFinishCallback onPrintFinishCallback) throws FileNotFoundException {
        if (Build$VERSION.SDK_INT >= 19) {
            final PrintUriAdapter printUriAdapter = new PrintUriAdapter(s, uri, onPrintFinishCallback, this.mScaleMode);
            final PrintManager printManager = (PrintManager)this.mContext.getSystemService("print");
            final PrintAttributes$Builder printAttributes$Builder = new PrintAttributes$Builder();
            printAttributes$Builder.setColorMode(this.mColorMode);
            if (this.mOrientation == 1 || this.mOrientation == 0) {
                printAttributes$Builder.setMediaSize(PrintAttributes$MediaSize.UNKNOWN_LANDSCAPE);
            }
            else if (this.mOrientation == 2) {
                printAttributes$Builder.setMediaSize(PrintAttributes$MediaSize.UNKNOWN_PORTRAIT);
            }
            printManager.print(s, (PrintDocumentAdapter)printUriAdapter, printAttributes$Builder.build());
        }
    }
    
    public void setColorMode(final int mColorMode) {
        this.mColorMode = mColorMode;
    }
    
    public void setOrientation(final int mOrientation) {
        this.mOrientation = mOrientation;
    }
    
    public void setScaleMode(final int mScaleMode) {
        this.mScaleMode = mScaleMode;
    }
    
    @RequiresApi(19)
    void writeBitmap(final PrintAttributes printAttributes, final int n, final Bitmap bitmap, final ParcelFileDescriptor parcelFileDescriptor, final CancellationSignal cancellationSignal, final PrintDocumentAdapter$WriteResultCallback printDocumentAdapter$WriteResultCallback) {
        PrintAttributes build;
        if (PrintHelper.IS_MIN_MARGINS_HANDLING_CORRECT) {
            build = printAttributes;
        }
        else {
            build = copyAttributes(printAttributes).setMinMargins(new PrintAttributes$Margins(0, 0, 0, 0)).build();
        }
        new AsyncTask<Void, Void, Throwable>() {
            protected Throwable doInBackground(final Void... p0) {
                // 
                // This method could not be decompiled.
                // 
                // Original Bytecode:
                // 
                //     1: astore_2       
                //     2: aload_0        
                //     3: getfield        androidx/print/PrintHelper$1.val$cancellationSignal:Landroid/os/CancellationSignal;
                //     6: invokevirtual   android/os/CancellationSignal.isCanceled:()Z
                //     9: ifeq            16
                //    12: aload_2        
                //    13: astore_1       
                //    14: aload_1        
                //    15: areturn        
                //    16: new             Landroid/print/pdf/PrintedPdfDocument;
                //    19: astore_3       
                //    20: aload_3        
                //    21: aload_0        
                //    22: getfield        androidx/print/PrintHelper$1.this$0:Landroidx/print/PrintHelper;
                //    25: getfield        androidx/print/PrintHelper.mContext:Landroid/content/Context;
                //    28: aload_0        
                //    29: getfield        androidx/print/PrintHelper$1.val$pdfAttributes:Landroid/print/PrintAttributes;
                //    32: invokespecial   android/print/pdf/PrintedPdfDocument.<init>:(Landroid/content/Context;Landroid/print/PrintAttributes;)V
                //    35: aload_0        
                //    36: getfield        androidx/print/PrintHelper$1.val$bitmap:Landroid/graphics/Bitmap;
                //    39: aload_0        
                //    40: getfield        androidx/print/PrintHelper$1.val$pdfAttributes:Landroid/print/PrintAttributes;
                //    43: invokevirtual   android/print/PrintAttributes.getColorMode:()I
                //    46: invokestatic    androidx/print/PrintHelper.convertBitmapForColorMode:(Landroid/graphics/Bitmap;I)Landroid/graphics/Bitmap;
                //    49: astore          4
                //    51: aload_0        
                //    52: getfield        androidx/print/PrintHelper$1.val$cancellationSignal:Landroid/os/CancellationSignal;
                //    55: invokevirtual   android/os/CancellationSignal.isCanceled:()Z
                //    58: istore          5
                //    60: aload_2        
                //    61: astore_1       
                //    62: iload           5
                //    64: ifne            14
                //    67: aload_3        
                //    68: iconst_1       
                //    69: invokevirtual   android/print/pdf/PrintedPdfDocument.startPage:(I)Landroid/graphics/pdf/PdfDocument$Page;
                //    72: astore          6
                //    74: getstatic       androidx/print/PrintHelper.IS_MIN_MARGINS_HANDLING_CORRECT:Z
                //    77: ifeq            200
                //    80: new             Landroid/graphics/RectF;
                //    83: astore_1       
                //    84: aload_1        
                //    85: aload           6
                //    87: invokevirtual   android/graphics/pdf/PdfDocument$Page.getInfo:()Landroid/graphics/pdf/PdfDocument$PageInfo;
                //    90: invokevirtual   android/graphics/pdf/PdfDocument$PageInfo.getContentRect:()Landroid/graphics/Rect;
                //    93: invokespecial   android/graphics/RectF.<init>:(Landroid/graphics/Rect;)V
                //    96: aload           4
                //    98: invokevirtual   android/graphics/Bitmap.getWidth:()I
                //   101: aload           4
                //   103: invokevirtual   android/graphics/Bitmap.getHeight:()I
                //   106: aload_1        
                //   107: aload_0        
                //   108: getfield        androidx/print/PrintHelper$1.val$fittingMode:I
                //   111: invokestatic    androidx/print/PrintHelper.getMatrix:(IILandroid/graphics/RectF;I)Landroid/graphics/Matrix;
                //   114: astore          7
                //   116: getstatic       androidx/print/PrintHelper.IS_MIN_MARGINS_HANDLING_CORRECT:Z
                //   119: ifeq            297
                //   122: aload           6
                //   124: invokevirtual   android/graphics/pdf/PdfDocument$Page.getCanvas:()Landroid/graphics/Canvas;
                //   127: aload           4
                //   129: aload           7
                //   131: aconst_null    
                //   132: invokevirtual   android/graphics/Canvas.drawBitmap:(Landroid/graphics/Bitmap;Landroid/graphics/Matrix;Landroid/graphics/Paint;)V
                //   135: aload_3        
                //   136: aload           6
                //   138: invokevirtual   android/print/pdf/PrintedPdfDocument.finishPage:(Landroid/graphics/pdf/PdfDocument$Page;)V
                //   141: aload_0        
                //   142: getfield        androidx/print/PrintHelper$1.val$cancellationSignal:Landroid/os/CancellationSignal;
                //   145: invokevirtual   android/os/CancellationSignal.isCanceled:()Z
                //   148: istore          5
                //   150: iload           5
                //   152: ifeq            324
                //   155: aload_3        
                //   156: invokevirtual   android/print/pdf/PrintedPdfDocument.close:()V
                //   159: aload_0        
                //   160: getfield        androidx/print/PrintHelper$1.val$fileDescriptor:Landroid/os/ParcelFileDescriptor;
                //   163: astore_1       
                //   164: aload_1        
                //   165: ifnull          175
                //   168: aload_0        
                //   169: getfield        androidx/print/PrintHelper$1.val$fileDescriptor:Landroid/os/ParcelFileDescriptor;
                //   172: invokevirtual   android/os/ParcelFileDescriptor.close:()V
                //   175: aload_2        
                //   176: astore_1       
                //   177: aload           4
                //   179: aload_0        
                //   180: getfield        androidx/print/PrintHelper$1.val$bitmap:Landroid/graphics/Bitmap;
                //   183: if_acmpeq       14
                //   186: aload           4
                //   188: invokevirtual   android/graphics/Bitmap.recycle:()V
                //   191: aload_2        
                //   192: astore_1       
                //   193: goto            14
                //   196: astore_1       
                //   197: goto            14
                //   200: new             Landroid/print/pdf/PrintedPdfDocument;
                //   203: astore          8
                //   205: aload           8
                //   207: aload_0        
                //   208: getfield        androidx/print/PrintHelper$1.this$0:Landroidx/print/PrintHelper;
                //   211: getfield        androidx/print/PrintHelper.mContext:Landroid/content/Context;
                //   214: aload_0        
                //   215: getfield        androidx/print/PrintHelper$1.val$attributes:Landroid/print/PrintAttributes;
                //   218: invokespecial   android/print/pdf/PrintedPdfDocument.<init>:(Landroid/content/Context;Landroid/print/PrintAttributes;)V
                //   221: aload           8
                //   223: iconst_1       
                //   224: invokevirtual   android/print/pdf/PrintedPdfDocument.startPage:(I)Landroid/graphics/pdf/PdfDocument$Page;
                //   227: astore          7
                //   229: new             Landroid/graphics/RectF;
                //   232: astore_1       
                //   233: aload_1        
                //   234: aload           7
                //   236: invokevirtual   android/graphics/pdf/PdfDocument$Page.getInfo:()Landroid/graphics/pdf/PdfDocument$PageInfo;
                //   239: invokevirtual   android/graphics/pdf/PdfDocument$PageInfo.getContentRect:()Landroid/graphics/Rect;
                //   242: invokespecial   android/graphics/RectF.<init>:(Landroid/graphics/Rect;)V
                //   245: aload           8
                //   247: aload           7
                //   249: invokevirtual   android/print/pdf/PrintedPdfDocument.finishPage:(Landroid/graphics/pdf/PdfDocument$Page;)V
                //   252: aload           8
                //   254: invokevirtual   android/print/pdf/PrintedPdfDocument.close:()V
                //   257: goto            96
                //   260: astore_1       
                //   261: aload_3        
                //   262: invokevirtual   android/print/pdf/PrintedPdfDocument.close:()V
                //   265: aload_0        
                //   266: getfield        androidx/print/PrintHelper$1.val$fileDescriptor:Landroid/os/ParcelFileDescriptor;
                //   269: astore_2       
                //   270: aload_2        
                //   271: ifnull          281
                //   274: aload_0        
                //   275: getfield        androidx/print/PrintHelper$1.val$fileDescriptor:Landroid/os/ParcelFileDescriptor;
                //   278: invokevirtual   android/os/ParcelFileDescriptor.close:()V
                //   281: aload           4
                //   283: aload_0        
                //   284: getfield        androidx/print/PrintHelper$1.val$bitmap:Landroid/graphics/Bitmap;
                //   287: if_acmpeq       295
                //   290: aload           4
                //   292: invokevirtual   android/graphics/Bitmap.recycle:()V
                //   295: aload_1        
                //   296: athrow         
                //   297: aload           7
                //   299: aload_1        
                //   300: getfield        android/graphics/RectF.left:F
                //   303: aload_1        
                //   304: getfield        android/graphics/RectF.top:F
                //   307: invokevirtual   android/graphics/Matrix.postTranslate:(FF)Z
                //   310: pop            
                //   311: aload           6
                //   313: invokevirtual   android/graphics/pdf/PdfDocument$Page.getCanvas:()Landroid/graphics/Canvas;
                //   316: aload_1        
                //   317: invokevirtual   android/graphics/Canvas.clipRect:(Landroid/graphics/RectF;)Z
                //   320: pop            
                //   321: goto            122
                //   324: new             Ljava/io/FileOutputStream;
                //   327: astore_1       
                //   328: aload_1        
                //   329: aload_0        
                //   330: getfield        androidx/print/PrintHelper$1.val$fileDescriptor:Landroid/os/ParcelFileDescriptor;
                //   333: invokevirtual   android/os/ParcelFileDescriptor.getFileDescriptor:()Ljava/io/FileDescriptor;
                //   336: invokespecial   java/io/FileOutputStream.<init>:(Ljava/io/FileDescriptor;)V
                //   339: aload_3        
                //   340: aload_1        
                //   341: invokevirtual   android/print/pdf/PrintedPdfDocument.writeTo:(Ljava/io/OutputStream;)V
                //   344: aload_3        
                //   345: invokevirtual   android/print/pdf/PrintedPdfDocument.close:()V
                //   348: aload_0        
                //   349: getfield        androidx/print/PrintHelper$1.val$fileDescriptor:Landroid/os/ParcelFileDescriptor;
                //   352: astore_1       
                //   353: aload_1        
                //   354: ifnull          364
                //   357: aload_0        
                //   358: getfield        androidx/print/PrintHelper$1.val$fileDescriptor:Landroid/os/ParcelFileDescriptor;
                //   361: invokevirtual   android/os/ParcelFileDescriptor.close:()V
                //   364: aload_2        
                //   365: astore_1       
                //   366: aload           4
                //   368: aload_0        
                //   369: getfield        androidx/print/PrintHelper$1.val$bitmap:Landroid/graphics/Bitmap;
                //   372: if_acmpeq       14
                //   375: aload           4
                //   377: invokevirtual   android/graphics/Bitmap.recycle:()V
                //   380: aload_2        
                //   381: astore_1       
                //   382: goto            14
                //   385: astore_2       
                //   386: goto            281
                //   389: astore_1       
                //   390: goto            364
                //   393: astore_1       
                //   394: goto            175
                //    Exceptions:
                //  Try           Handler
                //  Start  End    Start  End    Type                 
                //  -----  -----  -----  -----  ---------------------
                //  2      12     196    200    Ljava/lang/Throwable;
                //  16     60     196    200    Ljava/lang/Throwable;
                //  67     96     260    297    Any
                //  96     122    260    297    Any
                //  122    150    260    297    Any
                //  155    164    196    200    Ljava/lang/Throwable;
                //  168    175    393    397    Ljava/io/IOException;
                //  168    175    196    200    Ljava/lang/Throwable;
                //  177    191    196    200    Ljava/lang/Throwable;
                //  200    257    260    297    Any
                //  261    270    196    200    Ljava/lang/Throwable;
                //  274    281    385    389    Ljava/io/IOException;
                //  274    281    196    200    Ljava/lang/Throwable;
                //  281    295    196    200    Ljava/lang/Throwable;
                //  295    297    196    200    Ljava/lang/Throwable;
                //  297    321    260    297    Any
                //  324    344    260    297    Any
                //  344    353    196    200    Ljava/lang/Throwable;
                //  357    364    389    393    Ljava/io/IOException;
                //  357    364    196    200    Ljava/lang/Throwable;
                //  366    380    196    200    Ljava/lang/Throwable;
                // 
                // The error that occurred was:
                // 
                // java.lang.IndexOutOfBoundsException: Index 191 out of bounds for length 191
                //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
                //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
                //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
                //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
                //     at java.base/java.util.ArrayList.get(ArrayList.java:458)
                //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3321)
                //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:113)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformCall(AstMethodBodyBuilder.java:1164)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformByteCode(AstMethodBodyBuilder.java:1009)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformExpression(AstMethodBodyBuilder.java:540)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformByteCode(AstMethodBodyBuilder.java:554)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformExpression(AstMethodBodyBuilder.java:540)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformNode(AstMethodBodyBuilder.java:392)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformBlock(AstMethodBodyBuilder.java:333)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:294)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
                //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
                //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
                //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
                //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
                //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
                // 
                throw new IllegalStateException("An error occurred while decompiling this method.");
            }
            
            protected void onPostExecute(final Throwable t) {
                if (cancellationSignal.isCanceled()) {
                    printDocumentAdapter$WriteResultCallback.onWriteCancelled();
                }
                else if (t == null) {
                    printDocumentAdapter$WriteResultCallback.onWriteFinished(new PageRange[] { PageRange.ALL_PAGES });
                }
                else {
                    Log.e("PrintHelper", "Error writing printed content", t);
                    printDocumentAdapter$WriteResultCallback.onWriteFailed((CharSequence)null);
                }
            }
        }.execute((Object[])new Void[0]);
    }
    
    public interface OnPrintFinishCallback
    {
        void onFinish();
    }
    
    @RequiresApi(19)
    private class PrintBitmapAdapter extends PrintDocumentAdapter
    {
        private PrintAttributes mAttributes;
        private final Bitmap mBitmap;
        private final OnPrintFinishCallback mCallback;
        private final int mFittingMode;
        private final String mJobName;
        
        PrintBitmapAdapter(final String mJobName, final int mFittingMode, final Bitmap mBitmap, final OnPrintFinishCallback mCallback) {
            this.mJobName = mJobName;
            this.mFittingMode = mFittingMode;
            this.mBitmap = mBitmap;
            this.mCallback = mCallback;
        }
        
        public void onFinish() {
            if (this.mCallback != null) {
                this.mCallback.onFinish();
            }
        }
        
        public void onLayout(final PrintAttributes printAttributes, final PrintAttributes mAttributes, final CancellationSignal cancellationSignal, final PrintDocumentAdapter$LayoutResultCallback printDocumentAdapter$LayoutResultCallback, final Bundle bundle) {
            boolean b = true;
            this.mAttributes = mAttributes;
            final PrintDocumentInfo build = new PrintDocumentInfo$Builder(this.mJobName).setContentType(1).setPageCount(1).build();
            if (mAttributes.equals((Object)printAttributes)) {
                b = false;
            }
            printDocumentAdapter$LayoutResultCallback.onLayoutFinished(build, b);
        }
        
        public void onWrite(final PageRange[] array, final ParcelFileDescriptor parcelFileDescriptor, final CancellationSignal cancellationSignal, final PrintDocumentAdapter$WriteResultCallback printDocumentAdapter$WriteResultCallback) {
            PrintHelper.this.writeBitmap(this.mAttributes, this.mFittingMode, this.mBitmap, parcelFileDescriptor, cancellationSignal, printDocumentAdapter$WriteResultCallback);
        }
    }
    
    @RequiresApi(19)
    private class PrintUriAdapter extends PrintDocumentAdapter
    {
        PrintAttributes mAttributes;
        Bitmap mBitmap;
        final OnPrintFinishCallback mCallback;
        final int mFittingMode;
        final Uri mImageFile;
        final String mJobName;
        AsyncTask<Uri, Boolean, Bitmap> mLoadBitmap;
        
        PrintUriAdapter(final String mJobName, final Uri mImageFile, final OnPrintFinishCallback mCallback, final int mFittingMode) {
            this.mJobName = mJobName;
            this.mImageFile = mImageFile;
            this.mCallback = mCallback;
            this.mFittingMode = mFittingMode;
            this.mBitmap = null;
        }
        
        void cancelLoad() {
            synchronized (PrintHelper.this.mLock) {
                if (PrintHelper.this.mDecodeOptions != null) {
                    if (Build$VERSION.SDK_INT < 24) {
                        PrintHelper.this.mDecodeOptions.requestCancelDecode();
                    }
                    PrintHelper.this.mDecodeOptions = null;
                }
            }
        }
        
        public void onFinish() {
            super.onFinish();
            this.cancelLoad();
            if (this.mLoadBitmap != null) {
                this.mLoadBitmap.cancel(true);
            }
            if (this.mCallback != null) {
                this.mCallback.onFinish();
            }
            if (this.mBitmap != null) {
                this.mBitmap.recycle();
                this.mBitmap = null;
            }
        }
        
        public void onLayout(final PrintAttributes printAttributes, final PrintAttributes mAttributes, CancellationSignal build, final PrintDocumentAdapter$LayoutResultCallback printDocumentAdapter$LayoutResultCallback, final Bundle bundle) {
            while (true) {
                boolean b = true;
                synchronized (this) {
                    this.mAttributes = mAttributes;
                    // monitorexit(this)
                    if (build.isCanceled()) {
                        printDocumentAdapter$LayoutResultCallback.onLayoutCancelled();
                        return;
                    }
                }
                final PrintAttributes printAttributes2;
                if (this.mBitmap != null) {
                    build = (CancellationSignal)new PrintDocumentInfo$Builder(this.mJobName).setContentType(1).setPageCount(1).build();
                    if (mAttributes.equals((Object)printAttributes2)) {
                        b = false;
                    }
                    printDocumentAdapter$LayoutResultCallback.onLayoutFinished((PrintDocumentInfo)build, b);
                    return;
                }
                this.mLoadBitmap = (AsyncTask<Uri, Boolean, Bitmap>)new AsyncTask<Uri, Boolean, Bitmap>() {
                    protected Bitmap doInBackground(final Uri... array) {
                        try {
                            return PrintHelper.this.loadConstrainedBitmap(PrintUriAdapter.this.mImageFile);
                        }
                        catch (FileNotFoundException ex) {
                            return null;
                        }
                    }
                    
                    protected void onCancelled(final Bitmap bitmap) {
                        printDocumentAdapter$LayoutResultCallback.onLayoutCancelled();
                        PrintUriAdapter.this.mLoadBitmap = null;
                    }
                    
                    protected void onPostExecute(final Bitmap bitmap) {
                        super.onPostExecute((Object)bitmap);
                        Bitmap bitmap2 = bitmap;
                        Label_0098: {
                            if (bitmap == null) {
                                break Label_0098;
                            }
                            if (PrintHelper.PRINT_ACTIVITY_RESPECTS_ORIENTATION) {
                                bitmap2 = bitmap;
                                if (PrintHelper.this.mOrientation != 0) {
                                    break Label_0098;
                                }
                            }
                        Label_0163_Outer:
                            while (true) {
                                while (true) {
                                    Label_0183: {
                                        while (true) {
                                            synchronized (this) {
                                                final PrintAttributes$MediaSize mediaSize = PrintUriAdapter.this.mAttributes.getMediaSize();
                                                // monitorexit(this)
                                                bitmap2 = bitmap;
                                                if (mediaSize != null) {
                                                    bitmap2 = bitmap;
                                                    if (mediaSize.isPortrait() != PrintHelper.isPortrait(bitmap)) {
                                                        final Matrix matrix = new Matrix();
                                                        matrix.postRotate(90.0f);
                                                        bitmap2 = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
                                                    }
                                                }
                                                if ((PrintUriAdapter.this.mBitmap = bitmap2) == null) {
                                                    break Label_0183;
                                                }
                                                final PrintDocumentInfo build = new PrintDocumentInfo$Builder(PrintUriAdapter.this.mJobName).setContentType(1).setPageCount(1).build();
                                                if (!mAttributes.equals((Object)printAttributes2)) {
                                                    final boolean b = true;
                                                    printDocumentAdapter$LayoutResultCallback.onLayoutFinished(build, b);
                                                    PrintUriAdapter.this.mLoadBitmap = null;
                                                    return;
                                                }
                                            }
                                            final boolean b = false;
                                            continue Label_0163_Outer;
                                        }
                                    }
                                    printDocumentAdapter$LayoutResultCallback.onLayoutFailed((CharSequence)null);
                                    continue;
                                }
                            }
                        }
                    }
                    
                    protected void onPreExecute() {
                        build.setOnCancelListener((CancellationSignal$OnCancelListener)new CancellationSignal$OnCancelListener() {
                            public void onCancel() {
                                PrintUriAdapter.this.cancelLoad();
                                AsyncTask.this.cancel(false);
                            }
                        });
                    }
                }.execute((Object[])new Uri[0]);
            }
        }
        
        public void onWrite(final PageRange[] array, final ParcelFileDescriptor parcelFileDescriptor, final CancellationSignal cancellationSignal, final PrintDocumentAdapter$WriteResultCallback printDocumentAdapter$WriteResultCallback) {
            PrintHelper.this.writeBitmap(this.mAttributes, this.mFittingMode, this.mBitmap, parcelFileDescriptor, cancellationSignal, printDocumentAdapter$WriteResultCallback);
        }
    }
}
