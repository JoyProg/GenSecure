// 
// Decompiled by Procyon v0.5.36
// 

package gnu.mapping;

import gnu.lists.Consumer;
import java.io.Writer;

public class CharArrayOutPort extends OutPort
{
    public CharArrayOutPort() {
        super(null, false, CharArrayInPort.stringPath);
    }
    
    @Override
    public void close() {
    }
    
    @Override
    protected boolean closeOnExit() {
        return false;
    }
    
    public int length() {
        return this.bout.bufferFillPointer;
    }
    
    public void reset() {
        this.bout.bufferFillPointer = 0;
    }
    
    public void setLength(final int bufferFillPointer) {
        this.bout.bufferFillPointer = bufferFillPointer;
    }
    
    public char[] toCharArray() {
        final int bufferFillPointer = this.bout.bufferFillPointer;
        final char[] array = new char[bufferFillPointer];
        System.arraycopy(this.bout.buffer, 0, array, 0, bufferFillPointer);
        return array;
    }
    
    @Override
    public String toString() {
        return new String(this.bout.buffer, 0, this.bout.bufferFillPointer);
    }
    
    public String toSubString(final int offset) {
        return new String(this.bout.buffer, offset, this.bout.bufferFillPointer - offset);
    }
    
    public String toSubString(final int offset, final int n) {
        if (n > this.bout.bufferFillPointer) {
            throw new IndexOutOfBoundsException();
        }
        return new String(this.bout.buffer, offset, n - offset);
    }
    
    public void writeTo(final int n, final int n2, final Consumer consumer) {
        consumer.write(this.bout.buffer, n, n2);
    }
    
    public void writeTo(final Consumer consumer) {
        consumer.write(this.bout.buffer, 0, this.bout.bufferFillPointer);
    }
}
