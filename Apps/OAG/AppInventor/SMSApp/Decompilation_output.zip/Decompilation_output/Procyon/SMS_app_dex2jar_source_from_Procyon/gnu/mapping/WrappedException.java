// 
// Decompiled by Procyon v0.5.36
// 

package gnu.mapping;

public class WrappedException extends RuntimeException
{
    public WrappedException() {
    }
    
    public WrappedException(final String message) {
        super(message);
    }
    
    public WrappedException(final String message, final Throwable cause) {
        super(message, cause);
    }
    
    public WrappedException(final Throwable t) {
        this(t.toString(), t);
    }
    
    public static RuntimeException wrapIfNeeded(final Throwable t) {
        RuntimeException ex;
        if (t instanceof RuntimeException) {
            ex = (RuntimeException)t;
        }
        else {
            ex = new WrappedException(t);
        }
        return ex;
    }
    
    public Throwable getException() {
        return this.getCause();
    }
    
    @Override
    public String toString() {
        return this.getMessage();
    }
}
