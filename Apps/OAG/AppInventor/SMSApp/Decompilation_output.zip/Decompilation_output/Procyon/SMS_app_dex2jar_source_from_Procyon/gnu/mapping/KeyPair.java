// 
// Decompiled by Procyon v0.5.36
// 

package gnu.mapping;

public class KeyPair implements EnvironmentKey
{
    Symbol name;
    Object property;
    
    public KeyPair(final Symbol name, final Object property) {
        this.name = name;
        this.property = property;
    }
    
    @Override
    public boolean equals(final Object o) {
        final boolean b = false;
        boolean b2;
        if (!(o instanceof KeyPair)) {
            b2 = b;
        }
        else {
            final KeyPair keyPair = (KeyPair)o;
            b2 = b;
            if (this.property == keyPair.property) {
                if (this.name == null) {
                    b2 = b;
                    if (keyPair.name != null) {
                        return b2;
                    }
                }
                else {
                    b2 = b;
                    if (!this.name.equals(keyPair.name)) {
                        return b2;
                    }
                }
                b2 = true;
            }
        }
        return b2;
    }
    
    @Override
    public Object getKeyProperty() {
        return this.property;
    }
    
    @Override
    public Symbol getKeySymbol() {
        return this.name;
    }
    
    @Override
    public int hashCode() {
        return this.name.hashCode() ^ System.identityHashCode(this.property);
    }
    
    @Override
    public final boolean matches(final EnvironmentKey environmentKey) {
        return Symbol.equals(environmentKey.getKeySymbol(), this.name) && environmentKey.getKeyProperty() == this.property;
    }
    
    @Override
    public final boolean matches(final Symbol symbol, final Object o) {
        return Symbol.equals(symbol, this.name) && o == this.property;
    }
    
    @Override
    public String toString() {
        return "KeyPair[sym:" + this.name + " prop:" + this.property + "]";
    }
}
