// 
// Decompiled by Procyon v0.5.36
// 

package kawa;

import java.io.IOException;
import java.net.Socket;
import java.io.OutputStream;
import java.io.InputStream;

public class Telnet implements Runnable
{
    public static final int DO = 253;
    public static final int DONT = 254;
    public static final int ECHO = 1;
    static final int EOF = 236;
    static final int IAC = 255;
    static final int IP = 244;
    static final int LINEMODE = 34;
    static final int NAWS = 31;
    static final int NOP = 241;
    static final int OPTION_NO = 0;
    static final int OPTION_WANTNO = 1;
    static final int OPTION_WANTNO_OPPOSITE = 2;
    static final int OPTION_WANTYES = 3;
    static final int OPTION_WANTYES_OPPOSITE = 4;
    static final int OPTION_YES = 5;
    static final int SB = 250;
    static final int SE = 240;
    public static final int SUPPRESS_GO_AHEAD = 3;
    static final int TM = 6;
    static final int TTYPE = 24;
    public static final int WILL = 251;
    public static final int WONT = 252;
    TelnetInputStream in;
    boolean isServer;
    final byte[] optionsState;
    TelnetOutputStream out;
    final byte preferredLineMode;
    InputStream sin;
    OutputStream sout;
    public byte[] terminalType;
    public short windowHeight;
    public short windowWidth;
    
    public Telnet(final Socket socket, final boolean isServer) throws IOException {
        this.preferredLineMode = 3;
        this.optionsState = new byte[256];
        this.sin = socket.getInputStream();
        this.sout = socket.getOutputStream();
        this.out = new TelnetOutputStream(this.sout);
        this.in = new TelnetInputStream(this.sin, this);
        this.isServer = isServer;
    }
    
    public static void main(final String[] array) {
        if (array.length == 0) {
            usage();
        }
        final String host = array[0];
        int int1 = 23;
        if (array.length > 1) {
            int1 = Integer.parseInt(array[1]);
        }
        try {
            final Telnet target = new Telnet(new Socket(host, int1), false);
            final TelnetOutputStream outputStream = target.getOutputStream();
            final Thread thread = new Thread(target);
            thread.setPriority(Thread.currentThread().getPriority() + 1);
            thread.start();
            final byte[] b = new byte[1024];
            while (true) {
                final int read = System.in.read();
                if (read < 0) {
                    break;
                }
                b[0] = (byte)read;
                final int available = System.in.available();
                int read2;
                if ((read2 = available) > 0) {
                    int len;
                    if ((len = available) > b.length - 1) {
                        len = b.length - 1;
                    }
                    read2 = System.in.read(b, 1, len);
                }
                outputStream.write(b, 0, read2 + 1);
            }
            thread.stop();
        }
        catch (Exception x) {
            System.err.println(x);
        }
    }
    
    static void usage() {
        System.err.println("Usage:  [java] kawa.Telnet HOST [PORT#]");
        System.exit(-1);
    }
    
    boolean change(final int n, final int n2) {
        final boolean b = true;
        boolean b2;
        if (n2 == 6) {
            b2 = b;
        }
        else {
            if (this.isServer) {
                b2 = b;
                if (n2 == 31) {
                    return b2;
                }
            }
            if (this.isServer && n == 251 && n2 == 34) {
                try {
                    this.out.writeSubCommand(34, new byte[] { 1, 3 });
                    b2 = b;
                }
                catch (IOException ex) {
                    b2 = b;
                }
            }
            else if (this.isServer && n == 251 && n2 == 24) {
                try {
                    this.out.writeSubCommand(n2, new byte[] { 1 });
                    b2 = b;
                }
                catch (IOException ex2) {
                    b2 = b;
                }
            }
            else {
                if (!this.isServer && n2 == 1) {
                    if (n == 253) {
                        b2 = false;
                        return b2;
                    }
                    b2 = b;
                    if (n == 251) {
                        return b2;
                    }
                }
                b2 = false;
            }
        }
        return b2;
    }
    
    public TelnetInputStream getInputStream() {
        return this.in;
    }
    
    public TelnetOutputStream getOutputStream() {
        return this.out;
    }
    
    void handle(int n, final int n2) throws IOException {
        boolean b = true;
        int n3 = 254;
        final int n4 = 253;
        boolean b2;
        if (n < 253) {
            b2 = true;
        }
        else {
            b2 = false;
        }
        if ((n & 0x1) == 0x0) {
            b = false;
        }
        int n5;
        final byte b3 = (byte)(n5 = this.optionsState[n2]);
        if (b2) {
            n5 = (byte)(b3 >> 3);
        }
        switch (n5 >> 3 & 0x7) {
            default: {
                n = n5;
                break;
            }
            case 5: {
                if (!b) {
                    final int n6 = 0;
                    this.change(n, n2);
                    final TelnetOutputStream out = this.out;
                    if (b2) {
                        n = 254;
                    }
                    else {
                        n = 252;
                    }
                    out.writeCommand(n, n2);
                    n = n6;
                    break;
                }
                return;
            }
            case 0: {
                if (!b) {
                    return;
                }
                if (this.change(n, n2)) {
                    final int n7 = 5;
                    final TelnetOutputStream out2 = this.out;
                    if (b2) {
                        n = 253;
                    }
                    else {
                        n = 251;
                    }
                    out2.writeCommand(n, n2);
                    n = n7;
                    break;
                }
                final TelnetOutputStream out3 = this.out;
                if (!b2) {
                    n3 = 252;
                }
                out3.writeCommand(n3, n2);
                n = n5;
                break;
            }
            case 1: {
                n = 0;
                break;
            }
            case 2: {
                final int n8 = 3;
                final TelnetOutputStream out4 = this.out;
                if (b2) {
                    n = n4;
                }
                else {
                    n = 251;
                }
                out4.writeCommand(n, n2);
                n = n8;
                break;
            }
            case 3: {
                if (b) {
                    final int n9 = 5;
                    this.change(n, n2);
                    n = n9;
                    break;
                }
                n = 0;
                break;
            }
            case 4: {
                if (b) {
                    n = 1;
                    final TelnetOutputStream out5 = this.out;
                    if (!b2) {
                        n3 = 252;
                    }
                    out5.writeCommand(n3, n2);
                    break;
                }
                n = 0;
                break;
            }
        }
        if (b2) {
            n = (byte)((this.optionsState[n2] & 0xC7) | n << 3);
        }
        else {
            n = (byte)((this.optionsState[n2] & 0xF8) | n);
        }
        this.optionsState[n2] = (byte)n;
    }
    
    public void request(int n, final int n2) throws IOException {
        boolean b = true;
        boolean b2;
        if (n >= 253) {
            b2 = true;
        }
        else {
            b2 = false;
        }
        if ((n & 0x1) == 0x0) {
            b = false;
        }
        int n3;
        final byte b3 = (byte)(n3 = this.optionsState[n2]);
        if (b2) {
            n3 = (byte)(b3 >> 3);
        }
        int n4 = n3;
        switch (n3 & 0x7) {
            case 0: {
                if (b) {
                    n3 = 3;
                    this.out.writeCommand(n, n2);
                    break;
                }
                break;
            }
            case 5: {
                if (!b) {
                    n3 = 1;
                    this.out.writeCommand(n, n2);
                    break;
                }
                break;
            }
            case 1: {
                if (b) {
                    n3 = 2;
                    break;
                }
                break;
            }
            case 2: {
                if (!b) {
                    n3 = 1;
                    break;
                }
                break;
            }
            case 3: {
                n4 = n3;
                if (!b) {
                    n4 = 4;
                }
            }
            case 4: {
                n3 = n4;
                if (b) {
                    n3 = 3;
                    break;
                }
                break;
            }
        }
        if (b2) {
            n = (byte)((this.optionsState[n2] & 0xC7) | n3 << 3);
        }
        else {
            n = (byte)((this.optionsState[n2] & 0xF8) | n3);
        }
        this.optionsState[n2] = (byte)n;
    }
    
    @Override
    public void run() {
        try {
            final TelnetInputStream inputStream = this.getInputStream();
            final byte[] buf = new byte[1024];
            while (true) {
                final int read = inputStream.read();
                if (read < 0) {
                    break;
                }
                buf[0] = (byte)read;
                final int available = inputStream.available();
                int read2;
                if ((read2 = available) > 0) {
                    int n;
                    if ((n = available) > buf.length - 1) {
                        n = buf.length - 1;
                    }
                    read2 = inputStream.read(buf, 1, n);
                }
                System.out.write(buf, 0, read2 + 1);
            }
        }
        catch (IOException x) {
            System.err.println(x);
            System.exit(-1);
        }
    }
    
    public void subCommand(final byte[] array, int n, final int i) {
        switch (array[n]) {
            case 31: {
                if (i == 5) {
                    this.windowWidth = (short)((array[1] << 8) + (array[2] & 0xFF));
                    this.windowHeight = (short)((array[3] << 8) + (array[4] & 0xFF));
                    break;
                }
                break;
            }
            case 24: {
                final byte[] array2 = new byte[i - 1];
                System.arraycopy(array, 1, array2, 0, i - 1);
                this.terminalType = array2;
                System.err.println("terminal type: '" + new String(array2) + "'");
                break;
            }
            case 34: {
                System.err.println("SBCommand LINEMODE " + array[1] + " len:" + i);
                if (array[1] == 3) {
                    for (n = 2; n + 2 < i; n += 3) {
                        System.err.println("  " + array[n] + "," + array[n + 1] + "," + array[n + 2]);
                    }
                    break;
                }
                break;
            }
        }
    }
}
