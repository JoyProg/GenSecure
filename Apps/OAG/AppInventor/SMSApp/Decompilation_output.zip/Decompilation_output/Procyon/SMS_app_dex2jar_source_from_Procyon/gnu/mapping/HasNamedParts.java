// 
// Decompiled by Procyon v0.5.36
// 

package gnu.mapping;

public interface HasNamedParts
{
    Object get(final String p0);
    
    boolean isConstant(final String p0);
}
