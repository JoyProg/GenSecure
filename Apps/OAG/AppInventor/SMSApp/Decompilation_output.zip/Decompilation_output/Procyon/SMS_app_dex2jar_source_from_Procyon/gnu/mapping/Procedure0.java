// 
// Decompiled by Procyon v0.5.36
// 

package gnu.mapping;

public abstract class Procedure0 extends Procedure
{
    public Procedure0() {
    }
    
    public Procedure0(final String s) {
        super(s);
    }
    
    @Override
    public abstract Object apply0() throws Throwable;
    
    @Override
    public Object apply1(final Object o) {
        throw new WrongArguments(this, 1);
    }
    
    @Override
    public Object apply2(final Object o, final Object o2) {
        throw new WrongArguments(this, 2);
    }
    
    @Override
    public Object apply3(final Object o, final Object o2, final Object o3) {
        throw new WrongArguments(this, 3);
    }
    
    @Override
    public Object apply4(final Object o, final Object o2, final Object o3, final Object o4) {
        throw new WrongArguments(this, 4);
    }
    
    @Override
    public Object applyN(final Object[] array) throws Throwable {
        if (array.length != 0) {
            throw new WrongArguments(this, array.length);
        }
        return this.apply0();
    }
    
    @Override
    public int numArgs() {
        return 0;
    }
}
