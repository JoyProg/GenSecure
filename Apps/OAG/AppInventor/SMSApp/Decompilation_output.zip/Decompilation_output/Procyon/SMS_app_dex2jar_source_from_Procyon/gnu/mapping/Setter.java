// 
// Decompiled by Procyon v0.5.36
// 

package gnu.mapping;

public class Setter extends ProcedureN
{
    protected Procedure getter;
    
    public Setter(final Procedure getter) {
        this.getter = getter;
        final String name = getter.getName();
        if (name != null) {
            this.setName("(setter " + name + ")");
        }
    }
    
    @Override
    public Object applyN(final Object[] n) throws Throwable {
        this.getter.setN(n);
        return Values.empty;
    }
    
    @Override
    public int numArgs() {
        int numArgs = this.getter.numArgs();
        if (numArgs < 0) {
            ++numArgs;
        }
        else {
            numArgs += 4097;
        }
        return numArgs;
    }
}
