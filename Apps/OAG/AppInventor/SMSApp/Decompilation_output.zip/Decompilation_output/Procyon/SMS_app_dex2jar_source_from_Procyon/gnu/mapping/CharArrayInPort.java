// 
// Decompiled by Procyon v0.5.36
// 

package gnu.mapping;

import gnu.lists.CharSeq;
import gnu.lists.FString;
import java.io.IOException;
import java.io.Reader;
import gnu.text.NullReader;
import gnu.text.Path;

public class CharArrayInPort extends InPort
{
    static final Path stringPath;
    
    static {
        stringPath = Path.valueOf("<string>");
    }
    
    public CharArrayInPort(final String s) {
        this(s.toCharArray());
    }
    
    public CharArrayInPort(final char[] array) {
        this(array, array.length);
    }
    
    public CharArrayInPort(final char[] buffer, final int limit) {
        super(NullReader.nullReader, CharArrayInPort.stringPath);
        try {
            this.setBuffer(buffer);
            this.limit = limit;
        }
        catch (IOException ex) {
            throw new Error(ex.toString());
        }
    }
    
    public CharArrayInPort make(final CharSequence charSequence) {
        CharArrayInPort charArrayInPort;
        if (charSequence instanceof FString) {
            final FString fString = (FString)charSequence;
            charArrayInPort = new CharArrayInPort(fString.data, fString.size);
        }
        else {
            final int length = charSequence.length();
            final char[] dst = new char[length];
            if (charSequence instanceof String) {
                ((String)charSequence).getChars(0, length, dst, 0);
            }
            else if (!(charSequence instanceof CharSeq)) {
                int n = length;
                while (--n >= 0) {
                    dst[n] = charSequence.charAt(n);
                }
            }
            else {
                ((CharSeq)charSequence).getChars(0, length, dst, 0);
            }
            charArrayInPort = new CharArrayInPort(dst, length);
        }
        return charArrayInPort;
    }
    
    @Override
    public int read() throws IOException {
        int read;
        if (this.pos >= this.limit) {
            read = -1;
        }
        else {
            read = super.read();
        }
        return read;
    }
}
