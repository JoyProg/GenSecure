// 
// Decompiled by Procyon v0.5.36
// 

package gnu.mapping;

public class Setter0 extends Setter
{
    public Setter0(final Procedure procedure) {
        super(procedure);
    }
    
    @Override
    public Object apply1(final Object o) throws Throwable {
        this.getter.set0(o);
        return Values.empty;
    }
    
    @Override
    public Object applyN(final Object[] array) throws Throwable {
        final int length = array.length;
        if (length != 1) {
            throw new WrongArguments(this, length);
        }
        this.getter.set0(array[0]);
        return Values.empty;
    }
    
    @Override
    public int numArgs() {
        return 4097;
    }
}
