// 
// Decompiled by Procyon v0.5.36
// 

package androidx.versionedparcelable;

public final class R
{
}
