// 
// Decompiled by Procyon v0.5.36
// 

package gnu.mapping;

import java.io.IOException;
import java.io.Reader;
import gnu.text.Path;
import java.io.InputStream;

public class TtyInPort extends InPort
{
    protected boolean promptEmitted;
    protected Procedure prompter;
    protected OutPort tie;
    
    public TtyInPort(final InputStream inputStream, final Path path, final OutPort tie) {
        super(inputStream, path);
        this.setConvertCR(true);
        this.tie = tie;
    }
    
    public TtyInPort(final Reader reader, final Path path, final OutPort tie) {
        super(reader, path);
        this.setConvertCR(true);
        this.tie = tie;
    }
    
    public void emitPrompt(final String s) throws IOException {
        this.tie.print(s);
        this.tie.flush();
        this.tie.clearBuffer();
    }
    
    @Override
    public int fill(int read) throws IOException {
        read = this.in.read(this.buffer, this.pos, read);
        if (this.tie != null && read > 0) {
            this.tie.echo(this.buffer, this.pos, read);
        }
        return read;
    }
    
    public Procedure getPrompter() {
        return this.prompter;
    }
    
    @Override
    public void lineStart(final boolean b) throws IOException {
        if (b) {
            return;
        }
        if (this.tie != null) {
            this.tie.freshLine();
        }
        if (this.prompter == null) {
            return;
        }
        try {
            final Object apply1 = this.prompter.apply1(this);
            if (apply1 != null) {
                final String string = apply1.toString();
                if (string != null && string.length() > 0) {
                    this.emitPrompt(string);
                    this.promptEmitted = true;
                }
            }
        }
        catch (Throwable obj) {
            throw new IOException("Error when evaluating prompt:" + obj);
        }
    }
    
    @Override
    public int read() throws IOException {
        if (this.tie != null) {
            this.tie.flush();
        }
        final int read = super.read();
        if (read < 0) {
            final boolean promptEmitted = this.promptEmitted;
            boolean b;
            if (this.tie != null) {
                b = true;
            }
            else {
                b = false;
            }
            if (b & promptEmitted) {
                this.tie.println();
            }
        }
        this.promptEmitted = false;
        return read;
    }
    
    @Override
    public int read(final char[] array, int n, int read) throws IOException {
        if (this.tie != null) {
            this.tie.flush();
        }
        read = super.read(array, n, read);
        if (read < 0) {
            final boolean promptEmitted = this.promptEmitted;
            if (this.tie != null) {
                n = 1;
            }
            else {
                n = 0;
            }
            if ((n & (promptEmitted ? 1 : 0)) != 0x0) {
                this.tie.println();
            }
        }
        this.promptEmitted = false;
        return read;
    }
    
    public void setPrompter(final Procedure prompter) {
        this.prompter = prompter;
    }
}
