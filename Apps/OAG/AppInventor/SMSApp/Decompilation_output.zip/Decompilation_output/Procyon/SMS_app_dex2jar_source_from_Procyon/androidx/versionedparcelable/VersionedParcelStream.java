// 
// Decompiled by Procyon v0.5.36
// 

package androidx.versionedparcelable;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import android.os.IInterface;
import java.util.Iterator;
import java.util.Set;
import android.os.IBinder;
import java.io.IOException;
import android.os.Parcelable;
import android.os.Bundle;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.DataOutputStream;
import java.io.DataInputStream;
import android.util.SparseArray;
import java.nio.charset.Charset;
import androidx.annotation.RestrictTo;

@RestrictTo({ RestrictTo.Scope.LIBRARY })
class VersionedParcelStream extends VersionedParcel
{
    private static final int TYPE_BOOLEAN = 5;
    private static final int TYPE_BOOLEAN_ARRAY = 6;
    private static final int TYPE_DOUBLE = 7;
    private static final int TYPE_DOUBLE_ARRAY = 8;
    private static final int TYPE_FLOAT = 13;
    private static final int TYPE_FLOAT_ARRAY = 14;
    private static final int TYPE_INT = 9;
    private static final int TYPE_INT_ARRAY = 10;
    private static final int TYPE_LONG = 11;
    private static final int TYPE_LONG_ARRAY = 12;
    private static final int TYPE_NULL = 0;
    private static final int TYPE_STRING = 3;
    private static final int TYPE_STRING_ARRAY = 4;
    private static final int TYPE_SUB_BUNDLE = 1;
    private static final int TYPE_SUB_PERSISTABLE_BUNDLE = 2;
    private static final Charset UTF_16;
    private final SparseArray<InputBuffer> mCachedFields;
    private DataInputStream mCurrentInput;
    private DataOutputStream mCurrentOutput;
    private FieldBuffer mFieldBuffer;
    private boolean mIgnoreParcelables;
    private final DataInputStream mMasterInput;
    private final DataOutputStream mMasterOutput;
    
    static {
        UTF_16 = Charset.forName("UTF-16");
    }
    
    public VersionedParcelStream(final InputStream in, final OutputStream out) {
        final DataOutputStream dataOutputStream = null;
        this.mCachedFields = (SparseArray<InputBuffer>)new SparseArray();
        DataInputStream mMasterInput;
        if (in != null) {
            mMasterInput = new DataInputStream(in);
        }
        else {
            mMasterInput = null;
        }
        this.mMasterInput = mMasterInput;
        DataOutputStream mMasterOutput = dataOutputStream;
        if (out != null) {
            mMasterOutput = new DataOutputStream(out);
        }
        this.mMasterOutput = mMasterOutput;
        this.mCurrentInput = this.mMasterInput;
        this.mCurrentOutput = this.mMasterOutput;
    }
    
    private void readObject(final int i, final String s, final Bundle bundle) {
        switch (i) {
            default: {
                throw new RuntimeException("Unknown type " + i);
            }
            case 0: {
                bundle.putParcelable(s, (Parcelable)null);
                break;
            }
            case 1: {
                bundle.putBundle(s, this.readBundle());
                break;
            }
            case 2: {
                bundle.putBundle(s, this.readBundle());
                break;
            }
            case 3: {
                bundle.putString(s, this.readString());
                break;
            }
            case 4: {
                bundle.putStringArray(s, (String[])this.readArray(new String[0]));
                break;
            }
            case 5: {
                bundle.putBoolean(s, this.readBoolean());
                break;
            }
            case 6: {
                bundle.putBooleanArray(s, this.readBooleanArray());
                break;
            }
            case 7: {
                bundle.putDouble(s, this.readDouble());
                break;
            }
            case 8: {
                bundle.putDoubleArray(s, this.readDoubleArray());
                break;
            }
            case 9: {
                bundle.putInt(s, this.readInt());
                break;
            }
            case 10: {
                bundle.putIntArray(s, this.readIntArray());
                break;
            }
            case 11: {
                bundle.putLong(s, this.readLong());
                break;
            }
            case 12: {
                bundle.putLongArray(s, this.readLongArray());
                break;
            }
            case 13: {
                bundle.putFloat(s, this.readFloat());
                break;
            }
            case 14: {
                bundle.putFloatArray(s, this.readFloatArray());
                break;
            }
        }
    }
    
    private void writeObject(final Object o) {
        if (o == null) {
            this.writeInt(0);
        }
        else if (o instanceof Bundle) {
            this.writeInt(1);
            this.writeBundle((Bundle)o);
        }
        else if (o instanceof String) {
            this.writeInt(3);
            this.writeString((String)o);
        }
        else if (o instanceof String[]) {
            this.writeInt(4);
            this.writeArray((String[])o);
        }
        else if (o instanceof Boolean) {
            this.writeInt(5);
            this.writeBoolean((boolean)o);
        }
        else if (o instanceof boolean[]) {
            this.writeInt(6);
            this.writeBooleanArray((boolean[])o);
        }
        else if (o instanceof Double) {
            this.writeInt(7);
            this.writeDouble((double)o);
        }
        else if (o instanceof double[]) {
            this.writeInt(8);
            this.writeDoubleArray((double[])o);
        }
        else if (o instanceof Integer) {
            this.writeInt(9);
            this.writeInt((int)o);
        }
        else if (o instanceof int[]) {
            this.writeInt(10);
            this.writeIntArray((int[])o);
        }
        else if (o instanceof Long) {
            this.writeInt(11);
            this.writeLong((long)o);
        }
        else if (o instanceof long[]) {
            this.writeInt(12);
            this.writeLongArray((long[])o);
        }
        else if (o instanceof Float) {
            this.writeInt(13);
            this.writeFloat((float)o);
        }
        else {
            if (!(o instanceof float[])) {
                throw new IllegalArgumentException("Unsupported type " + o.getClass());
            }
            this.writeInt(14);
            this.writeFloatArray((float[])o);
        }
    }
    
    public void closeField() {
        if (this.mFieldBuffer == null) {
            return;
        }
        try {
            if (this.mFieldBuffer.mOutput.size() != 0) {
                this.mFieldBuffer.flushField();
            }
            this.mFieldBuffer = null;
        }
        catch (IOException ex) {
            throw new ParcelException(ex);
        }
    }
    
    @Override
    protected VersionedParcel createSubParcel() {
        return new VersionedParcelStream(this.mCurrentInput, this.mCurrentOutput);
    }
    
    @Override
    public boolean isStream() {
        return true;
    }
    
    public boolean readBoolean() {
        try {
            return this.mCurrentInput.readBoolean();
        }
        catch (IOException ex) {
            throw new ParcelException(ex);
        }
    }
    
    public Bundle readBundle() {
        final int int1 = this.readInt();
        Bundle bundle;
        if (int1 < 0) {
            bundle = null;
        }
        else {
            final Bundle bundle2 = new Bundle();
            int n = 0;
            while (true) {
                bundle = bundle2;
                if (n >= int1) {
                    break;
                }
                this.readObject(this.readInt(), this.readString(), bundle2);
                ++n;
            }
        }
        return bundle;
    }
    
    public byte[] readByteArray() {
        try {
            final int int1 = this.mCurrentInput.readInt();
            byte[] b;
            if (int1 > 0) {
                b = new byte[int1];
                this.mCurrentInput.readFully(b);
            }
            else {
                b = null;
            }
            return b;
        }
        catch (IOException ex) {
            throw new ParcelException(ex);
        }
    }
    
    public double readDouble() {
        try {
            return this.mCurrentInput.readDouble();
        }
        catch (IOException ex) {
            throw new ParcelException(ex);
        }
    }
    
    public boolean readField(final int p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: istore_2       
        //     2: aload_0        
        //     3: getfield        androidx/versionedparcelable/VersionedParcelStream.mCachedFields:Landroid/util/SparseArray;
        //     6: iload_1        
        //     7: invokevirtual   android/util/SparseArray.get:(I)Ljava/lang/Object;
        //    10: checkcast       Landroidx/versionedparcelable/VersionedParcelStream$InputBuffer;
        //    13: astore_3       
        //    14: aload_3        
        //    15: ifnull          138
        //    18: aload_0        
        //    19: getfield        androidx/versionedparcelable/VersionedParcelStream.mCachedFields:Landroid/util/SparseArray;
        //    22: iload_1        
        //    23: invokevirtual   android/util/SparseArray.remove:(I)V
        //    26: aload_0        
        //    27: aload_3        
        //    28: getfield        androidx/versionedparcelable/VersionedParcelStream$InputBuffer.mInputStream:Ljava/io/DataInputStream;
        //    31: putfield        androidx/versionedparcelable/VersionedParcelStream.mCurrentInput:Ljava/io/DataInputStream;
        //    34: iload_2        
        //    35: ireturn        
        //    36: aload_0        
        //    37: getfield        androidx/versionedparcelable/VersionedParcelStream.mCachedFields:Landroid/util/SparseArray;
        //    40: aload_3        
        //    41: getfield        androidx/versionedparcelable/VersionedParcelStream$InputBuffer.mFieldId:I
        //    44: aload_3        
        //    45: invokevirtual   android/util/SparseArray.put:(ILjava/lang/Object;)V
        //    48: aload_0        
        //    49: getfield        androidx/versionedparcelable/VersionedParcelStream.mMasterInput:Ljava/io/DataInputStream;
        //    52: invokevirtual   java/io/DataInputStream.readInt:()I
        //    55: istore          4
        //    57: iload           4
        //    59: ldc_w           65535
        //    62: iand           
        //    63: istore          5
        //    65: iload           5
        //    67: istore          6
        //    69: iload           5
        //    71: ldc_w           65535
        //    74: if_icmpne       86
        //    77: aload_0        
        //    78: getfield        androidx/versionedparcelable/VersionedParcelStream.mMasterInput:Ljava/io/DataInputStream;
        //    81: invokevirtual   java/io/DataInputStream.readInt:()I
        //    84: istore          6
        //    86: new             Landroidx/versionedparcelable/VersionedParcelStream$InputBuffer;
        //    89: astore_3       
        //    90: aload_3        
        //    91: iload           4
        //    93: bipush          16
        //    95: ishr           
        //    96: ldc_w           65535
        //    99: iand           
        //   100: iload           6
        //   102: aload_0        
        //   103: getfield        androidx/versionedparcelable/VersionedParcelStream.mMasterInput:Ljava/io/DataInputStream;
        //   106: invokespecial   androidx/versionedparcelable/VersionedParcelStream$InputBuffer.<init>:(IILjava/io/DataInputStream;)V
        //   109: aload_3        
        //   110: getfield        androidx/versionedparcelable/VersionedParcelStream$InputBuffer.mFieldId:I
        //   113: iload_1        
        //   114: if_icmpne       36
        //   117: aload_0        
        //   118: aload_3        
        //   119: getfield        androidx/versionedparcelable/VersionedParcelStream$InputBuffer.mInputStream:Ljava/io/DataInputStream;
        //   122: putfield        androidx/versionedparcelable/VersionedParcelStream.mCurrentInput:Ljava/io/DataInputStream;
        //   125: goto            34
        //   128: astore_3       
        //   129: iconst_0       
        //   130: istore_2       
        //   131: goto            34
        //   134: astore_3       
        //   135: goto            129
        //   138: goto            48
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  36     48     128    129    Ljava/io/IOException;
        //  48     57     134    138    Ljava/io/IOException;
        //  77     86     134    138    Ljava/io/IOException;
        //  86     109    134    138    Ljava/io/IOException;
        //  109    125    128    129    Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0048:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public float readFloat() {
        try {
            return this.mCurrentInput.readFloat();
        }
        catch (IOException ex) {
            throw new ParcelException(ex);
        }
    }
    
    public int readInt() {
        try {
            return this.mCurrentInput.readInt();
        }
        catch (IOException ex) {
            throw new ParcelException(ex);
        }
    }
    
    public long readLong() {
        try {
            return this.mCurrentInput.readLong();
        }
        catch (IOException ex) {
            throw new ParcelException(ex);
        }
    }
    
    public <T extends Parcelable> T readParcelable() {
        return null;
    }
    
    public String readString() {
        try {
            final int int1 = this.mCurrentInput.readInt();
            String s;
            if (int1 > 0) {
                final byte[] array = new byte[int1];
                this.mCurrentInput.readFully(array);
                s = new String(array, VersionedParcelStream.UTF_16);
            }
            else {
                s = null;
            }
            return s;
        }
        catch (IOException ex) {
            throw new ParcelException(ex);
        }
    }
    
    public IBinder readStrongBinder() {
        return null;
    }
    
    public void setOutputField(final int n) {
        this.closeField();
        this.mFieldBuffer = new FieldBuffer(n, this.mMasterOutput);
        this.mCurrentOutput = this.mFieldBuffer.mDataStream;
    }
    
    @Override
    public void setSerializationFlags(final boolean b, final boolean mIgnoreParcelables) {
        if (!b) {
            throw new RuntimeException("Serialization of this object is not allowed");
        }
        this.mIgnoreParcelables = mIgnoreParcelables;
    }
    
    public void writeBoolean(final boolean v) {
        try {
            this.mCurrentOutput.writeBoolean(v);
        }
        catch (IOException ex) {
            throw new ParcelException(ex);
        }
    }
    
    public void writeBundle(final Bundle bundle) {
        if (bundle != null) {
            try {
                final Set keySet = bundle.keySet();
                this.mCurrentOutput.writeInt(keySet.size());
                for (final String s : keySet) {
                    this.writeString(s);
                    this.writeObject(bundle.get(s));
                }
                return;
            }
            catch (IOException ex) {
                throw new ParcelException(ex);
            }
        }
        this.mCurrentOutput.writeInt(-1);
    }
    
    public void writeByteArray(final byte[] b) {
        Label_0022: {
            if (b == null) {
                break Label_0022;
            }
            try {
                this.mCurrentOutput.writeInt(b.length);
                this.mCurrentOutput.write(b);
                return;
                this.mCurrentOutput.writeInt(-1);
            }
            catch (IOException ex) {
                throw new ParcelException(ex);
            }
        }
    }
    
    public void writeByteArray(final byte[] b, final int off, final int n) {
        Label_0023: {
            if (b == null) {
                break Label_0023;
            }
            try {
                this.mCurrentOutput.writeInt(n);
                this.mCurrentOutput.write(b, off, n);
                return;
                this.mCurrentOutput.writeInt(-1);
            }
            catch (IOException ex) {
                throw new ParcelException(ex);
            }
        }
    }
    
    public void writeDouble(final double v) {
        try {
            this.mCurrentOutput.writeDouble(v);
        }
        catch (IOException ex) {
            throw new ParcelException(ex);
        }
    }
    
    public void writeFloat(final float v) {
        try {
            this.mCurrentOutput.writeFloat(v);
        }
        catch (IOException ex) {
            throw new ParcelException(ex);
        }
    }
    
    public void writeInt(final int v) {
        try {
            this.mCurrentOutput.writeInt(v);
        }
        catch (IOException ex) {
            throw new ParcelException(ex);
        }
    }
    
    public void writeLong(final long v) {
        try {
            this.mCurrentOutput.writeLong(v);
        }
        catch (IOException ex) {
            throw new ParcelException(ex);
        }
    }
    
    public void writeParcelable(final Parcelable parcelable) {
        if (!this.mIgnoreParcelables) {
            throw new RuntimeException("Parcelables cannot be written to an OutputStream");
        }
    }
    
    public void writeString(final String s) {
        Label_0030: {
            if (s == null) {
                break Label_0030;
            }
            try {
                final byte[] bytes = s.getBytes(VersionedParcelStream.UTF_16);
                this.mCurrentOutput.writeInt(bytes.length);
                this.mCurrentOutput.write(bytes);
                return;
                this.mCurrentOutput.writeInt(-1);
            }
            catch (IOException ex) {
                throw new ParcelException(ex);
            }
        }
    }
    
    public void writeStrongBinder(final IBinder binder) {
        if (!this.mIgnoreParcelables) {
            throw new RuntimeException("Binders cannot be written to an OutputStream");
        }
    }
    
    public void writeStrongInterface(final IInterface interface1) {
        if (!this.mIgnoreParcelables) {
            throw new RuntimeException("Binders cannot be written to an OutputStream");
        }
    }
    
    private static class FieldBuffer
    {
        final DataOutputStream mDataStream;
        private final int mFieldId;
        final ByteArrayOutputStream mOutput;
        private final DataOutputStream mTarget;
        
        FieldBuffer(final int mFieldId, final DataOutputStream mTarget) {
            this.mOutput = new ByteArrayOutputStream();
            this.mDataStream = new DataOutputStream(this.mOutput);
            this.mFieldId = mFieldId;
            this.mTarget = mTarget;
        }
        
        void flushField() throws IOException {
            this.mDataStream.flush();
            final int size = this.mOutput.size();
            final int mFieldId = this.mFieldId;
            int n;
            if (size >= 65535) {
                n = 65535;
            }
            else {
                n = size;
            }
            this.mTarget.writeInt(mFieldId << 16 | n);
            if (size >= 65535) {
                this.mTarget.writeInt(size);
            }
            this.mOutput.writeTo(this.mTarget);
        }
    }
    
    private static class InputBuffer
    {
        final int mFieldId;
        final DataInputStream mInputStream;
        private final int mSize;
        
        InputBuffer(final int mFieldId, final int mSize, final DataInputStream dataInputStream) throws IOException {
            this.mSize = mSize;
            this.mFieldId = mFieldId;
            final byte[] array = new byte[this.mSize];
            dataInputStream.readFully(array);
            this.mInputStream = new DataInputStream(new ByteArrayInputStream(array));
        }
    }
}
