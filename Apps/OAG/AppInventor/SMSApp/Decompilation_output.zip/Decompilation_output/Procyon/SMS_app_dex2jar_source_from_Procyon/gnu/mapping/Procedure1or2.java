// 
// Decompiled by Procyon v0.5.36
// 

package gnu.mapping;

public abstract class Procedure1or2 extends Procedure
{
    public Procedure1or2() {
    }
    
    public Procedure1or2(final String s) {
        super(s);
    }
    
    @Override
    public Object apply0() {
        throw new WrongArguments(this, 0);
    }
    
    @Override
    public abstract Object apply1(final Object p0) throws Throwable;
    
    @Override
    public abstract Object apply2(final Object p0, final Object p1) throws Throwable;
    
    @Override
    public Object apply3(final Object o, final Object o2, final Object o3) {
        throw new WrongArguments(this, 3);
    }
    
    @Override
    public Object apply4(final Object o, final Object o2, final Object o3, final Object o4) {
        throw new WrongArguments(this, 4);
    }
    
    @Override
    public Object applyN(final Object[] array) throws Throwable {
        Object o;
        if (array.length == 1) {
            o = this.apply1(array[0]);
        }
        else {
            if (array.length != 2) {
                throw new WrongArguments(this, array.length);
            }
            o = this.apply2(array[0], array[1]);
        }
        return o;
    }
    
    @Override
    public int numArgs() {
        return 8193;
    }
}
