// 
// Decompiled by Procyon v0.5.36
// 

package androidx.cursoradapter;

public final class R
{
}
