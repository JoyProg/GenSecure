// 
// Decompiled by Procyon v0.5.36
// 

package gnu.mapping;

import java.lang.ref.WeakReference;

class SymbolRef extends WeakReference
{
    SymbolRef next;
    
    SymbolRef(final Symbol referent, final Namespace namespace) {
        super(referent);
    }
    
    Symbol getSymbol() {
        return this.get();
    }
    
    @Override
    public String toString() {
        return "SymbolRef[" + this.getSymbol() + "]";
    }
}
