// 
// Decompiled by Procyon v0.5.36
// 

package gnu.mapping;

import gnu.bytecode.Type;
import gnu.expr.Expression;

public abstract class Procedure extends PropertySet
{
    public static final LazyPropertyKey<?> compilerKey;
    private static final Symbol setterKey;
    private static final String sourceLocationKey = "source-location";
    public static final Symbol validateApplyKey;
    
    static {
        setterKey = Namespace.EmptyNamespace.getSymbol("setter");
        validateApplyKey = Namespace.EmptyNamespace.getSymbol("validate-apply");
        compilerKey = new LazyPropertyKey<Object>("compiler");
    }
    
    public Procedure() {
    }
    
    public Procedure(final String name) {
        this.setName(name);
    }
    
    public static void apply(final Procedure procedure, final CallContext callContext) throws Throwable {
        final int count = callContext.count;
        Object o = null;
        if (callContext.where == 0 && count != 0) {
            o = procedure.applyN(callContext.values);
        }
        else {
            switch (count) {
                default: {
                    o = procedure.applyN(callContext.getArgs());
                    break;
                }
                case 0: {
                    o = procedure.apply0();
                    break;
                }
                case 1: {
                    o = procedure.apply1(callContext.getNextArg());
                    break;
                }
                case 2: {
                    o = procedure.apply2(callContext.getNextArg(), callContext.getNextArg());
                    break;
                }
                case 3: {
                    o = procedure.apply3(callContext.getNextArg(), callContext.getNextArg(), callContext.getNextArg());
                    break;
                }
                case 4: {
                    o = procedure.apply4(callContext.getNextArg(), callContext.getNextArg(), callContext.getNextArg(), callContext.getNextArg());
                    break;
                }
            }
        }
        callContext.writeValue(o);
    }
    
    public static void checkArgCount(final Procedure procedure, final int n) {
        final int numArgs = procedure.numArgs();
        if (n < minArgs(numArgs) || (numArgs >= 0 && n > maxArgs(numArgs))) {
            throw new WrongArguments(procedure, n);
        }
    }
    
    public static int maxArgs(final int n) {
        return n >> 12;
    }
    
    public static int minArgs(final int n) {
        return n & 0xFFF;
    }
    
    public void apply(final CallContext callContext) throws Throwable {
        apply(this, callContext);
    }
    
    public abstract Object apply0() throws Throwable;
    
    public abstract Object apply1(final Object p0) throws Throwable;
    
    public abstract Object apply2(final Object p0, final Object p1) throws Throwable;
    
    public abstract Object apply3(final Object p0, final Object p1, final Object p2) throws Throwable;
    
    public abstract Object apply4(final Object p0, final Object p1, final Object p2, final Object p3) throws Throwable;
    
    public abstract Object applyN(final Object[] p0) throws Throwable;
    
    public void check0(final CallContext callContext) {
        final int match0 = this.match0(callContext);
        if (match0 != 0) {
            throw MethodProc.matchFailAsException(match0, this, ProcedureN.noArgs);
        }
    }
    
    public void check1(final Object o, final CallContext callContext) {
        final int match1 = this.match1(o, callContext);
        if (match1 != 0) {
            throw MethodProc.matchFailAsException(match1, this, new Object[] { o });
        }
    }
    
    public void check2(final Object o, final Object o2, final CallContext callContext) {
        final int match2 = this.match2(o, o2, callContext);
        if (match2 != 0) {
            throw MethodProc.matchFailAsException(match2, this, new Object[] { o, o2 });
        }
    }
    
    public void check3(final Object o, final Object o2, final Object o3, final CallContext callContext) {
        final int match3 = this.match3(o, o2, o3, callContext);
        if (match3 != 0) {
            throw MethodProc.matchFailAsException(match3, this, new Object[] { o, o2, o3 });
        }
    }
    
    public void check4(final Object o, final Object o2, final Object o3, final Object o4, final CallContext callContext) {
        final int match4 = this.match4(o, o2, o3, o4, callContext);
        if (match4 != 0) {
            throw MethodProc.matchFailAsException(match4, this, new Object[] { o, o2, o3, o4 });
        }
    }
    
    public void checkN(final Object[] array, final CallContext callContext) {
        final int matchN = this.matchN(array, callContext);
        if (matchN != 0) {
            throw MethodProc.matchFailAsException(matchN, this, array);
        }
    }
    
    public Type getReturnType(final Expression[] array) {
        return Type.objectType;
    }
    
    public Procedure getSetter() {
        Procedure procedure;
        if (!(this instanceof HasSetter)) {
            final Object property = this.getProperty(Procedure.setterKey, null);
            if (!(property instanceof Procedure)) {
                throw new RuntimeException("procedure '" + this.getName() + "' has no setter");
            }
            procedure = (Procedure)property;
        }
        else {
            final int numArgs = this.numArgs();
            if (numArgs == 0) {
                procedure = new Setter0(this);
            }
            else if (numArgs == 4097) {
                procedure = new Setter1(this);
            }
            else {
                procedure = new Setter(this);
            }
        }
        return procedure;
    }
    
    public String getSourceLocation() {
        String string = null;
        final Object property = this.getProperty("source-location", null);
        if (property != null) {
            string = property.toString();
        }
        return string;
    }
    
    public boolean isSideEffectFree() {
        return false;
    }
    
    public int match0(final CallContext callContext) {
        int matchN = 0;
        final int numArgs = this.numArgs();
        final int minArgs = minArgs(numArgs);
        if (minArgs > 0) {
            matchN = (0xFFF10000 | minArgs);
        }
        else if (numArgs < 0) {
            matchN = this.matchN(ProcedureN.noArgs, callContext);
        }
        else {
            callContext.count = 0;
            callContext.where = 0;
            callContext.next = 0;
            callContext.proc = this;
        }
        return matchN;
    }
    
    public int match1(final Object value1, final CallContext callContext) {
        int matchN = 0;
        final int numArgs = this.numArgs();
        final int minArgs = minArgs(numArgs);
        if (minArgs > 1) {
            matchN = (0xFFF10000 | minArgs);
        }
        else if (numArgs >= 0) {
            final int maxArgs = maxArgs(numArgs);
            if (maxArgs < 1) {
                matchN = (0xFFF20000 | maxArgs);
            }
            else {
                callContext.value1 = value1;
                callContext.count = 1;
                callContext.where = 1;
                callContext.next = 0;
                callContext.proc = this;
            }
        }
        else {
            matchN = this.matchN(new Object[] { value1 }, callContext);
        }
        return matchN;
    }
    
    public int match2(final Object value1, final Object value2, final CallContext callContext) {
        int matchN = 0;
        final int numArgs = this.numArgs();
        final int minArgs = minArgs(numArgs);
        if (minArgs > 2) {
            matchN = (0xFFF10000 | minArgs);
        }
        else if (numArgs >= 0) {
            final int maxArgs = maxArgs(numArgs);
            if (maxArgs < 2) {
                matchN = (0xFFF20000 | maxArgs);
            }
            else {
                callContext.value1 = value1;
                callContext.value2 = value2;
                callContext.count = 2;
                callContext.where = 33;
                callContext.next = 0;
                callContext.proc = this;
            }
        }
        else {
            matchN = this.matchN(new Object[] { value1, value2 }, callContext);
        }
        return matchN;
    }
    
    public int match3(final Object value1, final Object value2, final Object value3, final CallContext callContext) {
        int matchN = 0;
        final int numArgs = this.numArgs();
        final int minArgs = minArgs(numArgs);
        if (minArgs > 3) {
            matchN = (0xFFF10000 | minArgs);
        }
        else if (numArgs >= 0) {
            final int maxArgs = maxArgs(numArgs);
            if (maxArgs < 3) {
                matchN = (0xFFF20000 | maxArgs);
            }
            else {
                callContext.value1 = value1;
                callContext.value2 = value2;
                callContext.value3 = value3;
                callContext.count = 3;
                callContext.where = 801;
                callContext.next = 0;
                callContext.proc = this;
            }
        }
        else {
            matchN = this.matchN(new Object[] { value1, value2, value3 }, callContext);
        }
        return matchN;
    }
    
    public int match4(final Object value1, final Object value2, final Object value3, final Object value4, final CallContext callContext) {
        int matchN = 0;
        final int numArgs = this.numArgs();
        final int minArgs = minArgs(numArgs);
        if (minArgs > 4) {
            matchN = (0xFFF10000 | minArgs);
        }
        else if (numArgs >= 0) {
            final int maxArgs = maxArgs(numArgs);
            if (maxArgs < 4) {
                matchN = (0xFFF20000 | maxArgs);
            }
            else {
                callContext.value1 = value1;
                callContext.value2 = value2;
                callContext.value3 = value3;
                callContext.value4 = value4;
                callContext.count = 4;
                callContext.where = 17185;
                callContext.next = 0;
                callContext.proc = this;
            }
        }
        else {
            matchN = this.matchN(new Object[] { value1, value2, value3, value4 }, callContext);
        }
        return matchN;
    }
    
    public int matchN(final Object[] values, final CallContext callContext) {
        int n = 0;
        final int numArgs = this.numArgs();
        final int minArgs = minArgs(numArgs);
        if (values.length < minArgs) {
            n = (0xFFF10000 | minArgs);
        }
        else {
            if (numArgs >= 0) {
                switch (values.length) {
                    default: {
                        final int maxArgs = maxArgs(numArgs);
                        if (values.length > maxArgs) {
                            n = (0xFFF20000 | maxArgs);
                            return n;
                        }
                        break;
                    }
                    case 0: {
                        n = this.match0(callContext);
                        return n;
                    }
                    case 1: {
                        n = this.match1(values[0], callContext);
                        return n;
                    }
                    case 2: {
                        n = this.match2(values[0], values[1], callContext);
                        return n;
                    }
                    case 3: {
                        n = this.match3(values[0], values[1], values[2], callContext);
                        return n;
                    }
                    case 4: {
                        n = this.match4(values[0], values[1], values[2], values[3], callContext);
                        return n;
                    }
                }
            }
            callContext.values = values;
            callContext.count = values.length;
            callContext.where = 0;
            callContext.next = 0;
            callContext.proc = this;
        }
        return n;
    }
    
    public final int maxArgs() {
        return maxArgs(this.numArgs());
    }
    
    public final int minArgs() {
        return minArgs(this.numArgs());
    }
    
    public int numArgs() {
        return -4096;
    }
    
    public void set0(final Object o) throws Throwable {
        this.getSetter().apply1(o);
    }
    
    public void set1(final Object o, final Object o2) throws Throwable {
        this.getSetter().apply2(o, o2);
    }
    
    public void setN(final Object[] array) throws Throwable {
        this.getSetter().applyN(array);
    }
    
    public void setSetter(final Procedure procedure) {
        if (this instanceof HasSetter) {
            throw new RuntimeException("procedure '" + this.getName() + "' has builtin setter - cannot be modified");
        }
        this.setProperty(Procedure.setterKey, procedure);
    }
    
    public void setSourceLocation(final String str, final int i) {
        this.setProperty("source-location", str + ":" + i);
    }
    
    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer();
        sb.append("#<procedure ");
        String s;
        if ((s = this.getName()) == null) {
            s = this.getSourceLocation();
        }
        String name;
        if ((name = s) == null) {
            name = this.getClass().getName();
        }
        sb.append(name);
        sb.append('>');
        return sb.toString();
    }
}
